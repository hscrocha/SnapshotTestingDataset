export type ButtonAppearance = 'default' | 'primary' | 'secondary' | 'link'

export type ButtonSize = 'sm' | 'md' | 'lg'
