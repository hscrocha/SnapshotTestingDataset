export const ROUTES = {
  LOGIN: '/login',
  DASHBOARD: '/',
  FORMS: '/forms',
  DATA_FETCHING: '/data-fetching',
}
