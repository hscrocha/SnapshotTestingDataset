
export const Test = "exported constant";