# jest-image-snapshot example usage

To run the examples:
```bash
git clone https://github.com/americanexpress/jest-image-snapshot.git
cd jest-image-snapshot/examples
npm install
npm test
```