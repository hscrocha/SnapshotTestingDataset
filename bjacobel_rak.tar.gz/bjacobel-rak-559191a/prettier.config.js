module.exports = {
  singleQuote: true,
  trailingComma: 'all',
  bracketSpacing: true,
  printWidth: 120,
  arrowParens: 'avoid',
};
