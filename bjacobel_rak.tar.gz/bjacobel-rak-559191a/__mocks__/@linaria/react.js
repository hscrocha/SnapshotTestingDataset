export const styled = jest.fn(strings => () => strings);
