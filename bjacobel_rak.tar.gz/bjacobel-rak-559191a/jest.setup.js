import '@testing-library/jest-dom';

import * as config from './config';

global.projectConfig = config;
