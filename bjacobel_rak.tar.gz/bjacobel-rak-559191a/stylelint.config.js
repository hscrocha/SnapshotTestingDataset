module.exports = {
  extends: ['@linaria/stylelint-config-standard-linaria'],
  rules: {
    'string-quotes': 'single',
  },
};
