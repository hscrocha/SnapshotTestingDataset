import React from 'react';

export default () => (
  <>
    <h3 className="errorHeader">Something went wrong.</h3>
    <pre>In the real component, the stack would be rendered here.</pre>
  </>
);
