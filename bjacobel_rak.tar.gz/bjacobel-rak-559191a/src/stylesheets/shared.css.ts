export const center = {
  display: 'flex',
  justifyContent: 'center',
  alignItems: 'center',
  textAlign: 'center',
};

export const openSans = {
  fontFamily: "'Open Sans', sans-serif",
};

export const robotoMono = {
  fontFamily: "'Roboto Mono', monospace",
};
