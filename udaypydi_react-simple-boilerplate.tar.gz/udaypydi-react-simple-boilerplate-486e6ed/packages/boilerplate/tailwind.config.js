module.exports = {
  important: true,
  theme: {
    extend: {},
  },
  variants: {},
  plugins: [],
}
