
module.exports = {
    webpack(config, { dev }) {
      return config
    }
}