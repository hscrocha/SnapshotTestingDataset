---
topic: "Development"
title: "Editor Setup"
index: "0"
date: "2020-01-02"
---

Commodo irure elit cupidatat amet esse ullamco non veniam ipsum culpa sunt non occaecat dolore. Sunt culpa commodo mollit ipsum elit. Aute proident enim reprehenderit voluptate commodo aute nostrud esse mollit officia. Aliqua occaecat magna deserunt et. Sit veniam tempor aliquip do occaecat veniam consequat ipsum tempor excepteur qui irure reprehenderit reprehenderit. Duis sunt fugiat laboris duis Lorem ad ipsum.

Amet nostrud fugiat sit eu irure exercitation dolore cupidatat ea pariatur nisi est ea velit. Fugiat labore enim non elit adipisicing. Aute culpa magna quis esse cillum ea esse est.

Qui sint tempor fugiat cupidatat non anim labore amet magna. Consequat esse in dolore cillum est occaecat ullamco voluptate ea aliqua adipisicing adipisicing. Elit proident esse laboris quis minim. Eu ipsum ut minim cupidatat consequat laborum excepteur commodo occaecat minim culpa. Est nostrud ipsum eiusmod sit incididunt. Cupidatat non nostrud adipisicing dolore eu velit deserunt dolor consequat non quis velit commodo. Voluptate incididunt officia do labore ut Lorem nostrud velit dolore aliqua eu.