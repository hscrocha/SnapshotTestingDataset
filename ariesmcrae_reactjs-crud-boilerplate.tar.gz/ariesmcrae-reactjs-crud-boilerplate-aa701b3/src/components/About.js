import React from 'react';


const About = () => {
  return (
    <div className="container">
      <h1>About</h1>
      <p>Est et amet perfecto sententiae, nec error essent eripuit ei. Velit sanctus ut has, partem dolorem atomorum est ad, sumo fabellas electram ex vim.</p>
    </div>
  );
};


export default About;