describe('An end-to-end test with Cypress', () => {
  it('Can visit the main page of the application', () => {
    cy.visit('/');
  });
});
