require('./config/patch.cjs');

module.exports = {
    extends: './config/eslint.cjs',
};
