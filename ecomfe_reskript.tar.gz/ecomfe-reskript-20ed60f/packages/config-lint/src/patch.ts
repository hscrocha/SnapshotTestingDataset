import '@rushstack/eslint-patch/modern-module-resolution';

export default {};
