function Foo() {
    return createElement('div');
}

function Bar() {
    return React.createElement('div');
}
