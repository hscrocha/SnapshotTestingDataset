function Foo(x, y) {
    return <div>{x + y}</div>;
}
