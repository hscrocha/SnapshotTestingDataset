function Foo() {
    return 'foo';
}
