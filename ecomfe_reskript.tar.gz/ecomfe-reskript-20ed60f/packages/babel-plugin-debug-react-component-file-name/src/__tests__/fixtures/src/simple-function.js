function foo() {
    return 'foo';
}
