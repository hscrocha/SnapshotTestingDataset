function Bar(props) {
    return React.cloneElement(props.children);
}
