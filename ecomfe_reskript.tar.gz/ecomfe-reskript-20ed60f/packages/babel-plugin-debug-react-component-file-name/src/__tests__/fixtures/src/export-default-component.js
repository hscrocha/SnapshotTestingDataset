export default function Foo() {
    return <div />;
}
