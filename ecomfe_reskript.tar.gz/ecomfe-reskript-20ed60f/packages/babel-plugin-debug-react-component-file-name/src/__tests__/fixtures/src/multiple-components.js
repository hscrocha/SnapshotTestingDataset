function Foo() {
    return <div />;
}

function Bar() {
    return <div />;
}
