function Foo(props) {
    return cloneElement(props.children);
}

function Bar(props) {
    return React.cloneElement(props.children);
}
