export default function Foo() {
    return 'foo';
}

