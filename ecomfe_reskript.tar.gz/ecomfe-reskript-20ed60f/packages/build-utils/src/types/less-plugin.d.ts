/* eslint-disable */
declare module 'less-plugin-npm-import' {
    export default class NpmImport {
        constructor(options: any);
    }
}

declare module 'less-plugin-functions' {
    export default class LessPluginFunctions {
        constructor(options:any);
    }
}
