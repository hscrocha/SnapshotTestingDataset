import c from './style.module.css';

document.body.className = c('app');
