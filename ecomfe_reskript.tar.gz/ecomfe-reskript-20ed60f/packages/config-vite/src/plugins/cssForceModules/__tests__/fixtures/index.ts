import foo from './foo.less';
import css from './style.css';
import './app.global.less';

export default {...foo, ...css};
