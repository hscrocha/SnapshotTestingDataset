import Icon from './icon-test.svg?react';

export default Icon;
