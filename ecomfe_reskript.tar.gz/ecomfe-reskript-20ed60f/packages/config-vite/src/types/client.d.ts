/// <reference types="@reskript/settings/client" />
