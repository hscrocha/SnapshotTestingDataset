declare module 'better-opn' {
    export default function(url: string): void;
}
