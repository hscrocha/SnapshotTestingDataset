// has namespace react import
import * as React from 'react';
