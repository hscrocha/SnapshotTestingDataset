// no react import
export const add = (x, y) => x + y;
