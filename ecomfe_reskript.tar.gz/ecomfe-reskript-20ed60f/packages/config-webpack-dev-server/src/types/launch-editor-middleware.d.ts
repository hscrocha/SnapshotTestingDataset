declare module 'launch-editor-middleware' {
    import {Handler} from 'express';

    export default () => Handler;
}
