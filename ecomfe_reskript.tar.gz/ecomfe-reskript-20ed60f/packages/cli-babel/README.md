# @reskript/cli-play

可在应用开发中互动式调试单个组件。

具体文档请参考：https://reskript.dev/docs/advanced/debug-component
