const foo = () => {
    document.write('OK');
};

foo();
