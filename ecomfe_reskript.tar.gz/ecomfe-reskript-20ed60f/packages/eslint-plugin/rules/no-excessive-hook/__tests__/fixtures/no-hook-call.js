import {bar} from 'mock-use';

const useFoo = () => {
    bar();
};
