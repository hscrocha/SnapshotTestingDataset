const userInfo = {
    nmae: 'jack',
};

let auther = 'bob';

function getAuther() {
    return auther;
};
