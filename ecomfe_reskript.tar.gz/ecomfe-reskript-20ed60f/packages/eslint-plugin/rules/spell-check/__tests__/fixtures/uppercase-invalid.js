const USER_NMAE = 'jack';

const __DOCCUMENT__ = window.document;

const getDOCCUMENTEntity = () => window.document;
