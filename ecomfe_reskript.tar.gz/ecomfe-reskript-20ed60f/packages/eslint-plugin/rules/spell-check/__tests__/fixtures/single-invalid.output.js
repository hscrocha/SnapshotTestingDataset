const author = user.name;

const _name = user.name;

const article$ = createStream();

const MODEL = 'demo';
