const userInfo = {
    name: 'jack',
};

let author = 'bob';

function getAuthor() {
    return author;
};
