const userInfo = {
    nmae: 'jack',
}

userInfo.getNmae = function () {
    return this.name;
}
