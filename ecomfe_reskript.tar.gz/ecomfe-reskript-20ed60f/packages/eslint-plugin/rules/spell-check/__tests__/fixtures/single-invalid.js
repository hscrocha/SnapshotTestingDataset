const auther = user.name;

const _nmae = user.name;

const articel$ = createStream();

const MODLE = 'demo';
