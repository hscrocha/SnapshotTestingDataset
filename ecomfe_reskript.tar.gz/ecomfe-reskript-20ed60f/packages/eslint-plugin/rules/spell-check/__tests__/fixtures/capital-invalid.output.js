const getAuthorName = user => user.name;

const DocumentRequest = createDocumentRequest();

const __Document__ = window.document;
