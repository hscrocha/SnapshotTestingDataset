const getAutherNmae = user => user.name;

const DoccumentRequest = createDocumentRequest();

const __Doccument__ = window.document;
