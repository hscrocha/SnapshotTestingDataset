const USER_NAME = 'jack';

const __DOCUMENT__ = window.document;

const getDOCUMENTEntity = () => window.document;
