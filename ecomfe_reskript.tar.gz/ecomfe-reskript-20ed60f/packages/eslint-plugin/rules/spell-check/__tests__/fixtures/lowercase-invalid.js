const user_nmae = 'jack';

const _auther = 'jack';

const originallData = data;

const originallDATA = data;
