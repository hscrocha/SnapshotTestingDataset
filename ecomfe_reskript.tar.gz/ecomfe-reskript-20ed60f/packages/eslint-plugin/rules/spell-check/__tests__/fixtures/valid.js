const author = user.name;

const getUserName = user => user.name;

const path = __dirname;

const USER_NAME = 'jack';

const status = XMLHttpRequest.status;

const $ = jquery;
