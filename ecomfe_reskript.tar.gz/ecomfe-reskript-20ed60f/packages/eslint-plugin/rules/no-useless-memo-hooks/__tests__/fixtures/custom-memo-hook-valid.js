const visible = useMemoizedResult(() => {
    hideModal();
}, [hideModal]);