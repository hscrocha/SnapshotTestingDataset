const handleOpen = useCallback(() => {
    hideModal(type);
}, [hideModal, type]);