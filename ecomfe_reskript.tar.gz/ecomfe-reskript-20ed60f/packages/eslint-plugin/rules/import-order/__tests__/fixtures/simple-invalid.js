import foo from '@/foo';
import fs from 'fs';
