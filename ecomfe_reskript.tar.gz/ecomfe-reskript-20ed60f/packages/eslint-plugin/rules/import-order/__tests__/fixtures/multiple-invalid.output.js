import fs from 'fs';
import * as lodash from 'lodash';
import {createElement} from 'react';
import foo from '@/foo';
