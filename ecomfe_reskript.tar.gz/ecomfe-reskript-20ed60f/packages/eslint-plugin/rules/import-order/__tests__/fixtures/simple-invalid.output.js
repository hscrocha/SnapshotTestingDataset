import fs from 'fs';
import foo from '@/foo';
