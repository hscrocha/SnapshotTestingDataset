import * as lodash from 'lodash';
import fs from 'fs';
import foo from '@/foo';
import {createElement} from 'react';
