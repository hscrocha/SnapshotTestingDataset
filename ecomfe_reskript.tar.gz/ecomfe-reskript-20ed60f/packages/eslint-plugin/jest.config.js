module.exports = {
    testMatch: [
        '**/__tests__/**/*.test.js',
    ],
    transformIgnorePatterns: [
        '\\/dist\\/',
        'node_modules',
    ],
};
