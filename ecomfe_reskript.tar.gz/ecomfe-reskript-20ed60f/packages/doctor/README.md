# @reskript/doctor

用于检测当前目录是否符合`reSKRipt`的各项要求。

具体参考：https://reskript.dev/docs/cli/doctor

## 使用方法

```shell
npx @reskript/doctor
```
