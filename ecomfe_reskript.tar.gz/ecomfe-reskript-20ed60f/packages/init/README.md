# @reskript/init

用于在指定目录初始化一个`reSKRipt`的项目模板。

具体参考：https://reskript.dev/docs/cli/init

## 使用方法

```shell
npx @reskript/init@latest [dir]
```
