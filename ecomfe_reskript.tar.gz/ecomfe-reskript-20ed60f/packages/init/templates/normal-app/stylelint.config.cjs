module.exports = {
    extends: require.resolve('@reskript/config-lint/config/stylelint'),
};
