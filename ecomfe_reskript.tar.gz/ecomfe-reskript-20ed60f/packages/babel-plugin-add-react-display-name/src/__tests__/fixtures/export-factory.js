// export default function containing nested function component
export default function () {
    function Foo() {
        return <div />;
    }

    return Foo;
};
