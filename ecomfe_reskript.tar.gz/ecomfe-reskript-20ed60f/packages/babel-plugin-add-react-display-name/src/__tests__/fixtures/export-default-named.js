// export default named function
export default function Foo() {
    return <div />;
}
