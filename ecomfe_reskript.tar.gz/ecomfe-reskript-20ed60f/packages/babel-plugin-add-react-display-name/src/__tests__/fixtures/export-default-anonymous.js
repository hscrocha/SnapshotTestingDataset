// export default a render function
export default function () {
    return <div />;
}
