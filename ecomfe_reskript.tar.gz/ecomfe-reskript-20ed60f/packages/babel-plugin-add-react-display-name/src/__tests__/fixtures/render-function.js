// render function returns jsx
function renderFoo() {
    return <div />;
}
