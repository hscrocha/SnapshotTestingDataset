// return jsx
function Foo() {
    return <div />;
}
