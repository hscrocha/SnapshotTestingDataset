// stub settings
export default {};
