// eslint-disable-next-line
console.log('worker');
