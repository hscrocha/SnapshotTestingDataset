export const entry = {
    filename: 'foo.dist.js',
};
