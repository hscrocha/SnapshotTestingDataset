export const html = {
    meta: {
        title: 'bob',
    },
};
