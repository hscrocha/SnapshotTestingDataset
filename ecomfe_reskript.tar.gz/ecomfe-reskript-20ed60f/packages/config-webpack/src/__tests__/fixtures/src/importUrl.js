import url from './assets/icon-test.svg?url';

// eslint-disable-next-line
console.log(url);
