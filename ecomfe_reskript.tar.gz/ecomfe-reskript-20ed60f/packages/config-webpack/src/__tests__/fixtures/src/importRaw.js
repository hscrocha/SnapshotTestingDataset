import url from './assets/icon-test.svg?raw';

// eslint-disable-next-line
console.log(url);
