/* eslint-disable */
globalThis?.console?.log('hello world');
