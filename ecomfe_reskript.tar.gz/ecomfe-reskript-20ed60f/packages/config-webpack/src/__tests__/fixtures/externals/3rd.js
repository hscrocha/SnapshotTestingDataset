/* eslint-disable */
globalThis?.console?.log('3rd-party');
