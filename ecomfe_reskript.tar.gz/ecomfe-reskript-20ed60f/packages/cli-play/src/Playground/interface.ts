export type PanelType = 'source' | 'description' | 'help';
