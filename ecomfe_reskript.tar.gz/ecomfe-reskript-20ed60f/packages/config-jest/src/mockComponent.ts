export default function MockComponent() {
    return null;
}
