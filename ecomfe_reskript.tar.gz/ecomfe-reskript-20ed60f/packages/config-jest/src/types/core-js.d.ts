declare module 'core-js' {
}
