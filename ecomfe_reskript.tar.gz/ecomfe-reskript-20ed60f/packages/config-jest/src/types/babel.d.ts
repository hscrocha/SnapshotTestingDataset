declare module '@babel/plugin-transform-modules-commonjs' {
    import {PluginTarget} from '@babel/core';

    const target: PluginTarget;
    export default target;
}
