declare module 'unixify' {
    export default function(input: string): string;
}
