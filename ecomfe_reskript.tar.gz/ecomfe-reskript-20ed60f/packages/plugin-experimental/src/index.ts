export {default as buildFast} from './buildFast/index.js';
