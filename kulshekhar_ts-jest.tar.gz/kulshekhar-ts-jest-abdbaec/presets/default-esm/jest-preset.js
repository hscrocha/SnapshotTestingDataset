module.exports = require('..').defaultsESM
