const { createBundle } = require('./lib/bundle')

createBundle()
