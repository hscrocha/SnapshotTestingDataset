let num = 0;

module.exports = function inc() {
  num++;
  return num;
};
