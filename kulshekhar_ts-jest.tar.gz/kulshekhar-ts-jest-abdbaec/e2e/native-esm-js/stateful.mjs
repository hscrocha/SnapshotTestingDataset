let num = 0;

export default function inc() {
  num++;
  return num;
}
