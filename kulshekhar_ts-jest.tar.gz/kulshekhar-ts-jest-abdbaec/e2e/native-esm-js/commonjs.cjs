module.exports = function half(num) {
  return num / 2;
};
