export function double(num) {
  return num * 2
}
