module.exports.half = require('./commonjs.cjs');
