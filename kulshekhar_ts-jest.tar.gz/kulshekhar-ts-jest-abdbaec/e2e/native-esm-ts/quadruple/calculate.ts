const calculate = (x: number) => x * 4
export default calculate
