export { default as quadruple } from '@quadruple/calculate.js'
