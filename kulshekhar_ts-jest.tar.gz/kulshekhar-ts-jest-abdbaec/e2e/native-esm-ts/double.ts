export function double(num: number): number {
  return num * 2
}
