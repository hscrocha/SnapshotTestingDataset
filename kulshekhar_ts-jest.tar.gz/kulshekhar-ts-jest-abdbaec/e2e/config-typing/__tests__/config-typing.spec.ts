test('should expose TypeScript types for Jest config', () => {
  expect(true).toBe(true)
})
