module.exports = {
  projects: ['babel-enabled', 'babel-js-file', 'babel-cjs-file'],
}
