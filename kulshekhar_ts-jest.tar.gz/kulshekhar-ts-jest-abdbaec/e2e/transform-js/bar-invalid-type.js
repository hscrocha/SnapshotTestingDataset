const barInvalidType = parseFloat(3.14)

export default barInvalidType
