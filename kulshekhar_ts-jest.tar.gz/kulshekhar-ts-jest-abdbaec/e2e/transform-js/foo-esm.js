const fooESM = 'FOO-ESM!'

export { fooESM }
