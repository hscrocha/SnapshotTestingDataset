module.exports = 'BAR!'
