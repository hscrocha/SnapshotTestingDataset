const barDefault = 'BAR-DEFAULT!'

export default barDefault
