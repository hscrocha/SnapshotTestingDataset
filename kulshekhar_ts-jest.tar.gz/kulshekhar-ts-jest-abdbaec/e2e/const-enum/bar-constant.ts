export const enum BarConstEnum {
  one = 'ONE',
}
