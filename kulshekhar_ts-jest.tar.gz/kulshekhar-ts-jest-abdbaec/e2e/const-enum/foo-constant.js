var FooConstEnum
;(function (FooConstEnum) {
  FooConstEnum[(FooConstEnum['two'] = 'TWO')] = 'two'
  // eslint-disable-next-line no-unused-vars
})((FooConstEnum = exports.FooConstEnum || (exports.FooConstEnum = {})))
