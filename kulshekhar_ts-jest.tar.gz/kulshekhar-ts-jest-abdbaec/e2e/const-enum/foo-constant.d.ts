export declare const enum FooConstEnum {
  two = 'TWO',
}
