export declare const enum HooConstEnum {
  two = 'TWO',
}
