test('should fail with stacktrace', () => {
  expect(true).toBe(false)
})
