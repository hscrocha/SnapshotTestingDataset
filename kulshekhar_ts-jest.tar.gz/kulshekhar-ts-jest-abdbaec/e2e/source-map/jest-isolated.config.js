module.exports = {
  projects: ['disabled/jest-isolated.config.js', 'enabled/jest-isolated.config.js'],
}
