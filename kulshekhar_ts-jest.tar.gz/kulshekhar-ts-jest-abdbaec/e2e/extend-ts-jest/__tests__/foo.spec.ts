test('should pass', () => {
  expect(true).toBe(true)
})
