'use strict'

// This is mock that does nothing but used for coverage integration test
