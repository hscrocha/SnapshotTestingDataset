'use strict'
var FooEnum
;(function (FooEnum) {
  FooEnum[(FooEnum['two'] = 'TWO')] = 'two'
  // eslint-disable-next-line no-unused-vars
})((FooEnum = exports.FooEnum || (exports.FooEnum = {})))
