export enum BarEnum {
  one = 'ONE',
}
