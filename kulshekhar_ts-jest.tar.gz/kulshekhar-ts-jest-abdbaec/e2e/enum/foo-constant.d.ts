export declare enum FooEnum {
  two = 'TWO',
}
