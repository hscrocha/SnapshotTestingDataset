type Color = 'red' | 'blue'

export const color: Color = 'red'
