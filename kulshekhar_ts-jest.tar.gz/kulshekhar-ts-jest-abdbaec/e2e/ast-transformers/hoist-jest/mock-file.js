jest.mock('./banana', () => {
  return 'apple'
})
