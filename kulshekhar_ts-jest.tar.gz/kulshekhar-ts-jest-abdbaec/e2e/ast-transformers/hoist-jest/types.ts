export type Color = 'red' | 'blue'
