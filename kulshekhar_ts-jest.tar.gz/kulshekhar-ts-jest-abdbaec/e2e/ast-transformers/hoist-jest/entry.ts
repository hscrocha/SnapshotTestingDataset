import type { Color } from './types'

export const color: Color = 'red'
