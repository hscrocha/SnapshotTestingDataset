export default class Mocked {
  constructor() {
    this.isMocked = true
  }
}
