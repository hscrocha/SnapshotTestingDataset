module.exports = {
  name: 'backticks-with-jest',
}
