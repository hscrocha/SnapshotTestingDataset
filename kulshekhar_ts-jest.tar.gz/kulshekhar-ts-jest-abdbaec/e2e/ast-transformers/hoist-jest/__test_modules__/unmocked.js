export default class Unmocked {
  constructor() {
    this.isUnmocked = true
  }
}
