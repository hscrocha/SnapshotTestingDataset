export type Thing = { a: number; b: number }
