const welcomePerson = 'Welcome to ts-jest!!!'

export default welcomePerson
