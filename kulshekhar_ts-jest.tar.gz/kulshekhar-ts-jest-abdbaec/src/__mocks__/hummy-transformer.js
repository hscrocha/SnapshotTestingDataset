function factory() {
  return () => {
    return (sf) => {
      return sf
    }
  }
}

module.exports = {
  factory,
}
