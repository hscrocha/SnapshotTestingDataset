export const version = '1.2.3-test.0'
export const digest = 'a0d51ca854194df8191d0e65c0ca4730f510f332'
export const createTransformer = jest.fn()
export const jestPreset = { jestPreset: true }
export const createJestPreset = jest.fn()
export const pathsToModuleNameMapper = jest.fn()
