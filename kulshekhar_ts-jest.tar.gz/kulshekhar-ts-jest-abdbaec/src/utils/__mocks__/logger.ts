import { testing } from 'bs-logger'

export const rootLogger = testing.createLoggerMock()
