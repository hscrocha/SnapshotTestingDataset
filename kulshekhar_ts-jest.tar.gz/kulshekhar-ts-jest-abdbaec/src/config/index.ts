export * from './paths-to-module-name-mapper'
