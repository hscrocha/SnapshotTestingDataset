---
id: esm-support
title: ESM Support
---

:::important

ESM support is only available in **v27++**

:::
