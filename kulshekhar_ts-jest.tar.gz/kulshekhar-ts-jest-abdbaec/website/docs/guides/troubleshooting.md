---
id: troubleshooting
title: Troubleshooting
---

You can check Jest [troubleshooting guide](https://jestjs.io/docs/en/troubleshooting) or visit `ts-jest` [troubleshooting
guide](https://github.com/kulshekhar/ts-jest/blob/main/TROUBLESHOOTING.md)
