import React from 'react';

import { Container } from './styles';

const FilterButtons: React.FC = () => {
  console.log('hello world');
  return (
    <Container>
      <h2>hello world</h2>

    </Container>
  );
};

export default FilterButtons;
