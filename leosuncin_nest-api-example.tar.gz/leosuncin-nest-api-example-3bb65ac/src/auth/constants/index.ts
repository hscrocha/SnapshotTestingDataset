export const JWT_STRATEGY_NAME = 'jwt';

export const TOKEN_COOKIE_NAME = 'token';
