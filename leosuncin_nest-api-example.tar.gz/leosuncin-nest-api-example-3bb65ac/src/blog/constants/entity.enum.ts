export const ENTITY_METADATA_KEY = 'entity' as const;

export enum Entities {
  ARTICLE = 'article',
  COMMENT = 'comment',
}
