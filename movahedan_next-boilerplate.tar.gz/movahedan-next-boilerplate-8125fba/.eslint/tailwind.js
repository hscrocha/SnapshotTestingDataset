const tailwindPlugin = {
	extends: ['plugin:tailwind/recommended'],
};

module.exports = tailwindPlugin;
