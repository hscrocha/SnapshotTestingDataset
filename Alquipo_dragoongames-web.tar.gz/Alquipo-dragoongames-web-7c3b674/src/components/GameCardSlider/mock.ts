export default [
  {
    id: '1',
    title: 'Population Zero',
    slug: 'population-zero',
    developer: 'Rockstar Games',
    img: 'https://source.unsplash.com/collection/4757197/301x140',
    price: 235,
    promotionalPrice: 215
  },
  {
    id: '2',
    title: 'Population Zero',
    slug: 'population-zero',
    developer: 'Rockstar Games',
    img: 'https://source.unsplash.com/collection/4757197/301x140',
    price: 235,
    promotionalPrice: 215
  },
  {
    id: '3',
    title: 'Population Zero',
    slug: 'population-zero',
    developer: 'Rockstar Games',
    img: 'https://source.unsplash.com/collection/4757197/301x140',
    price: 235,
    promotionalPrice: 215
  },
  {
    id: '4',
    title: 'Population Zero',
    slug: 'population-zero',
    developer: 'Rockstar Games',
    img: 'https://source.unsplash.com/collection/4757197/301x140',
    price: 235,
    promotionalPrice: 215
  },
  {
    id: '5',
    title: 'Population Zero',
    slug: 'population-zero',
    developer: 'Rockstar Games',
    img: 'https://source.unsplash.com/collection/4757197/301x140',
    price: 235,
    promotionalPrice: 215
  },
  {
    id: '6',
    title: 'Population Zero',
    slug: 'population-zero',
    developer: 'Rockstar Games',
    img: 'https://source.unsplash.com/collection/4757197/301x140',
    price: 235,
    promotionalPrice: 215
  }
]
