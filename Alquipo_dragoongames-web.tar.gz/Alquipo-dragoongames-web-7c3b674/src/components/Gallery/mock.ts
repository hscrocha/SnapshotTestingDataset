export default [
  {
    src: 'https://source.unsplash.com/collection/4757197/1042x580',
    label: 'Gallery Image 1'
  },
  {
    src: 'https://source.unsplash.com/collection/4757197/1042x580',
    label: 'Gallery Image 2'
  },
  {
    src: 'https://source.unsplash.com/collection/4757197/1042x580',
    label: 'Gallery Image 3'
  },
  {
    src: 'https://source.unsplash.com/collection/4757197/1042x580',
    label: 'Gallery Image 4'
  },
  {
    src: 'https://source.unsplash.com/collection/4757197/1042x580',
    label: 'Gallery Image 5'
  },
  {
    src: 'https://source.unsplash.com/collection/4757197/1042x580',
    label: 'Gallery Image 6'
  }
]
