import { addons } from '@storybook/addons'
import theme from './dragoon-theme'

addons.setConfig({ theme })
