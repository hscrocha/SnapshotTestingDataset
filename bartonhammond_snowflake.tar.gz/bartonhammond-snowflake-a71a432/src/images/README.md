# Steps I followed

* Took `Snowflake.png` and used
  [http://ticons.fokkezb.nl/](http://ticons.fokkezb.nl/) to generate
  splash images.

* Followed steps here:
  [http://stackoverflow.com/questions/34027270/ios-launch-screen-in-react-native](http://stackoverflow.com/questions/34027270/ios-launch-screen-in-react-native)

* Took `Snowflake.png` and used
  [https://makeappicon.com/](https://makeappicon.com/)

* Saved `SnowflakeFromAppIcon.zip` to here

* Opened XCode Target Snowflake -> General -> App Icons Source and
  clicked -> (arrow)

* Copied each appropriate icon to prepared location

* Within iOS simulator, did Simulator -> Reset Content and Settings
