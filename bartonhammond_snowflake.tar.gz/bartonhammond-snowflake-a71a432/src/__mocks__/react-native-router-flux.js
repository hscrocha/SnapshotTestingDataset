module.exports = {
  Actions: {
    Login: function () {},
    Tabbar: function () {},
    InitialLoginForm: function () {}
  }
}
