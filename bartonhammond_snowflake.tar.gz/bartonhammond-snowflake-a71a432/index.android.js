'use strict'

import snowflake from './src/snowflake'

snowflake('android')

