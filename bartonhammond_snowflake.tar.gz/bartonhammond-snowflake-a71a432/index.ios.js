'use strict'

import snowflake from './src/snowflake'

snowflake('ios')
