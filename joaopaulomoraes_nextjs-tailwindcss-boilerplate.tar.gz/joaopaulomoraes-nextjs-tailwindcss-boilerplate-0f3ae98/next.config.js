/* eslint-disable no-undef */
module.exports = {
  images: {
    domains: ['gravatar.com']
  }
}
