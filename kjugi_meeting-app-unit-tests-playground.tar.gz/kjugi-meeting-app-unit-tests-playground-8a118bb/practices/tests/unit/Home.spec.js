import HomePage from '@/views/Home.vue'

describe('views/Home.vue', () => {
  // it('meeting list contains elements from store', () => {
  // })

  // it('render empty list message when don\'t have items', () => {
  // })
})
