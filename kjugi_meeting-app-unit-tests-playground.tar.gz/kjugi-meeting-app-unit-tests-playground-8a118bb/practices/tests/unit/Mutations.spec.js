import { mutations } from '@/store'

describe('store/mutations', () => {
  // it('addMeeting push item to state.meetingList', () => {
  // })
})
