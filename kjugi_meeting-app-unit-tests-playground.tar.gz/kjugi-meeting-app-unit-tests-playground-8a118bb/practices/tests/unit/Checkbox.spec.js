import Checkbox from '@/components/Checkbox.vue'

describe('components/Checkbox.vue', () => {
  // it('emit events when trigger change on checkbox', () => {
  // })

  // it('default component matches snapshot', () => {
  // })
})
