import { actions } from '@/store'

describe('store/actions', () => {
  // it('doReservation commits to mutation', () => {
  // })

  // it('exampleApiAction makes commit based on API response', async () => {
  // })
})
