import Message from '@/components/Message.vue'

// Check for more: https://jestjs.io/docs/en/timer-mocks
jest.useFakeTimers()
// jest.runAllTimers()

describe('components/Message.vue', () => {
  // it('renders prop title when passed', () => {
  // })

  // it('emit event when isMessageShowed updates', () => {
  // })

  // it('default component matches snapshot', () => {
  // })
})
