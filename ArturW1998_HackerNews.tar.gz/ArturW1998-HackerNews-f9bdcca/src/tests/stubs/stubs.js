export const NEWS = [
  {
    author: 'Artur',
    created_at: '2019-11-19T23:36:09.816Z',
    num_comments: 10,
    objectID: 1,
    title: 'Hacker News',
    points: 100,
    url: '//test.url',
  },
  {
    author: 'Dan',
    created_at: '2013-05-29T23:36:09.816Z',
    num_comments: 8,
    objectID: 2,
    title: 'React',
    points: 10,
    url: '//test2121.url',
  },
];
