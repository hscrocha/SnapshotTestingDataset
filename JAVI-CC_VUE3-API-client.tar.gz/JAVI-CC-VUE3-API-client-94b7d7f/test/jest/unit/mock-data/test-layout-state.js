export const layoutState = {
    dark: true
}