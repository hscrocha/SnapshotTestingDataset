import { AddressbarColor } from 'quasar'

export default () => {
  AddressbarColor.set('#000000')
}