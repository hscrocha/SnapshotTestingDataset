
export default () => ({
    juegos: [],
    juego: [],
    desarrolladoras: [],
    generos: [],
    search: null,
    page: 0,
    errorMessage: "",
    desarrolladora: null,
    genero: null,
    paginateActive: true,
    order: null,
    items: null,
    imageInitial: null,
    isLoading: true,
})