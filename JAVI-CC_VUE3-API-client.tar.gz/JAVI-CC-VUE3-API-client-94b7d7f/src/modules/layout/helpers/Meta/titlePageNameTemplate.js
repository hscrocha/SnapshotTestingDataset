const titleNameTemplate = "JAVI-CC JUEGOS API | ";

export default titleNameTemplate