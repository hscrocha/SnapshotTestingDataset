export const dark = ( state ) => {
    return state.dark
}