
export default () => ({
    dark: true,
})