export default () => ({
    logged: false,
    user: null,
})