export const logged = ( state ) => {
    return state.logged
}

export const nombre = ( state ) => {
    return state.user.name
}