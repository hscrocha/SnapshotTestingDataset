/* @flow */
import EventTags from './EventTags';
export default EventTags;
