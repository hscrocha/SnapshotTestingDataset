/* @flow */
import EventCard from './EventCard';
export default EventCard;
