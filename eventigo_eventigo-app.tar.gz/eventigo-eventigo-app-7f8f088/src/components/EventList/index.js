/* @flow */
import EventList from './EventList';
export default EventList;
