/* @flow */
import Bookmark from './Bookmark';
export default Bookmark;
