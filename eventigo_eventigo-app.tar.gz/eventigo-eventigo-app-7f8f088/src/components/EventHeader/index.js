/* @flow */
import EventHeader from './EventHeader';
export default EventHeader;
