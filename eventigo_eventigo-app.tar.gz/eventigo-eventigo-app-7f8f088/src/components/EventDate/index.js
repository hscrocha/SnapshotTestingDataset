/* @flow */
import EventDate from './EventDate';
export default EventDate;
