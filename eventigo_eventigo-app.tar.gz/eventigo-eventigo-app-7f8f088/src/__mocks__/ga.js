/* @flow */
const ga = jest.genMockFromModule('../ga');
module.exports = ga;
