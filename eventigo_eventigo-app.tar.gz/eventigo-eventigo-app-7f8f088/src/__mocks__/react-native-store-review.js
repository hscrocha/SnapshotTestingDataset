const storeReview = jest.genMockFromModule('react-native-store-review');

storeReview.isAvailable = true;

module.exports = storeReview;
