/* @flow */

import 'react-native';
import React from 'react';
import Index from '../index';

// Note: test renderer must be required after react-native.
import renderer from 'react-test-renderer';

jest.mock('../api');
jest.mock('../ga.js');

it('renders correctly', () => {
  const tree = renderer.create(<Index />);
  expect(tree).toMatchSnapshot();
});
