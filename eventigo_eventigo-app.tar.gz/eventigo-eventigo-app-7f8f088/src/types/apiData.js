/* @flow */
import type { Event } from './model';

export type EventsData = Event[];
