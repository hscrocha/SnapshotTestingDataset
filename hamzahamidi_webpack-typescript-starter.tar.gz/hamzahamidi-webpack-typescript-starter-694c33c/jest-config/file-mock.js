module.exports = {
  process() {
    return `module.exports = 'test-file-stub'`;
  },
};