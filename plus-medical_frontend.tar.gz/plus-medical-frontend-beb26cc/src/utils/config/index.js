require('dotenv').config()
const config = {
  apiUrl: process.env.REACT_APP_API_URL
}
module.exports = { config }
