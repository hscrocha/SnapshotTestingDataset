export const NAME_TOKEN = 'token'
