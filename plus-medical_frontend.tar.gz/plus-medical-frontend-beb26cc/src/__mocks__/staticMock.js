module.exports = 'file-stub'
