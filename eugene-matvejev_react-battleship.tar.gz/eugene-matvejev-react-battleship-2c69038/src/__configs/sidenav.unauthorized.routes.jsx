export default [
    {
        to: '/acc/login',
        label: 'sign in',
    },
    {
        to: '/acc/create',
        label: 'create an account',
    },
    {
        to: '/acc/restore-password/1',
        label: 'forgot password',
    },
];
