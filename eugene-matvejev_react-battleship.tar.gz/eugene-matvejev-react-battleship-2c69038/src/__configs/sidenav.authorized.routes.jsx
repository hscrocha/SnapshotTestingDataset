export default [
    {
        to: '/logout',
        label: 'log out',
    }
]
