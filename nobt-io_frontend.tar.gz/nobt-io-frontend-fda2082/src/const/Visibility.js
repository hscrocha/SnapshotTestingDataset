export default {
  VISIBLE: 'VISIBLE',
  HIDDEN: 'HIDDEN',
};
