export default {
  EQUAL: 'EQUAL',
  UNEQUAL: 'UNEQUAL',
  PERCENTAGE: 'PERCENTAGE',
};
