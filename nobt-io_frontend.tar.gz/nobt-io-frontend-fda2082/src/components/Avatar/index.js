import Avatar from './Avatar.js';

export default Avatar;
