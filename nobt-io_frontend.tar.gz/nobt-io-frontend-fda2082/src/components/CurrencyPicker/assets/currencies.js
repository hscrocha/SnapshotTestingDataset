const currencies = [
  { value: 'GBP', label: 'GBP - £' },
  { value: 'EUR', label: 'EUR - €' },
  { value: 'USD', label: 'USD - $' },
  { value: 'CHF', label: 'CHF - CHF' },
];

export default currencies;
