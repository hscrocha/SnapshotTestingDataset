import * as React from 'react';
import styles from './Box.scss';

export default ({ children }) => <div className={styles.box}>{children}</div>;
