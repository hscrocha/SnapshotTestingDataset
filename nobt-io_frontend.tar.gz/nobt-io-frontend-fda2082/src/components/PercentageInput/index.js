import PercentageInput from './PercentageInput';

export default PercentageInput;
