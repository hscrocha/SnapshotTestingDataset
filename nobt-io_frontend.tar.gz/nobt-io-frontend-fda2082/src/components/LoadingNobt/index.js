import LoadingNobt from './LoadingNobt';

export default LoadingNobt;
