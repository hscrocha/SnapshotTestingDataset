import Amount from './Amount';

export default Amount;
