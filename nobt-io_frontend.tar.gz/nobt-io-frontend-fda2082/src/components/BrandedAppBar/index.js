import BrandedAppBar from './BrandedAppBar';

export default BrandedAppBar;
