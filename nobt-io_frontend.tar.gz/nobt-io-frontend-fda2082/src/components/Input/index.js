import input from './Input';
import currencyInput from './CurrencyInput';
import inputLegend from './InputLegend';

export const Input = input;
export const CurrencyInput = currencyInput;
export const InputLegend = inputLegend;
