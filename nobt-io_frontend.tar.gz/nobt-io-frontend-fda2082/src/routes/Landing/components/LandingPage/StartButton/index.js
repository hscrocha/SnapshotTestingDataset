import StartButton from './StartButton';

export default StartButton;
