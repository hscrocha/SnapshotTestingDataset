import WizardContainer from './WizardContainer';

export default WizardContainer;
