import BasicInformationForm from './BasicInformationForm';

export default BasicInformationForm;
