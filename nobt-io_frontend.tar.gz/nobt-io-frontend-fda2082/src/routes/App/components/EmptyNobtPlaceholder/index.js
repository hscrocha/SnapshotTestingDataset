import EmptyNobtPlaceholder from './EmptyNobtPlaceholder';

export default EmptyNobtPlaceholder;
