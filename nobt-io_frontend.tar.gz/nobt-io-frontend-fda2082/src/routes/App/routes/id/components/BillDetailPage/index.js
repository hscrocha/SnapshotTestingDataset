import BillDetailPage from './BillDetailPage';

export default BillDetailPage;
