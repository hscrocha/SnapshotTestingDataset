import Api from './api';

export default Api;
