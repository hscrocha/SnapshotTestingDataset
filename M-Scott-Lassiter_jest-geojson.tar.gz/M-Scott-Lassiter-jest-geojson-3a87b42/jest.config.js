module.exports = {
    setupFilesAfterEnv: ['./src/setup/all.js']
}
