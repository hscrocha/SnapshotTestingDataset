export default {
  accept: 'Accept',
  authorization: 'Authorization',
  contentType: 'Content-Type'
};
