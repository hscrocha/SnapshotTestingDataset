export default {
  json: 'application/json'
};
