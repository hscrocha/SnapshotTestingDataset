import CountriesListContainer from '../../common/Country/CountriesListContainer';

const HomePageContainer = () => <CountriesListContainer />;

export default HomePageContainer;
