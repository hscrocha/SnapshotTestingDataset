const paths = {
  home: "/",
  login: "/login",
  register: "/register",
  userBoard: "/user-board",
  notFound: "/404",
};

export default paths;
