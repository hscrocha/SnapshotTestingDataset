export const environment = {
  production: true,
  usersApi: '/v1',
};

export const ExternalModules = [];
