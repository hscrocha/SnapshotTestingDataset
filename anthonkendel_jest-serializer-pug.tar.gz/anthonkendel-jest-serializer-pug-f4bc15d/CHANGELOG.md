## [1.6.4](https://github.com/anthonkendel/jest-serializer-pug/compare/v1.6.3...v1.6.4) (2021-12-04)


### Bug Fixes

* **deps:** npm audit fix ([f5ac62f](https://github.com/anthonkendel/jest-serializer-pug/commit/f5ac62f3c1227e03ecf02c261b5e08a400f608e0))

## [1.6.3](https://github.com/anthonkendel/jest-serializer-pug/compare/v1.6.2...v1.6.3) (2020-12-20)


### Bug Fixes

* **deps:** npm audit fix ([7320d31](https://github.com/anthonkendel/jest-serializer-pug/commit/7320d311cd98ac787ef4393d28bbb366156b63c3))

## [1.6.2](https://github.com/anthonkendel/jest-serializer-pug/compare/v1.6.1...v1.6.2) (2020-09-15)


### Bug Fixes

* **deps:** npm audit fix ([2a55f07](https://github.com/anthonkendel/jest-serializer-pug/commit/2a55f07ef62faff25e836f602962868e40d569a9))

## [1.6.1](https://github.com/anthonkendel/jest-serializer-pug/compare/v1.6.0...v1.6.1) (2020-08-03)


### Bug Fixes

* run npm audit fix ([c3163ba](https://github.com/anthonkendel/jest-serializer-pug/commit/c3163babc7a15069c9f805e37db63de9b4c648f4))

# [1.6.0](https://github.com/anthonkendel/jest-serializer-pug/compare/v1.5.0...v1.6.0) (2020-05-01)


### Features

* update README and force release ([3b70c77](https://github.com/anthonkendel/jest-serializer-pug/commit/3b70c77716eed9b2f4ed867325d57b27dfdde8d2))

# [1.5.0](https://github.com/anthonkendel/jest-serializer-pug/compare/v1.4.0...v1.5.0) (2020-05-01)


### Bug Fixes

* **deps:** pin dependency html2pug to 4.0.0 ([c2f2f5f](https://github.com/anthonkendel/jest-serializer-pug/commit/c2f2f5f0753b7d650c7b70d67d9fa3570d621efa))


### Features

* use commitlint ([0e36475](https://github.com/anthonkendel/jest-serializer-pug/commit/0e36475895a11f676d7fccda5b72a08383a1a800))
* use semantic-release ([1ed7c36](https://github.com/anthonkendel/jest-serializer-pug/commit/1ed7c367eee4d530c5d27b9d03ca66d65cb28af6))
