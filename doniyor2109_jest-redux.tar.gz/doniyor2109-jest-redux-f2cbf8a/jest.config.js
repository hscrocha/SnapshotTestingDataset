module.exports = {
  "setupTestFrameworkScriptFile": "./setupTest.js"
};