/**
 * Deploys to now.
 * @see https://zeit.co/now
 */

import { exec } from '../utils';
const cmd = 'now';
exec(cmd);
