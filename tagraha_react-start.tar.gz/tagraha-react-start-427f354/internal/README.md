# Internal

This folder contains all the files relating to tooling.  You should ___not___ reference any of these files from within your server/client code.