module.exports = '/asset/mock';
