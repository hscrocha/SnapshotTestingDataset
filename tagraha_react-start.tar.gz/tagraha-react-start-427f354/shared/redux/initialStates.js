export const postMock = {
  asyncPostExample: {
    body: '',
    id: 0,
    title: '',
    userId: 0,
  },
};

export const counterMock = {
  counterValue: 0,
};

export const errorMock = {};
