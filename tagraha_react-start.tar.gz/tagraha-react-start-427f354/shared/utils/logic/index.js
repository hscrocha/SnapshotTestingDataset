/* eslint-disable import/prefer-default-export */

import ifElse from './ifElse';

export { ifElse };
