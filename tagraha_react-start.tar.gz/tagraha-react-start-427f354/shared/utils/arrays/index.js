/* eslint-disable import/prefer-default-export */

import removeNil from './removeNil';

export { removeNil };
