## Testing Apollo Graphql

- <https://www.apollographql.com/docs/react/development-testing/testing/>
- <https://bitbucket.lmc.cz/projects/COM/repos/fp-admin/browse/src/components/Admin/>__tests__/IconEditor.test.js#3,41,43,51,53,74,76
- <https://bitbucket.lmc.cz/projects/CP/repos/capybara-snippet/browse/src/pages/>__tests__/reply.test.js#3,143,150,199,206
