## API calls

- <https://bitbucket.lmc.cz/projects/COM/repos/mdk-admin/browse/src/libs/>__tests__/makeRequest.test.ts#1,5,85
- <https://github.com/nock/nock>
