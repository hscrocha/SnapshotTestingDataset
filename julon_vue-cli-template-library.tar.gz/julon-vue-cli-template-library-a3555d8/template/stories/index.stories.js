import { storiesOf } from "@storybook/vue";

// Add more stories here to live develop your components
storiesOf("HelloWorld", module).add("story as a template", () => ({
  template: `<hello-world></hello-world>`
}));
