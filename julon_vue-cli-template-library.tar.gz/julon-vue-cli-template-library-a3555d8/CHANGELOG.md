<a name="1.2.2"></a>
## [1.2.2](https://github.com/julon/vue-cli-template-library/compare/v1.2.1...v1.2.2) (2018-03-10)


### Bug Fixes

* add release.config.js ([e2af552](https://github.com/julon/vue-cli-template-library/commit/e2af552))

<a name="1.2.1"></a>
## [1.2.1](https://github.com/julon/vue-cli-template-library/compare/6a11b7671e6a07a4d366cc67da987aab790b7c94...v1.2.1) (2018-01-19)


### Bug Fixes

* add dependencies property test ([47a2ef1](https://github.com/julon/vue-cli-template-library/commit/47a2ef1))
* replace globals func by assign to merge obj ([f7c316f](https://github.com/julon/vue-cli-template-library/commit/f7c316f))

<a name="1.2.0"></a>
# [1.2.0](https://github.com/julon/vue-cli-template-library/compare/e24dbfe0b5a1876dc89f9f06839896d59eb84310...v1.2.0) (2018-01-19)


### Bug Fixes

* using npm instead of yarn in scripts ([6a11b76](https://github.com/julon/vue-cli-template-library/commit/6a11b76))


### Features

* **build:** add globals and externals ([586aa9a](https://github.com/julon/vue-cli-template-library/commit/586aa9a))

<a name="1.1.7"></a>
## [1.1.7](https://github.com/julon/vue-cli-template-library/compare/86901db27f73f731cd78cebee06c8b64b1a58ca3...v1.1.7) (2018-01-17)


### Bug Fixes

* **package:** bump packages versions in template ([e24dbfe](https://github.com/julon/vue-cli-template-library/commit/e24dbfe))

<a name="1.1.6"></a>
## [1.1.6](https://github.com/julon/vue-cli-template-library/compare/e14a2478feb6d99ec84af52d07f3a07969672c97...v1.1.6) (2018-01-11)


### Bug Fixes

* remove unused alias @ support ([86901db](https://github.com/julon/vue-cli-template-library/commit/86901db))

<a name="1.1.5"></a>
## [1.1.5](https://github.com/julon/vue-cli-template-library/compare/83a77e09b49e970f1047a446636fcee0511a6cc7...v1.1.5) (2018-01-10)


### Bug Fixes

* add complete message in meta and update docs ([e14a247](https://github.com/julon/vue-cli-template-library/commit/e14a247))

<a name="1.1.4"></a>
## [1.1.4](https://github.com/julon/vue-cli-template-library/compare/fd1640fff063d04b578e56b98213dc125376cfea...v1.1.4) (2018-01-09)


### Bug Fixes

* update license.md ([83a77e0](https://github.com/julon/vue-cli-template-library/commit/83a77e0))

<a name="1.1.3"></a>
## [1.1.3](https://github.com/julon/vue-cli-template-library/compare/e4fca996214f63c26a6cb3b717d75aa79306b0b8...v1.1.3) (2018-01-08)


### Bug Fixes

* change regex of jest transform ([fd1640f](https://github.com/julon/vue-cli-template-library/commit/fd1640f))

<a name="1.1.2"></a>
## [1.1.2](https://github.com/julon/vue-cli-template-library/compare/b35a4c70d94d8775410c5d7494feba75c95f901b...v1.1.2) (2018-01-07)


### Bug Fixes

* move documentation to Contributing.md ([e4fca99](https://github.com/julon/vue-cli-template-library/commit/e4fca99))

<a name="1.1.1"></a>
## [1.1.1](https://github.com/julon/vue-cli-template-library/compare/42189801ce39fe4ff74ab05c1ccc9ff257996ce7...v1.1.1) (2018-01-07)


### Bug Fixes

* Update the README ([b35a4c7](https://github.com/julon/vue-cli-template-library/commit/b35a4c7))

<a name="1.1.0"></a>
# [1.1.0](https://github.com/julon/vue-cli-template-library/compare/572e2ff82c6e7b9a41582cf3fbef971bd47e89a2...v1.1.0) (2018-01-07)


### Features

* Update the README ([4218980](https://github.com/julon/vue-cli-template-library/commit/4218980))

<a name="1.0.0"></a>
# 1.0.0 (2018-01-07)


### Features

* add vue-lib-template files ([71e72ef](https://github.com/julon/vue-lib-template/commit/71e72ef))
