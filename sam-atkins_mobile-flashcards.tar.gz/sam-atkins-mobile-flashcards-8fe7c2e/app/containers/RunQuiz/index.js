import RunQuiz from './RunQuiz';

export default RunQuiz;
