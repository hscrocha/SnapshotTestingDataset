import QuestionText from './QuestionText';

export default QuestionText;
