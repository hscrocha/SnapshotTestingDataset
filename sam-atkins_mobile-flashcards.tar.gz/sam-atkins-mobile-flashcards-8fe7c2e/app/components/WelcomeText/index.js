import WelcomeText from './WelcomeText';

export default WelcomeText;
