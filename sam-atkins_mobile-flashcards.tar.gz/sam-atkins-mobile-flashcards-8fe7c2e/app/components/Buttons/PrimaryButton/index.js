import PrimaryButton from './PrimaryButton';

export default PrimaryButton;
