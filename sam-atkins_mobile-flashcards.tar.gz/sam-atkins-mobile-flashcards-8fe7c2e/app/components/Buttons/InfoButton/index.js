import InfoButton from './InfoButton';

export default InfoButton;
