import SecondaryButton from './SecondaryButton';

export default SecondaryButton;
