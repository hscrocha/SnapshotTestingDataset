import Settings from './Settings';

export default Settings;
