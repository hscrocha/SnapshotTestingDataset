import AnswerText from './AnswerText';

export default AnswerText;
