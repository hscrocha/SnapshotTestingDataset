import QuizScore from './QuizScore';

export default QuizScore;
