import { queryMock } from '../__testUtils__/queryMock';

beforeEach(() => {
  queryMock.reset();
});
