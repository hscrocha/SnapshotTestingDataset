// @flow
import { QueryMock } from '../src/index';

export const queryMock = new QueryMock();
