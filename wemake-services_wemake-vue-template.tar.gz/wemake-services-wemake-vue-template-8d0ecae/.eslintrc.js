module.exports = {
  'extends': [
    '@wemake-services/javascript',
  ],
  'env': {
    'node': true,
  },
}
