<template>
  <div>
    <nuxt />
  </div>
</template>

<style lang="scss">
// Note that this component is not `scoped` or `module`.
// Here you can import or define any other styles that are required for this
// particular layout. This styles will be considered global.
// So, please be resposible!
</style>
