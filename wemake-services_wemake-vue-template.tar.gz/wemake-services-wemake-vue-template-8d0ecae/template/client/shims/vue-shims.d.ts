declare module '*.vue' {
  import Vue from 'vue'

  // Place any unimported plugins here:
  import '@nuxtjs/axios'

  export default Vue
}
