export function openSuperHeroDetailScreen(navigate: any, id: string) {
    navigate("SuperHeroDetailScreen", { superHeroId: id });
}
