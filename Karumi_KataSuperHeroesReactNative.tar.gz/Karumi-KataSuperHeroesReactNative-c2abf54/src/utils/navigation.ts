export interface NavigationLeafRoute<Params> {
    params?: Params;
  }
