export const LOADING_SUPER_HERO = "super-hero-detail/LOADING_SUPER_HERO";
export const SUPER_HERO_FETCHED = "super-hero-detail/SUPER_HERO_FETCHED";
export const CLEAR_SUPER_HERO = "super-hero-detail/CLEAR_SUPER_HERO";
