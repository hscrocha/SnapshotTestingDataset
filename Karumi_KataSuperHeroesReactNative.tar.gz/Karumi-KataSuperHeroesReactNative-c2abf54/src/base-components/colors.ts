const colors = {
    navigationBar: {
        backgroundColor: "#3d4a59",
        tintColor: "#ffffff",
    },
};

export default colors;
