
export const mockPlainNavigation = {
    navigate: jest.fn(),
};

export const navigationWithMockedParams = {
    navigate: jest.fn(),
    getParam: jest.fn(),
};
