export const LOADING_SUPER_HEROES = "super-heroes-list/LOADING_SUPER_HEROES";
export const SUPER_HEROES_FETCHED = "super-heroes-list/SUPER_HEROES_FETCHED";
