const images =  {
    avengersBadge: require("./ic_avengers.png"),
};

export default images;
