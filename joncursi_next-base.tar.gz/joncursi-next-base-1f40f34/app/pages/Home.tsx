/**
 * @prettier
 */

/* eslint-disable filenames/match-regex */

import Home from '~/views/Home';

export default Home;
