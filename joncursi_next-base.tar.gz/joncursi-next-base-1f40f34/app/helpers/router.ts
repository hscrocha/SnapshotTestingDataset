/**
 * @prettier
 */

import ServerRouter from '../../server/router';

export const Router = ServerRouter.Router;

export const RouterLink = ServerRouter.Link;
