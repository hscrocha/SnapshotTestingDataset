/**
 * @prettier
 */

export default {
  BORDER_RADIUS_DEFAULT: 3,
  LAYOUT_PADDING: 12,
};
