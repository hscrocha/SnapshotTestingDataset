/**
 * @prettier
 */

export default {
  APP: 'Next Base',
  COMPANY: 'Jon Cursi, Inc.',
};
