/**
 * @prettier
 */

export default {
  HOME: 'HOME',
};
