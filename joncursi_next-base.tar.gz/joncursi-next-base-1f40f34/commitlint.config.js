/**
 * @prettier
 */

/* eslint-disable immutable/no-mutation */

module.exports = require('@joncursi/eslint-config/commitlint.config');
