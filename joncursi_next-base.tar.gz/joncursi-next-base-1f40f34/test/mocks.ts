/**
 * @prettier
 */

jest.mock('next/router');
