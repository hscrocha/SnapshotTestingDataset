import { createHelpers } from 'yeoman-test';
import { join, dirname } from 'path';
import { fileURLToPath } from 'url';
// eslint-disable-next-line import/no-unresolved
import { EnvironmentBuilder } from 'generator-jhipster/esm/cli';

const packageRoot = join(dirname(fileURLToPath(import.meta.url)), '..');
const jhipsterPath = join(packageRoot, 'node_modules', 'generator-jhipster');

export function createTestHelpers(options = {}) {
  return createHelpers({ ...options, createEnv: EnvironmentBuilder.createEnv });
}

export const helpers = createTestHelpers();

export const lookups = { packagePaths: [packageRoot, jhipsterPath], lookups: ['generators'] };
