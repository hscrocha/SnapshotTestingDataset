const config = {
  coverageDirectory: './public/coverage',
};

module.exports = config;
