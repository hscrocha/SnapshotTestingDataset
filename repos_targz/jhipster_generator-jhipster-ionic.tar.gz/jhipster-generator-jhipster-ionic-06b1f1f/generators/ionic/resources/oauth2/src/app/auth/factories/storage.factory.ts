import { CapacitorStorage } from 'ionic-appauth/lib/capacitor';

export const storageFactory = () => new CapacitorStorage();
