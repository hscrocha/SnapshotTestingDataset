import { CapacitorBrowser } from 'ionic-appauth/lib/capacitor';

export const browserFactory = () => new CapacitorBrowser();
