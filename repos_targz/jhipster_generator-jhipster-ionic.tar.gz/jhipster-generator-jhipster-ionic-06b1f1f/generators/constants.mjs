export const IONIC_NAMESPACE = 'jhipster-ionic';
export const DEFAULT_IONIC_PATH = '../ionic4j';
export const DEFAULT_BACKEND_PATH = '../backend';
