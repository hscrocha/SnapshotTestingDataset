module.exports = {
  ionic: {
    desc: 'Run ionic',
  },
};
