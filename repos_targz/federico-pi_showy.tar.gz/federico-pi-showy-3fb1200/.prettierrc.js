module.exports = {
  bracketSpacing: true,
  bracketSameLine: false,
  singleQuote: true,
  trailingComma: 'es5',
  endOfLine: 'auto',
  printWidth: 80,
};
