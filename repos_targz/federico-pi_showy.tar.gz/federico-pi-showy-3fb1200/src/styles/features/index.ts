import * as DetailsFeatureStyles from './details';
import * as SearchFeatureStyles from './search';

export { DetailsFeatureStyles, SearchFeatureStyles };
