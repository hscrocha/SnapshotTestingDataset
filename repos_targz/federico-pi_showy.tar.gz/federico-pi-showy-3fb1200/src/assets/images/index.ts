import ChevronLeft from './chevron-left.svg';
import SearchLens from './search-lens.svg';

export { ChevronLeft, SearchLens };
