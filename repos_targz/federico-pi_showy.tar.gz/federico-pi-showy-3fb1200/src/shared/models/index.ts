import * as ApiModels from './api.models';
import * as RoutesModels from './routes.models';

export { ApiModels, RoutesModels };
