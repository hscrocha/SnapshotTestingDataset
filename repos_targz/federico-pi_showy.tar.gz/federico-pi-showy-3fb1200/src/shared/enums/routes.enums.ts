/**
 * Available routes for navigation
 */
export enum ROUTES {
  SEARCH = 'search',
  DETAILS = 'details',
}
