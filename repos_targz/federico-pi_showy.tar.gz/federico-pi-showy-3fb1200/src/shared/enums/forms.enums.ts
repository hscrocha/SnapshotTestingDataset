/**
 * Fields for the form
 */
export enum FORM_FIELDS {
  SEARCH = 'search',
}
