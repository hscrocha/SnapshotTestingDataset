/**
 * Mocking the svg transformer
 */
module.exports = 'SvgMock';
module.exports.ReactComponent = 'SvgMock';
