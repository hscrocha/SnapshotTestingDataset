/**
 * Mocking react-native-ratings imports
 */
import { View } from 'react-native';

export default View;
