declare module '~env' {
  export const APP_NAME: string;
  export const BASE_URL: string;
}
