/** @export const @type {string} */
const BASE_API_URL = 'https://kitsu.io/api/edge/';

export default BASE_API_URL;
