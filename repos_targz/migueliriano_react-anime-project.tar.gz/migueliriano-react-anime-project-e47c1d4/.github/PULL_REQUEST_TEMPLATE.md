### Github Ticket(s)
<The link to the related ticket on Github.>

* [CARD-xxx](https://github.com/migueliriano/react-anime-project/projects/1#card-xxx)

### Description
<Brief description of the code changes.>
