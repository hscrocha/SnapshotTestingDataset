const API_URL = 'https://randomuser.me/api';

export default API_URL;
