import React from "react";

const AboutPage = () => (
  <div>
    <h2>About</h2>
    <p>this page is about page</p>
  </div>
);

export default AboutPage;
