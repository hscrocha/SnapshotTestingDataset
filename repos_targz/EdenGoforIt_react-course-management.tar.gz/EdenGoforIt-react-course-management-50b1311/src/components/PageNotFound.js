import React from "react";

const PageNotFound = () => {
  return <h1>Opps! Page Not Found</h1>;
};
export default PageNotFound;
