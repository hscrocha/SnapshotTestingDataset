export const caronaGroups = {
  twbh:
  {
    members: {QdQZ1wadFxdXUzoFjzFKM7guTZf2: {admin: true}},
    name: 'ThoughtWorks BH'
  },
  twpoa:
  {
    members:
    {
      QdQZ1wadFxdXUzoFjzFKM7guTZf2: {admin: true},
      dbRu4x89syTbUl98nZDR46g14Xm2: {admin: false},
      wht06H0TK8TWPdloMNI6ysKsSpi1: {admin: false},
      y3Ns57iTCMVN3jsSjzxfSkwiktA2: {admin: false}
    },
    name: 'ThoughtWorks POA'
  }
}
