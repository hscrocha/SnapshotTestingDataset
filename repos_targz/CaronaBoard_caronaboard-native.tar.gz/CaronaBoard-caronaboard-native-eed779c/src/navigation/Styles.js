
export const style = {}

export const barsHidden = {
  navBarHidden: true,
  tabBarHidden: true,
  statusBarHidden: true,
  drawUnderNavBar: true,
  drawUnderTabBar: true
}
