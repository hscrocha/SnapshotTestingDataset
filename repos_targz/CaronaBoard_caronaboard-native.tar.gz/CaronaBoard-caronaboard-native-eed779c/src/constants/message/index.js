export const USER_SIGNED_UP = 'Usuário cadastrado com sucesso, favor verificar sua caixa de mensagem.'
export const USER_RESET_PASSWORD = 'Um e-mail com instruções para redefinir sua senha foi enviado.'
