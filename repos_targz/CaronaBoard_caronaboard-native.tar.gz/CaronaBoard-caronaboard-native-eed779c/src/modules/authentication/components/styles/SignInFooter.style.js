import { StyleSheet } from 'react-native'

export default StyleSheet.create({
  textRow: {
    flexDirection: 'row',
    justifyContent: 'center'
  }
})
