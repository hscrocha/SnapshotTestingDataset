import React from 'react'
import { View, Text } from 'react-native'

export const ConfirmationModal = props => (
  <View>
    <Text>
      {'Bico'}
    </Text>
  </View>
)
