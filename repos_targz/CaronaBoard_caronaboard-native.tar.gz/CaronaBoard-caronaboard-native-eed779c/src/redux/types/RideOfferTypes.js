export const UPDATE_RIDE_OFFERS = 'update_ride_offers'
export const UPDATE_YOUR_RIDE_OFFERS = 'update_your_ride_offers'
export const UPDATE_RIDE_REQUESTS = 'update_rides_requests'
export const UPDATE_RIDE_GROUP = 'update_ride_group'
