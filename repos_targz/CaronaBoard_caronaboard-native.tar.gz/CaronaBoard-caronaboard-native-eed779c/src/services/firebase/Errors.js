export const ERROR = {
  duplicatedApp: 'app/duplicate-app'
}
