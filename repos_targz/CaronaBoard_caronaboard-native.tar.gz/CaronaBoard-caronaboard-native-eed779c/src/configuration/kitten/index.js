import { bootstrap } from './bootstrap'

export default {
  setup: () => {
    bootstrap()
  }
}
