import { addDecorator } from '@storybook/react'
import withGlobalStyles from './withGlobalStyles'

addDecorator(withGlobalStyles)
