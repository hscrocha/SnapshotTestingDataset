export type T = number;
