# 半东东 - bàn dōng dōng - полуфабрикат

Simple project template based on webpack react, redux, material ui, jest.

## Quickstart

```bash
git clone https://github.com/antono/ban-dong-dong.git
cd ban-dong-dong
npm install
npm start
```
