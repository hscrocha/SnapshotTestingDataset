module.exports = {
    setupFiles: ["raf/polyfill", "./jest.setup.js"]
}