export function sayHello({name}) {
    return `Hello ${name}! Welcome to my website`;
}