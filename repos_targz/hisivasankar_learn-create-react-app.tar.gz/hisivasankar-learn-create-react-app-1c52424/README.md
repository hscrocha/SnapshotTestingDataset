# learn-create-react-app [![Build Status](https://travis-ci.org/hisivasankar/learn-create-react-app.svg?branch=master)](https://travis-ci.org/hisivasankar/learn-create-react-app) [![Coverage Status](https://coveralls.io/repos/github/hisivasankar/learn-create-react-app/badge.svg?branch=master)](https://coveralls.io/github/hisivasankar/learn-create-react-app?branch=master)

 This project is to understand how create-react-app works under the hood

### Target Audience:

This is for people who would like to understand how create-react-app works with the help of other modules
like 
* Webpack
* Babel
* Hot reload
* SASS loader etc...

I will be adding step by step procedure on every commit/branch.

1.create-package.json

2.create-simple-content

3.create-react-app

4.configure-dependencies

5.configure-webpack

6.configure-webpack-dev

7.configure-jest

8.add-build-badge

9.configure-coverage-badge

10.configure-builds

Stay tuned!
