import React from 'react';

const Home = () => (
  <div className="home">
    <h2>Welcome to our page</h2>
    <p>
      Lorem ipsum dolor sit amet, consectetur adipiscing elit, sed do eiusmod
      tempor incididunt ut labore et dolore magna aliqua. Bibendum neque egestas
      congue quisque egestas diam in arcu cursus. Non nisi est sit amet
      facilisis magna. Amet tellus cras adipiscing enim eu turpis egestas.
      Nullam vehicula ipsum a arcu cursus vitae congue mauris. Et malesuada
      fames ac turpis egestas sed. Elit ullamcorper dignissim cras tincidunt
      lobortis
    </p>
  </div>
);

export default Home;
