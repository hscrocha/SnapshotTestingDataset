import { AppRegistry }from 'react-native';
import App from './src/app';

AppRegistry.registerComponent('RelayApp', () => App);
