# Relay test integration with real GraphQL backend

## Summary
This code will test your Relay application against a working GraphQL backend, so we can make sure everything is working (e2e - end to end)

## Blog Post
[Relay Integration Test with Jest](https://medium.com/entria/relay-integration-test-with-jest-71236fb36d44#.ghhvvbbvl)
