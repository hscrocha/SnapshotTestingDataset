const config = {
  GRAPHQL_URL: process.env.GRAPHQL_URL ? process.env.GRAPHQL_URL : 'http://localhost:5000/graphql',
};

export default config;
