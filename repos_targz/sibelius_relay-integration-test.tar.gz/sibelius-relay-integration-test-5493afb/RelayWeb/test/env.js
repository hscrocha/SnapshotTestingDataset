import 'isomorphic-fetch';
// const XMLHttpRequest = require('xhr2');
//
// global.XMLHttpRequest = XMLHttpRequest;


