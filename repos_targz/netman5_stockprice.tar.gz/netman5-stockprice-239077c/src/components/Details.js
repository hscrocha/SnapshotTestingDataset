/* eslint-disable arrow-body-style */
import React from 'react';
import Topbar from './Pages/Topbar';
import Card from './views/Card';

const Details = () => {
  return (
    <div>
      <Topbar />
      <Card />
    </div>
  );
};

export default Details;
