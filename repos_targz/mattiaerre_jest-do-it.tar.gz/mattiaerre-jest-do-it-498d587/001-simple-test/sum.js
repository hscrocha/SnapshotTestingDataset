const sum = (a, b) => { // eslint-disable-line arrow-body-style
  return a + b;
};

module.exports = sum;
