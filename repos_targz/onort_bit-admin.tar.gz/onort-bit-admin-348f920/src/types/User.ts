import { BitData } from "./"

export interface User {
  name: string
  email: string
  bits?: BitData[]
}
