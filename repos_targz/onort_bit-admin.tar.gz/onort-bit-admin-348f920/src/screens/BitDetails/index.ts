import BitDetails from "./BitDetails"
import DetailView from "./DetailView"
import DetailEdit from "./DetailEdit"

export default BitDetails
export { DetailEdit, DetailView }
