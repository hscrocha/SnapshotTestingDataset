import ViewTags, { State as ViewTagsState } from "./ViewTags"
import TagsTable from "./TagsTable"

export default ViewTags
export { TagsTable, ViewTagsState }
