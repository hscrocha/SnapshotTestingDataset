import TagDetails from "./TagDetails"
import DetailEdit from "./DetailEdit"
import DetailView from "./DetailView"

export default TagDetails
export { DetailEdit, DetailView }
