import FormTitle from "./FormTitle"

export default FormTitle
