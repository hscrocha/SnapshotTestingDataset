import AuthRoute from "./AuthRoute"

export default AuthRoute
