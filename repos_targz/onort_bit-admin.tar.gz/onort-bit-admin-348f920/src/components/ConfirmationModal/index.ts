import ConfirmationModal from "./ConfirmationModal"

export default ConfirmationModal
