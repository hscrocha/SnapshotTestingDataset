import NoData from "./NoData"

export default NoData
