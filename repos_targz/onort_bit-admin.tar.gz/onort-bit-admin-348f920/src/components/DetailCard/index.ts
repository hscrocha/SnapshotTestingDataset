import DetailCard from "./DetailCard"
import DetailCardContent from "./Content"
import DetailCardItem from "./Item"
import DetailCardTitle from "./Title"

export default DetailCard

export { DetailCardContent, DetailCardItem, DetailCardTitle }
