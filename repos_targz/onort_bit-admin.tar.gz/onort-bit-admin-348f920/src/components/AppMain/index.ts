import AppMain from "./AppMain"

export default AppMain
