## About

This is a web application for administrator and authors of a content management system for a planned future application.

Application is still in its early development stage. Built with React, Typescript, Apollo, Sass, Formik & Draft.js. Jest and Enzyme for unit testing.

You might want to check out the [API](https://github.com/onort/bm-bit-graphql) its using.
