---
title: 'Hello, world.'
date: '2020-08-10T01:07:01.200Z'
summary: "This is a simple post that basically makes it clear what's possible."
coverImage: '/articles/hello-world.jpg'
author:
  name: Bruno Bernardino
  image: 'https://brunobernardino.com/images/logomark.svg'
---

Father Christmas. Santa Claus. Or as I've always known him: Jeff. Father Christmas. Santa Claus. Or as I've always known him: Jeff. Stop talking, brain thinking. Hush. I am the Doctor, and you are the Daleks!

It's art! A statement on modern society, 'Oh Ain't Modern Society Awful? '! You know how I sometimes have really brilliant ideas? They're not aliens, they're Earth…liens! Annihilate? No. No violence. __I won't stand for it.__ *Not now, not ever, do you understand me?!* I'm the Doctor, the Oncoming Storm - and you basically meant beat them in a football match, didn't you?

## I am the Doctor, and you are the Daleks!

You know how I sometimes have really brilliant ideas? It's art! A statement on modern society, 'Oh Ain't Modern Society Awful?'! You've swallowed a planet! It's a fez. I wear a fez now. Fezes are cool.

1. All I've got to do is pass as an ordinary human being. `Simple`. What could possibly go wrong?
2. Stop talking, brain thinking. Hush.
3. *Insistently* Bow ties are cool! Come on Amy, I'm a normal bloke, tell me what normal blokes do!

```
$ echo 'This is nice!'
This is nice!
```
