module.exports = require('./dist/config/prettierrc');
