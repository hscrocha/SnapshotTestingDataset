module.exports = require('./dist/config/stylelint.config');
