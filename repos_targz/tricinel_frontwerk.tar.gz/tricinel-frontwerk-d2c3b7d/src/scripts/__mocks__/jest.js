module.exports = {
  run: jest.fn()
};
