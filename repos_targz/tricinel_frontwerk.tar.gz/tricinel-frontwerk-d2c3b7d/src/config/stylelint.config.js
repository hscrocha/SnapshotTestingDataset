module.exports = {
  extends: 'stylelint-config-standard'
};
