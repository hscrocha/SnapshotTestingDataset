module.exports = {
  sync: jest.fn(() => ({ status: 0 }))
};
