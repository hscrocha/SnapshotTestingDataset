module.exports = {
  pkgPath: 'path/to/package/package.json'
};
