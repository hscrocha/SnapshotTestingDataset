module.exports = {
  appDirectory: 'path/to/package/'
};
