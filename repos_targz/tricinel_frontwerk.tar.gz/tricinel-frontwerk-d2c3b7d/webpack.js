module.exports = require('./dist/config/webpack.config');
