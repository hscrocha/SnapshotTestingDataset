module.exports = require('./dist/config/jest.config');
