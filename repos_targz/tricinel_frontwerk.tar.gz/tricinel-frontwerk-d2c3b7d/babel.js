module.exports = require('./dist/config/babelrc');
