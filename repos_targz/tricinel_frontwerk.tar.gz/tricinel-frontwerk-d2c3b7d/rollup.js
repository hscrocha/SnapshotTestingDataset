module.exports = require('./dist/config/rollup.config');
