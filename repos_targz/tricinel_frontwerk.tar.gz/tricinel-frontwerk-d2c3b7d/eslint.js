module.exports = require('./dist/config/eslintrc');
