'use strict';
const routesEvent = require('./eventRoutes');


module.exports = app => {

    routesEvent(app);

};