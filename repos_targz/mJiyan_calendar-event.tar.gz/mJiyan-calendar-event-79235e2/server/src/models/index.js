const Event = require('./eventModel');

module.exports = { Event };
