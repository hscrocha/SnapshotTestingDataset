const GET_EVENTS = 'EVENT/GET_EVENTS';
const SET_SELECTED_EVENT = 'EVENT/SET_SELECTED_EVENT';

const actionTypes = {
  GET_EVENTS,
  SET_SELECTED_EVENT,
};

export default actionTypes;
