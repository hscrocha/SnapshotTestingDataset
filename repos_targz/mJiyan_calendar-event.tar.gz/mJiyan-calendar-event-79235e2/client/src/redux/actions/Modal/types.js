const SET_MODAL = 'MODAL/SET_MODAL';

const actionTypes = {
  SET_MODAL,
};

export default actionTypes;
