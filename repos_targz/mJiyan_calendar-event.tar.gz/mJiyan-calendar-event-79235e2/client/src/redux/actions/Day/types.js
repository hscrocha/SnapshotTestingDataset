const SET_DAY_SELECTED = 'DAY/SET_DAY_SELECTED';

const actionTypes = {
  SET_DAY_SELECTED,
};

export default actionTypes;
