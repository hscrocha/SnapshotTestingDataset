const SET_MONTH = 'MONTH/SET_MONTH';

const actionTypes = {
  SET_MONTH,
};

export default actionTypes;
