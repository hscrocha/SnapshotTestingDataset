import { Calendar } from '../views';

const routes = [{ path: '/', component: Calendar }];

export default routes;
