# Task 1b: Composing promises

Expanding on what we've learned from chaing promises, we can also compose promises.

## Task

0. Make sure you are in the right directory (cd day2/task1).
1. Run the script using `babel-node main.js`.
2. Make a copy of the JavaScript file so you can keep them side-by-side.
3. Rewrite or refactor the script to do the same thing, but using Promises.
4. Use the Promise constructor to wrap callback-based operations into a Promise.

## Tips

- The 2 async operations can be started in parallel
