const foo = 'whatever';

const bar = input => input + 1;

/* EXPORTING AT THE END */
export { foo, bar };
