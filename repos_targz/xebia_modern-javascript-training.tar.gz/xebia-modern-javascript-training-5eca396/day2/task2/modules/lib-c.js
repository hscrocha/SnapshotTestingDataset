/* RE-EXPORTING */
/* not used so much */

export * from './lib-a';

export { foo, bar } from './lib-b';
