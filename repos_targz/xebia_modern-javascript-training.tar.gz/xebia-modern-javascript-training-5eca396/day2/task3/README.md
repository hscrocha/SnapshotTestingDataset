# Task 3: Working with Arrays

Most likely you'll be dealing with Arrays on a daily basis. More often than not, these will contain objects. Let's get
familiar with ways to transform them into useful information.

## Task

Build a function that takes an array of people with age and gender properties and returns the average age of the men.

Avoid using a for loop.
