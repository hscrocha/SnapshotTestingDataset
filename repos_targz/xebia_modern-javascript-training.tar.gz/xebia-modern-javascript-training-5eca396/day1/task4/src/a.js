var welcome = "welcome";
var message = "this is a message!";

var all = welcome + ", " + message;
