const alphabet = {
  "a": "The letter A",
  "b": "The letter B",
  "c": "The letter C",
  "d": "The letter D",
  "e": "The letter E",
  "f": "The letter F",
};
