export const add = (a, b) => a + b;
export const multiply = (a, b) => a * b;
export const substract = (a, b) => a - b;
export const devide = (a, b) => a / b;
export const random = (min = 0, max = 10) => Math.floor(Math.random() * (max - min)) + min;
