export { default } from './Richtext';
export type { RichtextProps } from './Richtext';
