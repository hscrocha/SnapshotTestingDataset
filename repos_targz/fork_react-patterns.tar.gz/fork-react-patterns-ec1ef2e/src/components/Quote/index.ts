export { default } from './Quote';
export type { QuoteProps } from './Quote';
