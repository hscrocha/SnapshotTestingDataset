export { default as Tabs } from './Tabs';
export type { TabsProps } from './Tabs';

export { default as Tab } from './Tab';
export type { TabProps } from './Tab';
