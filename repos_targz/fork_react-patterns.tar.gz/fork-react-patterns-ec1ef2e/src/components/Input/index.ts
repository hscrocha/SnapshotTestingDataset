export type { InputProps } from './Input';
export { default } from './Input';
