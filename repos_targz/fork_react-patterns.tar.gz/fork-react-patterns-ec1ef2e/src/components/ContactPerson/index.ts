export { default } from './ContactPerson';
export type { ContactPersonProps } from './ContactPerson';
