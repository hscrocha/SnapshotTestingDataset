export { default } from './Teaser';
