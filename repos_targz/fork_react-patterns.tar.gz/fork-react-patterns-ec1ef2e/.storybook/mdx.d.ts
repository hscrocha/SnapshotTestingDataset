declare module '*.mdx' {
  let MDXComponent: () => JSX.Element;
  export default MDXComponent;
}
