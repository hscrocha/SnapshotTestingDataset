export default (on, config) => {
  return config;
};
