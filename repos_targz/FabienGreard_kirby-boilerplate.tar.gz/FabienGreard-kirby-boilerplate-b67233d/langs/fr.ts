export default {
  greetings: 'Bonjour {name} !',
  editingMessage: 'Commencez par éditer',
  githubLinkMessage: 'Suivez Kirby sur github !',
  title: 'Kirby Boilerplate',
  description:
    'Kirby-boilerplate est un boilerblate subjectif avec tous les derniers outils pour du developpement front-end.',
};
