export default {
  greetings: 'Hello {name} !',
  editingMessage: 'Get started by editing',
  githubLinkMessage: 'Follow Kirby on github !',
  title: 'Kirby Boilerplate',
  description: 'This is an opinionated boilerplate with rocking tools for front-end development.',
};
