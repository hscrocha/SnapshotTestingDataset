const Home = () => (
  <div>
    <h2 className="home-title">Welcome to our page</h2>
    <p className="lorem">
      Lorem ipsum dolor sit amet, consectetur adipisicing elit. Minus, sequi
      dolorum reiciendis repudiandae, voluptatum molestias veritatis eveniet
      excepturi iusto dolores eaque obcaecati ab tenetur reprehenderit nemo,
      labore illum recusandae architecto?
    </p>
    <p className="lorem">
      Lorem ipsum dolor sit amet, consectetur adipisicing elit. Minus, sequi
      dolorum reiciendis repudiandae, voluptatum molestias veritatis eveniet
      excepturi iusto dolores eaque obcaecati ab tenetur reprehenderit nemo,
      labore illum recusandae architecto?
    </p>
  </div>
);

export default Home;
