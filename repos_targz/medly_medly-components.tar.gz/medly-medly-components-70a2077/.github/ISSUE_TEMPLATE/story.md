---
name: Story
about: Story for the contributors
title: 'feat/refactor: title of the story'
labels: story
assignees: ''

---

### Description
Provide a description of the story.

### In Scope
- 

### Out of Scope
- 

### Figma Link
https://www.figma.com/file/vA4EQdxl0d0ETtYpw2uSjW/Medly-Pattern-Library-B2B-Internal?node-id=7343%3A1201

### Additional context
Provide any other context or screenshots of the feature request.
