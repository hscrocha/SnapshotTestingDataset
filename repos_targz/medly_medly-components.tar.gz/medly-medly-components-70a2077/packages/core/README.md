# React Core Components

This library contains components like Avatar, Button, Input, List, Modal etc. Check docs [here](https://medly.github.io/medly-components).
