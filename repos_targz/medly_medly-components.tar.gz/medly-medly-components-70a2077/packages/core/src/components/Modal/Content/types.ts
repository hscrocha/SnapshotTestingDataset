import { ScrollState } from '../types';

export interface StyledProps {
    scrollState: ScrollState;
    headerHeight: number;
    overflowVisible?: boolean;
}
