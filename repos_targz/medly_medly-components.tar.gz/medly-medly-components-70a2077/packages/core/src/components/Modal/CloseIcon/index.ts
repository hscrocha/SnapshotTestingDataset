export { CloseIcon as default } from './CloseIcon.styled';
