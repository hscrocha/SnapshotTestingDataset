export type Modal = HTMLDivElement;
