export { Content as default } from './Content';
