import { HeadCell } from './HeadCell';

export default HeadCell;
