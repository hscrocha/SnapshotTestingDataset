const data = [
    {
        id: 1,
        patientInfo: 'Oli Bob',
        rxInfo: 'Metaformin',
        price: '535.76',
        status: 'Processing',
        disabled: true
    },
    {
        id: 2,
        patientInfo: 'Mary May',
        rxInfo: 'Carbinoxamine 6mg',
        price: '17.32',
        status: 'Pending'
    },
    {
        id: 3,
        patientInfo: 'Christine Mary Bob Lobowski',
        rxInfo: 'Lanoxin Carbinoxamine Metaformin 125mg',
        price: '89.49',
        status: 'Billed'
    },
    {
        id: 4,
        patientInfo: 'Brendon Philips',
        rxInfo: 'OxyContin 10mg',
        price: '142.75',
        status: 'Delivery Scheduled'
    }
];

export default data;
