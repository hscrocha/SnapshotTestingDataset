import { CardTable } from './CardTable';

export default CardTable;
