import { Body } from './Body';

export default Body;
