import { FieldWithLabel } from './FieldWithLabel';

export default FieldWithLabel;
