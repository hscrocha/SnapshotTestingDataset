import ColumnConfiguration from './ColumnConfiguration';

export default ColumnConfiguration;
