import styled from 'styled-components';

export const TBody = styled('tbody')`
    display: block;
    min-width: fit-content;
`;
