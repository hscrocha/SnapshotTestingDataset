export { ExtendedRowCell as default } from './ExtendedRowCell';
