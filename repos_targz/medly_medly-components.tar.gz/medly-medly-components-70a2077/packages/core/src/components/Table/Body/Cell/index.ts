import Cell from './Cell';

export default Cell;
