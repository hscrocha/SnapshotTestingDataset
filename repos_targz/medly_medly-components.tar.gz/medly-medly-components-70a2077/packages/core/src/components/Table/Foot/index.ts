export { Foot as default } from './Foot';
