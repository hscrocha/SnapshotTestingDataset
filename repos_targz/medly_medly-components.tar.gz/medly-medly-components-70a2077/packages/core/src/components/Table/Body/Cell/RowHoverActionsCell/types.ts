export type ObjectType = {
    [key: string]: any;
};

export type RowHoverActionsCellProps = {
    show: boolean;
};
