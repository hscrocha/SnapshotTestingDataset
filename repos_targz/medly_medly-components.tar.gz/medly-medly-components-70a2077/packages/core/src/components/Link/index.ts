import { Link } from './Link';

export default Link;
