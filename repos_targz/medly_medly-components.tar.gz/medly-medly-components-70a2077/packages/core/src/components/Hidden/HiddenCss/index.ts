export { HiddenCss as default } from './HiddenCss.styled';
