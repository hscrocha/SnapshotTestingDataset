export { InputSuffix as default } from './InputSuffix';
