import styled from 'styled-components';

export const InputSuffixStyled = styled.div<{ size: 'S' | 'M' }>`
    display: flex;
    align-items: center;
`;
