export { BreadcrumbBack as default } from './Back';
