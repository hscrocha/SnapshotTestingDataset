export { DateRangeCalendar as default } from './DateRangeCalendar';
