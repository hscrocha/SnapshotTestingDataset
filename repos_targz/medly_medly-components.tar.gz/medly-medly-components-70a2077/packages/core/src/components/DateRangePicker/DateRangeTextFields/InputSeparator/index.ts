export { InputSeparator as default } from './InputSeparator.styled';
