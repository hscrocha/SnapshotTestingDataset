import { DateRangePicker } from './DateRangePicker';

export default DateRangePicker;
