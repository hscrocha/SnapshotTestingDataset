export { DateRangeTextField as default } from './DateRangeTextField';
