import { CssBaseline } from './CssBaseline.styled';

export default CssBaseline;
