export { BtnLoader as default } from './Loader';
