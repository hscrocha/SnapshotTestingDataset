import { SearchBox } from './SearchBox';

export default SearchBox;
