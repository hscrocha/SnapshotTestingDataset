import { SingleSelect } from './SingleSelect';

export default SingleSelect;
