export { FlatVariant as default } from './FlatVariant';
