import styled from 'styled-components';

export const ContentStyled = styled('div')`
    flex: 1;
    box-sizing: border-box;
    overflow: auto;
    padding: 0 2.4rem;
`;
