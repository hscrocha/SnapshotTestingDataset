export type DrawerFooterProps = {
    /** Use this to align footer content horizontally */
    alignItems?: 'left' | 'center' | 'right';
};
