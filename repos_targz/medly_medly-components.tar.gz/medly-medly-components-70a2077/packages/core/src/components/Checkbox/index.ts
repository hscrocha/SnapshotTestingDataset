import { Checkbox } from './Checkbox';

export default Checkbox;
