export { PopupStyled as default } from './Popup.styled';
