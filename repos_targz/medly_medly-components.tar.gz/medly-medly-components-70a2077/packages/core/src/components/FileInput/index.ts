import { FileInput } from './FileInput';

export default FileInput;
