export { CenterAlignedLoader as default } from './CenterAlignedLoader';
