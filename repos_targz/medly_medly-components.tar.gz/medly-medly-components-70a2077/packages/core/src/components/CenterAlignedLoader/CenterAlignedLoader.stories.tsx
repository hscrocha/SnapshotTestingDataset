import styled from 'styled-components';

export const RelativeDiv = styled.div`
    position: relative;
`;
