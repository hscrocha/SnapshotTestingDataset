import styled from 'styled-components';

export const StepperStyled = styled('div')`
    display: flex;
`;
