export { WeekDays as default } from './WeekDays';
