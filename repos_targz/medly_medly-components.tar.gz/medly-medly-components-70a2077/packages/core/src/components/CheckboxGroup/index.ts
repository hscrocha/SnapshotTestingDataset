import { CheckboxGroup } from './CheckboxGroup';

export default CheckboxGroup;
