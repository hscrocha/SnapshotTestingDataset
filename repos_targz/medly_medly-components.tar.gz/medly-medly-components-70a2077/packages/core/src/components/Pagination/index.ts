import { Pagination } from './Pagination';

export default Pagination;
