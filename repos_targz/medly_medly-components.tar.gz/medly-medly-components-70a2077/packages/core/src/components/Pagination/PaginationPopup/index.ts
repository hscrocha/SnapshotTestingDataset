import { PaginationPopup } from './PaginationPopup';

export default PaginationPopup;
