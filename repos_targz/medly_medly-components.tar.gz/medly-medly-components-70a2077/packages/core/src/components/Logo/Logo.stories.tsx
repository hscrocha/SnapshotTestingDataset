import type { FC } from 'react';

export const DummyCompanyName: FC = () => <span>Cool company</span>;
