import { DialogBox } from './DialogBox';

export default DialogBox;
