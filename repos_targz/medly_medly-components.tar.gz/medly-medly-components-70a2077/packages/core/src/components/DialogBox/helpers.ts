export const getRemFromPx = (px: number) => (px ? px / 10 : 0);
