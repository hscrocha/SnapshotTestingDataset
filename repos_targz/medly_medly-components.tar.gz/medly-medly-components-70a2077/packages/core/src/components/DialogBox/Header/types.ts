import { HTMLProps, WithThemeProp } from '@medly-components/utils';
export interface DialogBoxHeaderProps extends HTMLProps<HTMLDivElement>, WithThemeProp {
    id: string;
}
