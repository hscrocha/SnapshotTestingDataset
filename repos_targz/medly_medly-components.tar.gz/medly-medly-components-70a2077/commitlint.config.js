module.exports = {
    extends: ['@commitlint/config-lerna-scopes']
};
