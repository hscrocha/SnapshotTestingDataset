import React from 'react';
import Home from '../components/Home';

const HomePage = () => (
  <div>
    <Home />
  </div>
);

export default HomePage;
