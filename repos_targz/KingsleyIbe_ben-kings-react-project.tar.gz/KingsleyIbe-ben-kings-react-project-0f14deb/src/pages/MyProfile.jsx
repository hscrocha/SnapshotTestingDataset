import React from 'react';
import Profile from '../components/Profile';

const MyProfile = () => (
  <div>
    <Profile />
  </div>
);

export default MyProfile;
