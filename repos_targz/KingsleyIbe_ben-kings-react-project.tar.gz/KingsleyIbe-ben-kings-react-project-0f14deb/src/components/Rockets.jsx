import React from 'react';
import RocketsCards from '../pages/RocketsCards';

const Rockets = () => (
  <div>
    <RocketsCards />
  </div>
);

export default Rockets;
