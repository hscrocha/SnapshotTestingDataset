[![ci](https://github.com/Danrrodrigues/boilerplate-react-next/actions/workflows/ci.yml/badge.svg)](https://github.com/Danrrodrigues/boilerplate-react-next/actions/workflows/ci.yml) [![Netlify Status](https://api.netlify.com/api/v1/badges/414ced7a-b9a3-411a-aa9b-c274290d2680/deploy-status)](https://app.netlify.com/sites/boilerplate-react-next/deploys)

[https://boilerplate-react-next.netlify.app/](https://boilerplate-react-next.netlify.app/)

## Getting Started

First, run the development server:

```bash
npm run dev
# or
yarn dev
```

Open [http://localhost:3000](http://localhost:3000) with your browser to see the result.

You can start editing the page by modifying `pages/index.js`. The page auto-updates as you edit the file.
