import * as actions from './actions'

export const updateSearchText = actions.updateSearchText
