const onValueChange = update => e => update({value: e.target.value})

export default onValueChange
