import {connect} from '@cerebral/react/index'
import S from '../sanctuary'

export default S.curry3(connect)
