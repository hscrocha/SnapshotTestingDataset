import 'jquery';
import 'bootstrap/dist/css/bootstrap.css';
import 'bootstrap';
import 'angular';
