export default {
  template: `
    <div class="container">
      <h1>My cart</h1>
      <cart/>
    </div>`,
};
