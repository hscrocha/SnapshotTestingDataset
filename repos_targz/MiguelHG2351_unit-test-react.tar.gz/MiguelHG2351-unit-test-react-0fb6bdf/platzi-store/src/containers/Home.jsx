import React from 'react';
import Products from '../components/Products';

const Home = () => <Products />;

export default Home;
