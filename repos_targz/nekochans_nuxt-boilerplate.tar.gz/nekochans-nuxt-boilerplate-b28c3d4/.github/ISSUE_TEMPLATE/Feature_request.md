---
name: ストーリー
about: スクラム開発でいうところのストーリーのテンプレート

---

# Doneの定義
[required]

# 補足情報
[optional]
