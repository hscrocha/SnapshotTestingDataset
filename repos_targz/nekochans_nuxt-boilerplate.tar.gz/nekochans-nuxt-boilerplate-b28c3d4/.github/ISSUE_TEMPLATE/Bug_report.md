---
name: バグ報告
about: バグの報告用テンプレート

---

# 概要
[required]

# 再現手順
[required]

# 再現環境
[required]

# このバグによって引き起こされる問題
[optional]

# スクリーンショット
[optional]

# 補足情報
[optional]
