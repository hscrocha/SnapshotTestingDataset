export default {
  id: 'keitakn',
  name: 'keita koga',
  imageUrl:
    'https://qiita-image-store.s3.amazonaws.com/0/71899/profile-images/1473698980',
  description: 'よろしくお願いします。'
};
