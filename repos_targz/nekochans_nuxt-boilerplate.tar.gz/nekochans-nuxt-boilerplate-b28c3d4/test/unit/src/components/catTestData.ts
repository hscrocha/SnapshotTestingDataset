export default { repeatNumber: 3 };
