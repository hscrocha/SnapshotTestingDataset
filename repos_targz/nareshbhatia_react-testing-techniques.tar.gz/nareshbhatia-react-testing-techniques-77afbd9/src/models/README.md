# models

This folder contains models (data structures) that are reused across application
features.
