/**
 * Environment variables
 */
export const EnvVar = {
  API_URL: 'API_URL',
};
