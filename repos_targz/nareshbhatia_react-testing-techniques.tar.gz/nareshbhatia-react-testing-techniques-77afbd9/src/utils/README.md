# utils

This folder contains utilities and constants that are reused across application
features.
