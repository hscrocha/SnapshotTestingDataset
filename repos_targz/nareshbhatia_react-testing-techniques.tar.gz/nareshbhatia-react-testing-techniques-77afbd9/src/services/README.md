# services

This folder contains service functions (api calls, hooks etc.) that are reused
across application features.
