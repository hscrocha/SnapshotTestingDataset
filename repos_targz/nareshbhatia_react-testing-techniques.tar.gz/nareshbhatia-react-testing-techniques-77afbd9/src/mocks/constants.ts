export const MOCK_API_URL = 'http://localhost:8080';
