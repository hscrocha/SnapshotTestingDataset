import React from 'react';

/**
 * This is a placeholder for a loading component
 */
export const Loading = () => {
  return <div>Loading...</div>;
};
