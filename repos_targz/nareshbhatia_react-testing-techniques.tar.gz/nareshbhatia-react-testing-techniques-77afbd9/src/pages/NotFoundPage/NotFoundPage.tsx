import React from 'react';

/**
 * This is a placeholder for the NotFound page
 */
export const NotFoundPage = () => {
  return (
    <main>
      <h1>Page Not Found</h1>
    </main>
  );
};
