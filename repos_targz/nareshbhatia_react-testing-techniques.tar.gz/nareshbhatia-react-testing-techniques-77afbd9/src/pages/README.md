# pages

This folder contains the top-level pages offered by the app. Pages are generally
associated with high-level business features.
