window._env_ = {
  API_URL: 'http://localhost:8080',
};
