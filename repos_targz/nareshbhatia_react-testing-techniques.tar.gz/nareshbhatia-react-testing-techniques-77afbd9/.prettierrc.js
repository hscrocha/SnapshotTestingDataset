module.exports = {
  singleQuote: true,
  proseWrap: 'always',
};
