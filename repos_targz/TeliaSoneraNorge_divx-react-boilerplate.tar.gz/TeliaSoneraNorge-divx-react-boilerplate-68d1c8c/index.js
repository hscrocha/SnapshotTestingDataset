/* eslint-env node */

require('babel-register');
require('babel-polyfill');

require('./server/start');
