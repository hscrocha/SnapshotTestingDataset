const getReactClient = {
  handler: {
    file: './server/views/index.html',
  },
};

export default getReactClient;
