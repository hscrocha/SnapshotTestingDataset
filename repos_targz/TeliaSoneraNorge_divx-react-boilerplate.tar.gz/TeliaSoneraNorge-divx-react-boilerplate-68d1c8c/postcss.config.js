/* eslint-disable import/no-extraneous-dependencies */

const autoprefixer = require('autoprefixer');

module.exports = {
  plugins: [
    autoprefixer,
  ],
};
