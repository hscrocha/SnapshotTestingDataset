const errorTypes = {
  ERROR_PAGE: 'ERROR_PAGE',
  NOTIFICATION: 'NOTIFICATION',
};

export default errorTypes;
