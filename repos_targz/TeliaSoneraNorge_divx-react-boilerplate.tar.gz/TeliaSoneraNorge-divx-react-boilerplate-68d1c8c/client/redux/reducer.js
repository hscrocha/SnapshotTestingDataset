import { combineReducers } from 'redux';

import examples from './examples/reducer';

export default combineReducers({ examples });
