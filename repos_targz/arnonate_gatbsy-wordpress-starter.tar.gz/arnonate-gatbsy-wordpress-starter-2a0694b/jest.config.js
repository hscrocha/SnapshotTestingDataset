module.exports = {
  preset: "jest-preset-gatsby/typescript",
  setupFilesAfterEnv: ["./jest.setup.js"],
}
