import Footer from "./Footer/Footer"
import Header from "./Header/Header"
import Layout from "./Layout/Layout"
import Seo from "./Seo/Seo"

export { Footer, Header, Layout, Seo }
