import CustomPost from "./CustomPost/CustomPost"
import Index from "./Index/Index"
import Page from "./Page/Page"
import Post from "./Post/Post"

export { CustomPost, Index, Page, Post }
