export default function orderSummary(state = [], action) {
	switch (action.type) {
	default:
		return state;
	}
}
