export const misc = {
	input: {
		height: '56px',
		width: '100%',
		icon: {
			height: '22px',
			width: '22px',
		},
	},
};

export const fonts = {
	input: {
		fontSize: '18px',
		fontWeight: '400',
	},
	button: {
		fontSize: '18px',
		fontWeight: '400',
	},
};

