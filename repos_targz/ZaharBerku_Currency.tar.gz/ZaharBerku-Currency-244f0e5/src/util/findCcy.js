export const findCcy = (arr, ccy) => {
    return arr.find(element => element.ccy === ccy);
};
