import { GlobalSvg } from "./icons/global/GlobalSvg";

export { GlobalSvg };