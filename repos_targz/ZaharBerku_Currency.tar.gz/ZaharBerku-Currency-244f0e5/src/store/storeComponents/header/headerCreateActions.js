import { GET_DATA_HEADER } from "./headerActions";


export const getDataHeader = (data) => ({type:GET_DATA_HEADER, payload: data});