export const everything = state => state.header;

export const header = state => everything(state).header;