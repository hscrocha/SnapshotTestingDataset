export const everything = state => state.currency;

export const currency = state => everything(state);