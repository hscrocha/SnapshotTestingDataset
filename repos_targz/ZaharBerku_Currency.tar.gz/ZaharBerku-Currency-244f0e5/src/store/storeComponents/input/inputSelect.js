export const everything = state => state.input;

export const input = state => everything(state);