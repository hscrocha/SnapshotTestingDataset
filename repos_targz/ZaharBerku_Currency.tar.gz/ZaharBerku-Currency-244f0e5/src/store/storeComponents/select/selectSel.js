export const everything = state => state.select;

export const select = state => everything(state);