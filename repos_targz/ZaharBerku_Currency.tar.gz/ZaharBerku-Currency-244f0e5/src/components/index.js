import { Main } from "./Main";
import { Header } from "./Header";

export { Header, Main };