export const trim = (str: string, seperator = ' '): string => str.replace(/\s+/g, seperator).trim()
