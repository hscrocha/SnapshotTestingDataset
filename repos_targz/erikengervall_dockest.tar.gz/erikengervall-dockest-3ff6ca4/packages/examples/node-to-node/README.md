# Node to Node

Showcases how to run Dockest with two Node services

# Exposed ports

- Node (users)
  - 1337
- Node (orders)
  - 1338
