module.exports = {
  roots: ['<rootDir>/integration-test'],
  transform: {
    '^.+\\.tsx?$': 'ts-jest',
  },
}
