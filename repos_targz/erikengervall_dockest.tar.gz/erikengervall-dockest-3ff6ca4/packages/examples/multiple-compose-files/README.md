# compose-files-only

Run Dockest without any attachedRunners.

# Exposed ports

- Postgres
  - 5433
- Redis
  - 6380
