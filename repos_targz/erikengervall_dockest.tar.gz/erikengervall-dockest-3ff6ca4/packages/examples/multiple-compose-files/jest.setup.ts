jest.setTimeout(60 * 1000)

process.env.NODE_ENV = 'test'
