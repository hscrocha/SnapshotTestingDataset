module.exports = {
  'max-len': 'off',
  printWidth: 120,
  semi: false,
  singleQuote: true,
  tabWidth: 2,
  trailingComma: 'all',
  proseWrap: 'always',
}
