curl -X POST http://localhost:1337/games/populate\?availability\=coming\&mediaType\=game&page=1\&sort\=popularity\?page\=1
curl -X POST http://localhost:1337/games/populate\?mediaType\=game\&page\=6\&price\=free\&sort\=release_desc


