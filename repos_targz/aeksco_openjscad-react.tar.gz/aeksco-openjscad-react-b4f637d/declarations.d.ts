declare module "@jscad/web/src/ui/umd.js";
