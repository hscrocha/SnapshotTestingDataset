// This is the mock output for the src path of a file
export default 'jest-mock-src';
