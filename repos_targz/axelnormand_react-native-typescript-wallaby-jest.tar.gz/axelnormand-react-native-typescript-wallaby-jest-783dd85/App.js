import React from 'react';
import App from './src/app/App';

/**
 * Create React Native App expects App.js to be in <root> folder
 * So just wrap our App.js in src/ here
 */
export default App;
