import { storiesOf } from '@storybook/react-native';
import React from 'react';
import App from './App';

storiesOf('App', module).add('normal render', () => <App />);
