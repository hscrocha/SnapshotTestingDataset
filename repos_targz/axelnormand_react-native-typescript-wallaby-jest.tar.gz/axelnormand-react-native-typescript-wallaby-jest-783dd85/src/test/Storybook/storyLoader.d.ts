export const stories: Array<string>;
export function loadStories(): void;
