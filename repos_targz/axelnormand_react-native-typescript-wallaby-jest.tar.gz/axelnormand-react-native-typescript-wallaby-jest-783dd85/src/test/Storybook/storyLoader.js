
// Auto-generated file created by react-native-storybook-loader
// Do not edit.
//
// https://github.com/elderfo/react-native-storybook-loader.git

function loadStories() {
  require('../../app/App/App.story');
  
}

const stories = [
  '../../app/App/App.story',
  
];

module.exports = {
  loadStories,
  stories,
};
