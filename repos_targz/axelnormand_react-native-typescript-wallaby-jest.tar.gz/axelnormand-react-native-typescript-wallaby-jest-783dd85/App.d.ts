declare const App: React.StatelessComponent<any>;
export default App;
