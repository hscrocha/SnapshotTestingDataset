/**
 * @module Polyfills
 * @desc Add support for older browsers.
 */
import 'core-js/stable';
import 'regenerator-runtime/runtime';
import 'react-app-polyfill/ie11';
import 'classlist-polyfill';
import 'events-polyfill/src/constructors/Event';
