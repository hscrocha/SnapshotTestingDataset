/**
 * Configuration
 * @module config
 */

const config = {
  name: 'React Redux Saga GitApp',
  description: 'GitApp with React and Redux with Redux Saga',
};

export default config;
