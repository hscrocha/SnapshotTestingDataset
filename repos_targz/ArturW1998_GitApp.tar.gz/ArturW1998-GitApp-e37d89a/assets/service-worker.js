console.log('Hello from service-worker.js');
