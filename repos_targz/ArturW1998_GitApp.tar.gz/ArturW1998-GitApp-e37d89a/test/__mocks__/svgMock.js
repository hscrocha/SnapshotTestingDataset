module.exports = { ReactComponent: () => 'SVG' };
