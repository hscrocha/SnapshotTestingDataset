// Return an object to emulate css modules (if you are using them)
module.exports = {};
