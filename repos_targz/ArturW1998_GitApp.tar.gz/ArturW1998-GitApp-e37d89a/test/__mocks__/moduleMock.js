// Return an object to mock a module
module.exports = () => {};
