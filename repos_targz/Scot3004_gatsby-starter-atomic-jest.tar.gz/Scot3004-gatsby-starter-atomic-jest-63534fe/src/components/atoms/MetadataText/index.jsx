import styled from 'styled-components';

export const MetadataText = styled.span`
  margin: 0 1rem 0 0.2rem;
  font-weight: lighter;
`;

export default MetadataText;
