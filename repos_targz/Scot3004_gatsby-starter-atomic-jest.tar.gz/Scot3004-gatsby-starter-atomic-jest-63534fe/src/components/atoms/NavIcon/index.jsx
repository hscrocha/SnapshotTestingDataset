import styled from 'styled-components';

export const NavIcon = styled.span``;

export default NavIcon;
