import styled from 'styled-components';

export const Excerpt = styled.p`
  margin: 0;
`;

export default Excerpt;
