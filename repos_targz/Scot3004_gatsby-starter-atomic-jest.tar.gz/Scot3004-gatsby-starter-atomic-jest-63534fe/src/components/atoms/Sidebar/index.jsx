import styled from 'styled-components';

export const Sidebar = styled.nav`
  grid-area: sidebar;
  min-width: 0;
`;

export default Sidebar;
