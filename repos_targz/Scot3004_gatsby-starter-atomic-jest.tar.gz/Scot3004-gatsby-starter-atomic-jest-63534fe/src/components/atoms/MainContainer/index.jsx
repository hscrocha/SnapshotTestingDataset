import styled from 'styled-components';

export const MainContainer = styled.main`
  grid-area: main;
  min-width: 0;
`;

export default MainContainer;
