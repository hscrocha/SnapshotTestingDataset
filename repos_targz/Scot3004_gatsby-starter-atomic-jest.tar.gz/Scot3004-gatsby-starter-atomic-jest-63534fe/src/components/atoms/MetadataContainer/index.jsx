import styled from 'styled-components';

export const MetadataContainer = styled.div`
  margin: 0 -1rem 0 0;
`;

export default MetadataContainer;
