const theme = {
  backgroundColor: '#f5f5f5',
  textColor: '#000',
  mutedColor: '#555',
  primaryColor: '#663399',
  visitedColor: '#402060'
};

export default theme;
