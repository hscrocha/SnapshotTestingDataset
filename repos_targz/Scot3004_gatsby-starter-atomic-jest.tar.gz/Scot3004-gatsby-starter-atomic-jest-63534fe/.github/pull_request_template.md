# Pull request

Closes #(numero de issue asociado)

## Observaciones

Colocar la información que considere pertinente del cambio que se está subiendo, por ejemplo una captura de pantalla si es algún cambio visual que quiera resaltar.
