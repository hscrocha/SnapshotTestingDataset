---
name: Solicitud de mejora
about: Encontraste algo que crees que debería tener el sitio web
---

# Solicitud de mejora en sitio web

Especifica como se puede implementar la mejora que sugieres para el sitio web.

## Ventajas

Que ventajas supone lo que estás sugiriendo a futuro.

## Desventajas

Cuales crees que podrían ser los inconvenientes que pueda ocasionar la implementación de lo que estás sugiriendo a futuro.
