---
name: Reporte de error
about: Genera un reporte de error para ayudarnos a mejorar
---

# Error en sitio web

## Comportamiento esperado

En esta zona escribe o adjunta una imagen de como debería funcionar el sitio web.

## Comportamiento actual

En esta zona escribe o adjunta una imagen de la salida actual que se observa del sitio web,
es preferible el uso de capturas de pantalla ademas de una descripción paso a paso de como reproducir el error.

## Pasos para reproducir el error

1.  En que url aparece el error.
2.  Definir paso a paso las acciones para reproducir el error.
3.  En este ejemplo se utiliza una lista numerada.
