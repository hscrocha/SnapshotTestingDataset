export interface IChallenge {
  open: boolean;
  link: string;
}
