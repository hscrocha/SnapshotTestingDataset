export interface IEvent {
  open: boolean;
  slido: string;
  link: string;
  name: string;
}
