const membersData = [
  {
    name: 'Wassef Ben Ahmed',
    description: 'writes code occasionally.',
    link: 'https://github.com/wassef911',
    img: 'https://avatars.githubusercontent.com/u/49594956?v=4',
  },
  {
    name: 'Safouene Turki',
    description: "if code is magic, i'm a wizard.",
    link: 'https://github.com/Safouene1',
    img: 'https://avatars.githubusercontent.com/u/22036449?v=4',
  },
  {
    name: 'Sabkhi',
    description: '',
    link: 'https://github.com/Medsabkhi21',
    img: 'https://avatars.githubusercontent.com/u/58121416?v=4',
  },
  {
    name: 'Ayoub Abidi',
    description: '',
    link: 'https://github.com/ayoub3bidi',
    img: 'https://avatars.githubusercontent.com/u/68862589?v=4',
  },
  {
    name: 'Firas Chabchoub',
    description: '',
    link: 'https://github.com/maxstain',
    img: 'https://avatars.githubusercontent.com/u/54244160?v=4',
  },
  {
    name: 'Ismail Zaidi',
    description: '',
    link: 'https://github.com/ismail-zaidi',
    img: 'https://avatars.githubusercontent.com/u/77702607?v=4',
  },
  {
    name: 'Rekik Chahine',
    description: '',
    link: 'https://github.com/RekikChahine',
    img: 'https://avatars.githubusercontent.com/u/58332328?v=4',
  },
  {
    name: 'Iheb Meftah',
    description: '',
    link: 'https://github.com/ihebmeftah',
    img: 'https://avatars.githubusercontent.com/u/78818443?v=4',
  },
  {
    name: 'Chaima Hamila',
    description: 'IT Student',
    link: 'https://github.com/Chaima-dev',
    img: 'https://avatars.githubusercontent.com/u/78934667?v=4',
  },
  {
    name: 'Ahmed Debbiche',
    description: '',
    link: 'https://github.com/Ahmed-Debbiche007',
    img: 'https://avatars.githubusercontent.com/u/62114253?v=4',
  },
  {
    name: 'Feiz Bn',
    description: '',
    link: 'https://github.com/FeizBN',
    img: 'https://avatars.githubusercontent.com/u/78981943?v=4',
  },

  {
    name: 'Mohamed Kamel Hamdouni',
    description: 'Web / Mobile Developer',
    link: 'https://github.com/medkamelhamdouni',
    img: 'https://avatars.githubusercontent.com/u/33313502?v=4',
  },
];
export default membersData;
