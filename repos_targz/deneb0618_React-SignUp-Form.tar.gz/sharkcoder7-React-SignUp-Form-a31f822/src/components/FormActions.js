import styled from '@emotion/styled';

const FormActions = styled.footer`
  margin-top: ${props => props.theme.spacing * 3}rem;
`;

export default FormActions;
