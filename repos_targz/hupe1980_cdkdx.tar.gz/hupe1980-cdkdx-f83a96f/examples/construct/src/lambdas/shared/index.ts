export const shared = 'SHARED';
