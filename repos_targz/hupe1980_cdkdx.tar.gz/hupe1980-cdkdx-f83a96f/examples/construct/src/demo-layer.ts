import * as crypto from 'crypto';
import * as fs from 'fs';
import * as path from 'path';
import * as lambda from '@aws-cdk/aws-lambda';
import { Construct } from '@aws-cdk/core';

/**
 * A demo Lambda layer.
 */
export class DemoLayer extends lambda.LayerVersion {
  constructor(scope: Construct, id: string) {
    super(scope, id, {
      code: lambda.Code.fromAsset(path.join(__dirname, 'layers', 'demo', 'layer.zip'), {
        // we hash the Dockerfile (it contains the tools versions) because hashing the zip is non-deterministic
        assetHash: hashFile(path.join(__dirname, 'layers', 'demo', 'Dockerfile')),
      }),
      description: '/opt/demo',
    });
  }
}

function hashFile(fileName: string) {
  return crypto.createHash('sha256').update(fs.readFileSync(fileName)).digest('hex');
}
