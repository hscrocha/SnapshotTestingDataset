import React from 'react'

const App =() => {
    return (
        <div>
            <span>Hello World</span>
        </div>
    )
}

export default App;