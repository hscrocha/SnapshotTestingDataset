# ${name}

> ${description}

## API Reference

See [API.md](API.md).

## License

[MIT](LICENCE)