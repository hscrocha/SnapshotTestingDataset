declare module 'standard-version';

declare module 'size-plugin';
