# eslint-config-cdk
> ESLint configuration used by cdkdx

:warning: This is experimental and subject to breaking changes.

## Install

```sh
yarn add -D eslint-config-cdk
```

## License

[MIT](LICENSE)
