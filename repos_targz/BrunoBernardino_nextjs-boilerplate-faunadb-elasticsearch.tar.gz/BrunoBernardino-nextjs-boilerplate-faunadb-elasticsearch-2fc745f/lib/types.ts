export type Product = {
  _id?: string;
  name: string;
  slug: string;
  price: number;
  views: number;
};
