import styled from 'styled-components/macro'
import { Col } from 'react-bootstrap'

export default styled(Col)`
  width: 100%;
  padding-left: 5px;
`
