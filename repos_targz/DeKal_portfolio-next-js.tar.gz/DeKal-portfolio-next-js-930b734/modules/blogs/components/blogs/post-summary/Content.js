import styled from 'styled-components/macro'

export default styled.div`
  height: 100%;
  width: 100%;
`
