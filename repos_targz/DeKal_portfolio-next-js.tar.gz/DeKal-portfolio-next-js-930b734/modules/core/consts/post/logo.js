export const REDIRECT_LINK = '/blogs'
export const LOGO_IMAGE = '/images/logo.png'
