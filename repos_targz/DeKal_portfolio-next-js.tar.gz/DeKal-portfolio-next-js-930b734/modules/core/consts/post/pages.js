export const HOME = 'Home'
export const BLOG = 'Blogs'

export const PAGE_LIST = [
  {
    name: HOME,
    url: `/`
  },
  {
    name: BLOG,
    url: `/blogs`
  }
]
