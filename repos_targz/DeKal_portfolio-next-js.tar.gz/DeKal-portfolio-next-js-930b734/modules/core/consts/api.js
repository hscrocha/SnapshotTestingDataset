export const API_END_POINT = 'https://blog-illuminati.herokuapp.com/api'
