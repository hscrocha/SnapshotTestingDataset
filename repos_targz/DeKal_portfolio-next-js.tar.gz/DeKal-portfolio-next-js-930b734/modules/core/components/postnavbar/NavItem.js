import styled from 'styled-components/macro'
import Nav from 'react-bootstrap/Nav'

export default styled(Nav.Link)`
  font-size: 18px;
`
