import styled from 'styled-components/macro'

const Title = styled.h4`
  text-transform: uppercase;
  font-weight: bold;
`
export default Title
