import styled from 'styled-components/macro'

const Bold = styled.b`
  font-weight: bold;
`

export default Bold
