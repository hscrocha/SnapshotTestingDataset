import styled from 'styled-components/macro'

const Title = styled.h4`
  margin-bottom: 10px;
`

export default Title
