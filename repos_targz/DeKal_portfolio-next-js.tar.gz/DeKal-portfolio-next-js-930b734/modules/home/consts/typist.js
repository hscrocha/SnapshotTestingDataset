export const MAX_LIMIT = 999999999999
export const SEC_PER_TURN = 3
export const START_COUNT = 0
export const INTERVAL = 1000
