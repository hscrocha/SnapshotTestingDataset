export const COMPANIES = [
  { name: 'Zalora', icon: '/images/companies/zalora.webp' },
  { name: 'Dek', icon: '/images/companies/dek.webp' },
  { name: 'GCS', icon: '/images/companies/gcs.webp' },
  { name: 'GCS-intern', icon: '/images/companies/gcs.webp' }
]
