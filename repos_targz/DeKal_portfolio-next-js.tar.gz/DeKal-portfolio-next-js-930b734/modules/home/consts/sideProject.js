const row1 = ['BootCareer-FE', 'BootCareer-BE']
const row2 = ['Portfolio-FE', 'Portfolio-BE']
const row3 = ['Popswap', 'LiveGuess']

export const getProjects = () => [row1, row2, row3]
