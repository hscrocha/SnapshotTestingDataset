import { HOME } from '~/modules/home/consts/pages'
import { EN } from '~/modules/home/consts/langs'

export const INIT_NAV_CONTENT_SHOW = false
export const INIT_SELECTED_PAGE = HOME
export const INIT_SELECTED_LANG = EN
