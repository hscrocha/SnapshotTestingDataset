export const photos = [
  {
    src: '/images/projects/zalora.webp',
    width: 2,
    height: 4,
    title: 'Zalora Lite'
  },
  {
    src: '/images/projects/popswap.webp',
    width: 2,
    height: 4,
    title: 'Popswap'
  },
  {
    src: '/images/projects/bootcareer.webp',
    width: 7,
    height: 4,
    title: 'Bootcareer Jobseeker'
  },
  {
    src: '/images/projects/brand360.webp',
    width: 6,
    height: 5,
    title: 'Brand360 project'
  },
  {
    src: '/images/projects/taman.webp',
    width: 3,
    height: 2,
    title: 'Tam An Web'
  },
  {
    src: '/images/projects/2048.webp',
    width: 6,
    height: 6,
    title: '2048 Fun Games'
  }
]
