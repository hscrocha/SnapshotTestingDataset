export const EN = 'en'
export const VN = 'vn'
