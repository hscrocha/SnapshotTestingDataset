import styled from 'styled-components/macro'
import Row from 'react-bootstrap/Row'

export default styled(Row)`
  margin-top: ${props => props.theme.marginFromContent};
`
