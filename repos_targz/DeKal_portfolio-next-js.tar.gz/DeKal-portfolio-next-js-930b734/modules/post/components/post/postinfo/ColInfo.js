import styled from 'styled-components/macro'
import Col from 'react-bootstrap/Col'

export default styled(Col)`
  display: block;
  width: 100%;
  padding-left: 12px;
`
