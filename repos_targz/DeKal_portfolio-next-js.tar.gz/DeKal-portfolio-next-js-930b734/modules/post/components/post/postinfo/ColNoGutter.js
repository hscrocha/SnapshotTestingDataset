import styled from 'styled-components/macro'
import Col from 'react-bootstrap/Col'

export default styled(Col)`
  padding-left: 0;
  padding-right: 0;
`
