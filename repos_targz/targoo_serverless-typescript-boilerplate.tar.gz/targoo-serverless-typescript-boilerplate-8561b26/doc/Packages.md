| serverless-apigw-binary | This Serverless plugin automates the process of adding binary files support in API Gateway |

- graphql-tools
- inherits
- stripe
- @types/stripe
