declare module 'nanoid/generate' {
  export default function generate(alphabet: string, size: number): string;
}
