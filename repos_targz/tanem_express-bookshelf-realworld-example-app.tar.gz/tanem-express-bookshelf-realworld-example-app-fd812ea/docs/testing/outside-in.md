# Outside-In

The preference is to create high-level tests first in order to test the API end-to-end from a user’s perspective. From there we can drop down into lower-level tests like unit tests (this hasn't yet been done in this repo). See [Testing from the Outside-In](https://robots.thoughtbot.com/testing-from-the-outsidein) for more information.
