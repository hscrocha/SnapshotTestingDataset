# Table of Contents

## Structure

- [Group by Coupling](structure/group-by-coupling.md)
- [Initializers](structure/initializers.md)
- [Configuration](structure/configuration.md)

## Testing

- [Outside-In](testing/outside-in.md)
- [Run in Band](testing/run-in-band.md)
- [Prefer Snapshot Tests](testing/prefer-snapshot-tests.md)
