'use strict';

const config = require('./');

module.exports = config.get('db');
