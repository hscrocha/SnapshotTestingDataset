import React from 'react';

const SvgMock: React.FC<unknown> = (): JSX.Element => {
  return <></>;
};

export default SvgMock;
