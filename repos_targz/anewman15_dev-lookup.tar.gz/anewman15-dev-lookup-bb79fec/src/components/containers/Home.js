import UserInfo from './UserInfo';

const Home = () => (
  <div className="Home">
    <UserInfo />
  </div>
);

export default Home;
