export const confirmUserPrefix = 'user-confirmation:';
export const forgotPasswordPrefix = 'forgot-password:';
