import React from 'react';

export const HomePage=() => <h1>Home page</h1>