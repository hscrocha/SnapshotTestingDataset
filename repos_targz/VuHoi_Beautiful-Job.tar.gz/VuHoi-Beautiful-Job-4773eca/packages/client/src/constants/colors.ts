export const mainColor = '#73acf7';
export const footerColor = '#2c3777';
export const secondaryColor = '#ffffff';
export const borderColor = '#DADADA';
export const backgroundColor = '#E9EBEE';
