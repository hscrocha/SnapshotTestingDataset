export type User = Partial<{
	phone: String;
	email: String;
	avatar: String;
	name: String;
	role: String;
	isActived: Boolean;
	firstName: String;
	lastName: String;
	middleName: String;
}>;
