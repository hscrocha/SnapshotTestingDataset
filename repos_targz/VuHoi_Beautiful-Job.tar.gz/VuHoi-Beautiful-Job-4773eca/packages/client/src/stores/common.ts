import { createStore } from 'easy-peasy';
import { homeStore } from './home.store';

export const store = createStore({
	homeStore
});
