import React from 'react';
import GitHubIcon from '@mui/icons-material/GitHub';
import { arrayOf, objectOf } from 'prop-types';
import {
  GridItem,
  Icon,
  Image, ItemText, ItemTitle, Link,
  LinksUl,
  PortfolioImageContainer,
  PortfolioProjectsContainer,
  ProjectContent,
} from './Styled';

function PortfolioProjects({ projectsToDisplay }) {
  return (
    <PortfolioProjectsContainer>
      {
        projectsToDisplay.map((project) => (
          <GridItem key={project.id}>
            <ProjectContent>
              <PortfolioImageContainer>
                <Image src={project.image} alt="" />
                <LinksUl>
                  <Link href=" ">
                    <Icon href={project.link1}>
                      <GitHubIcon />
                    </Icon>
                  </Link>
                </LinksUl>
              </PortfolioImageContainer>
              <ItemTitle>
                {project.title}
              </ItemTitle>
              <ItemText>
                {project.text}
              </ItemText>
            </ProjectContent>
          </GridItem>
        ))
      }
    </PortfolioProjectsContainer>
  );
}

PortfolioProjects.propTypes = {
  projectsToDisplay: arrayOf(objectOf).isRequired,
};

export default PortfolioProjects;
