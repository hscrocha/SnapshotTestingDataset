import styled from 'styled-components';

export const FilterButtonsTitleContainer = styled.div`
  display: flex;
  justify-content: center;
`;

export const H6 = styled.h6`

`;
