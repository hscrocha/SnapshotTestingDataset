import React from 'react';
import HomePageComponent from '../components/HomePageComponent/HomePageComponent';

function HomePage() {
  return (
    <HomePageComponent />
  );
}

export default HomePage;
