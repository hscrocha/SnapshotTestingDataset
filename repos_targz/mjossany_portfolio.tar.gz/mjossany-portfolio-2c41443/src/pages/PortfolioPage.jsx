import React from 'react';
import PortfolioPageComponent from '../components/PortfolioPageComponent/PortfolioPageComponent';

function PortfolioPage() {
  return (
    <PortfolioPageComponent />
  );
}

export default PortfolioPage;
