import React from 'react';
import ContactPageComponent from '../components/ContactPageComponent/ContactPageComponent';

function ContactPage() {
  return (
    <ContactPageComponent />
  );
}

export default ContactPage;
