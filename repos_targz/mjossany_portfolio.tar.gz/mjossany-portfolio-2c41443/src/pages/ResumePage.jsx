import React from 'react';
import ResumePageComponent from '../components/ResumePageComponent/ResumePageComponent';

function ResumePage() {
  return (
    <ResumePageComponent />
  );
}

export default ResumePage;
