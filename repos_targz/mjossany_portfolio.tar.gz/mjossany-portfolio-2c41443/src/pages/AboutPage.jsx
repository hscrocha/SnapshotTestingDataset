import React from 'react';
import AboutPageComponent from '../components/AboutPageComponent/AboutPageComponent';

function AboutPage() {
  return (
    <AboutPageComponent />
  );
}

export default AboutPage;
