import React from 'react';
import BlogsPageComponent from '../components/BlogsPageComponent/BlogsPageComponent';

function BlogsPage() {
  return (
    <BlogsPageComponent />
  );
}

export default BlogsPage;
