import blog1 from '../images/blogs/blog1.jpeg';

const blogs = [
  {
    id: 1,
    title: 'A little about me and how I discovered development',
    date: '15',
    month: 'October',
    image: blog1,
    link: 'https://medium.com/@jossanymoura/a-little-about-me-and-how-i-discovered-development-167e5bcbc713',
  },
];

export default blogs;
