module.exports = {
  displayName: 'Client',
  verbose: true,
  browser: true,
  setupTestFrameworkScriptFile: './jest-setup-framework.js',
};
