# My React Stack

Using React, Express, Babel, Jest and Webpack

### Easy setup 1, 2, 3...
1) `npm install`
2) `npm run build` or `npm run dev`
3) `npm start`

### Notes
- `npm test`
- `STEPBYSTEP.md` includes the log of this build
- `src/server/index.js` Startup file to configure the localhost port for express