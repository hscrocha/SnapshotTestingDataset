import {createText} from '@shopify/restyle';
import {Theme} from 'styles/theme';

const Text = createText<Theme>();

export default Text;
