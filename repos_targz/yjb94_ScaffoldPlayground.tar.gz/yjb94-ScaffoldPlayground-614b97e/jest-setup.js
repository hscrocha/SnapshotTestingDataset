require('react-native-reanimated/lib/reanimated2/jestUtils').setUpTests();
