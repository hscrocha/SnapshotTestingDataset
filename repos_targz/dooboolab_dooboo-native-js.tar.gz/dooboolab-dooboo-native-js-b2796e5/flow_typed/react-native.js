declare module 'react-native' { declare var exports: any; }
declare module 'jest' { declare var exports: any; }
