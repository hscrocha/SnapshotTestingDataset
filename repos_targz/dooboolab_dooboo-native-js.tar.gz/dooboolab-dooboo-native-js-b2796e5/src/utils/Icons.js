export const IC_MASK = require('../../assets/icons/mask.png');
