export type User = {
  displayName: string,
  age: number,
  job: string,
};
