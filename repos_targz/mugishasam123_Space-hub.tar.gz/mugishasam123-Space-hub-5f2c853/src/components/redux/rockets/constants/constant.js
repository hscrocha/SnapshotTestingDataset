export const ADD_ROCKETS = 'spacehub/rockets/ADD_ROCKETS';
export const RESERVE_ROCKETS = 'spacehub/rockets/RESERVE_ROCKETS';
export const CANCEL_ROCKETS = 'spacehub/rockets/CANCEL_ROCKETS';
