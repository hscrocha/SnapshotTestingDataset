export default {
    baseURL: 'http://react-cdp-api.herokuapp.com/movies'
};
