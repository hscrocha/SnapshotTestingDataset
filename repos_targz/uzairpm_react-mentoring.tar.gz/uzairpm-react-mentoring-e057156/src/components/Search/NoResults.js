import React from 'react';

const NoResults = (props) => {
    return (
        <h1 className="display-3 text-center mt-5">No films found</h1>
    );
};
export default NoResults;
