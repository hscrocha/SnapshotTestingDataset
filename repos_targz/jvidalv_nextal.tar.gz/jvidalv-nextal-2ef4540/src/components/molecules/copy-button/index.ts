import CopyButton from "./copy-button";

export default CopyButton;
