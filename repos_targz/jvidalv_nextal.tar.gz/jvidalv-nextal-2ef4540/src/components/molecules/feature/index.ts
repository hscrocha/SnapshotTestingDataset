import Feature from "./feature";
export type { FeatureProps } from "./feature";

export default Feature;
