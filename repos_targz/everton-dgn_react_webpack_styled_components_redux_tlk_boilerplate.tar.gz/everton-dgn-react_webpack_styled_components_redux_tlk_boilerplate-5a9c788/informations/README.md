# Edit svg like diagrams

---

Edit svg files with draw.io program or edit directly in your ide with plugins:

- Visual Studio Code: https://marketplace.visualstudio.com/items?itemName=hediet.vscode-drawio
- Webstorm: https://plugins.jetbrains.com/plugin/15635-diagrams-net-integration
