export const spacings = {
  xxSmall: '4px',
  xSmall: '8px',
  small: '12px',
  medium: '16px',
  large: '20px',
  xLarge: '24px',
  xxLarge: '28px',
  xxxLarge: '32px',
  xtreme: '40px'
}
