import { ReactNode } from 'react'

export type ThemeProvidersProps = { children: ReactNode }
