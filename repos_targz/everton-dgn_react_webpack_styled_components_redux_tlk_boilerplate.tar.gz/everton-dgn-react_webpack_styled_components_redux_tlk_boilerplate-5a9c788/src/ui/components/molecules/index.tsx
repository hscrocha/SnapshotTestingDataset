export { default as TitleAnimation } from './TitleAnimation'
