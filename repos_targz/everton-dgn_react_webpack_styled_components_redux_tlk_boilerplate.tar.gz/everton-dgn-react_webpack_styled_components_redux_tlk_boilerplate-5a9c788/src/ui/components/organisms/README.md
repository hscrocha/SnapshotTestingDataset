# Insert organisms into this directory

---

Insert organisms into this directory (combination of molecules/molecules or molecules/atoms) and export in the index file of the root of the components folder
