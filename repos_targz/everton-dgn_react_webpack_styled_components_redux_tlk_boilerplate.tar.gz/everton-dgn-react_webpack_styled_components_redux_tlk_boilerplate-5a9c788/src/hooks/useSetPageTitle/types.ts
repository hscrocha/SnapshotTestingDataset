export type UseSetPageTitleProps = {
  pageTitle: string
}
