export type UseAnimationRenderType = {
  isRenderComponent: boolean
  isVisible: boolean
  changeStateComponent: () => void
}
