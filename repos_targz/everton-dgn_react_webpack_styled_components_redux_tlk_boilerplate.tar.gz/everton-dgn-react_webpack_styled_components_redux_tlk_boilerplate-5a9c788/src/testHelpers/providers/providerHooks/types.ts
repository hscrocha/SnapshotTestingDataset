import { ReactNode } from 'react'

export type WrapperProps = {
  children: ReactNode
}

export type RenderHooksProviderProps = () => any
