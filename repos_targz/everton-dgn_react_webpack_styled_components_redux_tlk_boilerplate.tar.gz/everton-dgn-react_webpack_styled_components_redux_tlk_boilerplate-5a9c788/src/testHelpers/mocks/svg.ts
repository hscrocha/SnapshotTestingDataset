export const ReactComponent = 'div'
const svg = 'svg'
export default svg
