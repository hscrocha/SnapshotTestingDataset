export { default } from './ThemeSwitch';
