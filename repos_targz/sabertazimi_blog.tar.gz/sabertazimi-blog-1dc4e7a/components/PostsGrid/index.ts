export { default } from './PostsGrid';
