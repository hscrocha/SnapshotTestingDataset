import { Pre } from '@components/CodeBlocks';

interface Props {}

const MDXPre = (props: Props) => <Pre {...props} />;

export default MDXPre;
