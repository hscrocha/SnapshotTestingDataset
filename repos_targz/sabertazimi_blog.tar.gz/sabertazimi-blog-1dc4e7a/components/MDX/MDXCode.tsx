import { InlineCode } from '@components/CodeBlocks';

interface Props {}

const MDXCode = (props: Props) => <InlineCode {...props} />;

export default MDXCode;
