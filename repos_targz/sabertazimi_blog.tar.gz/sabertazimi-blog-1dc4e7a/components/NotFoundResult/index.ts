export { default } from './NotFoundResult';
