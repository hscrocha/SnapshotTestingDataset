export { default } from './PostsList';
