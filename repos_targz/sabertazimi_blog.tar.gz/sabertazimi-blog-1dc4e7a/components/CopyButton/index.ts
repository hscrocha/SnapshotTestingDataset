export { default } from './CopyButton';
