export { Input as default } from 'antd';
