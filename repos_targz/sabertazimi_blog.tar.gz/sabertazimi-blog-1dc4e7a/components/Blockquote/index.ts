export { default } from './Blockquote';
