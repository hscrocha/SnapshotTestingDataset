export { Badge as default } from 'antd';
