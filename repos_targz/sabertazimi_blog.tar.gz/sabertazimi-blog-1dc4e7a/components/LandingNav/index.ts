export { default } from './LandingNav';
