export { default } from './Col';
