export { default } from './PostsSearchBar';
