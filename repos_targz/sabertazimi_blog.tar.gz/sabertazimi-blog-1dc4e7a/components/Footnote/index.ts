export { default } from './Footnote';
