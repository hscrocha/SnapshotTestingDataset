import Text from './Text';

interface Props {}

const Delete = (props: Props): JSX.Element => <Text {...props} delete />;

export default Delete;
