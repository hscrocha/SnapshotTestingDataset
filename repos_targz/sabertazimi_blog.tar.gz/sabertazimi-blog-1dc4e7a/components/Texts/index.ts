export { default as Anchor } from './Anchor';
export { default as Delete } from './Delete';
export { default as Emphasis } from './Emphasis';
export { default as Span } from './Span';
export { default as Strong } from './Strong';
export { default as Text } from './Text';
