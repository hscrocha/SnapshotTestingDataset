import Text from './Text';

interface Props {}

const Strong = (props: Props): JSX.Element => <Text {...props} strong />;

export default Strong;
