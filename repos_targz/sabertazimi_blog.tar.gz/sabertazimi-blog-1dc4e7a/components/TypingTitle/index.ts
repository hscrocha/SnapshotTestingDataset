export { default } from './TypingTitle';
