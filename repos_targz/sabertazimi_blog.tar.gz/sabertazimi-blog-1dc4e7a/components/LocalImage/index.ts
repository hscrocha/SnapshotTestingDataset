export { default } from './LocalImage';
