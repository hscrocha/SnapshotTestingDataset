#!/usr/bin/env node

require('./cli');
