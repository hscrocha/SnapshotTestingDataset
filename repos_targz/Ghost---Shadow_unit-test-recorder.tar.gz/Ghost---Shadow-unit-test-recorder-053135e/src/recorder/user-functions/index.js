const { recorderWrapper } = require('./wrapper');

module.exports = { recorderWrapper };
