const { mockRecorderWrapper } = require('./wrapper');

module.exports = {
  mockRecorderWrapper,
};
