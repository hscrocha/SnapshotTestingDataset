#!/usr/bin/env ts-node

require('./cli');
