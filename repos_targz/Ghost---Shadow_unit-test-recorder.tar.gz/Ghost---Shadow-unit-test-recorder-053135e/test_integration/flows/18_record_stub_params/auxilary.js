const fun = a => a;
module.exports = { fun };
