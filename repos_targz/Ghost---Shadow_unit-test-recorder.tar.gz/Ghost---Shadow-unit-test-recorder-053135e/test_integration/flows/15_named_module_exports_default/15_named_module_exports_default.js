const foo = a => a;

module.exports = foo;
