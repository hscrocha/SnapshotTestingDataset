module.exports = a => a;
