export default (a, b) => a + b;
