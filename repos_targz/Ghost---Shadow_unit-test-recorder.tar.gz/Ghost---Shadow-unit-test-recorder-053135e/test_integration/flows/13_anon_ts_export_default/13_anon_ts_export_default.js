exports.default = (a, b) => a + b;
