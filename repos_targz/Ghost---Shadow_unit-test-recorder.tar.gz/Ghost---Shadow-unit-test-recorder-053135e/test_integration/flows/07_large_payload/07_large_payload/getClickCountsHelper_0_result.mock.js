module.exports = [
  {
    clicks: 0,
    imageId: 0
  },
  {
    clicks: 100,
    imageId: 1
  },
  {
    clicks: 200,
    imageId: 2
  },
  {
    clicks: 300,
    imageId: 3
  },
  {
    clicks: 400,
    imageId: 4
  },
  {
    clicks: 500,
    imageId: 5
  },
  {
    clicks: 600,
    imageId: 6
  },
  {
    clicks: 700,
    imageId: 7
  },
  {
    clicks: 800,
    imageId: 8
  },
  {
    clicks: 900,
    imageId: 9
  },
  {
    clicks: 1000,
    imageId: 10
  },
  {
    clicks: 1100,
    imageId: 11
  },
  {
    clicks: 1200,
    imageId: 12
  },
  {
    clicks: 1300,
    imageId: 13
  },
  {
    clicks: 1400,
    imageId: 14
  },
  {
    clicks: 1500,
    imageId: 15
  },
  {
    clicks: 1600,
    imageId: 16
  },
  {
    clicks: 1700,
    imageId: 17
  },
  {
    clicks: 1800,
    imageId: 18
  },
  {
    clicks: 1900,
    imageId: 19
  },
  {
    clicks: 2000,
    imageId: 20
  },
  {
    clicks: 2100,
    imageId: 21
  },
  {
    clicks: 2200,
    imageId: 22
  },
  {
    clicks: 2300,
    imageId: 23
  },
  {
    clicks: 2400,
    imageId: 24
  },
  {
    clicks: 2500,
    imageId: 25
  },
  {
    clicks: 2600,
    imageId: 26
  },
  {
    clicks: 2700,
    imageId: 27
  },
  {
    clicks: 2800,
    imageId: 28
  },
  {
    clicks: 2900,
    imageId: 29
  },
  {
    clicks: 3000,
    imageId: 30
  },
  {
    clicks: 3100,
    imageId: 31
  },
  {
    clicks: 3200,
    imageId: 32
  },
  {
    clicks: 3300,
    imageId: 33
  },
  {
    clicks: 3400,
    imageId: 34
  },
  {
    clicks: 3500,
    imageId: 35
  },
  {
    clicks: 3600,
    imageId: 36
  },
  {
    clicks: 3700,
    imageId: 37
  },
  {
    clicks: 3800,
    imageId: 38
  },
  {
    clicks: 3900,
    imageId: 39
  },
  {
    clicks: 4000,
    imageId: 40
  },
  {
    clicks: 4100,
    imageId: 41
  },
  {
    clicks: 4200,
    imageId: 42
  },
  {
    clicks: 4300,
    imageId: 43
  },
  {
    clicks: 4400,
    imageId: 44
  },
  {
    clicks: 4500,
    imageId: 45
  },
  {
    clicks: 4600,
    imageId: 46
  },
  {
    clicks: 4700,
    imageId: 47
  },
  {
    clicks: 4800,
    imageId: 48
  },
  {
    clicks: 4900,
    imageId: 49
  },
  {
    clicks: 5000,
    imageId: 50
  },
  {
    clicks: 5100,
    imageId: 51
  },
  {
    clicks: 5200,
    imageId: 52
  },
  {
    clicks: 5300,
    imageId: 53
  },
  {
    clicks: 5400,
    imageId: 54
  },
  {
    clicks: 5500,
    imageId: 55
  },
  {
    clicks: 5600,
    imageId: 56
  },
  {
    clicks: 5700,
    imageId: 57
  },
  {
    clicks: 5800,
    imageId: 58
  },
  {
    clicks: 5900,
    imageId: 59
  },
  {
    clicks: 6000,
    imageId: 60
  },
  {
    clicks: 6100,
    imageId: 61
  },
  {
    clicks: 6200,
    imageId: 62
  },
  {
    clicks: 6300,
    imageId: 63
  },
  {
    clicks: 6400,
    imageId: 64
  },
  {
    clicks: 6500,
    imageId: 65
  },
  {
    clicks: 6600,
    imageId: 66
  },
  {
    clicks: 6700,
    imageId: 67
  },
  {
    clicks: 6800,
    imageId: 68
  },
  {
    clicks: 6900,
    imageId: 69
  },
  {
    clicks: 7000,
    imageId: 70
  },
  {
    clicks: 7100,
    imageId: 71
  },
  {
    clicks: 7200,
    imageId: 72
  },
  {
    clicks: 7300,
    imageId: 73
  },
  {
    clicks: 7400,
    imageId: 74
  },
  {
    clicks: 7500,
    imageId: 75
  },
  {
    clicks: 7600,
    imageId: 76
  },
  {
    clicks: 7700,
    imageId: 77
  },
  {
    clicks: 7800,
    imageId: 78
  },
  {
    clicks: 7900,
    imageId: 79
  },
  {
    clicks: 8000,
    imageId: 80
  },
  {
    clicks: 8100,
    imageId: 81
  },
  {
    clicks: 8200,
    imageId: 82
  },
  {
    clicks: 8300,
    imageId: 83
  },
  {
    clicks: 8400,
    imageId: 84
  },
  {
    clicks: 8500,
    imageId: 85
  },
  {
    clicks: 8600,
    imageId: 86
  },
  {
    clicks: 8700,
    imageId: 87
  },
  {
    clicks: 8800,
    imageId: 88
  },
  {
    clicks: 8900,
    imageId: 89
  },
  {
    clicks: 9000,
    imageId: 90
  },
  {
    clicks: 9100,
    imageId: 91
  },
  {
    clicks: 9200,
    imageId: 92
  },
  {
    clicks: 9300,
    imageId: 93
  },
  {
    clicks: 9400,
    imageId: 94
  },
  {
    clicks: 9500,
    imageId: 95
  },
  {
    clicks: 9600,
    imageId: 96
  },
  {
    clicks: 9700,
    imageId: 97
  },
  {
    clicks: 9800,
    imageId: 98
  },
  {
    clicks: 9900,
    imageId: 99
  }
];
