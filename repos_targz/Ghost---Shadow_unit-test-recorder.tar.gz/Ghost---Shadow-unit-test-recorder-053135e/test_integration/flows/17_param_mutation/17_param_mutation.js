const fun = (a) => {
  a[0] += 1;
  return a;
};

module.exports = { fun };
