# Coinfilter

A React application for tracking and learning about cryptocurrencies.

[See live demo](https://coinfilter-mjmzvdcuyc.now.sh)

This is an experiment using the following:

- Flow
- Redux
- Redux Saga
- Styled Components
- Jest
- Enzyme

Bootstrapped with [Create React App](https://github.com/facebookincubator/create-react-app).