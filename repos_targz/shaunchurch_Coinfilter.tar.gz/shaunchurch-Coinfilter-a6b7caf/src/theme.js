export default {
  red: '#CD5360',
  green: '#4ABDAC'
};

// export default {
//   red: '#FC4A1A',
//   green: '#4ABDAC'
// };
