
# Expect custom message example

## Installation

```
yarn
```

## Running test

```
yarn test
```