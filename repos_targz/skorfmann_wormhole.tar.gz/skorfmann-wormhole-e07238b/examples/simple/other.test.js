jest.setTimeout(10000)

describe('OtherRequest', () => {
  it('handles something', () => {
    const foo = true
    expect(foo).toBe(true)
  });
});