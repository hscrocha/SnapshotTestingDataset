import styled from 'styled-components';

const Content = styled.div`
  width: 80%;
`;

export default Content;
