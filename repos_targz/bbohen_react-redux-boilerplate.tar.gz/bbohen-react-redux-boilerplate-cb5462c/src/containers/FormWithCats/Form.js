import styled from 'styled-components';

const Form = styled.form`
  margin: 0 auto;
  width: 75%;
`;

export default Form;
