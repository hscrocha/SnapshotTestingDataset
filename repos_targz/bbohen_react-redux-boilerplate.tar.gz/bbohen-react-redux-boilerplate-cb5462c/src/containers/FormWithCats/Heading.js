import styled from 'styled-components';

import { Heading } from 'components';

const CatFormHeading = styled(Heading)`
  margin-bottom: 1em;
`;

export default CatFormHeading;
