import styled from 'styled-components';

const NavigationItem = styled.li`
  margin: .3em .5em 0 .5em;
`;

export default NavigationItem;
