export cats from './cats';
export loremIpsum from './loremIpsum';
