import styled from 'styled-components';

const Content = styled.div`
  background: white;
  padding: 2em;
  width: 40%;
`;

export default Content;
