import React from 'react';

import Heading from '../Heading';

const NotFound = () => (
  <Heading>Not Found!</Heading>
);

export default NotFound;
