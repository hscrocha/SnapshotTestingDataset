### Todo

* dynamic theming with light/dark theme
* make the boilerplate more fun to use and attractive
* update, organize and optimize webpack usage
* lighthouse / PWA?
* beef up the readme
* put it on github pages
