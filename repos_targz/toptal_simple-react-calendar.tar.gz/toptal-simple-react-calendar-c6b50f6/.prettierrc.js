module.exports = {
  ...require('@toptal/davinci-syntax/src/configs/.prettierrc.js')
}
