export { default } from './Notice'
