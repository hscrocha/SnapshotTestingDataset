export const BLOCK_CLASS_NAME = 'calendar'
export const NEXT_MONTH_TITLE = 'Next month'
export const PREV_MONTH_TITLE = 'Previous month'
export const DAYS_IN_WEEK = [0, 1, 2, 3, 4, 5, 6]
export const DAYS_OF_WEEK = ['Mon', 'Tue', 'Wed', 'Thu', 'Fri', 'Sat', 'Sun']
