// This file is for setting up Jest test environments
afterEach(() => {
  jest.clearAllMocks()
})
