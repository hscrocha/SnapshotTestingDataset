module.exports = require('lundle').babelConfig('test', {
  typescript: false,
  react: true,
})
