import styled from 'styled-components';

const TestComponent = styled.div`
  color: green;
`;

export default TestComponent;
