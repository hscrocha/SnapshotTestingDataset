// add actions of the newly created container here.
import * as home from '@containers/home/action';
import * as app from '@containers/app/action';

export default { home, app }; // exports all the actions.
