// write all common functionalities and variables here
const Common = {};

export default Common;
