// TEST
export const TEST = 'TEST';
export const TEST_ERROR = 'TEST_ERROR';
export const TEST_SUCCESS = 'TEST_SUCCESS';
export const TEST_CANCEL = 'TEST_CANCEL';
// -------------

// HOME_TEST
export const HOME_TEST = 'HOME_TEST';
export const HOME_TEST_ERROR = 'HOME_TEST_ERROR';
export const HOME_TEST_SUCCESS = 'HOME_TEST_SUCCESS';
export const HOME_TEST_CANCEL = 'HOME_TEST_CANCEL';
// --------------

export const RESET = 'RESET';
