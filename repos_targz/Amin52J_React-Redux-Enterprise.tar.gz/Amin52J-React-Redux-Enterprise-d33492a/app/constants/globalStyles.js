export default `
  html {
    body {
      overflow-x: hidden;
    }
  }
`;
