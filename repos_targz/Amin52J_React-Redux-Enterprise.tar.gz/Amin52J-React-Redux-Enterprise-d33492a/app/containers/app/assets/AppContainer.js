import styled from 'styled-components';

const AppContainer = styled.div``;

export default AppContainer;
