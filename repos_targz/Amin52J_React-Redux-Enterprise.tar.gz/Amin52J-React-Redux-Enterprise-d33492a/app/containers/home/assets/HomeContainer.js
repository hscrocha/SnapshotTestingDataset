import styled from 'styled-components';

const HomeContainer = styled.div`
  color: red;
`;

export default HomeContainer;
