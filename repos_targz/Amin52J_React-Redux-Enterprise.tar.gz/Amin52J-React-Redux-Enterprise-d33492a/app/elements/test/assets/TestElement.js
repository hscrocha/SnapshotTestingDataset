import styled from 'styled-components';

const TestElement = styled.div`
  color: blue;
`;

export default TestElement;
