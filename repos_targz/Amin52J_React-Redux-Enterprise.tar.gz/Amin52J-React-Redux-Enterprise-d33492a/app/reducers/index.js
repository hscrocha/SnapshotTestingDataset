// add all new reducers here to export
export { default as home } from '@containers/home/reducer';
export { default as app } from '@containers/app/reducer';
