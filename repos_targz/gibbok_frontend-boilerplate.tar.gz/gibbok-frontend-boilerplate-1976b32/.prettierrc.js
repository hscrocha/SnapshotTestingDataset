module.exports = {
    singleQuote: true,
  };
