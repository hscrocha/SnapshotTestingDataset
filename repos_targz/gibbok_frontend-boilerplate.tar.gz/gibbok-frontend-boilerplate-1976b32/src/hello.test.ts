describe('hello', () => {
  it('should say hello', () => {
    expect('Hello world!').toBe('Hello world!');
  });
});
