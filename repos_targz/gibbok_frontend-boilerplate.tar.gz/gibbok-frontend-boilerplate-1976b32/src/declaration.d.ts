declare module '*.png';
declare module '*.gif';
declare module '*.svg';
declare module '*.jpg';
declare module '*.svg';
