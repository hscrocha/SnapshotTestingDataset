export const test: string;
