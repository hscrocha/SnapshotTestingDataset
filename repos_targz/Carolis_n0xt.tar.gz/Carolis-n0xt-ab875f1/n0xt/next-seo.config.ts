export default {
    openGraph: {
      type: 'website',
      locale: 'en_US',
      url: 'whatever.com',
      site_name: 'Cool Recipes'
    },
    twitter: {
      handle: '@caroliscaroles',
      site: '@site',
      cardType: 'summary_large_image'
    }
  }
  