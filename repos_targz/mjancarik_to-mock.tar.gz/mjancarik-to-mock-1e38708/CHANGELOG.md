<a name="1.6.2"></a>
## [1.6.2](https://github.com/mjancarik/to-mock/compare/1.6.1...1.6.2) (2020-02-14)


### Bug Fixes

* problem with exhausting memory and cpu for mocking prototype chain ([b698b62](https://github.com/mjancarik/to-mock/commit/b698b62))



<a name="1.6.1"></a>
## [1.6.1](https://github.com/mjancarik/to-mock/compare/1.6.0...1.6.1) (2020-02-06)


### Bug Fixes

* all mocks created from toMockedInstance have got mocked methods ([c2e685d](https://github.com/mjancarik/to-mock/commit/c2e685d))



<a name="1.6.0"></a>
# [1.6.0](https://github.com/mjancarik/to-mock/compare/1.5.5...1.6.0) (2020-01-16)


### Bug Fixes

* original class constructor prototype is cloned ([a7b2c4f](https://github.com/mjancarik/to-mock/commit/a7b2c4f))



<a name="1.5.5"></a>
## [1.5.5](https://github.com/mjancarik/to-mock/compare/1.5.4...1.5.5) (2020-01-01)



<a name="1.5.4"></a>
## [1.5.4](https://github.com/mjancarik/to-mock/compare/1.5.3...1.5.4) (2019-06-10)



<a name="1.5.3"></a>
## [1.5.3](https://github.com/mjancarik/to-mock/compare/1.5.2...1.5.3) (2019-05-19)



<a name="1.5.2"></a>
## [1.5.2](https://github.com/mjancarik/to-mock/compare/1.5.1...1.5.2) (2019-04-18)



<a name="1.5.1"></a>
## [1.5.1](https://github.com/mjancarik/to-mock/compare/1.5.0...1.5.1) (2019-03-23)



<a name="1.5.0"></a>
# [1.5.0](https://github.com/mjancarik/to-mock/compare/1.4.1...1.5.0) (2019-03-10)


### Features

* **unmock:** added new method objectKeepUnmock ([f1680e1](https://github.com/mjancarik/to-mock/commit/f1680e1))



