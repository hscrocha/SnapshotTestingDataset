// @flow strict

const theme: Theme = {
  colors: {
    black: '#010101',
    orange: '#FFA500',
    white: '#FFF',
  },
};

export default theme;
