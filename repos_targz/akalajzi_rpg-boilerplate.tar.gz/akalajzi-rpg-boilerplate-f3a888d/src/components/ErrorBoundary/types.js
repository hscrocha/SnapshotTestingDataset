// @flow strict

export type RenderErrorInfo = {
  componentStack: string,
};
