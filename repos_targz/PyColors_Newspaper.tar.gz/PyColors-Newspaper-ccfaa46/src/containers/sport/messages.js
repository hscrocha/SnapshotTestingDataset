/*
 * Sport Messages
 * This contains all the text for Sport container.
 */
import { defineMessages } from 'react-intl';

export default defineMessages({
  titleMessage: {
    id: 'newspaper.containers.App.title.message',
    defaultMessage: '❝ Sport ❞'
  }
});
