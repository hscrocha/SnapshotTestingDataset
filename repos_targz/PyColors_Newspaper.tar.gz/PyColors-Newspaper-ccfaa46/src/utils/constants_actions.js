/* Actions */

/* Common */
export const CLEAR_STORE = 'CLEAR_STORE';

/* Home Page */
export const FETCH_DATA = 'FETCH_DATA';
export const RECEIVE_DATA = 'RECEIVE_DATA';
export const FAILED_RECIEVE_DATA = 'FAILED_RECIEVE_DATA';
