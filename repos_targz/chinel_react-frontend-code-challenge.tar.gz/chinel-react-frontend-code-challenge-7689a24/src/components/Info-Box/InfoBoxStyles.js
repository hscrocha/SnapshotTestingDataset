import { makeStyles } from "@material-ui/core";

const useStyles = makeStyles({
  cardContainer: {
    display: "flex",
    flexWrap: "wrap",
  },
});

export default useStyles;
