import { makeStyles } from "@material-ui/core";

const useStyles = makeStyles({
  loading: {
    color: "#006FD6",
  },
});

export default useStyles;
