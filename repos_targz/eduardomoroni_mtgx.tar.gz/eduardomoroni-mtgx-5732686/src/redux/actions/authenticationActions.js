// @flow

import { SET_USER } from '../types'

export const setUser = (user: Object) => ({ type: SET_USER, user })
