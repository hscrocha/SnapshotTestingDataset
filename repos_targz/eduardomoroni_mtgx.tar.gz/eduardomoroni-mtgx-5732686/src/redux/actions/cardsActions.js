// @flow

import { SET_CARDS } from '../types'

export const setCards = (cards: Object) => ({ type: SET_CARDS, cards })
