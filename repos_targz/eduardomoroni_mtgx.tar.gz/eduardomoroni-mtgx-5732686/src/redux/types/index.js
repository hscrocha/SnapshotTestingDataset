// @flow

export const SET_USER = 'create_user_with_email_and_password'
export const SHOW_MESSAGE = 'show_message_to_user'
export const CLEAR_MESSAGE = 'clear_message'
export const SET_CARDS = 'set_cards'
