export default {
  black: require('./black.png'),
  blue: require('./blue.png'),
  green: require('./green.png'),
  red: require('./red.png'),
  white: require('./white.png')
}
