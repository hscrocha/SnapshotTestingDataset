// @flow

export const superTypeSchema = {
  name: 'SuperType',
  primaryKey: 'superType',
  properties: { superType: 'string' }
}
