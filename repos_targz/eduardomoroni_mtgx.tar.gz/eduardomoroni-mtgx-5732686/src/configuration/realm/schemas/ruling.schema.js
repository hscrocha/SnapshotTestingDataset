// @flow

export const rulingSchema = {
  name: 'Ruling',
  properties: {
    'date': 'string',
    'text': 'string'
  }
}
