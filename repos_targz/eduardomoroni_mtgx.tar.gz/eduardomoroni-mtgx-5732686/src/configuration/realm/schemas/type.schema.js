// @flow

export const typeSchema = {
  name: 'Type',
  primaryKey: 'type',
  properties: { type: 'string' }
}
