// @flow

export const legalitySchema = {
  name: 'Legality',
  primaryKey: 'format',
  properties: {
    'format': 'string',
    'legality': 'string'
  }
}
