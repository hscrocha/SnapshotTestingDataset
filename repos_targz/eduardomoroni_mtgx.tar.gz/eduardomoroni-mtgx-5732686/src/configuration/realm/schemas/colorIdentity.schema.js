// @flow

export const colorIdentitySchema = {
  name: 'ColorIdentity',
  primaryKey: 'colorIdentity',
  properties: { colorIdentity: 'string' }
}
