// @flow

export const printingSchema = {
  name: 'Printing',
  primaryKey: 'printing',
  properties: { printing: 'string' }
}
