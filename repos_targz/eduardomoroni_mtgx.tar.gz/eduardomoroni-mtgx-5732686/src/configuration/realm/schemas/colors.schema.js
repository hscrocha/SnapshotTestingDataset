// @flow

export const colorSchema = {
  name: 'Color',
  primaryKey: 'color',
  properties: { color: 'string' }
}
