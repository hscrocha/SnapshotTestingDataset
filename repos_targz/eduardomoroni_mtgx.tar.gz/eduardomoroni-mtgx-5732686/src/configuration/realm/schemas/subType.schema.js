// @flow

export const subTypeSchema = {
  name: 'SubType',
  primaryKey: 'subType',
  properties: { subType: 'string' }
}
