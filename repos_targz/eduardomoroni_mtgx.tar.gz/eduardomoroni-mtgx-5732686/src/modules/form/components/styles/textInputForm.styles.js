// @flow

import { StyleSheet } from 'react-native'

export const styles = StyleSheet.create({
  foo: {
    bar: 1
  }
})
