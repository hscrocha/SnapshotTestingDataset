// @flow

import { StyleSheet } from 'react-native'

export const styles = StyleSheet.create({
  inputPicker: {
    flex: 1,
    justifyContent: 'flex-end'
  }
})
