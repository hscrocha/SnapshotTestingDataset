// @flow

import { StyleSheet } from 'react-native'

export const styles = StyleSheet.create({
  manaIcon: {
    width: 30,
    height: 30,
    marginHorizontal: 5
  }
})
