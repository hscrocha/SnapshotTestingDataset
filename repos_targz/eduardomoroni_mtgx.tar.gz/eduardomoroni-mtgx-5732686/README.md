# Trading card manager
[![Android Build](https://dashboard.buddybuild.com/api/statusImage?appID=599430d92835a80001b38c2b&branch=master&build=latest)](https://dashboard.buddybuild.com/apps/599430d92835a80001b38c2b/build/latest?branch=master)
[![iOS Build](https://dashboard.buddybuild.com/api/statusImage?appID=59943a91efa638000108f8d8&branch=master&build=latest)](https://dashboard.buddybuild.com/apps/59943a91efa638000108f8d8/build/latest?branch=master)
[![Build Status](https://travis-ci.org/eduardomoroni/trading-card-manager.svg?branch=master)](https://travis-ci.org/eduardomoroni/trading-card-manager)
[![Code Climate](https://codeclimate.com/github/eduardomoroni/trading-card-manager/badges/gpa.svg)](https://codeclimate.com/github/eduardomoroni/trading-card-manager)
[![Test Coverage](https://codeclimate.com/github/eduardomoroni/trading-card-manager/badges/coverage.svg)](https://codeclimate.com/github/eduardomoroni/trading-card-manager/coverage)
[![JavaScript Style Guide](https://img.shields.io/badge/code_style-standard-brightgreen.svg)](https://standardjs.com)

# App Preview
[![appetize-preview](https://user-images.githubusercontent.com/823150/29251040-46599e48-8024-11e7-85ac-026f695f9360.png)](https://appetize.io/embed/0pqphm7ze5q0mvqdqkhykd3jyr?device=nexus5&scale=75&orientation=portrait&osVersion=7.1)
