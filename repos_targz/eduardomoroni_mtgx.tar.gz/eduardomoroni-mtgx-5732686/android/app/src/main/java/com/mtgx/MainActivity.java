package com.mtgx;

import com.reactnativenavigation.controllers.SplashActivity;

public class MainActivity extends SplashActivity {

    protected String getMainComponentName() {
        return "mtgx";
    }
}
