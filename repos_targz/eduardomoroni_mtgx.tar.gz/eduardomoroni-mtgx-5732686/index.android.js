// @flow

import { initializeApp } from './src/configuration'

initializeApp()
