let Config = jest.genMockFromModule('react-native-config')

Config.TEST_ENV = 'TEST_ENV'

export default Config
