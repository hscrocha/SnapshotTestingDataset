export const firebaseUser = {
  email: 'email@jonh.com',
  emailVerified: true,
  uid: 'somethin_unique',
  providerData: [{
    email: 'email@jonh.com',
    uid: 'email@jonh.com',
    providerId: 'password'
  }]
}
