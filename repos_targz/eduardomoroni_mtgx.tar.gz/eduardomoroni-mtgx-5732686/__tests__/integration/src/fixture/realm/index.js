export const subTypeFixture = {
  subType: 'Goblin'
}

export const printingFixture = {
  date: '15/12/2002',
  text: 'text'
}
