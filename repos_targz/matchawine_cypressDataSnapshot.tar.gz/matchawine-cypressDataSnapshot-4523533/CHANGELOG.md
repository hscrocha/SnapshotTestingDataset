# Changelog

## v1.10.0
- Fix the absolute file path bug with alternate method

## v1.9.0
- Cleaner & more jest-like update workflow

## v1.8.0
- Better env management

## v1.7.2
- Better tests, add tests & eslint to CI

## v1.7.1
- Better readme

## v1.7.0
- Added hint test
- Fixed hint
- Better readme

## v1.6.0

- First stable version, do not use earlier versions