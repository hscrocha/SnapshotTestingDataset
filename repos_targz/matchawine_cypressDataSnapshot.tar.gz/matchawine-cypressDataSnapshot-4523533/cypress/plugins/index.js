// From: https://github.com/cypress-io/cypress/issues/1247
require("@babel/register")

// eslint-disable-next-line immutable/no-mutation
module.exports = require("./main")
