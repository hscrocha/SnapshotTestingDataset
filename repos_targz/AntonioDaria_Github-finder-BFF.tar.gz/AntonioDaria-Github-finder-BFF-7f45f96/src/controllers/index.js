const favouriteLanguageController = require("./favouriteLanguage.controller");

const controllers = [favouriteLanguageController];

module.exports =  controllers;
