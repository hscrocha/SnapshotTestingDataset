import React from 'react';
import './App.css';
import Submmissionform from './components/SubmissionForm';

function App() {
  return (
      
      <div className="container"> 
       <Submmissionform />
      </div>
   
  );
}

export default App;
