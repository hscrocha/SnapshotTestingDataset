import {syncTest} from './sync'

test('happy', () => {
  console.log([1, 2, 3])
  syncTest()
})
