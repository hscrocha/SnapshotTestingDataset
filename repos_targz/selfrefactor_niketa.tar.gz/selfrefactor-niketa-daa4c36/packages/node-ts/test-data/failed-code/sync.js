export function syncTest() {
  console.log(1)
  JSON.parse('{a:')
}
