export function specHasLogs(x) {
  return x % 2 ? 1 : 2
}
