export function bothHaveLogs(x) {
  console.log(x)
  console.log(typeof x)

  return x % 2 ? 1 : 2
}
