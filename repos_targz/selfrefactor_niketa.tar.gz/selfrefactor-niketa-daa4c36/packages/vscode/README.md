# Niketa tools - lightweight Wallaby.js alternative
> VSCode extension

## Start automatic Jest run on every file save

**Ctrl+Shift+2**

## Start Jest with current file

**Alt+W**

## Lint current file

**Ctrl+1**

