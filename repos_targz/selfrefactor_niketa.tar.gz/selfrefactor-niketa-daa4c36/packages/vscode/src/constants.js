exports.REQUEST_CANCELATION = 'niketa.request.cancelation'
exports.REQUEST_TEST_RUN = 'niketa.request.test.run'
exports.REQUEST_LINT_FILE = 'niketa.lint.file'
exports.REQUEST_LINT_FILE_ALT = 'niketa.lint.file.alt'
