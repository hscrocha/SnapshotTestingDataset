const { toHaveNoViolations } = require('jest-axe');

expect.extend(toHaveNoViolations);
