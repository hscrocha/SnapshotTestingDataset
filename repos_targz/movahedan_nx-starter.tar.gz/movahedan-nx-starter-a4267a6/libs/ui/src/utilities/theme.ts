export const theme = {
  colors: {
    primary: '#0070f3',
  },
};
