module.exports = {
  stories: [],
  addons: []
};
  