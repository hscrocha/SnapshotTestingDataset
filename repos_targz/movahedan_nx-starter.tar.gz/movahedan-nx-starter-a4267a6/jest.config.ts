import { getJestProjects } from '@nrwl/jest';

const config = {
  projects: getJestProjects(),
};

export default config;
