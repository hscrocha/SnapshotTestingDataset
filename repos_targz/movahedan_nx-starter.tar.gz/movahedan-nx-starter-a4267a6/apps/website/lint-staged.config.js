module.exports = {
  extends: '../../lint-staged.config.js',
};
