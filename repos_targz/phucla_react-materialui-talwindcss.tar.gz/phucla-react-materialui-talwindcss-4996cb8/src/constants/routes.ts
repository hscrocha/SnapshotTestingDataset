export default {
  HOME: '/',
  LOGIN: '/login',
  PRODUCT: 'app/product',
  TODOS: '/todos'
}
