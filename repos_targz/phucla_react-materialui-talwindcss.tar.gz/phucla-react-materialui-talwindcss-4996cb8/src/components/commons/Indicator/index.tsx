const Indicator = () => (
  <div className="indicator">
    <span className="indicator__img" />
  </div>
)

export default Indicator
