import React from 'react'

const Todos = () => {

  return (
    <div>
      <p>Todos</p>
    </div>
  )
}

export default Todos
