const Metrics = {
  XL: '',
}

export default Metrics
