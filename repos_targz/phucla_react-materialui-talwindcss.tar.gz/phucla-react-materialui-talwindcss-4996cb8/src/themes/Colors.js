module.exports = {
  red: 'red',
  text: "rgba(33, 150, 243, 0.5)"
}