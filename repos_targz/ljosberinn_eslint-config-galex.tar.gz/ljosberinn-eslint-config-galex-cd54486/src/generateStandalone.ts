import { generateStandalone } from './utils/standalone';

void generateStandalone();
