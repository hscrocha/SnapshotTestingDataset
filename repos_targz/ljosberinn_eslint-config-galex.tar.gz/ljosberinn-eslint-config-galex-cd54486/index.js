const { createConfig } = require('./src/createConfig');

module.exports = createConfig();
