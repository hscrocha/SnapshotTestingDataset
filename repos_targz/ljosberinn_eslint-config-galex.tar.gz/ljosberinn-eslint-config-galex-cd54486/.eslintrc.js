const { createConfig } = require('./dist/createConfig');

const config = createConfig();

module.exports = config;
