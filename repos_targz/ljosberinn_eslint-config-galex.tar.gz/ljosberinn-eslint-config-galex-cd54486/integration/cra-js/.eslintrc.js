module.exports = require('../abstractConfig');
