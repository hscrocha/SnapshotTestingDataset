module.exports = require('../abstractConfig');
