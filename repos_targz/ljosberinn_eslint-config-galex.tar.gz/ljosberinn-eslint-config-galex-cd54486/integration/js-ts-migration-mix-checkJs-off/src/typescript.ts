export const foo = someFunction();
export const bar = a + 1;
