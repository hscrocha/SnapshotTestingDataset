const foo = someFunction();
const bar = a + 1;

module.exports = {
  foo,
  bar,
};
