const { main } = require('./base');
main.node = {
    __dirname: false,
    __filename: false
};
module.exports = main;