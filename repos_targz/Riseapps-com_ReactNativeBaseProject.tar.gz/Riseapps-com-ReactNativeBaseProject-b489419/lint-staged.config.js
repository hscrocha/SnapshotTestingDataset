module.exports = {
  '*.{ts,tsx,js,jsx,yml,yaml}': ['yarn verify'],
};
