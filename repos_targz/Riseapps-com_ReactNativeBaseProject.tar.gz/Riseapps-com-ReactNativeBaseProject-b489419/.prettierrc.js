module.exports = {
  arrowParens: 'avoid',
  bracketSpacing: true,
  bracketSameLine: false,
  printWidth: 120,
  singleQuote: true,
};
