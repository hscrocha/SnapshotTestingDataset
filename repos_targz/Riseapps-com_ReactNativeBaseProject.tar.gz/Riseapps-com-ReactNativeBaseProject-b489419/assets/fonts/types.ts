export type Font = 'black' | 'heavy' | 'light' | 'medium' | 'regular' | 'semiBold' | 'thin' | 'ultraLight' | 'bold';
