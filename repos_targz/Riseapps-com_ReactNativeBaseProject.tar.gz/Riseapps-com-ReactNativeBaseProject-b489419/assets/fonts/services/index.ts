import { default as getFont } from './getFont';

export { getFont };
