import { default as useImages } from './useImages';

export { useImages };
