abstract class Organism {
  protected type = Symbol('Organism');
}

export default Organism;
