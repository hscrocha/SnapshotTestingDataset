abstract class Atom {
  protected type = Symbol('Atom');
}

export default Atom;
