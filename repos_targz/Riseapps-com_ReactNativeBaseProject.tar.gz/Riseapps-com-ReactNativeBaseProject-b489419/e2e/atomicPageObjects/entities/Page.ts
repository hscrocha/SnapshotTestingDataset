abstract class Page {
  protected type = Symbol('Page');
}

export default Page;
