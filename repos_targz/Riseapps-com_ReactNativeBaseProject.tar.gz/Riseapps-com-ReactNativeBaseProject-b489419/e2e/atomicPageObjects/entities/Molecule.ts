abstract class Molecule {
  protected type = Symbol('Molecule');
}

export default Molecule;
