abstract class Template {
  protected type = Symbol('Template');
}

export default Template;
