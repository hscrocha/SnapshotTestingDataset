import AsyncStorage from '@react-native-async-storage/async-storage/jest/async-storage-mock';

export default AsyncStorage;
