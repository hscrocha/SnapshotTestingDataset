/* eslint-disable @typescript-eslint/naming-convention,@typescript-eslint/no-magic-numbers */

module.exports = {
  LENGTH_LONG: 0,
  LENGTH_SHORT: -1,
  LENGTH_INDEFINITE: -2,
  show: jest.fn(),
};
