import * as countriesApi from '../countriesApi';

jest.mock('../countriesApi');

export { countriesApi };
