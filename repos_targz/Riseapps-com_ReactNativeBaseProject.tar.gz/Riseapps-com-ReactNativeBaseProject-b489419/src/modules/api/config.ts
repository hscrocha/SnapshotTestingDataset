export const AXIOS_REQUEST_TIMEOUT = 8000;

export const DEV_URL = 'https://restcountries.com/v3.1';
export const PROD_URL = 'https://restcountries.com/v3.1';
