import type { StatusMessagesState } from './types';

export const STATUS_MESSAGES_STATE_KEY = 'statusMessagesState';

export const DEFAULT_STATUS_MESSAGES_STATE: StatusMessagesState = {
  statusMessage: null,
};
