import type { NetInfoState } from './types';

export const NET_INFO_STATE_KEY = 'netInfoState';

export const DEFAULT_NET_INFO_STATE: NetInfoState = {
  netInfo: null,
};
