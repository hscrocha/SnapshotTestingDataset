import { useResetRecoilState } from 'recoil';

export default useResetRecoilState;
