import { useRecoilState } from 'recoil';

export default useRecoilState;
