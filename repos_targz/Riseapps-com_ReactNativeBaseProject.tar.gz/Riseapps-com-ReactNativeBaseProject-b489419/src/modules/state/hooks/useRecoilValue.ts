import { useRecoilValue } from 'recoil';

export default useRecoilValue;
