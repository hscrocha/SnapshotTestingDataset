import { styleSheetFactory } from '~theme';

export default styleSheetFactory(() => ({}));
