import * as errorsParsers from '../errorsParsers';

jest.mock('../errorsParsers');

export { errorsParsers };
