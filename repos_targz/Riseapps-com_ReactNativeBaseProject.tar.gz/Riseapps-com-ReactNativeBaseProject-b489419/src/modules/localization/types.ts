export type TranslationGetters = {
  [key: string]: () => Record<string, any>;
};
