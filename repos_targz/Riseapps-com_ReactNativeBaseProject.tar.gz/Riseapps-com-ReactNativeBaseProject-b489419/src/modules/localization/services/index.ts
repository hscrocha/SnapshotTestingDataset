export { default as I18n } from './I18n';
