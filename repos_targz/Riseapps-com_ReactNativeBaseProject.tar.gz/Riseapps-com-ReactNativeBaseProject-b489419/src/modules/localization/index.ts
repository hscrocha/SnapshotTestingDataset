import * as localizationConfig from './config';

export * from './services';

export { localizationConfig };
