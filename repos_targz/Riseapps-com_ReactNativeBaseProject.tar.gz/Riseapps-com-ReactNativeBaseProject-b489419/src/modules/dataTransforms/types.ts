export type SortDirection = 'ascending' | 'descending';
