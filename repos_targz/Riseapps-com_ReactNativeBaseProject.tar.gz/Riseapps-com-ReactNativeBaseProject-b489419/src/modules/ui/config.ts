export const SHADOW_HEIGHT = 2;
export const SHADOW_OPACITY = 0.25;
export const SHADOW_RADIUS = 3.84;
export const ELEVATION = 5;
