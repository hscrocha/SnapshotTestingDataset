import type * as SentryTypes from '@sentry/types';

export type SentryMessageDetails = SentryTypes.Context | SentryTypes.Contexts;
