export const INTERNATIONAL_KLEIN_BLUE = '#0036A7';
export const CAPE_COD = '#4A4E4D';
export const SUNSET_ORANGE = '#fe4a49';
export const VIOLET_EGGPLANT = '#91198E';
export const SHAMROCK = '#29C7AC';
export const TRANSPARENT = 'transparent';
export const WHITE = '#FFFFFF';
export const BLACK = '#000000';
