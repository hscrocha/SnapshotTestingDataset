import { default as useTheme } from './useTheme';

export { useTheme };
