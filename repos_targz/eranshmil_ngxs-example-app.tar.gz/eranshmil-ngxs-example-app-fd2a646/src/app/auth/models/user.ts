export interface Authenticate {
  username: string;
  password: string;
}

export interface User {
  name: string;
}
