export class OpenSidenav {
  static readonly type = '[Layout] Open Sidenav';
}

export class CloseSidenav {
  static readonly type = '[Layout] Close Sidenav';
}
