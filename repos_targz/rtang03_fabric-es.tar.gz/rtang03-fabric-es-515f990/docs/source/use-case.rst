Use case
========

`fabric-es` enhances the use of Hyperledger Fabric. Theoretically, classic Hyperledger Fabric use-cases are good candidates
to start with; suitable for establishing enterprise-graded, and consortium-based B2B network.

Decentralized Identity
----------------------

TODO

Consent Management
------------------

TODO
