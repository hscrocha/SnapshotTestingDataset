export const UNAUTHORIZED_ACCESS = 'unauthorized access';
export const USER_NOT_FOUND = 'could not find user';
export const IDENTITY_ALREADY_EXIST = 'Identity already exists in the wallet';
export const MISSING_CONNECTION_PROFILE = 'missing path to connection profile';
export const MISSING_CA_NAME = 'missing ca name';
export const MISSING_CHANNELNAME = 'missing channelName';
export const MISSING_WALLET = 'missing wallet';
export const MISSING_ORGKEY = 'missing org-key';