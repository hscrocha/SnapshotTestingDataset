/**
 * @packageDocumentation
 * @hidden
 */

// prettier-ignore
export const CREATE_WALLET = `
  mutation CreateWallet {
    createWallet
  }
`;
