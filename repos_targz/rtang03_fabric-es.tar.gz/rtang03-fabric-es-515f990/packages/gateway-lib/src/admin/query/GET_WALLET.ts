// prettier-ignore
export const GET_WALLET = `query GetWallet {
  getWallet {
    type
    mspId
    certificate
  }
}`;
