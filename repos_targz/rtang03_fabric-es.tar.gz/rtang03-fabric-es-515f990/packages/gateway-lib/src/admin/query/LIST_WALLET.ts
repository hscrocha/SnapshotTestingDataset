// prettier-ignore
export const LIST_WALLET = `query ListWallet {
  listWallet
}`;
