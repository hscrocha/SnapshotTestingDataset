### Note
This is COUNTER expample
