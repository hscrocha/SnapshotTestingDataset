/**
 * @about the typed returned from auth-server, upon user registration
 */
export type RegisterResponse = {
  id: string;
  username: string;
};
