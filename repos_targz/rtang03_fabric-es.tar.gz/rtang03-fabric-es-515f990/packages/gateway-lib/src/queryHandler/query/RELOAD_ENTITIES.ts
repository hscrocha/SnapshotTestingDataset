// prettier-ignore
export const RELOAD_ENTITIES = `
  mutation CreateWallet {
    createWallet
  }
`;
