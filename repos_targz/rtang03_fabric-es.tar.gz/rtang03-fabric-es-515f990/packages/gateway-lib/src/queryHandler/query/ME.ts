// prettier-ignore
export const ME = `
  query Me {
    me
  }
`;
