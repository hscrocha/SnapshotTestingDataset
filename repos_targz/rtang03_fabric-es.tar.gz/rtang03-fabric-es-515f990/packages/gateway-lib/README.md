# gateway-lib

## Installation

```shell script
yarn install @fabric-es/gateway-lib
```
