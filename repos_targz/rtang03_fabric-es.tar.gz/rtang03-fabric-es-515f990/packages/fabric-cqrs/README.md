# fabric-cqrs

## Installation

```shell script
yarn install @fabric-es/fabric-cqrs
```
