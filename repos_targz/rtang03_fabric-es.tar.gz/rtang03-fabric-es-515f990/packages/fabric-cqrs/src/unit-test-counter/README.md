### About

unit-test-counter is the example implementation, to be used by unit-tests throughout the monorepo. 
