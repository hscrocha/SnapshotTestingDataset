/**
 * @about generic response from Fabric
 */
export type FabricResponse = {
  status: string;
  message: string;
  result: any;
};
