import mergeEntity from './mergeEntity';
import mergeEntityBatch from './mergeEntityBatch';

export const epic = [mergeEntity, mergeEntityBatch];
