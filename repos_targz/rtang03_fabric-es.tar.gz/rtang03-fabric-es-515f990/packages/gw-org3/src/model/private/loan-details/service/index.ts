export { resolvers as loanDetailsResolvers } from './resolvers';
export { typeDefs as loanDetailsTypeDefs } from './schema';
