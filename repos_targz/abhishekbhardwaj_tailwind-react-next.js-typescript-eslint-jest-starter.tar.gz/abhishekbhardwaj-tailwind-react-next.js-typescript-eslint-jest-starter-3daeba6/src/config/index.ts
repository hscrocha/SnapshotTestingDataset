export const APP_NAME = process.env.NEXT_PUBLIC_APP_NAME
