import { Layout } from './Layout';

export default {
	title: 'templates/Layout',
	component: Layout,
};

export const LayoutStory = () => <Layout>Some content</Layout>;

LayoutStory.storyName = 'Layout';
