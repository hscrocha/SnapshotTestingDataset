export * from './FloatingImages';
