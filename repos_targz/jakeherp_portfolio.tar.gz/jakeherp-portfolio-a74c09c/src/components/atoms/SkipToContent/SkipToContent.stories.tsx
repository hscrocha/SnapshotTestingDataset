import { SkipToContent } from './SkipToContent';

export default {
	title: 'atoms/SkipToContent',
	component: SkipToContent,
};

export const SkipToContentStory = () => <SkipToContent />;

SkipToContentStory.storyName = 'SkipToContent';
