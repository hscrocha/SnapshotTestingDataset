import { Footer } from './Footer';

export default {
	title: 'organisms/Footer',
	component: Footer,
};

export const FooterStory = () => <Footer />;

FooterStory.storyName = 'Footer';
