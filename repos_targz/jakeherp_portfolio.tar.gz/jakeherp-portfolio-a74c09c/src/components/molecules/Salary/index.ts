export * from './Salary';
