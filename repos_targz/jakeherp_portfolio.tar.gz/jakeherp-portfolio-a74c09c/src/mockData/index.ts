export * from './mockCaseStudy';
export * from './mockCompany';
export * from './mockJobs';
export * from './mockPodcast';
export * from './mockSchool';
