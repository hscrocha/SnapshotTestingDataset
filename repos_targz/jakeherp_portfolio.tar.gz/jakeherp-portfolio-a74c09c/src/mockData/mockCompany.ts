import { ICompany } from '@types';

export const mockCompany: ICompany = {
	name: 'Some Company',
	url: 'https://somecompany.com/',
	logo: '/assets/companies/dennis.svg',
};
