import { IPodcast } from '@types';

export const mockPodcast: IPodcast = {
	name: 'Syntax.fm',
	imagePath: '/assets/podcasts/syntax.png',
	url: 'https://www.syntax.fm/',
};
