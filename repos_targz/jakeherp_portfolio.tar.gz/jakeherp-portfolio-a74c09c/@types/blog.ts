export interface IBlogPost {
	content: string;
	publishedDate: string;
	slug: string;
	title: string;
	introText: string;
	seoDescription: string;
}
