export interface IImage {
	id: string;
	url: string;
}
