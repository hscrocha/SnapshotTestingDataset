// 用于开发环境的构建过程中的常量

module.exports = {
  SVRCODECOMPLETED: '编译完成...', // 服务端代码编译完成
  CLIENTCOMPILEDONE: '客户端编译完成...'
}
