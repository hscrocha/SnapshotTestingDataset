module.exports = {
  port: 8080,
  host: 'http://localhost',
  assetsPublicPath: '/'
}
