module.exports = {
  assetsPublicPath: ''
}
