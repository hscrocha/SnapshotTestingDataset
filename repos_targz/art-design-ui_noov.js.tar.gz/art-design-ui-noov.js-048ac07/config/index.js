module.exports = {
  base: require('./base'),
  prod: require('./prod'),
  dev: require('./dev')
}
