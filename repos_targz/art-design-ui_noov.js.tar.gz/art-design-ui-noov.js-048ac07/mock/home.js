module.exports = {
  'get /userbase': {
    data: {
      id: 1,
      email: 'sw_@163.com',
      nickname: '',
      avatar: ''
    }
  }
}
