export default {
  '/': {
    title: 'home',
    keywords: 'noov.js',
    description: '一套react-ssr解决方案'
  }
}
