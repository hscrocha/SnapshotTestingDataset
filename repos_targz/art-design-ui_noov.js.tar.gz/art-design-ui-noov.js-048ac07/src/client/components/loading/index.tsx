import React from 'react'

export default function LoadingComponent() {
  return <div className="loading">loading......</div>
}
