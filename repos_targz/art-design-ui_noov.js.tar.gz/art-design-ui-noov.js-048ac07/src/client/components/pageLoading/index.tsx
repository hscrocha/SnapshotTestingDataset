import React from 'react'

import './index.less'

const PageLoading: React.SFC<any> = () => <div styleName="loader">Loading...</div>

export default PageLoading
