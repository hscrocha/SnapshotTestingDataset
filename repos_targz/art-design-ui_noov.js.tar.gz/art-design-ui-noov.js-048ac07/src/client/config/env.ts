const env = {
  ENV: window.ENV ? window.ENV.toLowerCase() : 'local'
}

export default env
