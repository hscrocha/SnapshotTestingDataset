# `<Welcome />`

This is the `Welcome` component used as the home page.

## Directory Structure

- `Welcome.stories.tsx`: Component playground (`npm run test:playground`)
- `Welcome.module.css`: Component styles
- `Welcome.test.tsx`: Component tests (`npm run test:unit`)
- `Welcome.tsx`: Component code
- `index.ts`: Component export
- `README.md`: Component documentation (hey, that's me!)
