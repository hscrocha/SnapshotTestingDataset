# `<Nav />`

This is a `Nav` component used to navigate between pages.

## Directory Structure

- `Nav.stories.tsx`: Component playground (`npm run test:playground`)
- `Nav.module.css`: Component styles
- `Nav.test.tsx`: Component tests (`npm run test:unit`)
- `Nav.tsx`: Component code
- `index.ts`: Component export
- `README.md`: Component documentation (hey, that's me!)
