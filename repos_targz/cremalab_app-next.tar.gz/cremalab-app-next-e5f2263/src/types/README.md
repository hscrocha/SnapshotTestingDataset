# `./src/types`

This directory is intended to organize global application [types](http://www.typescriptlang.org/docs/handbook/basic-types.html).