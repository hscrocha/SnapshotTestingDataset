# `<SSG />`

This is the `SSG` page.

## Directory Structure

- `SSG.stories.tsx`: Page playground (`npm run test:playground`)
- `SSG.module.css`: Page styles
- `SSG.test.tsx`: Page tests (`npm run test:unit`)
- `index.page.tsx`: Page code
- `README.md`: Page documentation (hey, that's me!)
