# `<SSR />`

This is the `SSR` page.

## Directory Structure

- `SSR.stories.tsx`: Page playground (`npm run test:playground`)
- `SSR.module.css`: Page styles
- `SSR.test.tsx`: Page tests (`npm run test:unit`)
- `index.page.tsx`: Page code
- `README.md`: Page documentation (hey, that's me!)
