# `./src/pages`

This directory is intended to organize Next.js [pages](https://nextjs.org/docs/basic-features/pages).
