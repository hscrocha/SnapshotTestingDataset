# Continuous Integration

Basically we are supporting CircleCI out of the box with this boilerplate. Please have a look at some other CI if you want.

## Guides

- [Greenkeeper.io](greenkeeper.md)
