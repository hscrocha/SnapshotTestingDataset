# Implementing a custom font-face

Since we moved away from `aphrodite` since version 3.1.0, we are encouraging you reading the following thread in the `styled-components` issues section to have a slightly better understanding at how to implement web fonts manually into the project:

https://github.com/styled-components/styled-components/issues/233
