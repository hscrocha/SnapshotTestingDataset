// @flow

export type TemplateOpts = {
  helmet: Object,
  head: string,
  html: string,
  scripts: string,
}
