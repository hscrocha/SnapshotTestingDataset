module.exports = 'sample-string'
