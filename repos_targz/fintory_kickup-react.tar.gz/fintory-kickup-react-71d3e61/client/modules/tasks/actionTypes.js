// @flow
export const CREATE_TASK: string = 'CREATE_TASK'
export const REMOVE_TASK: string = 'REMOVE_TASK'
