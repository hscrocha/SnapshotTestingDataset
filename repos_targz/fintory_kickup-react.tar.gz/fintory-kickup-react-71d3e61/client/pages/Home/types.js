// @flow

export type State = {
  loading: boolean,
}

export type Props = {}
