// @flow

export const baseSpacing: number = 16
export const smallSpacing: number = 12
export const miniSpacing: number = 8
