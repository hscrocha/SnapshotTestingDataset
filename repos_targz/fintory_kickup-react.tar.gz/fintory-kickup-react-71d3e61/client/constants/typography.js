// @flow

export const baseFontSize: string = '16px'
