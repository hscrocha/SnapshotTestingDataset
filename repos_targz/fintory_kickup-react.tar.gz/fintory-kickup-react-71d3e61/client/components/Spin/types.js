// @flow

export type Props = { [key: string]: any }
