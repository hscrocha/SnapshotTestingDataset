export const FRONTEND_TYPE = "FRONT-END";
export const BACKEND_TYPE = "BACK-END";
