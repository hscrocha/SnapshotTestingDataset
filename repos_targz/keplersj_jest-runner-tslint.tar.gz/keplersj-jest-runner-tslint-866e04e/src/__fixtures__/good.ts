export class SampleClass {
  private example: string;

  constructor() {
    this.example =
      "Hello from a Good TypeScript file! (It doesn't log to the console 😄)";
  }
}
