export class SampleClass {
  constructor() {
    console.log(
      "Hello from a Bad TypeScript file! (It logs to the console 😠)"
    );
  }
}
