module.exports = {
  moduleFileExtensions: ["ts", "tsx", "js", "jsx"],
  runner: "tslint",
  testMatch: ["**/*.ts", "**/*.tsx", "**/*.d.ts", "**/*.js", "**/*.jsx"],
};
