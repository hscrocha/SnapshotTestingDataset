**General Information**

- [ ] Bug
- [ ] Improvement
- [ ] Feature
- [ ] Other

**Description**

(Add images if possible)

**Steps to reproduce**

(Add link to a demo on https://jsfiddle.net or similar if possible)

**Versions**

- styled-components-test-utils:
- node:

- jest:
- expect:
- chai:
- jasmine:
