const isServer = () => typeof document === 'undefined';

export default isServer;
