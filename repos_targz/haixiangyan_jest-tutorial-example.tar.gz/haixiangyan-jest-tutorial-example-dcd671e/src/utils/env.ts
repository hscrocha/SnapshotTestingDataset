export const config = {
  getEnv() {
    return "test";
  },
};

export const configObj = {
  get env() {
    return "test";
  },
};

export const getEnv = () => "test";

export const env = "test";
