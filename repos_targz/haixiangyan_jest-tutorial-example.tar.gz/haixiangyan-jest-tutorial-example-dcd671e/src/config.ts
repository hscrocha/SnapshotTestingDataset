export const isDev = window.location.search.includes("isDev");
