# 🃏《Jest 实践指南》（配套项目）

[![Coverage Status](https://coveralls.io/repos/github/haixiangyan/jest-tutorial-example/badge.svg?branch=main)](https://coveralls.io/github/haixiangyan/jest-tutorial?branch=main)

<img src="https://raw.githubusercontent.com/haixiangyan/jest-tutorial/main/cover.jpeg" width="300"/>

更多关于 Jest 的实践内容请查看 [《Jest 实践指南》](http://github.yanhaixiang.com/jest-tutorial/) 。

