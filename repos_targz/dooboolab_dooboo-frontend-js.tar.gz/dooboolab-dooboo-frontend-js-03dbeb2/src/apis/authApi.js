import { getSessionStorage } from '../utils/Functions';

const LOGIN_USER_API = '/api/auth/login';
const SIGNUP_USER_API = '/api/auth/signup';

export {

};
