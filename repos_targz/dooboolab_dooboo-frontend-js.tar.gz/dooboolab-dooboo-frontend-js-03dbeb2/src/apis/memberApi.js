const GET_MEMBERS_URL = '/api/user/all';
const GET_MEMBER_URL = '/api/user/one/';
const UPDATE_MEMBER_URL = '/api/user/update/';

export {

};
