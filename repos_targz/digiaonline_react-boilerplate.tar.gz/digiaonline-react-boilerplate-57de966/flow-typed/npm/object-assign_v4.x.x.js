// flow-typed signature: c597e0b0defff17abb9f150848cbd316
// flow-typed version: b43dff3e0e/object-assign_v4.x.x/flow_>=v0.16.x

declare module 'object-assign' {
  declare function exports(target: any, ...sources: Array<any>): Object;
}
