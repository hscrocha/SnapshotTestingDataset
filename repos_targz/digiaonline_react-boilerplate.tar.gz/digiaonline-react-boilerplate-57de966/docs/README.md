# Documentation

Here you can read about our coding conventions, best practices, tools and more.

**Note:** This documentation is work in progress.

## Table of contents

- [Coding Conventions](./01-coding-conventions.md)
- [Best Practices](./02-best-pratices.md)
- [Tools](./03-tools.md)
- [Create React App](./04-create-react-app.md)
