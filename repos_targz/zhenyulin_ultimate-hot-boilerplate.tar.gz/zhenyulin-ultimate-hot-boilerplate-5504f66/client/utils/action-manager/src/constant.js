// @flow
export const ASYNC = {
  IDLE: 'IDLE',
  PROCESS: 'PROCESS',
  SUCCESS: 'SUCCESS',
  ERROR: 'ERROR',
};

export default ASYNC;
