// @flow

// import type { Map } from 'immutable';

// TODO: create strong-typed state
