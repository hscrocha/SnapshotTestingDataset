import postLogics from './post';
import messageLogics from './message';

export default [...postLogics, ...messageLogics];
