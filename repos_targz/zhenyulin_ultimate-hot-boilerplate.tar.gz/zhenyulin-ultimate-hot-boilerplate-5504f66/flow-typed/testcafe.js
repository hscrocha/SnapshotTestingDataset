// @flow

declare var fixture: any;
declare var test: any;

declare module 'testcafe' {
  declare module.exports: any;
}
