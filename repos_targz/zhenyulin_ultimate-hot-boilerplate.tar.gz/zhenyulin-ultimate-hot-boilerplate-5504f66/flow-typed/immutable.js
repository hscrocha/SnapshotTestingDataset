// @flow

declare module 'immutable' {
  declare module.exports: any;
}
