import AddCheck from './AddCheck';

const AddCheckContainer = () => (
  <AddCheck />
);

export default AddCheckContainer;
