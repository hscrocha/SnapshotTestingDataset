export const firstColor = '#62b5e5';
export const secondColor = '#67899c';
export const thirdColor = '#addc91';
export const fourthColor = '#dc9e91';
export const fifthColor = '#f3f4f6';
export const sixthColor = '#313944';
export const seventhColor = '#d2d2d2';
