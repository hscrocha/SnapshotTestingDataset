module.exports = [
  {
    type: 'input',
    name: 'path',
    message: "New component path: (empty for 'components/')"
  },
  {
    type: 'input',
    name: 'name',
    message: 'New component name:'
  }
]
