import { addons } from '@storybook/addons';
import bookTheme from './bookTheme';

addons.setConfig({
  theme: bookTheme,
});
