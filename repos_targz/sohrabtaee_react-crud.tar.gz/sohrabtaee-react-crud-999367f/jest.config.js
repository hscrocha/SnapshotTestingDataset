module.exports = {
  moduleNameMapper: {
    '~(.*)$': '<rootDir>/$1',
  },
}
