module.exports = {
  "rules": {
    "react/prop-types": 0
  }
}
