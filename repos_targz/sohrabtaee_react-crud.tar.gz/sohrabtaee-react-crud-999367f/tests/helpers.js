export const sampleNotes = [
  {
    id: 1,
    title: 'title',
    content: 'content',
    date: new Date('2020-02-20'),
  },
  {
    id: 2,
    title: 'title2',
    content: 'content2',
    date: new Date('2020-02-21'),
  },
]
