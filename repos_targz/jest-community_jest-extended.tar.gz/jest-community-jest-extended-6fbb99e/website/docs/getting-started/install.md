---
sidebar_position: 1
---

# Installation

With npm:

```sh
npm install --save-dev jest-extended
```

With yarn:

```sh
yarn add -D jest-extended
```
