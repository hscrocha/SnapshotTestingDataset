export const add2 = (a: number, b: number) => {
  return a + b;
};
