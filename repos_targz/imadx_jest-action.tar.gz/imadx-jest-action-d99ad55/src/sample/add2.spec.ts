import { add2 } from "./add2";

describe("add2", () => {
  it("should add 2 numbers", () => {
    expect(add2(1, 2)).toBe(3);
  });
});
