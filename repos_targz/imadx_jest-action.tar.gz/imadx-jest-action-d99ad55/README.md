# Jest GitHub Action

This action allows Jest to be run in shards and reports merged coverage to the commit on behalf of the commit owner.
The action consumes the default `npm run test` command. Therefore, additional `jest` arguments could be defined in `package.json` with the `test` command.

## Inputs

> `*` -- required inputs

### with 'run-tests' command

| Input                  | Default        | Description                                                                            |
| ---------------------- | -------------- | -------------------------------------------------------------------------------------- |
| `github-token` \*      | `GITHUB_TOKEN` | Github Token for the workflow                                                          |
| `command`              | `run-tests`    | Action to run. <br /> Available commands: `run-tests`, `merge-coverage`                |
| `coverage`             | `true`         | Enable Coverage for`run-tests` command                                                 |
| `shard`                | `1/1`          | Jest shard to be executed for`run-tests` command (eg: `1/4`)                           |
| `skip-artifact-upload` | `false`        | Avoid uploading coverage results,<br/> if all the actions are running in a single step |

### with 'merge-coverage' command

| Input                       | Default        | Description                                                                                |
| --------------------------- | -------------- | ------------------------------------------------------------------------------------------ |
| `github-token` \*           | `GITHUB_TOKEN` | Github Token for the workflow                                                              |
| `command` \*                | `run-tests`    | **Should set to `merge-coverage`**                                                         |
| `shard-count`               | `1`            | **Shard count need to be defined `merge-coverage` command<br/> if different from default** |
| `skip-artifact-upload`      | `false`        | Avoid uploading coverage results, if all the actions are running in a single step          |
| `show-all-files-in-summary` | `false`        | Shows coverage information of all files, along with the summary                            |

## Example with a matrix

> Note: if running multiple shards, `shard` (for `run-tests` command) and `shard-count` for `merge-coverage` command) need to be defined.

```yaml
name: Publish coverage result on Pull request

on:
  pull_request:
    branches:
      - master
jobs:
  run-tests:
    runs-on: ubuntu-latest
    strategy:
      matrix:
        shard: [1/2, 2/2]
    steps:
      - uses: actions/checkout@v2
      - uses: actions/setup-node@v2
        with:
          node-version: "16.x"
      - uses: imadx/jest-action@v0.8
        with:
          command: "run-tests"
          shard: ${{ matrix.shard }}

  merge-coverage:
    runs-on: ubuntu-latest
    needs: run-tests
    steps:
      - uses: actions/checkout@v2
      - uses: actions/setup-node@v2
        with:
          node-version: "16.x"
      - uses: imadx/jest-action@v0.8
        with:
          show-all-files-in-summary: true
          github-token: "${{ secrets.GITHUB_TOKEN }}"
          command: "merge-coverage"
          shard-count: "2"
```

## Example Usage for tests in this repo

The following is how the action is being used for this repo with `pnpm`

[.github/workflows/test.yml](https://github.com/imadx/jest-action/blob/main/.github/workflows/test.yml)
