process.env = {
  ...process.env,
  "INPUT_github-token": "123",
  GITHUB_REPOSITORY: "imadx/jest-actions",
};
