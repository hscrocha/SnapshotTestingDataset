module.exports = {
  hit: () => {},
  event: () => {},
};
