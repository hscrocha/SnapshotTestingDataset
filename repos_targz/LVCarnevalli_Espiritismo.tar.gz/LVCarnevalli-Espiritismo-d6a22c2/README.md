 <img alt="Espiritismo" src="https://github.com/LVCarnevalli/Espiritismo/raw/master/assets/images/Icon.png" height="50"> Espiritismo
======================
[![Build Status](https://travis-ci.org/LVCarnevalli/Espiritismo.svg?branch=master)](https://travis-ci.org/LVCarnevalli/Espiritismo)

O aplicativo Espiritismo têm o objetivo de agrupar conteúdos espíritas e trazer até você de maneira fácil, produtiva e divertida.

**O projeto não visa fins lucrativos, sendo assim o aplicativo não contêm propagandas.**

## Aplicativos

<a href="https://play.google.com/store/apps/details?id=br.verdi.espiritismo">
  <img alt="Download on Google Play" src="https://play.google.com/intl/en_us/badges/images/badge_new.png" height=43>
</a>

## Créditos
[![](https://sourcerer.io/fame/LVCarnevalli/LVCarnevalli/espiritismo/images/0)](https://sourcerer.io/fame/LVCarnevalli/LVCarnevalli/espiritismo/links/0)[![](https://sourcerer.io/fame/LVCarnevalli/LVCarnevalli/espiritismo/images/1)](https://sourcerer.io/fame/LVCarnevalli/LVCarnevalli/espiritismo/links/1)[![](https://sourcerer.io/fame/LVCarnevalli/LVCarnevalli/espiritismo/images/2)](https://sourcerer.io/fame/LVCarnevalli/LVCarnevalli/espiritismo/links/2)[![](https://sourcerer.io/fame/LVCarnevalli/LVCarnevalli/espiritismo/images/3)](https://sourcerer.io/fame/LVCarnevalli/LVCarnevalli/espiritismo/links/3)[![](https://sourcerer.io/fame/LVCarnevalli/LVCarnevalli/espiritismo/images/4)](https://sourcerer.io/fame/LVCarnevalli/LVCarnevalli/espiritismo/links/4)[![](https://sourcerer.io/fame/LVCarnevalli/LVCarnevalli/espiritismo/images/5)](https://sourcerer.io/fame/LVCarnevalli/LVCarnevalli/espiritismo/links/5)[![](https://sourcerer.io/fame/LVCarnevalli/LVCarnevalli/espiritismo/images/6)](https://sourcerer.io/fame/LVCarnevalli/LVCarnevalli/espiritismo/links/6)[![](https://sourcerer.io/fame/LVCarnevalli/LVCarnevalli/espiritismo/images/7)](https://sourcerer.io/fame/LVCarnevalli/LVCarnevalli/espiritismo/links/7)
