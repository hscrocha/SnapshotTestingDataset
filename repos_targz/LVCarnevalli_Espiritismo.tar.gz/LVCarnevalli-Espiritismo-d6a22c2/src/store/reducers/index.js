import global from './GlobalReducer';
import prayer from './PrayerReducer';
import question from './QuestionReducer';

export default {
  question,
  prayer,
  global,
};
