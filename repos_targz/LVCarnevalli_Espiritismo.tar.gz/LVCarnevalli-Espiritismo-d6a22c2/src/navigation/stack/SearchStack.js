import React from 'react';

import SearchScreen from '../../screens/Search';

const SearchStack = {
  screen: SearchScreen,
};

export default SearchStack;
