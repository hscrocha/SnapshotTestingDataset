import React from 'react';

const HomePage = () => (
  <div data-testid="home" className="home-container">
    <h2>Welcome to our page!</h2>
    <p>
      Lorem ipsum dolor sit amet, consectetur adipisicing elit.
      Quod dolores quidem corrupti dolorum necessitatibus maxime consequuntur praesentium fuga?
      Delectus at unde et iusto cumque vero harum dignissimos debitis accusantium veniam
      blanditiis molestiae culpa perferendis nostrum consequatur, autem expedita
      assumenda reprehenderit
      odio dolore officiis reiciendis magnam aliquid alias!
      Ea maxime sed assumenda fugit, aperiam dicta voluptate dolores?
      Veritatis, repudiandae necessitatibus.
      Ipsum dolorum expedita minima excepturi odio tempora hic natus officia!
      Unde, aut quos?
      Vitae distinctio similique necessitatibus odio aspernatur cupiditate tempora
      fugiat molestiae maiores enim. Ratione ea hic repellendus est, deleniti obcaecati! Sed.
    </p>
    <p>
      Lorem ipsum dolor sit amet consectetur adipisicing elit.
      Ipsa reprehenderit harum, culpa soluta quam,
      excepturi nemo vel enim itaque cum obcaecati nobis commodi ad deleniti et
      qui nulla consequatur doloribus! Nam modi voluptas at.
      Nemo quasi nam fugit sed sunt consequatur
      assumenda quod culpa tempora, blanditiis, dicta exercitationem,
      dolore rerum pariatur eum amet nihil veritatis
      non odio cumque et vero reprehenderit dolores optio? Quae.
    </p>
  </div>
);

export default HomePage;
