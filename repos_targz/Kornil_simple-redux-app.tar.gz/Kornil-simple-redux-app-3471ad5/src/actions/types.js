// incremement counter
export const INCREMENT = 'INCREMENT';
// decrement counter
export const DECREMENT = 'DECREMENT';
