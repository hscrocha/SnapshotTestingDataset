# Project Roadmap

This is where we'll define a few things about the library's goals.

We haven't filled this out yet though. Care to help? See `CONTRIBUTING.md`

## Want to do

## Might do

## Wont do
