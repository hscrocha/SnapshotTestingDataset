export { default } from 'modules/Cards/containers/CardList.container';
export { default as reducer } from 'modules/Cards/reducers/Cards.reducer.js';
