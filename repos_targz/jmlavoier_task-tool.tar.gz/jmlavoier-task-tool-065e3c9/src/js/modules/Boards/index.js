export { default } from './containers/BoardList.container';
export { default as reducer } from './reducers/Boards.reducer.js';
