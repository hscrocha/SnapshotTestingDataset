## [1.0.8](https://github.com/aquariuslt/jest-properties-loader/compare/v1.0.7...v1.0.8) (2020-02-29)


### Bug Fixes

* jest.Transformer after upgrade to @types/jest v25 issue ([465db3f](https://github.com/aquariuslt/jest-properties-loader/commit/465db3f31b798e945cbe9ac37833ed975ead5fe4))
