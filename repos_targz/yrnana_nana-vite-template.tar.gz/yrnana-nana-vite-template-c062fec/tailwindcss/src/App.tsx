import Button from '~/components/Button';

function App() {
  return (
    <div>
      <Button>버튼</Button>
    </div>
  );
}

export default App;
