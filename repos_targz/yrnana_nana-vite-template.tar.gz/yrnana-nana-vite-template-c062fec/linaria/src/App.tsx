import { css } from '@linaria/core';

function App() {
  return (
    <div
      className={css`
        font-size: 3em;
      `}
    >
      Hello
    </div>
  );
}

export default App;
