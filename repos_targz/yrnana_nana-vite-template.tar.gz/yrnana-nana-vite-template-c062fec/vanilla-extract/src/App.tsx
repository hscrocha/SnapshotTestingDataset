import Button from '~/components/Button';

function App() {
  return <Button>버튼</Button>;
}

export default App;
