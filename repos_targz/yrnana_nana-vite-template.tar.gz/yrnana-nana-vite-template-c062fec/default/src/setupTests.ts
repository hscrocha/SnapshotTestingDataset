import '@testing-library/jest-dom';

// @ts-ignore
globalThis.IS_REACT_ACT_ENVIRONMENT = true;
