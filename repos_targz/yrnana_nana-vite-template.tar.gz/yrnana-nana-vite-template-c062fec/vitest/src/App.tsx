import Link from '~/components/Link';

function App() {
  return (
    <div>
      <Link page="/hello">Hello</Link>
    </div>
  );
}

export default App;
