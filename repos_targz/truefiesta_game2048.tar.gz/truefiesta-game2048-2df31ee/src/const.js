export const Move = {
    DOWN: `down`,
    UP: `up`,
    LEFT: `left`,
    RIGHT: `right`,
};

export const ScoreType = {
    GAME: `Game`,
    BEST: `Best`,
};
