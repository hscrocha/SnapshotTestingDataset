# Game 2048

My version of a famous game. The project was developed as a way to practice my coding skills and practice TDD. This version has an additional feature and allows a user to play on 8 by 8 board.

![Game 2048](https://github.com/truefiesta/game2048/blob/master/src/img/game-preview.png?raw=true "Game 2048")