  
module.exports = {
    rootDir: `./src`,
    moduleFileExtensions: [
      `js`,
      `jsx`,
      `json`,
      `node`
    ],
  };