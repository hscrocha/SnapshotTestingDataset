export const Translation = ({ children }: any) => children((k: string) => k, { i18n: {} });
