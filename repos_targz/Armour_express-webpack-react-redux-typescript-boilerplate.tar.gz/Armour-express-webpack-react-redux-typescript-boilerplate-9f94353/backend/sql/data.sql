INSERT INTO notes (content) VALUES ('note data 1');
INSERT INTO notes (content) VALUES ('note data 2');
