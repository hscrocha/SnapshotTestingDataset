export { BodyContentLoader, HeaderContentLoader, FooterContentLoader } from './contentLoader';
