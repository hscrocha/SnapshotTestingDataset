export { default } from './footer';
