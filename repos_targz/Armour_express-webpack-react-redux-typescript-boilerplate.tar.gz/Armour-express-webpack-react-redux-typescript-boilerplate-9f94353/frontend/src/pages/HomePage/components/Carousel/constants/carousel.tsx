// Toast timer
export const TOAST_DISPLAY_DURATION = 3000;

// Tooltip timer
export const TOOLTIP_DELAY_TIME = 50;

// Carousel autoplay interval
export const CAROUSEL_AUTOPLAY_INTERVAL = 3500;
