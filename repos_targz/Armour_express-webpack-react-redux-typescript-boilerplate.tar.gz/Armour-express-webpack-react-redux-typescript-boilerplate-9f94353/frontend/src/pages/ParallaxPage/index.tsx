export { default } from './parallaxPage';
