export { default } from './prismCodes';
export * from './constants/prismCodes';
