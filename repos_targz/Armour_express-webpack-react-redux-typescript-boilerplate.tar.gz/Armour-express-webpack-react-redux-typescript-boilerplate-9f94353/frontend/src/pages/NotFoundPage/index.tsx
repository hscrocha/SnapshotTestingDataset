export { default } from './notFoundPage';
