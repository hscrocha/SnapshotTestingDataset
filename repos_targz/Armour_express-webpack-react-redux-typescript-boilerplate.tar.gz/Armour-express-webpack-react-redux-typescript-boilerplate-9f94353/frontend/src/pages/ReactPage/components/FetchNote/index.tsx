export { default } from './fetchNote';
