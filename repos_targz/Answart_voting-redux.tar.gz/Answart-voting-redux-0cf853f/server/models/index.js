

module.exports = () => {
  require('./user');
  require('./poll');
}
