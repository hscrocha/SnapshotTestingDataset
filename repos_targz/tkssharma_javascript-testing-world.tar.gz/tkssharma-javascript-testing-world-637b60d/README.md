## 🥼🧬🧪🔬🧫🦠  All about javascript testing using different Libraries 🥼🧬🧪🔬🧫🦠 

## 🥼🧬🧪🔬🧫🦠  Testing in javascript 
- https://www.youtube.com/watch?v=G2Apg6Pb1BY&list=PLIGDNOJWiL1-IVcu_hvsIPQJRZ9oOwWRf 

### What we are covering in this playlist 🥼🧬🧪🔬🧫🦠 

- This covers all about testing in javascript
- testing using simple assertion librray chai, mocha.
- testing react components using jest 
- using jest test runner for all kind of testing 
- using nyc and istanbul for getting coverage for testing 
- writing unit and e2e test cases for api and UI components 
- E2E functional testing using cypress


![](https://i.ytimg.com/vi/9mqwmpA8CSo/maxresdefault.jpg)
