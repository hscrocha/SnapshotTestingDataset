import React from 'react';
import './App.css';
import Body from './components/Body';

function App() {
  return (
    <div className="App">
      <Body title="Hello world"/>
    </div>
  );
}

export default App;
