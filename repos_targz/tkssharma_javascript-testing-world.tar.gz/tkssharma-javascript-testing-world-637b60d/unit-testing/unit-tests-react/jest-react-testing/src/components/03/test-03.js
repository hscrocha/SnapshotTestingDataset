import React, { useState } from "react";

function App() {

  return (
    <>
      <div data-testid="custom-element" />
      <span title="Delete" id="2"></span>
      <svg>
        <title>Close</title>
        <g><path /></g>
      </svg>
      <img alt="Incredibles 2 Poster" src="/incredibles-2.png" />
      <a href="/about">About ℹ️</a>
      <div role="dialog">...</div>
    </>
  )
}

export default App;