import React from 'react';
import './App.css';
import Hello from './components/hello/hello';

function App() {
  return (
    <div className="App">
      <Hello title="Hello world"/>
    </div>
  );
}

export default App;
