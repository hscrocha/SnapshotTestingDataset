## React Testing
This project is part of the medium article at https://medium.com/@mayooresan/beginners-guide-to-react-testing-with-testing-library-97f23b4af40f