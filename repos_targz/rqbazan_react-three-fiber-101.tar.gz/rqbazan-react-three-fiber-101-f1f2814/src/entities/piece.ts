export default class Piece {
  key: number

  constructor(key: number) {
    this.key = key
  }
}
