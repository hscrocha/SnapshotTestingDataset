<h1 align="center">
  <br>
  <img align="center" src="https://raw.githubusercontent.com/evilfactorylabs/nadya/canary/app/src/assets/illustrations/money.png" width="666">
  <br>
</h1>

> subscription management done right

Current debt:

[![counter](https://img.shields.io/badge/dynamic/json.svg?label=TODO&query=%24.total_count&url=https%3A%2F%2Fapi.github.com%2Fsearch%2Fcode%3Fq%3Dtodo%2Bin%3Afile%2Brepo%3Aevilfactorylabs%2Fnadya&color=green")](https://github.com/evilfactorylabs/nadya/search?q=todo) [![counter](https://img.shields.io/badge/dynamic/json.svg?label=FIXME&query=%24.total_count&url=https%3A%2F%2Fapi.github.com%2Fsearch%2Fcode%3Fq%3Dfixme%2Bin%3Afile%2Brepo%3Aevilfactorylabs%2Fnadya&color=orange)](https://github.com/evilfactorylabs/nadya/search?q=fixme)

## Canary release

https://canary.nadya.app
