module.exports = {
  target: 'serverless'
}
