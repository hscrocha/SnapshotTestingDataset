test.todo('It should delete database and userId from localStorage')
