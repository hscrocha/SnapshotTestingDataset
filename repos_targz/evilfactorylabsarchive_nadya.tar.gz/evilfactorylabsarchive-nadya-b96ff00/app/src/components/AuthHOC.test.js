import React from 'react'

describe('Test AuthHOC', () => {
  test.todo('Render <Component /> if authorized')
  test.todo('Render <Onboarding /> if unauthorized')
})
