import React from 'react'

const LoadingPage=()=>(

  <div className="loader">
    <img src="/images/Spinner.gif" />

  </div>
);
export default LoadingPage;
