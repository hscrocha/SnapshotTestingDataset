export const update_state = payload => ({
  type: 'UPDATE_STATE',
  payload
})

export const update_state_asyncSaga = payload => ({
  type: 'UPDATE_STATE_SAGA',
  payload
})

export const update_state_TakeLatest = payload => ({
  type: 'UPDATE_STATE_TAKELATEST',
  payload
})

export const update_other_state = payload => ({
  type: 'UPDATE_OTHER_STATE',
  payload
})