const initSate = {
  testData: 1314
}

export default initSate