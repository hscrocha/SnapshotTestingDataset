const initSate = {}

export default initSate