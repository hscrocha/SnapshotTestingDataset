import { combineReducers } from 'redux'
import common from './common/common'
import other from './other/other'

export default combineReducers({
  common,
  other
})