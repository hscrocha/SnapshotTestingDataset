import axios from '@src/servers/interceptors';
//请求接口数据的方法规整

// /* 获取IP信息等 */
// export function ipInfo() {
//   return axios.get('xxxxxxxxxxxxxxxxxx');
// }