import Router from 'next/router';

Router.router = {
  push: () => {},
  prefetch: () => new Promise(() => {}),
};
