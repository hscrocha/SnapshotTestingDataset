export enum Language {
  'pt' = 'pt',
  'en' = 'en',
  'es' = 'es',
}

export enum LanguageResource {
  'pt' = 'Português',
  'en' = 'English',
  'es' = 'Español',
}
