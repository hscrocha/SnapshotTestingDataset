export interface i18n {
  t: (message: string, args?: string[]) => string
}
