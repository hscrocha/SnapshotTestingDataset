export { default as Technology } from './Technology'
export type { TechnologyProps, TechnologySize } from './Technology'
