export { default as ContactCard } from './ContactCard'
export type { ContactCardProps } from './ContactCard'
