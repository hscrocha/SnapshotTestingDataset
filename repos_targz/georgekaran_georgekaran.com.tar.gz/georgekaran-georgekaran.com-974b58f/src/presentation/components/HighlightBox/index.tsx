export { default as HighlightBox } from './HighlightBox'
export type { HighlightBoxProps } from './HighlightBox'
