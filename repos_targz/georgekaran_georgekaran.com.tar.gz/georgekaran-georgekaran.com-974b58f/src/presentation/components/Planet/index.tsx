export { default as Planet } from './Planet'
export type { PlanetProps } from './Planet'
