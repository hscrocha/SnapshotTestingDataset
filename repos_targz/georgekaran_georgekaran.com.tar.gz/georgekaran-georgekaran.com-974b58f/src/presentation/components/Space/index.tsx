export { default as Space } from './Space'
export type { SpaceProps } from './Space'
