export { default as Heading } from './Heading'
export type { HeadingProps } from './Heading'
