export { default as Footer } from './Footer'
export type { FooterProps } from './Footer'
