export { default as Testimonional } from './Testimonional'
export type { TestimonionalProps } from './Testimonional'
