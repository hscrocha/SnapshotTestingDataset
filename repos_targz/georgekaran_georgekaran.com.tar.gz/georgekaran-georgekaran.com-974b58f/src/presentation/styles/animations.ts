export const baseAosAnimation = {
  'data-aos-duration': '800',
  'data-aos-easing': 'ease',
  'data-aos-once': 'true'
}
