/*
 * @Author: 廉恒凯
 * @Date: 2020-01-05 16:27:56
 * @LastEditors: 廉恒凯
 * @LastEditTime: 2020-05-04 16:15:00
 * @Description: file content
 */
import getInitList from './list';

export default getInitList;
