/*
 * @Author: 廉恒凯
 * @Date: 2020-05-05 13:22:16
 * @LastEditors: 廉恒凯
 * @LastEditTime: 2020-05-05 13:22:59
 * @Description: file content
 */
const RESET_ERROR_MESSAGE = 'RESET_ERROR_MESSAGE';

export default RESET_ERROR_MESSAGE;
