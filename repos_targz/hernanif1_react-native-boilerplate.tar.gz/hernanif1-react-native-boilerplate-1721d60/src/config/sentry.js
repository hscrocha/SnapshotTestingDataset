import Sentry from 'sentry-expo';

Sentry.config(
  'PUT_YOUR_ID_HERE'
).install();
