import Color from './color';

export default Color;
