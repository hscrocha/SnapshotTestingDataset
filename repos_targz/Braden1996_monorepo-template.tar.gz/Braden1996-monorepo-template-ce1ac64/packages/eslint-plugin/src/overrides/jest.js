module.exports = {
  files: [
    '**/*.test.js',
    '**/*.spec.js',
    '**/*.test.ts',
    '**/*.spec.ts',
    '**/*.test.tsx',
    '**/*.spec.tsx',
  ],
  extends: ['plugin:jest/recommended'],
};
