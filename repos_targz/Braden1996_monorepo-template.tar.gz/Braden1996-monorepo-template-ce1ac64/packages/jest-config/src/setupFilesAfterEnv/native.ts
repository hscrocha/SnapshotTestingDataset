import '@testing-library/jest-native/extend-expect';
import 'jest-styled-components/native';
