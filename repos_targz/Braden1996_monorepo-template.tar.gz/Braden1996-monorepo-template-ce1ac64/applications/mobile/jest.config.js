const jestPreset = require('@monorepo-template/jest-config/presets/react-native/jest-preset');

module.exports = jestPreset;
