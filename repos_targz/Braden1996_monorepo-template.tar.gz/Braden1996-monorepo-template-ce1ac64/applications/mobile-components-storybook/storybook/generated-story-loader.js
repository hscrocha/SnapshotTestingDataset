// Auto-generated file created by react-native-storybook-loader
// Do not edit.
//
// https://github.com/elderfo/react-native-storybook-loader.git

function loadStories() {
  require('../../../packages/mobile-components/src/components/atoms/GhostButton/GhostButton.stories');
  require('../../../packages/mobile-components/src/components/particles/Colors/Colors.stories');
  require('../../../packages/mobile-components/src/components/particles/Pressable/Pressable.stories');
}

const stories = [
  '../../../packages/mobile-components/src/components/atoms/GhostButton/GhostButton.stories',
  '../../../packages/mobile-components/src/components/particles/Colors/Colors.stories',
  '../../../packages/mobile-components/src/components/particles/Pressable/Pressable.stories',
];

module.exports = {
  loadStories,
  stories,
};
