// Type our generated generated-story-loader file.
export declare const loadStories: () => void;
export declare const stories: Array<string>;
