/** @format */

import { atom } from 'jotai';
import { APIResponseInterface } from 'types';

export const pokemonsAtom = atom<APIResponseInterface[]>([]);
export const inputAtom = atom<string>('');
export const darkModeAtom = atom<boolean>(false);
