'use strict';
const routesOffers = require('./offersRoutes');


module.exports = app => {
    routesOffers(app);
};