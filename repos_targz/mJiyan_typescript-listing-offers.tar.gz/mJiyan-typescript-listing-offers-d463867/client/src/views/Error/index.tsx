import { ErrorCard } from '../../components';

const Error = () => {
  return <ErrorCard />;
};

export default Error;

// if the server return error then this page will be showed