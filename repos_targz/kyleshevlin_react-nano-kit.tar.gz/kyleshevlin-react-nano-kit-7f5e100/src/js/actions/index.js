import * as types from '../constants/actionTypes'

export function testActionCreator() {
  return { type: types.TEST_ACTION_CREATOR }
}
