// eslint-disable-next-line import/prefer-default-export
export const TEST_ACTION_CREATOR = 'TEST_ACTION_CREATOR'
