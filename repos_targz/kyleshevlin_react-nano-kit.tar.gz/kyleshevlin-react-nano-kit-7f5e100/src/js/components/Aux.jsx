// @flow

const Aux = ({ children }: { children: Array<any> }) => children

export default Aux
