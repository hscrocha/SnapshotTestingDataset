import Example from './Components/Example.js';

function App() {
  return (
    <div className="App">
      <h1>Horizontal Scrolling Cards</h1>
      <Example/>
    </div>
  );
}

export default App;
