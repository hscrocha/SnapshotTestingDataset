import Product from 'components/pages/product';

export default Product;
