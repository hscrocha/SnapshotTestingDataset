import Products from 'components/pages/products';

export default Products;
