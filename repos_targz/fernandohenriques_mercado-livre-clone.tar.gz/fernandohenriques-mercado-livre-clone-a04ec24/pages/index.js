import Home from 'components/pages/home';

export default Home;
