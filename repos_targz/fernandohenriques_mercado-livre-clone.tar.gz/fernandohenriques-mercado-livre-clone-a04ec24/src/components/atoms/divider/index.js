import React from 'react';
import styles from './index.module.scss';

const Divider = () => (
  <div className={styles.divider} />
);

export default Divider;
