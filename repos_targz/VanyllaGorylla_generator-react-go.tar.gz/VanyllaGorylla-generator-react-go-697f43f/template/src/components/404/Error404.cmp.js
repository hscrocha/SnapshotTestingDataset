import React from 'react';

const Error404Handler = () => (
  <div className="row">
    <div className="col">
      <h3>Error 404 - no page found</h3>
    </div>
  </div>
);

export default Error404Handler;
