import Posts from './Posts.cmp';

import PostsEdit from './PostsEdit.cmp';

export { Posts, PostsEdit };
