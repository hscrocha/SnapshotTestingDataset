import React from 'react';
import { Container, Card } from 'react-materialize';

const Index = () => (
  <Container className="index">
    <Card title="Hello my friend!!" />
  </Container>
);

export default Index;
