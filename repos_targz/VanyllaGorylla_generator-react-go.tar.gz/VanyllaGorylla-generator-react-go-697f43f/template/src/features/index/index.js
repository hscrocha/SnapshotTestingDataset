export { default as Index } from './Index.cmp';
