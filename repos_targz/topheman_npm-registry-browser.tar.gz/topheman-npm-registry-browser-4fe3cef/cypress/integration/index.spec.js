import "./home.spec";
import "./package.spec";
import "./qrcode.spec";
import "./about.spec";
import "./search.spec";
import "./searchResults.spec";
