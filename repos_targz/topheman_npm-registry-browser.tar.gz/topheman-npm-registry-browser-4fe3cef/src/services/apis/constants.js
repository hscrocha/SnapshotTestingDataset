export const TARGET_API_NPM_REGISTRY = "npmRegistry";
export const TARGET_API_NPM_API = "npmApi";
export const TARGET_API_NPMS_IO = "npmsIo";
