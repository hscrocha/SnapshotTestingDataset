export default (() => {
  throw new Error('erro');
})();
