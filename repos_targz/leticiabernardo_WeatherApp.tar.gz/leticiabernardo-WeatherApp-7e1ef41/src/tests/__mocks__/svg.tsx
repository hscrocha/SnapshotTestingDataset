export = {
  ReactComponent: () => <div className="svg-mock" />,
};
