import makeConsoleMock from './consolemock';

export default makeConsoleMock;
