// import React from 'react';
// import {render} from 'react-testing-library';
import {createSerializer} from 'jest-emotion';
import * as emotion from 'emotion';

// import FormContainer from './FormContainer';

expect.addSnapshotSerializer(createSerializer(emotion));

describe('Component: FormContainer', () => {
  test('should ', () => {});
});
