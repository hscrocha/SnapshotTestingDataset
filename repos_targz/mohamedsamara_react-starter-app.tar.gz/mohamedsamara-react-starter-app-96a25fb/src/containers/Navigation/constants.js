/*
 *
 * Navigation constants
 *
 */

export const TOGGLE_DRAWER = 'src/Navigation/TOGGLE_DRAWER';
