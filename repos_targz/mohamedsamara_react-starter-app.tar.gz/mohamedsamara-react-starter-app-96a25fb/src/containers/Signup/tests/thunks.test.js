// import { fetch } from '../thunks';

describe('Signup Thunk', () => {
  it('should calls the function fetch', () => {});
});
