/*
 *
 * Signup constants
 *
 */

export const DEFAULT_ACTION = 'src/Signup/DEFAULT_ACTION';
