/*
 *
 * TopHeader constants
 *
 */

export const OPEN_MENU = 'src/TopHeader/OPEN_MENU';
export const CLOSE_MENU = 'src/TopHeader/CLOSE_MENU';
