/*
 *
 * TopHeader types
 *
 */

// import propType definitions
import { node, any } from 'prop-types';

export const anchorEl = any;
