/*
 *
 * Post constants
 *
 */

export const FETCH_POSTS_REQUEST = 'src/Post/FETCH_POSTS_REQUEST';
export const FETCH_POSTS_SUCCESS = 'src/Post/FETCH_POSTS_SUCCESS';
export const HANLDE_POSTS_FAILURE = 'src/Post/HANLDE_POSTS_FAILURE';
export const DELETE_POST_SUCCESS = 'src/Post/DELETE_POST_SUCCESS';
