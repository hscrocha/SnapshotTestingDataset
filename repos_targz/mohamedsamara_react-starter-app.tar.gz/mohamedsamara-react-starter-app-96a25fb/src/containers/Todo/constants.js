/*
 *
 * Todo constants
 *
 */

export const FETCH_TODOS_REQUEST = 'src/Todo/FETCH_TODOS_REQUEST';
export const FETCH_TODOS_SUCCESS = 'src/Todo/FETCH_TODOS_SUCCESS';
export const FETCH_TODOS_FAILURE = 'src/Todo/FETCH_TODOS_FAILURE';
