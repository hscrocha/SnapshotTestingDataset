/*
 *
 * LanguageProvider constants
 *
 */

export const SET_LOCALE = 'src/LanguageProvider/SET_LOCALE';
