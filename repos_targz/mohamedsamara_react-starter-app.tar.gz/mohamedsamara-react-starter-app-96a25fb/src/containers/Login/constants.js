/*
 *
 * Login constants
 *
 */

export const DEFAULT_ACTION = 'src/Login/DEFAULT_ACTION';
