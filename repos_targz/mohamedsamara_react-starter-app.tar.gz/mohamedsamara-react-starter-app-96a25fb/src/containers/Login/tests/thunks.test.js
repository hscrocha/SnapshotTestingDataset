// import { fetch } from '../thunks';

describe('Login Thunk', () => {
  it('should calls the function fetch', () => {});
});
