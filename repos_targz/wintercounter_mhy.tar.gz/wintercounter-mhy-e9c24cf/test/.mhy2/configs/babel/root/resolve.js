module.exports = function() {
    return {
        zekeizon: 'trunkcall'
    }
}
