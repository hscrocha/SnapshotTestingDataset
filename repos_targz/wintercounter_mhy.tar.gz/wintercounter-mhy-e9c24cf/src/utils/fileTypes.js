export default {
    JS: 'js',
    MJS: 'mjs',
    JSX: 'jsx',
    TS: 'ts',
    TSX: 'tsx',
    JSON: 'json',
    JSON_NO_EXT: 'json-no-ext',
    RAW: 'raw',
    ESM: 'esm'
}
