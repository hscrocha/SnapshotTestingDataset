export default () => 'source-map'
