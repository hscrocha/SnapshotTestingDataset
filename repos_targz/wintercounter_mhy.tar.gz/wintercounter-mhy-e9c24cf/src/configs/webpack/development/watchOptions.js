export default () => ({
    ignored: ['node_modules', 'build', 'dist', 'cache', '__']
})
