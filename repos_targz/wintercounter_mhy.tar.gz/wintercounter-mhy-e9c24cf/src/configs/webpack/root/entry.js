export default () => {
    const returnValue = {
        app: ['./src']
    }
    return returnValue
}
