export default () => 'nosources-source-map'
