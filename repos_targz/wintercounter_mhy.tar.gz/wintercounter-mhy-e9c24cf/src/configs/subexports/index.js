import { loadConfig } from '@/utils'

const subexportsConfig = loadConfig('subexports', {})

export default subexportsConfig
