import '@/utils/globals'

import loader from './loader'

export default loader
