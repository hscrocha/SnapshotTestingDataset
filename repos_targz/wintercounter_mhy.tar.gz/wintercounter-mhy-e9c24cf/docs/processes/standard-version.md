# standard-version

- Alias: `sv`

## Default command
```bash
standard-version
```

## CLI Options
https://github.com/conventional-changelog/standard-version

## Examples

### Default CLI
```bash
mhy sv
```

### With argument
```bash
mhy sv --dry-run
```