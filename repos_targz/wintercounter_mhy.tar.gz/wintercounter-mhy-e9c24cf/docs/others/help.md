# Help

## Experienced/resolve any issues?
Help your fellow developers and make a PR to this page with your solution! Thank you!

## TypeScript

### Errors after updating `mhy` to the latest version.
1. Remove your local `node_modules` folder if you have any.
2. `npm i` if you have any local dependencies.
3. Use `mhy config typescript -io` to regenerate your `tsconfig.json` file.
4. You might also need an IDE restart.


