# suggest

## Suggest a library

You can suggest any JS library to be added to the project. Use GitHub issues for that. The goal is you don't need to install anything to work on you project.