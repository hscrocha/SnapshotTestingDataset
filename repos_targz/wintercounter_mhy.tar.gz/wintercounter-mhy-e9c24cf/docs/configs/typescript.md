# typescript

* [https://www.typescriptlang.org/docs/handbook/compiler-options.html](https://www.typescriptlang.org/docs/handbook/compiler-options.html)
* [https://www.typescriptlang.org/docs/handbook/tsconfig-json.html](https://www.typescriptlang.org/docs/handbook/tsconfig-json.html)

```bash
# Print config to console
mhy config typescript

# Write tsconfig.json
mhy config typescript -i
```

## Used by

* `typescript`

