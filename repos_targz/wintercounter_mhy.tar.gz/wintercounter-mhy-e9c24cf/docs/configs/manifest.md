# manifest

[https://developer.mozilla.org/en-US/docs/Web/Manifest](https://developer.mozilla.org/en-US/docs/Web/Manifest)

Used by `webpack` to generate `manifest.json` WebApp Manifest file.

```bash
# Print config to console
mhy config manifest

# Write manifest.json
mhy config manifest -i
```

## Used by

* `webpack`

