# webpack

[https://webpack.js.org/configuration/](https://webpack.js.org/configuration/)

```bash
# Print config to console
mhy config webpack

# Write webpack.config.js
mhy config webpack -i
```

## Used by

* `webpack`
* `webpack-dev-server`
* `storybook-start`

