# swc

[https://swc.rs/docs/configuration/swcrc](https://swc.rs/docs/configuration/swcrc)

```bash
# Print config to console
mhy config swc

# Write .swcrc
mhy config swc -i
```

