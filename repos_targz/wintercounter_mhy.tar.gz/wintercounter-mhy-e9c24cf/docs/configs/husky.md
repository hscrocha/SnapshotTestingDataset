# Husky

Add githooks support to your project. To add custom rules simply modify generated .huskyrc

[Husky](https://github.com/typicode/husky)

```bash
# First generate Husky config by running 
mhy config
# or 
mhy config husky -i
```