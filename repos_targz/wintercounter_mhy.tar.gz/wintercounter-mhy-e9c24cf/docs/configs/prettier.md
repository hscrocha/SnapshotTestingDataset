# prettier

[https://prettier.io/docs/en/configuration.html](https://prettier.io/docs/en/configuration.html)

```bash
# Print config to console
mhy config prettier

# Write .prettierrc
mhy config prettier -i
```

## Used by

* `prettier`

