# add-your-own

Since `mhy` can be used in many different ways for many different cases, there can be a tons of great solutions. You're always welcome to add your own solutions to the list on the for of a Pull Request.