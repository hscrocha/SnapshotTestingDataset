# Installation

```text
npm i mhy -g
```

> `mhy` has an _always-up-to-date_ policy which means it is updated
> regularly. Please follow this practice in your project also.
> To update `mhy` simply use: `npm i mhy@latest -g`.
>
> Even though it's possible, `mhy` isn't supposed to be installed locally.
