import { RickAndMorty } from '@/services'

export const getCharacter = (opt = {}) => RickAndMorty('character', opt) // eslint-disable-line
