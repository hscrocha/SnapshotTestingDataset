export { default as RickAndMorty } from './RickAndMorty' // eslint-disable-line
