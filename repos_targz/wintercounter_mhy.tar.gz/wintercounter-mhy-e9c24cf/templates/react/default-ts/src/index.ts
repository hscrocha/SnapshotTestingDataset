import { Mount } from '@/core'

const initialState = {}
const root = document.querySelector('#root')

Mount(root, initialState)
