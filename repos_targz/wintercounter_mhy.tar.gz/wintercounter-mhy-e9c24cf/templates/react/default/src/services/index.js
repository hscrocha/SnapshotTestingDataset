export RickAndMorty from './RickAndMorty'
