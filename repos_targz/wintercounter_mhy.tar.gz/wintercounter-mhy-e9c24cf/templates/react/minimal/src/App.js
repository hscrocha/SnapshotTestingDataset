import React from 'react'

const styles = {
    display: 'flex',
    height: '100vh',
    alignItems: 'center',
    justifyContent: 'center'
}

const App = () => <div style={styles}>Hello mhy!</div>

export default App