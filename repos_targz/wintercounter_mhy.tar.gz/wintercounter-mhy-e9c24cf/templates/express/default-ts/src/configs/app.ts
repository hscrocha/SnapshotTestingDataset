export const port = 4000

export default {
    port
}