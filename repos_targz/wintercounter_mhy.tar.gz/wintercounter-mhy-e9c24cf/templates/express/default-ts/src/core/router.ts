import app from '@/core/app'

app.get('/', (req, res) => res.send('Hello World!'))