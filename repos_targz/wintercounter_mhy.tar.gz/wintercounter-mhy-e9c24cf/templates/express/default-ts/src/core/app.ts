import express from 'express'

export default express()
