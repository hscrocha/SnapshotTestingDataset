module.exports = {
  preset: "jest-hugo",
  reporters: ["default", "jest-junit"]
}
