import {combineReducers} from 'redux';
import repos from './repos';

const reducers = combineReducers({
  repos
});

export default reducers;
