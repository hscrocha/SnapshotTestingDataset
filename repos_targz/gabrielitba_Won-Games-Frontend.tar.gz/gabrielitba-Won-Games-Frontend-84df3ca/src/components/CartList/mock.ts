export default [
  {
    id: '1',
    img: 'https://source.unsplash.com/user/willianjusten/151x70',
    title: 'Red Dead Redemption 2',
    price: 'R$ 215,00',
  },
  {
    id: '2',
    img: 'https://source.unsplash.com/user/willianjusten/151x70',
    title: 'Borderlands 3',
    price: 'R$ 215,00',
  },
];
