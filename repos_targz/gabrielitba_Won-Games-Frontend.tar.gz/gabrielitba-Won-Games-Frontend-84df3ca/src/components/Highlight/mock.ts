const highlight = {
  title: 'Read Dead is back!',
  subtitle: 'Come see John new adventures',
  backgroundImage: '/img/red-dead-img.jpg',
  buttonLabel: 'Buy now',
  buttonLink: '/games/rdr2',
};

export default highlight;
