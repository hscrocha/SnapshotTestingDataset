// import { defenderLifeBar } from '../selectors/lifeBar'

// export const checkDefenderEffects = ({ wrap = 1, count }: { wrap?: number, count: number }) => {
//   defenderEffectsWrap().should('have.length', wrap)
//   defenderEffectsBottom().should('have.length', count)
//   defenderEffectsTop().should('have.length', count)
//   defenderEffectsIcon().should('have.length', count)
// }
