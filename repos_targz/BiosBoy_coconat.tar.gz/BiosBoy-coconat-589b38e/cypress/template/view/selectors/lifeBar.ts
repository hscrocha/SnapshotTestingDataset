// export const defenderLifeBar = () => cy.get('#player-progress_toshykazu')
