// import { common } from '../view/selectors'

// export const start = () => common.start.click()
// export const leave = () => common.leave.focus()
// export const escape = () => common.escape.click()
