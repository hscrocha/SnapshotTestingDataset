// export type TWeaponsType = 'mainWeapon' | 'secondaryWeapon' | 'meleeWeapon' | 'tempWeapon' | 'fistsWeapon'

// export interface IShouldAttack {
//   weaponType: TWeaponsType
//   attackCount: number
// }

// export interface IRunFight {
//   withFocus?: boolean
// }
