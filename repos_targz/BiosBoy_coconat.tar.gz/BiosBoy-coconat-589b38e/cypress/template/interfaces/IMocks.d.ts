// export interface IStartFightData {
//   step: 'startFight'
//   user2ID: '1435333'
// }
