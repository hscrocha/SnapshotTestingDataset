const subscribeAPI = () => {
  // cy.route('POST', '/loader.php?sid=attackData&mode=json').as('action');
}

export default subscribeAPI
