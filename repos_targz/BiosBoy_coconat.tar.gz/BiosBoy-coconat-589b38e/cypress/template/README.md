# Cypress Template - best way to start your E2E App development

## Please, follow the architecture designed in this folder

## This is optimized way for creating and expanding your App E2E testing

* For any question contact 3p-sviat in Slack or mail, please.

Thanks!
