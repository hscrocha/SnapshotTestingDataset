// import initiateE2ETest from '../../../services/initiateE2ETest'

// const runFight = ({ withFocus = false }: { withFocus?: boolean }) => {
//   initiateE2ETest({
//     runAPI: subscribeAPI,
//     url: `/loader.php?sid=attack&user2ID=${RIVAL_ID}`
//   })

//   // initial load data
//   onInit()

//   // focus should fire
//   withFocus && onFocus()

//   // poll should running
//   onPoll()

//   // staring fight
//   onStart()
// }

// export default runFight
