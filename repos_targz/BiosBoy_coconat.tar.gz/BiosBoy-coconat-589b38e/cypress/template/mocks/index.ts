// const startFightData = {
//   step: 'startFight',
//   user2ID: '1435333'
// }

// export {
//   startFightData
// }

