export const BASE_ROOT = 'www.google.com'
