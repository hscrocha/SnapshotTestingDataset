import runFight from './runFight'
import shouldAttack from './shouldAttack'
import finishFight from './finishFight'
import redirectToLog from './redirectToLog'

export {
  runFight,
  shouldAttack,
  finishFight,
  redirectToLog
}
