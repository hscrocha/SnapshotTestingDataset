# Attack - E2E scenarios


## 2.0.0
 * Fully covered Attacker & defender behaviors UI tests.
 * Improved selector structure.

## 1.7.0
 * Added Effects Behavior UI test suits.

## 1.6.0
 * Added StatusBar Behavior UI test suits.

## 1.5.0
 * Added Attacker Model and Armour Behavior UI test suits.

## 1.4.0
 * Added Attacker Overlay Behavior UI test suits.

## 1.3.0
 * Added Weapons Behavior UI test suits.
 * Added IndicatorFacilities Behavior UI test suits.
 * Added StealthBar Behavior UI test suits.

## 1.2.0
 * Added Header Behavior UI test suits.

## 1.1.0
 * Added 3 NPC fight tests.

## 1.0.0
 * Added first 3 basic scenarios.
