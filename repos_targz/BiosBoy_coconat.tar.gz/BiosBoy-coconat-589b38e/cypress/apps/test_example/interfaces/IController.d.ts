export type TPersonTypes = 'attacker' | 'defender'
