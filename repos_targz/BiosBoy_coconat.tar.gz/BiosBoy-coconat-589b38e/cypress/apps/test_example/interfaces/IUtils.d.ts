import { TModalTypes } from './IModules'

export interface IGetModalTitle {
  type: TModalTypes
  removeName: boolean
}
