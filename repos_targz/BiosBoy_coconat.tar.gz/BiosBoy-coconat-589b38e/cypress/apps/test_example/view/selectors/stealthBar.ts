export const stealthBar = () => cy.get('#attacker [class^="stealthBarWrap"]')
export const stealthBarIcon = () => cy.get('#attacker [class^="iconStealth"]')
