const initialState = {
  app: {
    appName: 'CoConatBuider',
    imageToShow: 1
  }
}

export default initialState
