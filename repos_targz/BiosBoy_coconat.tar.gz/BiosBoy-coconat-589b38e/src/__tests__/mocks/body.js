export default {
  imageToShow: 1,
  switchImage: (imgNumber) => imgNumber
}
