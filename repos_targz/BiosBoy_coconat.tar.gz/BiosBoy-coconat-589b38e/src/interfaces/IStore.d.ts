// TODO: make store logic typed
export interface IAsyncReducersStore {
  asyncReducers: object
}
