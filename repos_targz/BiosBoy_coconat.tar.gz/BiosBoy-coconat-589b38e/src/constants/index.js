export const SWITCH_IMAGE = 'SWITCH_IMAGE'
// consts for Saga asyc actions, probably you do not need this below
export const SOME_SAGA = 'SOME_SAGA'
export const SOME_ASYNC_ACTION = 'SOME_ASYNC_ACTION'
