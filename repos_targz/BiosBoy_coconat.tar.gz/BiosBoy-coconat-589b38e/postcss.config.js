module.exports = {
  plugins: {
    'postcss-import': {},
    'postcss-cssnext': {},
    'postcss-preset-env': {},
    'cssnano': {}
  }
};
