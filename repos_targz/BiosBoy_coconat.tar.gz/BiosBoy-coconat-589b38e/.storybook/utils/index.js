import getMediaType from './getMediaType'

export { getMediaType }
