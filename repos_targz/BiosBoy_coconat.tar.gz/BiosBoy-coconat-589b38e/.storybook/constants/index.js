export const BACKGROUNDS = {
  backgrounds: [
    { name: 'ccc', value: '#ccc', default: true },
    { name: 'white', value: '#fff' },
    { name: 'black', value: '#111' }
  ]
}
