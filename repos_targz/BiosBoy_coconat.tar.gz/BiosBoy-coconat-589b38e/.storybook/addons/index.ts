import withCustomStyles from './withCustomStyles'

export { withCustomStyles }
