# Expensify

Expensify is a SPA that helps managing your expenses.

# Live

Live example of this app can be found at: https://expensify-spa.herokuapp.com/
