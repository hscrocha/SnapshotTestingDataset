export default {
  url: 'https://strapi-landing-pages-bylazo.herokuapp.com/pages/?slug=',
  defaultSlug: 'landing-page',
};
