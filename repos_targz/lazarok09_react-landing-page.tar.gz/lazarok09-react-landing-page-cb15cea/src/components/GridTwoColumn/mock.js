export default {
  title: 'Grid Two Columns',
  text: `Lorem ipsum dolor sit amet, consectetur adipisicing elit. Culpa perspiciatis obcaecati recusandae eum, harum veniam sequi quisquam beatae, qui voluptates rerum minima vel laborum adipisci! Corporis beatae sunt quisquam ipsum.`,
  srcImage: 'assets/images/javascript.svg',
};
