import * as Styled from './styles';

export const Loading = () => {
  return <Styled.Container />;
};
