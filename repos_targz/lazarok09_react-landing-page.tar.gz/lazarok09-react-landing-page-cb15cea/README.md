<h1 align=center>
Finalizado ㊗️
</h1>

<h3 align=center>
  
[veja como ficou](https://react-landing-page-bylazo.netlify.app/)
  
</h3>
