import Pets from './Pets';

const entities = {
  Pets,
};

export const dbEntities = Object.values(entities);
export default entities;
