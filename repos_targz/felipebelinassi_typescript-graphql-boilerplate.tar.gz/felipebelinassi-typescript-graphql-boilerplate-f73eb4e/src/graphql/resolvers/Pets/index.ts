import pets from './queries/pets';
import createPet from './mutations/createPet';

export default {
  pets,
  createPet,
};
