import Info from './queries/info';

export default {
  Info,
};
