declare const before: (message: string, callback: () => void) => void;
declare const after: (message: string, callback: () => void) => void;
