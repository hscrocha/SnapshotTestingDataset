module.exports = {
  plugins: ["jest"],
  env: {
    jest: true
  },
  globals: {
    given: "readonly",
  }
};