module.exports = {
  plugins: ["jasmine"],
  env: {
    jasmine: true
  },
};