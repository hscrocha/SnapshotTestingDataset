module.exports = {
  plugins: ["mocha"],
  env: {
    mocha: true
  },
};
