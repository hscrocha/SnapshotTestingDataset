module.exports = {
  plugins: ["jest"],
  env: {
    jest: true
  }
};
