# Demo
This folder contains the files for the demo, which you can find online at
[chunfeilung.github.io/game-of-life](https://chunfeilung.github.io/game-of-life).
