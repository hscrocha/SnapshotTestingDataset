This folder is meant for strictly functional components that serve as building blocks of the UI. 
