const units = {
  MINKM: 'minkm',
  KMH: 'kmh',
  MINMI: 'minmi',
  MIH: 'mih'
};

module.exports = units;
