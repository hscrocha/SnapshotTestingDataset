const convert = require('./convert');

module.exports = { convert };
