export interface SEO {
  title: string
  description?: string
}
