export interface FetchParams {
  variables?: any
  preview?: boolean
}
