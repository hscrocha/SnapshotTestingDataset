export const companies = [
  {
    name: 'Yellow.ai',
    path: '/static/yellow_ai.svg',
  },
  {
    name: 'Daikin',
    path: '/static/daikin.svg',
  },
  {
    name: 'Softway',
    path: '/static/softway.svg',
  },
  {
    name: 'Dish',
    path: '/static/dish.svg',
  },
  {
    name: 'Betsol',
    path: '/static/betsol_logo.svg',
  },
  {
    name: 'Homero',
    path: '/static/Homero.svg',
  },
]
