## adithyabhat.com

[![Codacy Badge](https://api.codacy.com/project/badge/Grade/cc374861dc924f6f8e2f3175cf29e81a)](https://app.codacy.com/manual/adithyabhat17.ab/adithyabhat.com?utm_source=github.com&utm_medium=referral&utm_content=AdithyaBhat17/adithyabhat.com&utm_campaign=Badge_Grade_Settings)

This repository contains the source code for my new portfolio (2021)

### Tools used
- Figma (Design)
- Next
- React
- Tailwind CSS
- TypeScript
- Framer Motion (Micro-animations)
- react-datocms (SEO and Images)
- react-hook-form
- react-intersection-observer

