module.exports = {
  cliOptions: {
    maxWarnings: 2,
  },
};
