module.exports = {
  runner: '../../../',
  testMatch: ['**/__eslint__/**/*.js'],
};
