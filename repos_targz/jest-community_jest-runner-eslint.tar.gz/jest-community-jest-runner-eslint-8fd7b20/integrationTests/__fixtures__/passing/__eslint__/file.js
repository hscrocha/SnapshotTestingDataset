const a = 1;

if (a === 2) {
  hello();
}
