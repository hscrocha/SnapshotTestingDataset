module.exports = {
  cliOptions: {
    format: 'codeframe',
  },
};
