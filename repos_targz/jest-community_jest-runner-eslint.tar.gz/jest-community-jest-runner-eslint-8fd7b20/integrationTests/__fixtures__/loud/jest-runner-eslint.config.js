module.exports = {
  cliOptions: {
    quiet: false,
  },
};
