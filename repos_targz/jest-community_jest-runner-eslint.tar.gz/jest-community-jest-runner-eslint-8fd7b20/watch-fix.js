const ESLintWatchFixPlugin = require('./build/watchFixPlugin');

module.exports = ESLintWatchFixPlugin;
