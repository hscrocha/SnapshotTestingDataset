function b() {}
const a = 1;

if (a === 1) {
  b();
  hello();
}
