*All PRs should be based on an issue*
**WHY?**
See issue # / A short description
**WHAT?**
A short description of the changes

- [ ] I have considered (and possibly added) tests
- [ ] I have updated the documentation (gitbook)

[Optional] Resolves #
