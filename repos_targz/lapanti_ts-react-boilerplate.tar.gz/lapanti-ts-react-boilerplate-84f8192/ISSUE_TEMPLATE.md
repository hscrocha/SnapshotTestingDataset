*Make sure the title is descriptive*

This is a feature request/bug report/something else

Add a short description

I will create a PR with the solution / I need help to create a PR / I don't have the time/skills to create a PR
