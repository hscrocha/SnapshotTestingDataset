export default [
  { location: 0, sign: "X"}, 
  { location: 1, sign: "O"}, 
  { location: 2, sign: "X"}, 
  { location: 3, sign: "O"}, 
  { location: 4, sign: "X"},
  { location: 8, sign: "X"},
]

test("could not find ignore this file for jest", () => {
  expect(true).toBe(true)
})