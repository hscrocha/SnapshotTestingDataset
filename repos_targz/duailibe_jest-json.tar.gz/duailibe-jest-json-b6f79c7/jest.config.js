"use strict";

module.exports = {
  snapshotSerializers: [
    "jest-snapshot-serializer-ansi",
    "jest-snapshot-serializer-raw/always",
  ],
};
