export default {
  print (str) {
    console.log(str)
  }
}