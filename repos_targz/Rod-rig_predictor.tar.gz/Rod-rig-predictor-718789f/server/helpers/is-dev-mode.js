exports.isDevMode = () => {
  return process.env.NODE_ENV === "development";
};
