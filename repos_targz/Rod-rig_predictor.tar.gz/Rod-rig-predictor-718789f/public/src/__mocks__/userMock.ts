/* tslint:disable: object-literal-key-quotes object-literal-sort-keys*/
export const userMock = {
  isLoggedIn: true,
  name: "test user",
};
