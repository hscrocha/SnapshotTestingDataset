/* tslint:disable: object-literal-key-quotes object-literal-sort-keys*/
export const predictions = [
  {
    awayTeam: "Tottenham Hotspur",
    homeTeam: "Newcastle United",
    homeScore: 2,
    awayScore: 2,
    status: 0,
    id: "sr:match:1",
    season: "19/20",
  },
  {
    awayTeam: "West Ham United",
    homeTeam: "Liverpool FC",
    homeScore: 1,
    awayScore: 2,
    status: 1,
    id: "sr:match:2",
    season: "19/20",
  },
  {
    awayTeam: "Manchester City",
    homeTeam: "Wolverhampton Wanderers",
    homeScore: 6,
    awayScore: 1,
    status: -1,
    id: "sr:match:3",
    season: "19/20",
  },
  {
    awayTeam: "Fulham FC",
    homeTeam: "Cardiff City",
    homeScore: 1,
    awayScore: 1,
    status: 0,
    id: "sr:match:4",
    season: "19/20",
  },
];
