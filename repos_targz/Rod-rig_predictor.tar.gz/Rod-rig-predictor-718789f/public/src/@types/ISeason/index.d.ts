export interface ISeason {
  end_date: string;
  id: string;
  name: string;
  start_date: string;
  tournament_id: string;
  year: string;
}
