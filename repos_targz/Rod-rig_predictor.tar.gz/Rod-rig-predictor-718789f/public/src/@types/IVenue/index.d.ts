export interface IVenue {
  capacity: number;
  city_name: string;
  country_code: string;
  country_name: string;
  id: string;
  map_coordinates: string;
  name: string;
}
