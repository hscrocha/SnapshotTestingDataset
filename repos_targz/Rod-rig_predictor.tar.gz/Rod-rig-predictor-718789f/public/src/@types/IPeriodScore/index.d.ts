export interface IPeriodScore {
  away_score: number;
  home_score: number;
  number: number;
  type: string;
}
