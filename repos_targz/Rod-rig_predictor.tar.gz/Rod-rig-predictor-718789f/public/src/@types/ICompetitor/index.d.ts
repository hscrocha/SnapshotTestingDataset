export interface ICompetitor {
  abbreviation: string;
  country: string;
  country_code: string;
  id: string;
  name: string;
  qualifier: string;
  userPrediction?: number;
}
