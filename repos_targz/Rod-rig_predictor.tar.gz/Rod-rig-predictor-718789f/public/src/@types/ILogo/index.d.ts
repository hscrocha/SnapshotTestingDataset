export interface ILogo {
  [index: string]: string;
}
