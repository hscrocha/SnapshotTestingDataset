export const ASC = "asc";
export const DESC = "desc";
export const TOTAL_PREDICTIONS = "totalPredictions";
export const CORRECT_PREDICTIONS = "correctPredictions";
export const SUCCESS_RATE = "successRate";
export const ONEXTWO_SUCCESS_RATE = "oneXTwoSuccessRate";
export const ORDER_BY = ONEXTWO_SUCCESS_RATE;
