export type Inputs = {
  email: string;
  password: string;
};
