export default {
  convertor: require("./templates/puppeteer/core.js"),
  mochaSetup: require('./mocha-setup'),
}
