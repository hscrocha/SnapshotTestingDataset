export default ['Helsinki'];
export const lengthTwo = ['Helsinki', 'Istanbul'];
export const lengthMore = ['Helsinki', 'Istanbul', 'New York'];
