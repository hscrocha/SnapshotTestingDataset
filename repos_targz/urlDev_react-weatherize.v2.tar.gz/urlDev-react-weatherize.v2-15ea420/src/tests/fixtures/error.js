export default {
  message: 'city not found',
  error: 'city not found',
};

export const errorConnection = {
  Error: 'Request failed with status code 404',
};

export const error = {
  error: 'Failed to fetch',
};
