import {combineReducers} from 'redux'
import basicReducer from './basicReducer/basicReducerReducer'
export default combineReducers({basicReducer})
