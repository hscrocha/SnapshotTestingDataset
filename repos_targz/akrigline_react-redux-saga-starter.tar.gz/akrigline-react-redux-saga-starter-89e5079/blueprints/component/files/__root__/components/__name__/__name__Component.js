import React from 'react'

export default function <%= pascalEntityName %> (props) {
  return (
    <div>
      <p>Things!</p>
    </div>
  )
}
