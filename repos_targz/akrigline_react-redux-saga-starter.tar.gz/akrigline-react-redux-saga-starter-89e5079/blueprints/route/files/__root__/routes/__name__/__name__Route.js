import React from 'react'

class <%= pascalEntityName %>Scene extends React.Component {
  props: {

  }

  render () {
    return (
      
        <div>
          Things!
        </div>

    )
  }
}

export default <%= pascalEntityName %>Scene
