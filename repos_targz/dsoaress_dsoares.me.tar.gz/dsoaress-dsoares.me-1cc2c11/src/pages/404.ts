import { NotFoundError } from '@/containers'

export default NotFoundError
