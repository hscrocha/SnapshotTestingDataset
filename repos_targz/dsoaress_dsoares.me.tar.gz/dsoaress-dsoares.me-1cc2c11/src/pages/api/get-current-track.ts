import { getCurrentTrack } from '@/services'

export default getCurrentTrack
