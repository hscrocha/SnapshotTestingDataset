import { InternalServerError } from '@/containers'

export default InternalServerError
