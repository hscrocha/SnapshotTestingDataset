export const analytics = {
  domain: 'dsoares.me',
  id: 'f4b04d5d-93fc-4073-a1d3-5113814daf6a',
  src: 'https://stats.dsoares.me/umami.js'
}
