export type CurrentTrack = {
  title: string
  artist: string
  album: string
  duration: string
}
