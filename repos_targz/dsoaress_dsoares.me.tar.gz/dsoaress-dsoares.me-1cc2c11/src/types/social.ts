import type { IconsVariants } from '@/components'

export type Social = {
  label: IconsVariants
  url: string
}
