---
name: Feature request
about: Suggest an idea for this project
title: ''
labels: ''
assignees: ''

---

**What problem does this feature solve?**

**Describe the solution you'd like**

**What does the proposed API look like?**
