---
name: Bug report
about: Create a report to help us improve
title: ''
labels: ''
assignees: ''

---

**Version information**
- ChatUI or ChatUI Pro?
- ChatUI Version:
- React Version:
- OS Version:
- Browser Version:

**Describe the bug**

**Steps To Reproduce**
1. 
2. 

**Link to minimal reproduction**

**Expected behavior**
