export { Tabs } from './Tabs';
export type { TabsProps } from './Tabs';
export { Tab } from './Tab';
export type { TabProps } from './Tab';
