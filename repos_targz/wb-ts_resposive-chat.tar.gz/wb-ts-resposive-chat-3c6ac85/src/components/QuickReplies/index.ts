export { default as QuickReplies } from './QuickReplies';
export type { QuickRepliesProps } from './QuickReplies';
export { QuickReply } from './QuickReply';
export type { QuickReplyProps, QuickReplyItemProps } from './QuickReply';
