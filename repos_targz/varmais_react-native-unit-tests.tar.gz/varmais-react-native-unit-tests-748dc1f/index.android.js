'use strict';

import { AppRegistry } from 'react-native';
import ReactNativeTesting from './src/ReactNativeTesting';

AppRegistry.registerComponent('ReactNativeTesting', () => ReactNativeTesting);
