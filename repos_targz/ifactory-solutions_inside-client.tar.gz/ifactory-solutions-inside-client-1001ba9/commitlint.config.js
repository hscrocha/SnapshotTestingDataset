module.exports = {
  extends: ['./commitlint/'],
};
