import ListVacations from './ListVacations';

export {
  ListVacations,
};
