import ListMedicalCertificates from './ListMedicalCertificates';

export {
  ListMedicalCertificates,
};
