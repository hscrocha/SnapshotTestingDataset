import EmployeeListTable from './EmployeeListTable';

export default EmployeeListTable;
