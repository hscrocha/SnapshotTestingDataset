export const LABELS = {
  PHONE_1: 'Telefone 01',
  PHONE_2: 'Telefone 02',
  OFFICE_EMAIL: 'Email da Empresa',
  PERSONAL_EMAIL: 'Email Pessoal',
};

export const PLACEHOLDERS = {
  PHONE_1: 'Digite o telefone',
  PHONE_2: 'Digite o telefone',
  PERSONAL_EMAIL: 'Digite o email pessoal',
  OFFICE_EMAIL: 'Digite o email da empresa',
};
