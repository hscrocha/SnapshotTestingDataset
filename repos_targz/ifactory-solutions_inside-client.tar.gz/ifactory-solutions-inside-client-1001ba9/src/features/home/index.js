import Home from './Home.container';

export default Home;
