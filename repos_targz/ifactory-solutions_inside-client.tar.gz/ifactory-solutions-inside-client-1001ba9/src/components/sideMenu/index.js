import SideMenu from './SideMenu.container';

export default SideMenu;
