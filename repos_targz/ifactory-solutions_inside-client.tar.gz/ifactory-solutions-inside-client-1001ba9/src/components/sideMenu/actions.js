export const TOGGLE_MENU = 'TOGGLE_MENU';
export const CHANGE_MENU = 'CHANGE_MENU';

/* eslint arrow-body-style: ["error", "always"] */
/* eslint-env es6 */
export const toggleMenu = () => {
  return {
    type: TOGGLE_MENU,
  };
};
