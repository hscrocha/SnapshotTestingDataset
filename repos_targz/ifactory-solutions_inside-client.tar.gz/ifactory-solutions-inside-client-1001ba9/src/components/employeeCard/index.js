import EmployeeCard from './EmployeeCard';

export default EmployeeCard;
