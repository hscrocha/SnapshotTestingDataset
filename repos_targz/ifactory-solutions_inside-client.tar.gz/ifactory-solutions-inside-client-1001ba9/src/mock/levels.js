export default [
  {
    key: '1',
    name: 'Desenvolvedor Nível 1',
    category: 'Desenvolvedor',
    description: 'Desenvolvedor Nível 1',
    order: 1,
  }, {
    key: '2',
    name: 'Desenvolvedor Nível 3',
    category: 'Desenvolvedor',
    description: 'Desenvolvedor Nível 1',
    order: 3,
  }, {
    key: '3',
    name: 'Desenvolvedor Nível 3',
    category: 'Desenvolvedor',
    description: 'Desenvolvedor Nível 1',
    order: 3,
  }, {
    key: '4',
    name: 'Desenvolvedor Nível 5',
    category: 'Desenvolvedor',
    description: 'Desenvolvedor Nível 1',
    order: 4,
  }, {
    key: '5',
    name: 'Consultor Nível 1',
    category: 'Consultor',
    description: 'COnsultor nível 1',
    order: 1,
  }, {
    key: '5',
    name: 'Consultor Nível 2',
    category: 'Consultor',
    description: 'COnsultor nível 2',
    order: 2,
  },
];
