export default [
  {
    id: 1,
    author: 'Gustavo Barbosa',
    status: 'Approved',
    startDate: '01/07/2018',
    endDate: '01/08/2018',
  },
  {
    id: 2,
    author: 'Jouderian',
    status: 'Pending',
    startDate: '01/12/2018',
    endDate: '01/01/2019',
  },
  {
    id: 3,
    author: 'João Silva',
    status: 'Approved',
    startDate: '01/09/2018',
    endDate: '15/09/2018',
  },
];
