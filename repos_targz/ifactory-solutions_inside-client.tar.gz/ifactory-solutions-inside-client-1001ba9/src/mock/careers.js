export default [
  {
    key: '1',
    name: 'Carreira 1',
    description: 'Nível 1 para nível 2',
  }, {
    key: '2',
    name: 'Carreira 2',
    description: 'Nível 2 para nível 3',
  }, {
    key: '3',
    name: 'Carreira 3',
    description: 'Nível 3 para nível 4',
  }, {
    key: '4',
    name: 'Carreira 4',
    description: 'Nível 4 para nível 5',
  },
];
