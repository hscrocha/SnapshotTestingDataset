export default [
  {
    key: '1',
    name: 'Admin',
    description: 'Administradores do sistema',
  }, {
    key: '2',
    name: 'Gerente de projetos',
    description: 'Gerente de projetos',
  }, {
    key: '3',
    name: 'DHO',
    description: 'Colaborador do DHO',
  }, {
    key: '4',
    name: 'Colaborador',
    description: 'Todos os colaboradores',
  },
];
