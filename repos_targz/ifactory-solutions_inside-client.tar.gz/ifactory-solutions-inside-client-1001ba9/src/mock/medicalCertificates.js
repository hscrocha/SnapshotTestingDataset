export default [
  {
    id: 1,
    author: 'Gustavo Barbosa',
    status: 'Approved',
    startDate: '01/07/2017 08:00',
    endDate: '02/07/2017 18:00',
    type: 'Sick Note',
  },
  {
    id: 2,
    author: 'Jouderian',
    status: 'Pending',
    startDate: '16/01/2018 14:00',
    endDate: '16/01/2018 16:00',
    type: 'Medical Appointment',
  },
  {
    id: 3,
    author: 'João Silva',
    status: 'Approved',
    startDate: '22/12/2017',
    endDate: '22/12/2017',
    type: 'Medical Appointment',
  },
];
