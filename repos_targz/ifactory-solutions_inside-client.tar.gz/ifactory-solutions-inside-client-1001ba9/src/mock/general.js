export default {
  logoUrl: '',
};
