export default [
  {
    key: '1',
    name: 'Posts medium em inglês',
    description: 'Posts medium em inglês',
  }, {
    key: '2',
    name: '6 meses de empresa',
    description: '6 meses de empresa',
  }, {
    key: '3',
    name: '2 anos de empresa',
    description: '2 anos de empresa',
  }, {
    key: '4',
    name: '1 Certificação',
    description: 'Tirar uma certificação',
  },
];
