export default [
  {
    key: '1',
    name: 'Projeto 0',
    description: 'Descrição do projeto',
    startDate: '10/10/2010',
    endDate: '10/10/2010',
    stack: 'Angular, React, etc',
    status: 'Em andamento',
  }, {
    key: '2',
    name: 'Projeto 1',
    description: 'Descrição do projeto',
    startDate: '10/10/2010',
    endDate: '10/10/2010',
    stack: 'Angular, React, etc',
    status: 'Finalizado',
  },
];
