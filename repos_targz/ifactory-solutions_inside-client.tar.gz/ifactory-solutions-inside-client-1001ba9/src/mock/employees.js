export default [
  {
    key: '1',
    name: 'José Valter Carneiro Júnior',
    level: 'Desenvolvedor Nível 1',
    alocation: 'Fortaleza',
    project: 'Devry USA',
  }, {
    key: '2',
    name: 'Adriano Brito',
    level: 'Desenvolvedor Nível 3',
    alocation: 'Fortaleza',
    project: 'Devry USA',
  }, {
    key: '3',
    name: 'Jouderian da silva',
    level: 'Desenvolvedor Nível 3',
    alocation: 'Fortaleza',
    project: 'Devry USA',
  }, {
    key: '4',
    name: 'Jefferson mario selves',
    level: 'Desenvolvedor Nível 5',
    alocation: 'Fortaleza',
    project: 'Devry USA',
  },
];
