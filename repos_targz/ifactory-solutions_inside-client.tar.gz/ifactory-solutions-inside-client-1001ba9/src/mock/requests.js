export default [
  {
    key: '1',
    author: 'José Valter Carneiro Júnior',
    request: 'Reivindicar Badge: Posts medium em inglês',
    date: '10/12/2018',
  }, {
    key: '2',
    author: 'Adriano',
    request: 'Reivindicar Badge: Certificação Java',
    date: '10/12/2018',
  }, {
    key: '3',
    author: 'Jouderian',
    request: 'Reivindicar Badge: Curso de Angular Finalizado',
    date: '10/12/2018',
  }, {
    key: '4',
    author: 'Jefferson',
    request: 'Reivindicar Badge: 10h de aulas de inglês',
    date: '10/12/2018',
  },
];
