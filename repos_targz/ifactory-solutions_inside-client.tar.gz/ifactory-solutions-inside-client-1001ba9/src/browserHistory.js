import { createBrowserHistory } from 'history';
// https://github.com/ReactTraining/react-router/issues/3972
export default createBrowserHistory();
