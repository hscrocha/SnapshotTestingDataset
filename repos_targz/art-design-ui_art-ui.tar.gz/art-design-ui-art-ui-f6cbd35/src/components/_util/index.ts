export const getPrefixCls = (type: string): string => {
  const prefix = 'art'
  return `${prefix}-${type}`
}
