import DingAuth from './dingAuth'

export default DingAuth
