import Spin from './spin'

export default Spin
