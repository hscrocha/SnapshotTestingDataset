export interface FormValues {
  name: string;
  age: number | string;
  country: string;
  developer: boolean;
  employed: boolean;
  password: string;
}
