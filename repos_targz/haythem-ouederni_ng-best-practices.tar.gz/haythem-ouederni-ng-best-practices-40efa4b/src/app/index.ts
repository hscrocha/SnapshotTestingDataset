export * from './components';
// export * from './lazy-modules'; => should not be added to the barrel we have an unexpected exception
export * from './app-routing.module';
export * from './app.module';
