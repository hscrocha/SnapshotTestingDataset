export interface PathEnv {
  // to base path to navigate to the module different pages
  basePath: string;
}
