export const dev = {
  production: false,
};
export const prod = {
  production: true,
};
