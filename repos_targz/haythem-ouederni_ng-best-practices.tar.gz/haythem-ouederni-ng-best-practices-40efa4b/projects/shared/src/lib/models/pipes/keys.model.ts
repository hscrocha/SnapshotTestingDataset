export interface KeysModel {
  key: any;
  value: any;
}
