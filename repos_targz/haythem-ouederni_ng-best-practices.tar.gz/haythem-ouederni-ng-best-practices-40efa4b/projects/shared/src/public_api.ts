/*
 * Public API Surface of shared
 */

export * from './lib/shared.module';
