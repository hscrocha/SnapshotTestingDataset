import {InjectionToken} from '@angular/core';

export const CONNECTION_PATH = new InjectionToken<string>('CONNECTION_PATH');
