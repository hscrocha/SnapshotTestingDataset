export interface PageOneInformation {
  username: string;
  password: string;
  age: number;
}
