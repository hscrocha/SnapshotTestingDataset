// This is a helper for jest to set up autoUnsubscribe in the "setupFilesAfterEnv" configuration option

import { autoUnsubscribe } from './auto-unsubscribe';

autoUnsubscribe();
