<template>
  <p>{{ $t('hello') }}</p>
</template>

<script>
export default {
  name: 'json-external'
}
</script>

<i18n src="./locales.json" />
