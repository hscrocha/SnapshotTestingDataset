<template>
  <p>hello!</p>
</template>

<script>
export default {
}
</script>

<i18n lang="json" locale="ja">
{
  "hello": "こんにちは！"
}
</i18n>

<i18n lang="json" locale="en">
{
  "hello": "hello!"
}
</i18n>
