<template>
  <p>hello!</p>
</template>

<script>
export default {
}
</script>

<i18n src="./locale.json"></i18n>
