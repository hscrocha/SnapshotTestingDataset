<template>
  <p>hello!</p>
</template>

<script>
export default {
}
</script>

<i18n lang="json5" src="./locale.json5"></i18n>
