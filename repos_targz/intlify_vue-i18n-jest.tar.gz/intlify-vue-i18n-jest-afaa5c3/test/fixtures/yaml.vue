<template>
  <p>hello!</p>
</template>

<script>
export default {
}
</script>

<i18n lang="yaml">
ja:
  hello: こんにちは！
en:
  hello: hello!
</i18n>