import process from './process'

export = { process }
