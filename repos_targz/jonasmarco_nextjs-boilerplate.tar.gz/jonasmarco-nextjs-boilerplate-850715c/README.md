# Boilerplate do projeto React Avançado
### Inicia um projeto NextJS já configurado para codificar

#### Comando para criar o projeto baseado nesse boilerplate:
```console
yarn create next-app -e https://github.com/jonasmarco/nextjs-boilerplate
```
