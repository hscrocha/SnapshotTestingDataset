import { Counter } from "./components/Counter";
import { Login } from "./components/Login";
import { Location } from "./components/Location";
import "./App.css";

function App() {
  return (
    <div className="App">
      <Location />
    </div>
  );
}

export default App;
