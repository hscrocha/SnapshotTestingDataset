import moment from 'moment';

export default {
  sortBy: 'someSortBy',
  genres: [1, 2, 3],
  releaseDateStart: moment(),
  releaseDateEnd: moment(),
};
