const selectApi = (state) => state.api;

export default {
  selectApi,
};
