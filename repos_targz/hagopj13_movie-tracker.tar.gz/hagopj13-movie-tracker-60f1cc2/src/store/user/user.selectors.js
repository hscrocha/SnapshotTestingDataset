const selectUser = (state) => state.user;

export default {
  selectUser,
};
