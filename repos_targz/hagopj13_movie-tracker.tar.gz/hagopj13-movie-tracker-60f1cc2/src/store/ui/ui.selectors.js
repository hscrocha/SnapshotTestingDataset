const selectUi = (state) => state.ui;

export default {
  selectUi,
};
