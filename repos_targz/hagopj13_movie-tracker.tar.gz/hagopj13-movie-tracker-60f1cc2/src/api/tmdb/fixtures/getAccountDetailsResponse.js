export default {
  avatar: { gravatar: { hash: '0a213123123123123' } },
  id: 123456789,
  iso_639_1: 'en',
  iso_3166_1: 'US',
  name: 'name',
  include_adult: false,
  username: 'username',
};
