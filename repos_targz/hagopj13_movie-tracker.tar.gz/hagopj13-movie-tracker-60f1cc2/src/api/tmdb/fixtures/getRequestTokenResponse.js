export default {
  success: true,
  expires_at: '2020-05-05 15:19:20 UTC',
  request_token: 'b05d6b7049826c0d03563a6bb483cff5e92b02f1',
};
