export default {
  success: true,
  session_id: 'c608ac0b156b32272acad376016f461f8b0d468d',
};
