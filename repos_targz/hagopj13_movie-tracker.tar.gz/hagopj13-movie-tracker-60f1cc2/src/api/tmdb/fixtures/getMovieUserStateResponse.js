export default { id: 58574, favorite: true, rated: { value: 10.0 }, watchlist: true };
