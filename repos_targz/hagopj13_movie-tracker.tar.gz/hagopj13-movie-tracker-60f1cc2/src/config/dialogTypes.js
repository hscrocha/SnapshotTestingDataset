export default {
  LOGIN: 'LOGIN',
};
