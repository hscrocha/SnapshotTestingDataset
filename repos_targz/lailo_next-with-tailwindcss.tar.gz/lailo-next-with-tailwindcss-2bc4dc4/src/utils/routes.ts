export default {
  INDEX: {
    href: '/',
    as: '/',
  },
  COMPONENTS: {
    href: '/components',
    as: '/components',
  },
  TYPOGRAPHY: {
    href: '/typography',
    as: '/typography',
  },
}
