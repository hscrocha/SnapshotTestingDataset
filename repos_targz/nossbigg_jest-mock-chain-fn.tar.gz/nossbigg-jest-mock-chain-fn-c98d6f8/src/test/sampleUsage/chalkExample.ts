// as per example usage on: https://github.com/chalk/chalk#readme
export const chalkExample = (chalk: any) => {
  const result = chalk.bold.red('some message')
  return result
}
