export const JestMockChainFnInternalState = Symbol(
  'JestMockChainFn:InternalState'
)
