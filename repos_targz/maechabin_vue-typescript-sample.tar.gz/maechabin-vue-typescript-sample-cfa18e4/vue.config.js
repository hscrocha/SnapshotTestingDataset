module.exports = {
  baseUrl: './',
};
