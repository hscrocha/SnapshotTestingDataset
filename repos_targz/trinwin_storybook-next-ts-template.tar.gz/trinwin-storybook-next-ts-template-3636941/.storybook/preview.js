// Import global css here
import "../styles/global.scss";
