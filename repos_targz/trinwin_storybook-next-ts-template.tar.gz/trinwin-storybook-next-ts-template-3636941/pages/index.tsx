import * as React from "react";

const Home = () => {
  return <h1>Welcome to My Next App!</h1>;
};

export default Home;
