import React from 'react';

const Footer = () => (
  <footer className="app-grid orange-bg">
    <div className="layout-grid">
      <p>© 2018. Hand crafted by Celestine Ekoh-Ordan</p>
    </div>
  </footer>
);

export default Footer;
