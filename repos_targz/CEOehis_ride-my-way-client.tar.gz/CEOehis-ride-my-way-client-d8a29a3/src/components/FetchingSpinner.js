import React from 'react';

const FetchingSpinner = () => (
  <i style={{ textAlign: 'center', display: 'block' }} className="fa fa-spinner fa-spin fa-pulse fa-5x" aria-hidden="true" />
);

export default FetchingSpinner;
