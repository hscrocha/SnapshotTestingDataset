export interface Todo {
  id: number;
  text: string;
  creationDate: Date;
  completed: boolean;
}
