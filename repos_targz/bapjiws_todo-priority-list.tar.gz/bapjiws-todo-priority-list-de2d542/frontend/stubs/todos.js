export const currentTodos = [
    {
        priority: 4,
        name: 'eat something',
        description: 'ASAP'
    },
    {
        priority: 3,
        name: 'get some sleep',
        description: 'ASAP, too'
    },
    {
        priority: 1,
        name: 'do some work',
        description: 'meh'
    }
];

export const todoToInsert = {
    priority: 2,
    name: 'do the dishes',
    description: 'not so urgent'
};

export const sortedTodos = [
    {
        priority: 4,
        name: 'eat something',
        description: 'ASAP'
    },
    {
        priority: 3,
        name: 'get some sleep',
        description: 'ASAP, too'
    },
    {
        priority: 2,
        name: 'do the dishes',
        description: 'not so urgent'
    },
    {
        priority: 1,
        name: 'do some work',
        description: 'meh'
    }
];