import colors from './colors';
import device from './device';
import gStyle from './globalStyles';

export { colors, device, gStyle };
