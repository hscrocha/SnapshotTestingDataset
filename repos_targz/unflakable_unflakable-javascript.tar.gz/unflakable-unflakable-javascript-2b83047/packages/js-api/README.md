<p align="center">
  <a href="https://unflakable.com" target="_blank" rel="noopener" align="center">
    <img src="https://github.com/unflakable/unflakable-javascript/blob/main/images/logo.svg?raw=true" width="350" alt="Unflakable" />
  </a>
</p>

[![npm version](https://img.shields.io/npm/v/@unflakable/js-api.svg)](https://www.npmjs.com/package/@unflakable/js-api)
[![Twitter](https://img.shields.io/twitter/url?label=%40unflakable&style=social&url=https%3A%2F%2Ftwitter.com%2Funflakable)](https://twitter.com/unflakable)

# Unflakable JavaScript API

This package is used by the Unflakable JavaScript plugins to communicate with the Unflakable API.

## Contributing

To report a bug or request a new feature, please
[file a GitHub issue](https://github.com/unflakable/unflakable-javascript/issues).
We also welcome pull requests!
