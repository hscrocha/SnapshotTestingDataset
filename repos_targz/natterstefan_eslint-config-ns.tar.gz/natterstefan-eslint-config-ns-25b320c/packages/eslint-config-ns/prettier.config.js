module.exports = require('eslint-config-ns-base/prettier.config')
