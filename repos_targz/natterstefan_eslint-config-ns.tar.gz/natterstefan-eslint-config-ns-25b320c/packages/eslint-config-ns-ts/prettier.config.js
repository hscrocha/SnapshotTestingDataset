module.exports = require('eslint-config-ns-ts-base/prettier.config')
