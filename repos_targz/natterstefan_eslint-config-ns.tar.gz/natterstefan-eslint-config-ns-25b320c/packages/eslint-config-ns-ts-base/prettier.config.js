module.exports = require('eslint-config-ns/prettier.config')
