/* eslint-disable import/no-extraneous-dependencies */
import 'jest-preset-ns/presets/react/jest-setup.js'
