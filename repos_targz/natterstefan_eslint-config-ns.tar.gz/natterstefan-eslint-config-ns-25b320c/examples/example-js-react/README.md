# eslint-config-ns Example

This example is currently just basic and only illustrates a subset of the
defined and available rules. Please keep this in mind, it is more a playground
than an extensive example.

## Start

```sh
yarn
yarn start
```

## LICENCE

[MIT](../LICENCE)
