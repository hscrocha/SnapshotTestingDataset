export const returnTypeOf = input => typeof input
