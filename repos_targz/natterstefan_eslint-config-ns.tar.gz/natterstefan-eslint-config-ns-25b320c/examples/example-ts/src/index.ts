export const returnTypeOf = (input: unknown): typeof input => typeof input
