/* eslint-disable import/no-extraneous-dependencies */
module.exports = require('eslint-config-ns-ts/prettier.config')
