module.exports = {
  cliOptions: {
    allowEmptyInput: true,
  },
};
