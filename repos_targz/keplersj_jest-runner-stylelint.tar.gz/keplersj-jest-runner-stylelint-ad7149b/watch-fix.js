const StylelintWatchFixPlugin = require("./src/watchFixPlugin");

module.exports = StylelintWatchFixPlugin;
