# Changelog

## [6.0.0] - 2019-01-19

- removing support of [eslint-plugin-dollar-sign](https://www.npmjs.com/package/eslint-plugin-dollar-sign)
- updated readme.md with instructions how to add it back
- end of support for Node.js 6

## [1.0.3] - 2017-09-22

- lint change from `"lint": "eslint \"src/**\" --cache"` to `"lint": "eslint . --cache"`
- updated readme.md

## [1.0.2] - 2017-09-22

- add enzyme with config for snapshot testing, small fixes

## [1.0.0] - 2017-09-22

- init commit
