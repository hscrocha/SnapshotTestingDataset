import createJestRunner from "create-lite-jest-runner";
import run from "./run.js";

export default createJestRunner(run);
