export const ACTION = {
  CHECKBOX: {
    ADD: 'ac@checkbox.add',
    DELETE: 'ac@checkbox.delete',
  },
};
