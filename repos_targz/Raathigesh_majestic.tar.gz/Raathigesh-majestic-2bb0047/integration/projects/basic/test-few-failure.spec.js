describe('test', () => {
  it('should add third', () => {
    expect(5).toBe(6);
  });

  it('should add 1', () => {
    expect(5).toBe(5);
  });

  it('should add 2', () => {
    expect(5).toBe(5);
  });

  it('should add 3', () => {
    expect(5).toBe(5);
  });

  it('should add 4', () => {
    expect(5).toBe(5);
  });

  it('should add 5', () => {
    expect(5).toBe(5);
  });
});
