describe('test', () => {
  it('Should not show snapshot button', () => {
    expect('snapshot').toBe('a snapshot');
  });
});
