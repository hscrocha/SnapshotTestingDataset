export const root = process.env.ROOT || process.cwd();
