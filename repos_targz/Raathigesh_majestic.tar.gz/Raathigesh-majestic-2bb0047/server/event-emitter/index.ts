import { PubSub } from "graphql-yoga";

export const pubsub = new PubSub();
