/* eslint-env commonjs */

const ReactRedux = require.requireActual('react-redux');
ReactRedux.Provider = 'Provider';
module.exports = ReactRedux;
