// Return a Proxy to emulate css modules
// export { default as default } from 'identity-obj-proxy';
module.exports = require('identity-obj-proxy');
