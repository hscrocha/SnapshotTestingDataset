// @flow

export default {
  red: '#e53935',
  dark: '#111',
};
