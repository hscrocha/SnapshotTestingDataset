// eslint-disable-next-line import/no-extraneous-dependencies
require('dotenv').config();
require('./server');
