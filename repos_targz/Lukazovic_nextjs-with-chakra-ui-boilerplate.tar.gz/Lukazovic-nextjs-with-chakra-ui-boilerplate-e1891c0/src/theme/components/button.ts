const Button = {
  baseStyle: {
    fontWeight: 'bold'
  }
}

export default Button
