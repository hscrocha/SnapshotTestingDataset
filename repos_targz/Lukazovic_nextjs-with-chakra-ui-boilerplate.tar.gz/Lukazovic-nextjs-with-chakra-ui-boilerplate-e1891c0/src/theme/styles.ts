const styles = {
  global: {
    'html, body': {}
  }
}

export default styles
