import colors from './colors'

const shadows = {
  outline: `0 0 0 3px ${colors.primary[300]}`
}

export default shadows
