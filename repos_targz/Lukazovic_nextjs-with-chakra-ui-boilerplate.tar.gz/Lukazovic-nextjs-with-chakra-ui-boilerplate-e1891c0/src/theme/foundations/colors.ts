import { theme } from '@chakra-ui/react'

const primary = theme.colors.teal

export default {
  primary
}
