const fonts = {
  heading: "'Roboto', Arial, Helvetica, sans-serif",
  body: "'Roboto', Arial, Helvetica, sans-serif"
}

export default fonts
