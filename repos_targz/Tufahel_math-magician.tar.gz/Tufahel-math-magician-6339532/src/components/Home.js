import React from 'react';
import './Home.css';

function Home() {
  return (
    <div className="home">
      <h3 className="home-title">Welcome to our page!</h3>
      <p>
        Lorem ipsum dolor sit amet consectetur adipisicing elit.
        Quia tempore veritatis error ratione repellat qui, dolorum
        consequatur mollitia placeat tempora magnam commodi!
        Ipsa molestiae officiis, unde et porro nisi illo.
      </p>
      <p>
        Lorem ipsum dolor sit amet, consectetur adipisicing elit.
        Voluptate odio quasi veritatis enim non dolor harum sunt,
        quas ipsam laboriosam dicta repudiandae autem atque,
        architecto repellat obcaecati? Temporibus, delectus aperiam.
      </p>
    </div>
  );
}

export default Home;
