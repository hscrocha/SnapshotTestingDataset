module.exports = {
  extends: ['@kurosame/eslint-config-vue']
}
