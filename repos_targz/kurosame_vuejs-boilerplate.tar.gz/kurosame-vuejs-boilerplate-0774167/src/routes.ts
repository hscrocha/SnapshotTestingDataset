import Parent from '@/containers/Parent.vue'

export default [
  {
    name: 'parent',
    path: '/',
    component: Parent
  }
]
