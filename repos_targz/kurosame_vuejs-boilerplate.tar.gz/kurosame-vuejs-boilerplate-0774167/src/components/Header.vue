<template>
  <div class="header">
    Header
  </div>
</template>
<style lang="scss" scoped>
.header {
  color: white;
  background-color: red;
}
</style>
<script lang="ts">
import Vue from 'vue'

export default Vue.extend({
  name: 'Header'
})
</script>
