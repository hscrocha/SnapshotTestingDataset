import { CounterState } from '@/vuex/modules/counter'

export interface States {
  counter: CounterState
}
