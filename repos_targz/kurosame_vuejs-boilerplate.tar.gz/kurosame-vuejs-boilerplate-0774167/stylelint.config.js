module.exports = {
  extends: ['@kurosame/stylelint-config-vue']
}
