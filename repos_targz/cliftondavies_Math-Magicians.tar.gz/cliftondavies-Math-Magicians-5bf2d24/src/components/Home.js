const Home = () => {
  const paragraph = 'Lorem ipsum dolor sit amet, consectetur adipiscing elit, sed do eiusmod tempor incididunt ut labore et dolore magna aliqua. Consequat nisl vel pretium lectus quam id leo in. Suspendisse in est ante in nibh mauris cursus mattis molestie. Arcu felis bibendum ut tristique et egestas quis. Suspendisse in est ante in. Tortor consequat id porta nibh venenatis cras sed. Blandit turpis cursus in hac habitasse platea dictumst quisque. Est lorem ipsum dolor sit amet consectetur adipiscing elit pellentesque. Ac feugiat sed lectus vestibulum. Tellus elementum sagittis vitae et leo duis ut diam quam. Dui sapien eget mi proin sed libero enim sed faucibus. Magna sit amet purus gravida. Et ultrices neque ornare aenean euismod elementum nisi quis eleifend. Consequat interdum varius sit amet mattis vulputate.';

  return (
    <main className="home">
      <h2>
        Welcome to our page!
      </h2>

      <p>
        {paragraph}
      </p>

      <p>
        {paragraph}
      </p>
    </main>
  );
};

export default Home;
