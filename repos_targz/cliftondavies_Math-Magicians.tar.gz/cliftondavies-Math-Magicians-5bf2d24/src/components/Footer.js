const Footer = () => (
  <footer className="footer">
    <span>
      Math Magicians by Clifton Davies.
    </span>
  </footer>
);

export default Footer;
