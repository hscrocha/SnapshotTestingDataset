## 1.2.0
- Allow more precise configuration for mocking identifiers
- ```mockIdentifiers``` was renamed to ```ignoreIdentifiers```

### 1.1.0
- Added ```jest.mockFn()```
- Added ability to merge mocked identifiers with actual module, use ```{ requireActual: true }``` in the plugin config. Default false
- Added ability to overwrite default configuration

### 1.0.0
Initial release