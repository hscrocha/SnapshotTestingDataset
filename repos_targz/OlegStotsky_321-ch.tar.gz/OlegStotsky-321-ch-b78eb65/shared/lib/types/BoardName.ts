enum BoardName {
  a = "a",
  aw = "aw",
  mech = "mech",
  otaku = "otaku",
  pr = "pr",
  s = "s",
  sci = "sci",
  wd = "wd",
  b = "b",
  po = "po",
  int = "int",
  soc = "soc"
}

export default BoardName;