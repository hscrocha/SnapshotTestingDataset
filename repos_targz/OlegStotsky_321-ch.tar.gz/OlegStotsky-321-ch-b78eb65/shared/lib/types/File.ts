export interface IFile {
  name: string;
  data: string;
  type: string;
}
