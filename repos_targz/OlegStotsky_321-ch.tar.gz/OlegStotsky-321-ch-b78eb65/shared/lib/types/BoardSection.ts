import { IBoardCredentials } from "./BoardCredentials";

export interface IBoardSection {
  name: string;
  boardList: IBoardCredentials[];
}
