import BoardName from "./BoardName";

export interface IBoardCredentials {
  name: string;
  link: string;
  shortName: BoardName;
}
