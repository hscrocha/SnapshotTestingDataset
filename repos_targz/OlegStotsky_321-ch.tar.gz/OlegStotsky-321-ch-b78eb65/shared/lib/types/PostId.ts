type PostId = number;

export default PostId;