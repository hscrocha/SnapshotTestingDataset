import * as React from "react";
import Post from "./Post";

class BoardBodyContainer extends React.Component<any, any> {
  public render() {
    return <div>In progress..</div>;
  }
}
