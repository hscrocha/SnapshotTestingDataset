import * as React from "react";
import Post from "./Post";

const BoardBody = ({ posts }) => (
  <div>
    <input />
  </div>
);
