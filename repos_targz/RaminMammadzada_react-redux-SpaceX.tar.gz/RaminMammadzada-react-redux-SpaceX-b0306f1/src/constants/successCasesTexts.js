const successCasesTexts = [
  'Yes',
  'No',
];

export default successCasesTexts;
