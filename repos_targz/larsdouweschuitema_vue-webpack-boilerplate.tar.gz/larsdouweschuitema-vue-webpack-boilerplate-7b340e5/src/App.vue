<template>
  <div>
    <h1>App</h1>
  </div>
</template>

<script>
  export default {
    name: "App"
  };
</script>

<style scoped lang="scss">
  h1 {
    color: red;
  }
</style>