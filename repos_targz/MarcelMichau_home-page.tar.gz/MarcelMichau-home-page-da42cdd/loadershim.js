global.___loader = {
	enqueue: jest.fn()
};
