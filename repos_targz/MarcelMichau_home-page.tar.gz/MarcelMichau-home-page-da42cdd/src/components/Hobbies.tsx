import React from 'react';

const Hobbies = () => (
	<div>
		<h2>Hobbies/Spare Time Activities</h2>
		<ul>
			<li>Reading</li>
			<li>Music</li>
			<li>PC gaming</li>
			<li>Coding / Contributing to open-source</li>
			<li>Watching online courses</li>
			<li>Jogging</li>
			<li>Watching TV shows & films</li>
		</ul>
	</div>
);

export default Hobbies;
