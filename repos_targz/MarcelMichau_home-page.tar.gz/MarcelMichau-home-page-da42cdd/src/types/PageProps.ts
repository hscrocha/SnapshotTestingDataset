export type PageProps = {
	data: {
		markdownContent: {
			html: string;
		};
	};
};
