import packageJson from "../../package.json";

export const APP_ID = packageJson.name;
export const VERSION = packageJson.version;
