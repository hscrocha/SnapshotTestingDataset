export const API = {
  EXAMPLE: "http://localhost:5000/mock-api/example",
};
