export default {
  API_DATA: "API data",
  BRAND_NAME: "React Redux Boilerplate",
  CURRENT_ROUTE: "Current route",
  ERROR_404_MESSAGE: "This page does not exist.",
  ERROR_404_TITLE: "Page not found",
  ERROR_MESSAGE: "An error has occurred, please try again.",
  ERROR_TITLE: "An error has occurred",
  FETCH_API_DATA: "Fetch API data",
  INDEX_DESCRIPTION: "Some basic examples of user interaction are shown below.",
  INDEX_TITLE: "Welcome to the React Redux Boilerplate",
  LOCAL_DATA: "Local data",
  UPDATE_LOCAL_DATA: "Update local data",
};
