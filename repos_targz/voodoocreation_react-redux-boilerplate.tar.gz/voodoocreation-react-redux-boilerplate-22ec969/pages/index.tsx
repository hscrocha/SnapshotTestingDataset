import IndexRoute from "../src/components/routes/IndexRoute/IndexRoute";

export default IndexRoute;
