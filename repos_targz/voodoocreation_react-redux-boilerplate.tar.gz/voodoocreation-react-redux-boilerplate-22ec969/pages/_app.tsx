import WrappedApp from "../src/components/connected/App/App";

export default WrappedApp;
