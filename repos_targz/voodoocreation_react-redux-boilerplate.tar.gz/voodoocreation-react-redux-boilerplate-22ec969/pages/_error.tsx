import ErrorRoute from "../src/components/routes/ErrorRoute/ErrorRoute";

export default ErrorRoute;
