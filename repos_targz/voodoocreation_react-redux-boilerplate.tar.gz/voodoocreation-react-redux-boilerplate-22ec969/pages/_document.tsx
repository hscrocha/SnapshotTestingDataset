import Document from "../src/components/connected/Document/Document";

export default Document;
