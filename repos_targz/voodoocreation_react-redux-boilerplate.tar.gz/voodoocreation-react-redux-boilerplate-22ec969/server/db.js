module.exports = {
  example: require("./mocks/example"),
};
