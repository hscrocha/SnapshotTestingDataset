const routes = require("next-routes")();

/*
Add custom routes as shown below

routes
  .add("/example-route-1/:id", "index")
  .add("/example-route-2/:id", "index");
*/

module.exports = routes;
