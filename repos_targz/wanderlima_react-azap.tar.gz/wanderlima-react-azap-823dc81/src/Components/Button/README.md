# Button

A component to blah blah...

``` js
<Button
	onClick={ () => { console.log('clicked') } }
	disabled={false}
>
	Click me
</Button>
```
