import configureMockStore from "redux-mock-store";

const middlewares = [];
const mockStore = configureMockStore(middlewares);

export default mockStore;
