export const Mock = jest.fn();
