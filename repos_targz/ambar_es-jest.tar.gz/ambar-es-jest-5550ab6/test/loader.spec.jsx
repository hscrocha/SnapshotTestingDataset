import React from 'react'

test('create element', () => {
  expect(<>foo</>).toBeTruthy()
})
