export enum StateEnum {
  TODO,
  SUCCESS,
  FAIL
}
