declare module 'cache-manager-redis-store';

declare module 'qn';
