export const EMAIL_TOKEN = 'EMAIL_TOKEN';
