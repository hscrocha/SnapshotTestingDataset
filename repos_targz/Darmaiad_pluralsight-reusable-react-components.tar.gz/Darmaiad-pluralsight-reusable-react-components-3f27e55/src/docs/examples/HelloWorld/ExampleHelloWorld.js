import React from 'react';
import HelloWorld from 'ps-react/HelloWorld';

/** Custom message */
const ExampleHelloWorld = () => <HelloWorld message="Pluralsight viewers!" />;

export default ExampleHelloWorld;
