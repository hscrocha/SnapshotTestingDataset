import React from 'react';
import EyeIcon from 'ps-react/EyeIcon';

const EyeIconExample = () => <EyeIcon />;

export default EyeIconExample;
