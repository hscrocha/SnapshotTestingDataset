import React from 'react';
import Label from 'ps-react/Label';

/** Optional label */
const ExampleOptional = () => <Label htmlFor="test" label="testing" />;

export default ExampleOptional;
