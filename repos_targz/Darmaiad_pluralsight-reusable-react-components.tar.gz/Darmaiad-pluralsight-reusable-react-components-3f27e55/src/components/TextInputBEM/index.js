// importing the stylesheet here offers to options for importing the component:
//      - If someone wants to import the styles, he can import from this index.
//      - If someone does not want the styles he can import the component directly.

import './textInput.css';
export { default } from './TextInputBEM';
