# react-component-lib-boilerplate

## 1.1.3

### Patch Changes

-   73d762c: update release github action

## 1.1.2

### Patch Changes

-   766c525: remove unused file

## 1.1.1

### Patch Changes

-   e95be41: fix release pipeline

## 1.1.0

### Minor Changes

-   42d2ddc: feat : add build process ci/cd
