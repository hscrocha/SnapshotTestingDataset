import Icon from './Icon/Icon';
import Container from './Container/Container';
import Title from './Title/Title';

export { Icon, Title, Container };
