import styled from 'styled-components';

export const StyledSvg = styled.svg`
    display: inline-block;
    vertical-align: top;
`;
