import Util from './util'
let util = null

beforeAll(() => {
  util = new Util()
})

test('Util a func', () => {
  // expect(util.a(1, 2)).toEqual(5)
})
