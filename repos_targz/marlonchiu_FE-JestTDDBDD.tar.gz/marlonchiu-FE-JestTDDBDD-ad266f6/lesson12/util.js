// 工具类测试函数
class Util {
  init () {
    // ...
  }
  a () {
    // ...
  }
  b () {
    // ...
  }
}

export default Util
