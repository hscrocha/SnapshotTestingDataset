/*
 *  Created by : ZhaoJiandong
 *  Modified time: 2020/4/23 17:21
 */

function add (a, b) {
  return a + b
}

function minus (a, b) {
  return a - b
}

function multi (a, b) {
  return a * b
}

try {
  module.exports = {
    add,
    minus,
    multi
  }
} catch (error) {

}
