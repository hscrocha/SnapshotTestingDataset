import $ from 'jquery'

const addDivToBody = () => {
  $('body').append('<div/>')
}

export default addDivToBody
