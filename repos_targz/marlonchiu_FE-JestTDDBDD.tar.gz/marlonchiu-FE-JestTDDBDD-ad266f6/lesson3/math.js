/*
 *  Created by : ZhaoJiandong
 *  Modified time: 2020/4/23 17:21
 */

export function add (a, b) {
  return a + b
}

export function minus (a, b) {
  return a - b
}

export function multi (a, b) {
  return a * b
}
