import env from './e2e-env-test';
process.env = env;
