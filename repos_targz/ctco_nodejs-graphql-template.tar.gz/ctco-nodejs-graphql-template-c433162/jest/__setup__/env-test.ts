// read env to be accessible on every test (used in integration tests)
import env from '../../src/env';
process.env = env;
