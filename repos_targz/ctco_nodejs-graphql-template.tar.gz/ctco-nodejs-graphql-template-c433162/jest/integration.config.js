module.exports = Object.assign(
  {},
  require('./default.config.js'),
  {
    "roots": [
      "src/graphql"
    ]
  }
);
