import { JokeResolvers } from '../_generated/types';

export const joke: JokeResolvers.Type = {
  ...JokeResolvers.defaultResolvers,
};
