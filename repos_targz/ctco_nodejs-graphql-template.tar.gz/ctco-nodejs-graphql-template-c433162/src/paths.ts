const paths = {
  GRAPHQL_PATH: 'graphql',
  GRAPHIQL_PATH: 'graphiql',
  VOYAGER_PATH: 'voyager',
  PLAYGROUND_PATH: 'playground',
  LIVENESS_PATH: 'healthz',
};

export default paths;
