const sum = (a: number, b: number): number => a + b;

export default sum;
