module.exports = require('./jest/default.config');
