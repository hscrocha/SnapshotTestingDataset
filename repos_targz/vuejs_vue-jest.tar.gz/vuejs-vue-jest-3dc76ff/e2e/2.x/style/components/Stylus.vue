<template>
  <div />
</template>

<style lang="stylus" module="css">
@import './relative/resource';

.a {
  background-color: red;
}
</style>

<style lang="styl" module>
.b {
  background-color: blue;
}
</style>
