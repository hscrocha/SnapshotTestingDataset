<template>
  <div />
</template>

<script lang="coffee">
export default
    data: -> {}
</script>
