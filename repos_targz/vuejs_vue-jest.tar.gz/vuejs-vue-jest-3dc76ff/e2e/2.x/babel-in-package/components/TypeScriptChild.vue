<template>
  <div>{{ exclamationMarks }}</div>
</template>

<script lang="ts">
export default {
  computed: {
    exclamationMarks(): string {
      return 'string'
    }
  }
}
</script>
