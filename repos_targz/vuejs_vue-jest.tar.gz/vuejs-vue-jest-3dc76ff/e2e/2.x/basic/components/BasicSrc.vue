<template src="./BasicSrc.html"></template>

<script src="./BasicSrc.js"></script>
