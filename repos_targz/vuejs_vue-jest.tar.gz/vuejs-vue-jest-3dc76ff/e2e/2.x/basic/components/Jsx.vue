<script>
export default {
  render(h) {
    return <div />
  }
}
</script>
