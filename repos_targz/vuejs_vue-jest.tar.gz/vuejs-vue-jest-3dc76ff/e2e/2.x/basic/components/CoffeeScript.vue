<template>
  <div />
</template>

<script lang="coffeescript">
export default
    data: -> {}
</script>
