<template lang="jade">
  .jade
</template>

<script>
export default {
  name: 'jade'
}
</script>
