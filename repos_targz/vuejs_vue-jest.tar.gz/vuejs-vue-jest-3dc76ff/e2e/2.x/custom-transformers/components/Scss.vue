<template>
  <div>
    <span :class="$style.g"></span>
    <span :class="$style.dark.f"></span>
  </div>
</template>

<style lang="scss" module themed>
.f {
  background-color: red;
}
</style>

<style lang="scss" module>
.d {
  background-color: red;
}
</style>
