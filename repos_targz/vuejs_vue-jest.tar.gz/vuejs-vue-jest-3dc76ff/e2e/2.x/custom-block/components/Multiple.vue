<template>
  <p>multiple custom block</p>
</template>

<script>
export default {
  name: 'Multiple'
}
</script>

<custom>
{
  "en": {
    "hello": "Hello!"
  },
  "ja": {
    "hello": "こんにちは！"
  }
}
</custom>

<custom>
{
  "foo": "foo"
}
</custom>
