<template>
  <p>basic custom block</p>
</template>

<script>
export default {
  name: 'Basic'
}
</script>

<custom>
{
  "en": {
    "hello": "Hello!"
  },
  "ja": {
    "hello": "こんにちは！"
  }
}
</custom>
