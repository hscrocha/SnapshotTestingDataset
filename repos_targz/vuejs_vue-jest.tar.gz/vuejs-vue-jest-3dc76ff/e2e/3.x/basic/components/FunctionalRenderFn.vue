<script>
import { h } from 'vue'

export default () =>
  h(
    'div',
    {
      id: 'functional-render-fn'
    },
    'Nyan'
  )
</script>
