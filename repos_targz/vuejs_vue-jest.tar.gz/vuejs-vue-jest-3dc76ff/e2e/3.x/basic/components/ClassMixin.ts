import { Vue } from 'vue-class-component'

export default class ClassMixin extends Vue {
  message = 'Hello world!'
}
