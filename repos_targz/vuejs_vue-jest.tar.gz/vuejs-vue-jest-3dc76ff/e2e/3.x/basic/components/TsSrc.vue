<template src="./BasicSrc.html"></template>

<script lang="ts" src="./TsSrc.ts"></script>
