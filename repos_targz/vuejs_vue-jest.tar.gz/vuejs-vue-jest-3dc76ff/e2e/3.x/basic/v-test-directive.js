module.exports = (dir, node, ...args) => {
  return { needRuntime: false, props: [] }
}
