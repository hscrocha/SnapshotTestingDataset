<template>
  <h1>Coffee</h1>
</template>

<script lang="coffee">
export default
    name: 'coffee'
    data: -> {}
</script>
