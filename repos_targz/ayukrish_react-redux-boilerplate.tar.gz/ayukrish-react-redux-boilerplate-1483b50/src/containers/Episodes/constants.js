export const GET_EPISODES = 'GET_EPISODES';
export const SET_EPISODES = 'SET_EPISODES';
