export const episodeData = (state) => state.episodes && state.episodes.data;
