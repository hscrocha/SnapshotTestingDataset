export const charactersData = (state) =>
  state.characters && state.characters.data;
