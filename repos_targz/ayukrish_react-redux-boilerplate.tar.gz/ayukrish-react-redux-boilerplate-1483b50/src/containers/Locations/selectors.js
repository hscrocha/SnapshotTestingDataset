export const locationData = (state) => state.location && state.location.data;
