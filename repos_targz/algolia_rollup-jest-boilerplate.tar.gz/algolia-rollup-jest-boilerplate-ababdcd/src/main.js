export default function rollupJestBoilerplate(string) {
  return {
    awesomeString: string,
  };
}
