module.exports = {
    "extends": [
        "standard", 
        "plugin:react/recommended"
    ]
}