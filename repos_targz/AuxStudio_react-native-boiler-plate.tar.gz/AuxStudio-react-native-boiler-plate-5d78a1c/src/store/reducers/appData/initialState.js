const initialState = {
  app: null,
  users: null,
};

export default initialState;
