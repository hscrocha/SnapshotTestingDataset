const initialState = {
  scene: null,
};

export default initialState;
