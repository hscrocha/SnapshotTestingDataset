import { StyleSheet } from 'react-native';

const styles = StyleSheet.create({
  container: {},
  itemContainer: {},
  itemText: {},
});

export default styles;
