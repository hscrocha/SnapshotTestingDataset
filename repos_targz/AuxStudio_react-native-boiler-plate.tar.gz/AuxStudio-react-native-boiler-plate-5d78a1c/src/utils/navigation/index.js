import navigate from './navigate';

export { navigate };

export default {
  navigate,
};
