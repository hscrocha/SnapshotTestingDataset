import getPercentage from './getPercentage';

export { getPercentage };

export default {
  getPercentage,
};
