import sortArrayOfObjectsByKey from './sortArrayOfObjectsByKey';

export { sortArrayOfObjectsByKey };

export default {
  sortArrayOfObjectsByKey,
};
