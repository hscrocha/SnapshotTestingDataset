import createError from './createError';

// All app-specific utils go here
export { createError };

export default {
  createError,
};
