import logEvent from './logEvent';

export { logEvent };

export default {
  logEvent,
};
