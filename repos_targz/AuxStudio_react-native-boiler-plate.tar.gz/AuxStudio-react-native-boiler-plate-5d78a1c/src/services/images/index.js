import showImagePicker from './showImagePicker';
import resizeImage from './resizeImage';

export { showImagePicker, resizeImage };

export default {
  showImagePicker,
  resizeImage,
};
