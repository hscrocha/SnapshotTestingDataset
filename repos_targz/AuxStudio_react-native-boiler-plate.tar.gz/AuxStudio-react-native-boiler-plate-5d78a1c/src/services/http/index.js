import get from './get';
import post from './post';

export { get, post };

export default {
  get,
  post,
};
