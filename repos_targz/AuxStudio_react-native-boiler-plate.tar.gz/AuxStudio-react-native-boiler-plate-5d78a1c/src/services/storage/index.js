import uploadFile from './uploadFile';

export { uploadFile };

export default {
  uploadFile,
};
