const version = {
  major: 0,
  minor: 0,
  patch: 1,
  build: 1,
  code: 1,
  forceCodePushUpdate: Date.now(), // remove this if you do not want to force code push updates
};

export default version;
