const slack = {
  webhook: null,
  channel: null,
  username: null,
  icon_emoji: ':bug',
};

export default slack;
