const googleSignIn = {
  webClientId: 'XXXXXXXX',
  iosClientId: 'XXXXXXXX',
  offlineAccess: false,
};

export default googleSignIn;
