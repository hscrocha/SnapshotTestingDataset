export default function GoogleSignIn() {
  return jest.fn();
}
