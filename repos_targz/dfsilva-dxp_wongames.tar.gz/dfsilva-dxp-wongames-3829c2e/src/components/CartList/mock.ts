export default [
  {
    img: "https://source.unsplash.com/user/willianjusten/151x70",
    title: "Red Dead Redemption 2",
    price: 215.0
  },
  {
    img: "https://source.unsplash.com/user/willianjusten/151x70",
    title: "Borderlands 3",
    price: 215.0
  }
];
