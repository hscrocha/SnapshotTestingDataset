export default [
  {
    src: "/img/games/cyberpunk-1.jpeg",
    label: "Gallery Image 1"
  },
  {
    src: "/img/games/cyberpunk-2.jpeg",
    label: "Gallery Image 2"
  },
  {
    src: "/img/games/cyberpunk-3.jpeg",
    label: "Gallery Image 3"
  },
  {
    src: "/img/games/cyberpunk-4.jpeg",
    label: "Gallery Image 4"
  },
  {
    src: "/img/games/cyberpunk-5.jpeg",
    label: "Gallery Image 5"
  },
  {
    src: "/img/games/cyberpunk-6.jpeg",
    label: "Gallery Image 6"
  }
];
