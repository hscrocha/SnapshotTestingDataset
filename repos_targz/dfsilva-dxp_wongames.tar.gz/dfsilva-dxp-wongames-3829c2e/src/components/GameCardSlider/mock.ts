export default [
  {
    title: "Population Zero",
    slug: "population-zero",
    developer: "Rockstar Games",
    img: "https://source.unsplash.com/user/willianjusten/300x140",
    price: 215.0,
    promotionalPrice: 115.0
  },
  {
    title: "Population Zero",
    slug: "population-zero",
    developer: "Rockstar Games",
    img: "https://source.unsplash.com/user/willianjusten/300x141",
    price: 215.0,
    promotionalPrice: 115.0
  },
  {
    title: "Population Zero",
    slug: "population-zero",
    developer: "Rockstar Games",
    img: "https://source.unsplash.com/user/willianjusten/300x142",
    price: 215.0,
    promotionalPrice: 115.0
  },
  {
    title: "Population Zero",
    slug: "population-zero",
    developer: "Rockstar Games",
    img: "https://source.unsplash.com/user/willianjusten/300x143",
    price: 215.0,
    promotionalPrice: 115.0
  },
  {
    title: "Population Zero",
    slug: "population-zero",
    developer: "Rockstar Games",
    img: "https://source.unsplash.com/user/willianjusten/300x144",
    price: 215.0,
    promotionalPrice: 115.0
  }
];
