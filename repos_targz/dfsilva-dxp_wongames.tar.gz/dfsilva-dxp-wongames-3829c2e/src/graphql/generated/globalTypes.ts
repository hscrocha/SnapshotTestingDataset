/* tslint:disable */
/* eslint-disable */
// @generated
// This file was automatically generated and should not be edited.

//==============================================================
// START Enums and Input Objects
//==============================================================

export enum ENUM_COMPONENTPAGEHIGHLIGHT_ALIGNMENT {
  left = "left",
  right = "right",
}

export enum ENUM_COMPONENTPAGEROBBON_COLOR {
  primary = "primary",
  secondary = "secondary",
}

export enum ENUM_COMPONENTPAGEROBBON_SIZE {
  normal = "normal",
  small = "small",
}

export enum ENUM_GAME_RATING {
  BR0 = "BR0",
  BR10 = "BR10",
  BR12 = "BR12",
  BR14 = "BR14",
  BR16 = "BR16",
  BR18 = "BR18",
}

//==============================================================
// END Enums and Input Objects
//==============================================================
