## Projeto Won Games

O Won Games é um e-commerce desenvolvido no curso de [React Avançado](https://www.udemy.com/course/react-avancado/) do [Willian Justen](https://willianjusten.com.br/), utilizando as tecnologias Nextjs, API com strapi, boas práticas com Styled Components, Storybook, Testes e Graphql
