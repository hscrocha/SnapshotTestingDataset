export const PROJECT_NAME = "ts-dev-tools";
export const PACKAGE_BASE_NAME = `@${PROJECT_NAME}`;
export const PROJECT_URL = `https://escemi-tech.github.io/${PROJECT_NAME}/`;
