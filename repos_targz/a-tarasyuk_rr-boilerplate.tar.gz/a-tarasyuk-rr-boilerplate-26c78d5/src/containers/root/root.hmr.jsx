import { hot } from 'react-hot-loader';
import Container from './root';

export const Root = hot(module)(Container);
export default Root;
