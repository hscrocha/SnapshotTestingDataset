/**
 * Constants
 */