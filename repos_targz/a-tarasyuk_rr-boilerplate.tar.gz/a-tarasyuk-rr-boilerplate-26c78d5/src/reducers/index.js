import { combineReducers } from 'redux';
import features from './features.reducer';

export default combineReducers({
  features,
});
