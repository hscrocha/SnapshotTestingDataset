const initialState = [];

/**
 * Features
 *
 * @param {Array}  state
 * @param {Object} action
 *
 * @return {Array}
 */
function features(state = initialState) {
  return state;
}

export default features;
