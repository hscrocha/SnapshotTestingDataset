export default {
  api: 'https://api.lyrics.ovh',
  maxInput: 2,
};
