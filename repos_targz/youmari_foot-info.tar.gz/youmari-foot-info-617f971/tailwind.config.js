module.exports = {
  content: ['./src/**/*.{js,jsx}'],
  theme: {
    extend: {},
    fontFamily: {
      lato: ['Lato', 'sans-serif'],
      gill: ['Gill Sans', 'Gill Sans MT', 'Trebuchet MS', 'sans-serif'],
    },
  },
  plugins: [],
};
