import { Component } from "react";

class Index extends Component {
  render() {
    return (
      <div>
        <h1>Index Page</h1>
      </div>
    );
  }
}

export default Index;
