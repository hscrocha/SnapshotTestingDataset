import Layout from "../components/Layout/Layout";
import RequestReset from "../components/Auth/RequestReset";

const PasswordPage = () => (
  <Layout>
    <RequestReset />
  </Layout>
);

export default PasswordPage;
