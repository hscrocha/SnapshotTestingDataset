const Type = {
  User: {
    password: (parent, args, context) => "Password not available"
  }
};

module.exports = Type;
