# Jest with Nuxt.js
## Example used: Dynamic Components with Nuxt.js

* `yarn or npm i`

* `yarn test` for running the tests

!! if you can't run this repo with npm , you can use yarn with locked dependence.

Demo: https://nuxt-chat.now.sh

Video: https://www.youtube.com/watch?v=HzDea5-PFaw
