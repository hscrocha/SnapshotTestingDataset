<template>
  <h1>Hello Component</h1>
</template>

<script>
export default {
  
}
</script>
