import React from 'react';
import './Header.scss';

const Header = (props) => {
    return (
        <div className="Header">
            <header className="App__header">
                <a href="/" className="App__Logo">
                    <span className="App__Logo--First">GFonts</span>
                    <span className="App__Logo--Last">Space</span>
                </a>
                <div className="App__SocialIcons">
                    <a className="App__SocialIcons__Link"
                        href="https://www.linkedin.com/in/pankajladhar/"
                        target="_blank"
                        rel="noopener noreferrer"
                        title="Pankaj Ladhar linkedin profile ">
                        <i className="fa fa-linkedin"></i>
                    </a>
                    <a className="App__SocialIcons__Link"
                        href="https://github.com/pankajladhar/GFontsSpace"
                        target="_blank"
                        rel="noopener noreferrer"
                        title="Pankaj Ladhar github profile ">
                        <i className="fa fa-github"></i>
                    </a>
                </div>
            </header>
        </div>
    );
}

export default Header;
