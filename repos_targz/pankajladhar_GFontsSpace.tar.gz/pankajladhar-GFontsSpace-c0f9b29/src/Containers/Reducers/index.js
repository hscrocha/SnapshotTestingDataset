import { combineReducers } from 'redux';
import GFontsReducer from './GFontsReducer';

export default combineReducers({
    GFontsReducer
})