# How to run locally

Project has been done using [create-react-app](https://github.com/facebookincubator/create-react-app).

* git clone https://github.com/pankajladhar/GFontsSpace.git
* npm install
* npm start ( for starting application )
* npm run test ( for running unit test )
## How to contribute

* Fork the repo
* Implement feature or improvment
* Raise a pull request
