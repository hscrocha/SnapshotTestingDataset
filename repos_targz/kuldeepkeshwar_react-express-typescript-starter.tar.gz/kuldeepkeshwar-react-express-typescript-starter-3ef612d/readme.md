# react-express-typescript-starter
This is a starter project with react, express, typescript, webpack &amp; jest

## `npm start` to start the server 
## `npm start:dev` to start the server in dev mode
## `npm run build` to build application
## `npm run client-build:dev` to build frontend in dev mode
## `npm run server-build:dev` to build server in dev mode
##