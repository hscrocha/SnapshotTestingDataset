global.System = {
  import: () => ({}),
};

