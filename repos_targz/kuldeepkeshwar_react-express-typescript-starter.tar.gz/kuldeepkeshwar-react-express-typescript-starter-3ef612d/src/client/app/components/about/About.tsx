import * as React from 'react'

function About() {
  return (
    <div className="container about">
      <h1>About</h1>
    </div>
  )
}

export default About
