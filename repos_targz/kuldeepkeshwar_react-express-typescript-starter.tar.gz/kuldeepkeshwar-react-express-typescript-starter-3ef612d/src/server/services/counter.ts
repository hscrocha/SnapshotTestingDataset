
let counter: number = 0
export function getCounter(): number {
    counter = counter + 1
    return counter
}
