module.exports = {
  PORT: 8080,
  NODE_ENV: 'development',
  MYSQL_DATABASE: 'app_db',
  MYSQL_USER: 'root',
  MYSQL_PASSWORD: 'root',
};
