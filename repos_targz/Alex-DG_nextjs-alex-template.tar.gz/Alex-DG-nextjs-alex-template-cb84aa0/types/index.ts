export type PostType = {
  id: string
  title: string
  date: string
  contentHtml: string
}
