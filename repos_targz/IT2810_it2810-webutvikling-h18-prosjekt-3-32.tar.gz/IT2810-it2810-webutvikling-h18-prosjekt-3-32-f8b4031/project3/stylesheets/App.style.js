import {StyleSheet} from "react-native";

export default StyleSheet.create({
    topBar: {
        height: "3%",
    },
});
