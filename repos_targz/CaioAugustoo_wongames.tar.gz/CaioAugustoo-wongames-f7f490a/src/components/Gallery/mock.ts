export default [
  {
    src: '/img/cyberpunk-1.jpg',
    label: 'Gallery Image 1'
  },
  {
    src: '/img/cyberpunk-2.jpg',
    label: 'Gallery Image 2'
  },
  {
    src: '/img/cyberpunk-3.jpg',
    label: 'Gallery Image 3'
  },
  {
    src: '/img/cyberpunk-4.jpg',
    label: 'Gallery Image 4'
  },
  {
    src: '/img/cyberpunk-5.jpg',
    label: 'Gallery Image 5'
  },
  {
    src: '/img/cyberpunk-6.jpg',
    label: 'Gallery Image 6'
  }
]
