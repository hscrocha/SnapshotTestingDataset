/// <reference path="../support/index.d.ts" />

describe.skip('Cypress TS', () => {
  it('should go to google', () => {
    cy.google()
  })
})
