declare module '*.html' {
  const _: (...args: any[]) => string;

  export default _;
}
