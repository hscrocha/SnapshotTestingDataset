export const BASE_URL = 'https://api.spacexdata.com/v3/';
export const ROCKETS_URL = `${BASE_URL}rockets`;
export const MISSIONS_URL = `${BASE_URL}missions`;
