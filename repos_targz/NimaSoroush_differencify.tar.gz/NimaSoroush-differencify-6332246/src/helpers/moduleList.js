module.exports = [
  'page',
  'keyboard',
  'mouse',
  'touchscreen',
  'tracing',
];
