{
  "verbose": true,
  "ignore": ["*.json", "*.scss"],
}

