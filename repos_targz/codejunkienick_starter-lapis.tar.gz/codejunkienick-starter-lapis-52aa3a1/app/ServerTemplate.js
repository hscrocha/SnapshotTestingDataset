import { App } from 'screens';

export default App;
