import React from 'react';
import './index.css';

const NotificationIcon = () => <span styleName="icon" />;

export default NotificationIcon;
