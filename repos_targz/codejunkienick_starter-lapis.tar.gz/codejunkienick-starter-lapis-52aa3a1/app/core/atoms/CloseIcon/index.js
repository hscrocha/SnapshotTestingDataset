import React from 'react';
import './index.css';

const CloseIcon = () => <span styleName="close-icon" />;

export default CloseIcon;
