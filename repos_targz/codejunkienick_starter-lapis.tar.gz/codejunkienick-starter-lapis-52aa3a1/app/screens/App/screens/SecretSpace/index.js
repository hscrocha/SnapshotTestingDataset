import React from 'react';

export default function SecretSpace() {
  return <h2>Whoa! You&apos;ve found the secret space</h2>;
}
