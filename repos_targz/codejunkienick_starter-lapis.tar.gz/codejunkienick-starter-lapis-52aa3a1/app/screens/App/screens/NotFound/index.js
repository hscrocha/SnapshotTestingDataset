import React from 'react';
import './index.css';

export default function NotFound() {
  return (
    <div>
      <h1 styleName="header">404</h1>
    </div>
  );
}
