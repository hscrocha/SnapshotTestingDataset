// @flow
const s: string = ""
export default s
