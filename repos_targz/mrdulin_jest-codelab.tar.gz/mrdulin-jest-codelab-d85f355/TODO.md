# TODO

- [x] https://stackoverflow.com/questions/50085505/testing-typescript-code-with-namespaces-by-jest-ts-jest
- [ ] https://stackoverflow.com/questions/45175599/mock-a-namespace-and-a-function-with-same-name-using-jest
