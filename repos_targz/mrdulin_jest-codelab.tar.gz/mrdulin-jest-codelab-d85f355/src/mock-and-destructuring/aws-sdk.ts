export class SharedIniFileCredentials {}

// tslint:disable-next-line: max-classes-per-file
export class SecretsManager {}
