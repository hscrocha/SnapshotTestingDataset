import React from 'react';

class Foo extends React.Component {
  constructor(props) {
    super(props);
  }

  public render() {
    return <div className="foo">Bar</div>;
  }
}

export default Foo;
