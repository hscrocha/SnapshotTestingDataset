class User {
  constructor(public name: string, public age: number) {}
}

export default User;
