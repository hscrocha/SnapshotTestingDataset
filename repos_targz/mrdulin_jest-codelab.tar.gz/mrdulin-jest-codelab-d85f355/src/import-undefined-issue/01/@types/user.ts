enum UserRoles {
  ADMIN = 'ADMIN',
  GUEST = 'GUEST'
}

export { UserRoles };
