export * from './user';
console.log('load index.ts');
