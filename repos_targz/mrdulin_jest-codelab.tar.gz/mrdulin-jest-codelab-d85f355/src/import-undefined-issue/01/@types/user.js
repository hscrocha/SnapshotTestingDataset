"use strict";
exports.__esModule = true;
var UserRoles;
(function (UserRoles) {
    UserRoles["ADMIN"] = "ADMIN";
    UserRoles["GUEST"] = "GUEST";
})(UserRoles || (UserRoles = {}));
exports.UserRoles = UserRoles;
