export const maxRetry = 5;

export enum UserRoles {
  ADMIN = 'ADMIN',
  GUEST = 'GUEST'
}
