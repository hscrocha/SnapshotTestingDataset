module.exports = () => 'apple';
