module.exports = () => 'grape';
