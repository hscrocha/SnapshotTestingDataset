module.exports = () => 'banana';
