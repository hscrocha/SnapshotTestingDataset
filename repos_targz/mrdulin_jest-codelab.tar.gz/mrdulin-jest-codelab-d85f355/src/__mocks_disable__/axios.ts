const axiosMocked = {
  get: jest.fn(),
};
export default axiosMocked;
