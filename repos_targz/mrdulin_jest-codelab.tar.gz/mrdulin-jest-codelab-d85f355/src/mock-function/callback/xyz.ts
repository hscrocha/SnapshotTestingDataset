function xyz(id, values, callback) {
  return callback();
}

export default xyz;
