function toBeTested(id, values, xyz, callback) {
  return xyz(id, values, callback);
}

export { toBeTested };
