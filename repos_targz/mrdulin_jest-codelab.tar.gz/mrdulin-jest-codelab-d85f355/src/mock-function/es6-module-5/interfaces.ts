export interface IObj {
  getMessage: () => string;
  genName: () => string;
  getAge: () => number;
}
