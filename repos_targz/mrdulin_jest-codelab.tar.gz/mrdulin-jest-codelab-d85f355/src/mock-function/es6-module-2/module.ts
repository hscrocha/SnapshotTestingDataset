export function getMessage(num: number): string {
  return `Her name is ${genName(num)}`;
}

export function genName(num: number): string {
  return 'novaline';
}
