import React, { Component } from 'react';

class SomeComponent extends Component {
  render() {
    return <div {...this.props}></div>;
  }
}

export default SomeComponent;
