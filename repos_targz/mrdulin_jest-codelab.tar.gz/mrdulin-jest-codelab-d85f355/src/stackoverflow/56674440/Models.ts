import console = require('console');

export async function patchAccount(...args) {
  return { error: true };
}
