async function auth() {
  return 'real auth response';
}
module.exports = { auth };
