export const ExternalLandingPageUtil = {
  getExternalLandingPageUrl(context) {
    return context.externalLP;
  }
};
