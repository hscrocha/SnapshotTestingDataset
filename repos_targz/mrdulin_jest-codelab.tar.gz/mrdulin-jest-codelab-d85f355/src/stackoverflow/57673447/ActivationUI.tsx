import React from 'react';

export const ActivationUI = ({ context, messages }) => <div>ActivationUI</div>;
