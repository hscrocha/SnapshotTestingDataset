export class B {
  someBFunctionFoo(arg) {
    console.log('real someBFunctionFoo implementation');
  }
  someBFunctionBar() {
    console.log('real someBFunctionBar implementation');
  }
}
