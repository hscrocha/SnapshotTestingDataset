import { findByName } from './someModule';

function other() {
  return findByName();
}

export { other };
