function findById() {
  return 'real data by id';
}

function findByName() {
  return 'real data by name';
}

export { findById, findByName };
