import { findById } from './someModule';

function main() {
  return findById();
}

export { main };
