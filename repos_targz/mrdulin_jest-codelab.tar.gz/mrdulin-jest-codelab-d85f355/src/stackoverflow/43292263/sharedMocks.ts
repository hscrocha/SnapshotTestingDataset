const findById = jest.fn();

export { findById };
