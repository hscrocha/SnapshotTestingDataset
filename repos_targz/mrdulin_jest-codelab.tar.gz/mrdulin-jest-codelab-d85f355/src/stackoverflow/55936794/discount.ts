export const discount = {
  put(obj) {
    return obj;
  }
};
