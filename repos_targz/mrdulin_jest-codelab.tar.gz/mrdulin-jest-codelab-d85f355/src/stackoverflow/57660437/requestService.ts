export async function runningSince() {
  return {
    data: {
      runningSince: 'real data'
    }
  };
}
