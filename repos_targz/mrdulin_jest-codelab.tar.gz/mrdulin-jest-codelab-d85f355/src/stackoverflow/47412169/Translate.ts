const Translator = {
  trans: text => text
};

(global as any).Translator = Translator;

export { Translator };
