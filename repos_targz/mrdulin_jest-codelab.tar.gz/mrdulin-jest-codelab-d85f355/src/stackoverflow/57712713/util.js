const util = {
  isElement() {}
};

module.exports = util;
