function Viewer() {
  // Doing things
  console.log('new viewer instance');
}

Viewer.prototype.foo = function() {};

module.exports = { Viewer };
