// tslint:disable-next-line: no-namespace
export namespace MainNamespace {
  export class MainClass {
    public sum(a: number, b: number): number {
      return a + b;
    }
  }
}
