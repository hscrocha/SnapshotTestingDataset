export const SetFiltersValue = () => ({ type: 'SET_FILTER' });
