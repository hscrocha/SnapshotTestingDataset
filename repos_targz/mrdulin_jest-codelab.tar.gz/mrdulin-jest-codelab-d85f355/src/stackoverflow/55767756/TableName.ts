export class TableName {
  constructor(opts) {}
  async save() {
    return this;
  }
}
