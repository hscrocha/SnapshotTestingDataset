export default class HttpClient {
  public async get(url) {
    return 'real data';
  }
}
