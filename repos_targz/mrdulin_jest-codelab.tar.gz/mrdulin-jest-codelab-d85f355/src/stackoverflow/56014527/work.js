function work(req, res, next) {
  next();
}

module.exports = work;
