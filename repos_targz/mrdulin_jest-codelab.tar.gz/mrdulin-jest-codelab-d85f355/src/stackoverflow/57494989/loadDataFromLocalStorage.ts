function loadDataFromLocalStorage() {
  return () => {
    return '';
  };
}

export default loadDataFromLocalStorage;
