function loadDataFromLocalStorage() {
  return () => {
    return 'mock data';
  };
}

export default loadDataFromLocalStorage;
