import { MongoDb } from '../interfaces';

export class UserModel {
  constructor(private mongodb: MongoDb) {}
}
