export interface MongoDb {}

export interface Models {}
