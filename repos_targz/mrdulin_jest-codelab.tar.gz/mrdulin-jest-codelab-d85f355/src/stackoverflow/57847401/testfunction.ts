async function testfunction(userParams, successCallback, errorCallback) {
  return {
    type: 'ACTION_TYPE',
    payload: {}
  };
}
export { testfunction };
