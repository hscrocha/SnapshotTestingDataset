export default { name: 'one' };
