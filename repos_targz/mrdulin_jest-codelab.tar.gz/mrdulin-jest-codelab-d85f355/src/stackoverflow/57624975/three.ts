export default { name: 'three' };
