function extractPayloadDates(agent) {
  return agent.getParameter();
}

export { extractPayloadDates };
