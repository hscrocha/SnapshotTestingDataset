const firebase = {
  auth() {
    return firebase;
  },
  async signInWithEmailAndPassword(email: string, password: string): Promise<any> {
    return firebase;
  }
};

export default firebase;
