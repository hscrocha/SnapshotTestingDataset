const yearGroupsSelectors = {
  selectAllTeachers(state) {
    return 'real computed data based on state';
  }
};

export default yearGroupsSelectors;
