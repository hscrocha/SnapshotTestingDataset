const checkNetwork = () => new Promise(resolve => resolve(true));

export default checkNetwork;
