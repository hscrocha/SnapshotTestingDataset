import React, { Component } from 'react';

class App extends Component {
  componentDidMount() {
    window.alert('haha');
  }
  render() {
    return <div></div>;
  }
}

export default App;
