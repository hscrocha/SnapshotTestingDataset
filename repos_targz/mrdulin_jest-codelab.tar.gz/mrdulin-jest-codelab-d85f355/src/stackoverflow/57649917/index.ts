export class SomeClass {
  find() {
    console.log('find');
  }
  findById(id) {
    console.log('findById');
  }
}
