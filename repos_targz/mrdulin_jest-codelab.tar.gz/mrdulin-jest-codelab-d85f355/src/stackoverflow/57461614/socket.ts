export const socket = {
  emit(event, data, callback) {
    // real implemetation
  }
};
