export default {
  func1() {}
};
