import moduleName from './third_party_module';

const util = {
  simple_function() {
    const name = moduleName.func1();
  }
};

export default util;
