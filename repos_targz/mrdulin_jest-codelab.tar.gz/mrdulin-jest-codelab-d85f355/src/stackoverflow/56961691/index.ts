const { setupUserAccounts } = require('./shared/user');

export function main() {
  return setupUserAccounts();
}
