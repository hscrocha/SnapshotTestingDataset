exports.setupUserAccounts = config => {
  console.log('setupUserAccounts');
};
