export default class UploadHandler {
  constructor(opts) {}

  public async uploadFile(opt) {
    console.log('uploadFile');
  }
}
