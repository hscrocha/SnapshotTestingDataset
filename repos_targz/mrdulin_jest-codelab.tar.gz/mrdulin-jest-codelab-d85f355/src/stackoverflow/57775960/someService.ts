class SomeService {
  public async saveNewElement(data) {
    return 'real data';
  }
}

export { SomeService };
