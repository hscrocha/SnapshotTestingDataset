export function showErrorAlert(jsonResponse) {
  console.log(jsonResponse);
}
