export const hash = async (data: string) => {
  return 'real hashed value';
};
