export class WebAuth {
  public client = {
    login(options, callback) {
      callback(null, {});
    }
  };
  constructor(...args: any) {}
}
