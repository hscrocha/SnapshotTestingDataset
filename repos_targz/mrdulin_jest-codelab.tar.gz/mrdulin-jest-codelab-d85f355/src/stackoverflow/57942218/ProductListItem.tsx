import React from 'react';

export default function ProductListItem(props) {
  return <div>ProductListItem</div>;
}
