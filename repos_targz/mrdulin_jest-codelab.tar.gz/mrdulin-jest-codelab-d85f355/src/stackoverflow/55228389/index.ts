function mySessionSetFunction() {
  sessionStorage.setItem('name', 'jest');
}

export { mySessionSetFunction };
