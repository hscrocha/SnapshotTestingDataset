const touchId = {
  isSupported() {
    return false;
  },
  authenticate() {
    return false;
  }
};
export default touchId;
