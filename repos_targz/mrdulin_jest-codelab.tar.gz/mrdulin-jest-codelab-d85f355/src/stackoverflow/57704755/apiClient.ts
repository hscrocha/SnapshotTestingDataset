const apiClient = {
  get: async parameter => {
    return 'real data';
  }
};

export { apiClient };
