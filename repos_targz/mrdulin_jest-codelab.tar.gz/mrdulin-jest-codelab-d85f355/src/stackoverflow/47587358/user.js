export class User {
  constructor(nick, firstName, userName, phoneNumber, userId) {
    this.nick = nick;
    this.firstName = firstName;
    this.userName = userName;
    this.phoneNumber = phoneNumber;
    this.userId = userId;
  }
}
