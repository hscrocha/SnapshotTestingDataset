const signupModule = {
  async createAccount(...args) {
    return { accountId: 2222 };
  }
};

export default signupModule;
