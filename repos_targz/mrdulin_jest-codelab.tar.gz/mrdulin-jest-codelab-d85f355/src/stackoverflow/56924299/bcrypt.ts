const bcrypt = {
  async hash(...args) {
    return 'real hash';
  }
};

export default bcrypt;
