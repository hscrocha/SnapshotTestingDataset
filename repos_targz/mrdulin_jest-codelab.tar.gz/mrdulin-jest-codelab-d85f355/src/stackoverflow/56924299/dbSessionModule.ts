class DbSessionModule {
  public async connect() {
    return {};
  }
  public async release() {
    return {};
  }
}

export default DbSessionModule;
