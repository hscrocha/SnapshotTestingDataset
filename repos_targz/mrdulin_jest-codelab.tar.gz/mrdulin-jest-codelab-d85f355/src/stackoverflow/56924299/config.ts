const config = { saltRounds: '123' };

export default config;
