export const CANCEL_EDITS = 'CANCEL_EDITS';

export const cancelEdits = () => ({
  type: CANCEL_EDITS,
});
