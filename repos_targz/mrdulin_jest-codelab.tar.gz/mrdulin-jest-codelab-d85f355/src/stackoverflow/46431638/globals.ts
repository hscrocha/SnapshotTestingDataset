export const document = {
  getElementsByTagName() {
    return 'real element';
  },
};
