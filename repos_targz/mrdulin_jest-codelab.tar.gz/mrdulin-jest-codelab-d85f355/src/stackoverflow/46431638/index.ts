import { document } from './globals';

export const Overlay = () => {
  console.log(document.getElementsByTagName());
};
