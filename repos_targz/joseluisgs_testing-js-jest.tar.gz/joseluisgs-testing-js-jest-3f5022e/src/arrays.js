// Arrays
export const provincias = ['Álava', 'Badajoz', 'Cáceres', 'Girona', 'Huelva', 'Jaén', 'La Rioja', 'Madrid', 'Navarra'];
export const dias = ['Lunes', 'Martes', 'Miercoles', 'Jueves', 'Viernes', 'Sabado', 'Domingo'];
// export const arrProvincias = () => provincias;
// export const arrDias = () => dias;
