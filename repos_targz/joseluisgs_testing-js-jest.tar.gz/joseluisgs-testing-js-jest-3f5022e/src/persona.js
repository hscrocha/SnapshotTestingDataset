export const persona1 = {
  nombre: 'Persona 1',
  edad: 10,
};
export const persona2 = {
  nombre: 'Persona 1',
  edad: 10,
};
