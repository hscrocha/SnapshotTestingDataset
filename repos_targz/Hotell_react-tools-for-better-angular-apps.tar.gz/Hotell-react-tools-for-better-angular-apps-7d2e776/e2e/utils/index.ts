import { BASE_URL } from '../environment';
import { Browser } from './browser';

export const browser = new Browser(BASE_URL);
