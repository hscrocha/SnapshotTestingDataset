export const BASE_URL = process.env.BASE_URL || 'http://localhost:4200';
