import { UserService } from './user.service';

export { UserService };
export const PROVIDERS = [UserService];
