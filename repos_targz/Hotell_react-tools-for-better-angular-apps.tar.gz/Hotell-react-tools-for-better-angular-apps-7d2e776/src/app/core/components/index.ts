import { TitleComponent } from './title/title.component';

export { TitleComponent };
export const COMPONENTS = [TitleComponent];
