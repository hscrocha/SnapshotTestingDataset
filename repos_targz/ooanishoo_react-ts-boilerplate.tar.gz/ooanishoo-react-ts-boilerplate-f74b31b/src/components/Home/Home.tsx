import React from 'react'

const Home: React.FC = () => {
    return <div data-testid="home">This is a Home Page</div>
}

export default Home
