/** All types goes here*/
export type Todo = {
    userId: number
    id: number
    title: string
    completed: boolean
}
