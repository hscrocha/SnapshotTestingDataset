[Changes](https://github.com/RusinovAnton/react-select3/releases)
