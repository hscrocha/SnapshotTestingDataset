export const DEFAULT_LANG = { // eslint-disable-line import/prefer-default-export
  isEmpty: 'No options.',
  isPending: '...',
  minLength: 'Minimum ${minLength} to search...', // eslint-disable-line no-template-curly-in-string
  responseEmpty: 'Cannot find anything.',
  serverError: 'Server error.',
};
