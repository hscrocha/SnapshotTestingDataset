### Do you want to request a feature, improve documentation, or ask a question?

### Do you want to report a bug?

**What is the current behavior?**

**What is the expected behavior?**

**What are the steps to reproduce?**

**What version of Docker, docker-compose, and what OS are you using?**
