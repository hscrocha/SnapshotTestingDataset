import Login from 'login/components/Login';
import {render} from 'react-dom';
import React from 'react';

import 'login/css/login.scss';

render(<Login />, document.getElementById('mount'));
