export const defaultState = {
  stepper: {
    step: undefined,
    completed: []
  }
};
