import * as React from 'react';

const NotFound = () => <span>404 Not Found</span>;

export default NotFound;
