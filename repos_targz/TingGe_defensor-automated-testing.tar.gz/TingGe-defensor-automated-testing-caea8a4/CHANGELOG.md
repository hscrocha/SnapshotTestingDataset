<a name="0.1.3"></a>
## [0.1.3](https://github.com/TingGe/defensor-automated-testing/compare/v0.1.2...v0.1.3) (2018-09-03)


### Bug Fixes

* update README.md ([a043b1b](https://github.com/TingGe/defensor-automated-testing/commit/a043b1b))


### Features

* add command test:createTests and vscode debug ([54046c8](https://github.com/TingGe/defensor-automated-testing/commit/54046c8))



<a name="0.1.2"></a>
## 0.1.2 (2018-08-30)



