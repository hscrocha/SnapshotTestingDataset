declare interface IPracticeProjectWebPartStrings {
  PropertyPaneDescription: string;
  BasicGroupName: string;
  DescriptionFieldLabel: string;
}

declare module 'PracticeProjectWebPartStrings' {
  const strings: IPracticeProjectWebPartStrings;
  export = strings;
}
