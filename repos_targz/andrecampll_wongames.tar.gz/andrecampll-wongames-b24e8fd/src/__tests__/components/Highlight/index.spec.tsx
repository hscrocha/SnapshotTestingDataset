import { screen } from '@testing-library/react';
import Highlight from '../../../components/Highlight';

import { render } from '../../../utils/test-utils';

import * as Styles from '../../../components/Highlight/styles';

import 'jest-styled-components';

const props = {
  title: 'heading 1',
  subtitle: 'heading 2',
  floatImage: '/float-image.png',
  backgroundImage: '/img/red-dead-img.jpg',
  buttonLabel: 'Buy now',
  buttonLink: '/rdr2',
};

describe('Highlight', () => {
  it('should be able to render headings and button', () => {
    const { container } = render(<Highlight {...props} />);

    expect(
      screen.getByRole('heading', {
        name: /heading 1/i,
      }),
    ).toBeInTheDocument();

    expect(
      screen.getByRole('heading', {
        name: /heading 2/i,
      }),
    ).toBeInTheDocument();

    expect(
      screen.getByRole('link', {
        name: /buy now/i,
      }),
    ).toBeInTheDocument();

    expect(container.firstChild).toMatchSnapshot();
  });

  it('should be able to render background image', () => {
    const { container } = render(<Highlight {...props} />);

    expect(container.firstChild).toHaveStyle({
      backgroundImage: `url(${props.backgroundImage})`,
    });

    expect(container.firstChild).toMatchSnapshot();
  });

  it('should be able to render background image', () => {
    render(<Highlight {...props} floatImage="/float-image.png" />);

    expect(
      screen.getByRole('img', {
        name: props.title,
      }),
    ).toHaveAttribute('src', '/float-image.png');
  });

  it('should be able to render align right by default', () => {
    const { container } = render(<Highlight {...props} />);

    expect(container.firstChild).toHaveStyleRule(
      'grid-template-areas',
      "'floatimage content'",
    );

    expect(container.firstChild).toHaveStyleRule('text-align', 'right', {
      modifier: `${Styles.Content}`,
    });
  });

  it('should be able to render align left', () => {
    const { container } = render(<Highlight {...props} alignment="left" />);

    expect(container.firstChild).toHaveStyleRule(
      'grid-template-areas',
      "'content floatimage'",
    );

    expect(container.firstChild).toHaveStyleRule('text-align', 'left', {
      modifier: `${Styles.Content}`,
    });
  });
});
