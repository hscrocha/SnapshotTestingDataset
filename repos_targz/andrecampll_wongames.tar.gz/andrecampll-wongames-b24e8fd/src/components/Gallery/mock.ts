export default [
  {
    src: '/img/games/cyberpunk-1.jpg',
    label: 'Gallery Image 1',
  },
  {
    src: '/img/games/cyberpunk-2.jpg',
    label: 'Gallery Image 2',
  },
  {
    src: '/img/games/cyberpunk-3.jpg',
    label: 'Gallery Image 3',
  },
  {
    src: '/img/games/cyberpunk-4.jpg',
    label: 'Gallery Image 4',
  },
  {
    src: '/img/games/cyberpunk-5.jpg',
    label: 'Gallery Image 5',
  },
  {
    src: '/img/games/cyberpunk-6.jpg',
    label: 'Gallery Image 6',
  },
];
