---
name: Initial Project Setup  
about: file and project setup
title: ''
labels: ''
assignees: ''

---

**Is this a required part of the project?**


**Does this add dependencies to the project? If so, please list them.**


**Additional context**
Add any other context or screenshots about the feature request here.
