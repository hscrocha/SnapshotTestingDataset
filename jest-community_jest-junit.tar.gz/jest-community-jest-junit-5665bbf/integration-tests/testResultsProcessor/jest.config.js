module.exports = {
  displayName: 'TestResultsProcessor Integration Tests',
  testResultsProcessor: '../../',
  testEnvironment: 'node'
};
