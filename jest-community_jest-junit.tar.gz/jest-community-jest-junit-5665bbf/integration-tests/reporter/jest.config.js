module.exports = {
  displayName: 'Reporter Integration Tests',
  reporters: [ '../../' ],
  testEnvironment: 'node'
};
