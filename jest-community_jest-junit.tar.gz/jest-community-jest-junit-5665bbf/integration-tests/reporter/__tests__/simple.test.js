describe('foo', () => {
  it('should pass', () => {
    expect(true).toEqual(true);
  });
});
