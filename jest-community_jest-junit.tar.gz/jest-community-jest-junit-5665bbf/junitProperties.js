module.exports = (suite) => {
  return {
    'best-tester': 'Jason Palmer'
  }
}
