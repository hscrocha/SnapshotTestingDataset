# ExpensifyApp
ExpensifyApp is a React application for managing your expenses. It uses Redux, SCSS.

