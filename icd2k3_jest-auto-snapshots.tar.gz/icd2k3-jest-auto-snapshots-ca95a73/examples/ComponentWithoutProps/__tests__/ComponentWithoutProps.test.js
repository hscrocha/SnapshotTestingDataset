import snap from 'jest-auto-snapshots';
import ComponentWithoutProps from '../ComponentWithoutProps';

snap(ComponentWithoutProps, '../ComponentWithoutProps.jsx');
