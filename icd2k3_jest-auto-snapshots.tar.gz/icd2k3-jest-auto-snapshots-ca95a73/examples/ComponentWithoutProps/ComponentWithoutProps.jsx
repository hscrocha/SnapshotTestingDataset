import React from 'react';

const ComponentWithoutProps = () => (
  <span>
    No Props Needed
  </span>
);

export default ComponentWithoutProps;
