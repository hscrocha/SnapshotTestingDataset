import snap from 'jest-auto-snapshots';
import DeepProps from '../DeepProps';

snap(DeepProps, '../DeepProps.jsx');
