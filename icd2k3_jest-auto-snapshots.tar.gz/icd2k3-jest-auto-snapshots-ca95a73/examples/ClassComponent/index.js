export { default } from './ClassComponent';
