import snap from 'jest-auto-snapshots';
import ClassComponent from '../ClassComponent';

snap(ClassComponent, '../ClassComponent.jsx');
