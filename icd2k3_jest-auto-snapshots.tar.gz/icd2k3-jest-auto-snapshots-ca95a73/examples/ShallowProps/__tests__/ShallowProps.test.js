import snap from 'jest-auto-snapshots';
import ShallowProps from '../ShallowProps';

snap(ShallowProps, '../ShallowProps.jsx');
