Contributing
===============================================================================

Have something to add? Feature requests, bug reports, and contributions are
enormously welcome!

  1. Fork this repo
  2. Update the tests and implement the change
  3. Submit a [pull request][github-pull-request]

(hint: following the conventions in the [the code review
checklist][code-review-checklist] will expedite review and merge)

[github-pull-request]: help.github.com/pull-requests/
[code-review-checklist]: https://github.com/rjz/code-review-checklist
