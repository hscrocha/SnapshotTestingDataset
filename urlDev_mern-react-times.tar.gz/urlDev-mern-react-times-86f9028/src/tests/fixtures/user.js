export const user = {
  avatar: { png: "iVBORw0KGgoAAAANSUhEUgAAAZAAAAGQCAYAAACAvzbMAAAACX" },
  email: "can@example.com",
  name: "Can",
  _id: "5589123",
};

export const userWebP = {
  avatar: {
    webp: "iVBORw0KGgoAAAANSUhEUgAAAZAAAAGQCAYAAACAvzbMAAAA",
  },
  email: "can@example.com",
  name: "Can",
  _id: "5589123",
};

export const token = "ey12345qwerty";

export const errorUser = {
  Error: "Can not get user",
};

export const userInputRegister = {
  name: "Can",
  email: "can@example.com",
  password: "cookies123",
};

export const userInputLogin = {
  email: "can@example.com",
  password: "cookies123",
};

export const data = {
  user,
  token,
};
