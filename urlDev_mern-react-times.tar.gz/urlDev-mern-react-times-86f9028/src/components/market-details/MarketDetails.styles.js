import styled from "styled-components";

export const MarketDetailsContainer = styled.div`
  display: flex;

  @media (max-width: 1400px) {
    flex-direction: column;
  }
`;
