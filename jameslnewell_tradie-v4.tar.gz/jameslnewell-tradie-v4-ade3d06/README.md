# <a href="https://github.com/jameslnewell/tradie">

  <img alt="tradie" src="./docs/img/logo.png" height="60px" />
</a>
<br/>
<a href="https://lernajs.io/" rel="nofollow"><img src="https://camo.githubusercontent.com/ecafd86d8356a1adc60fb4fd393bcc7584187f99/68747470733a2f2f696d672e736869656c64732e696f2f62616467652f6d61696e7461696e6564253230776974682d6c65726e612d6363303066662e737667" alt="lerna" data-canonical-src="https://img.shields.io/badge/maintained%20with-lerna-cc00ff.svg" style="max-width:100%;"></a>

[![Build Status](https://travis-ci.org/jameslnewell/tradie-v4.svg?branch=master)](https://travis-ci.org/jameslnewell/tradie-v4)

A framework for building tools like `create-react-app` tailored to your
use case and tech stack.

## Documentation

* ### [Contributor](docs/contributing.md)
