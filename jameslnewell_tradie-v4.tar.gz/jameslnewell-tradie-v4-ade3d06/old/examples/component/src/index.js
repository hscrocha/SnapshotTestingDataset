// @flow
import * as React from 'react';

export default class Foo extends React.Component<{}> {
  render() {
    return <div>Hello World!</div>;
  }
}
