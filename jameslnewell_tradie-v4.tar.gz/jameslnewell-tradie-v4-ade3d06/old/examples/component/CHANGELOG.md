# Change Log

All notable changes to this project will be documented in this file.
See [Conventional Commits](https://conventionalcommits.org) for commit guidelines.

<a name="1.1.0-alpha.1a7ea183"></a>

# 1.1.0-alpha.1a7ea183 (2018-06-04)

### Bug Fixes

* deps ([a41fe42](https://github.com/jameslnewell/tradie-v4/commit/a41fe42))
* make it deploy ([1a7ea18](https://github.com/jameslnewell/tradie-v4/commit/1a7ea18))
* scripts ([27c7c65](https://github.com/jameslnewell/tradie-v4/commit/27c7c65))

### Features

* switched node-scripts to typescript ([e523d30](https://github.com/jameslnewell/tradie-v4/commit/e523d30))

<a name="1.1.0-alpha.4fedd406"></a>

# 1.1.0-alpha.4fedd406 (2018-06-04)

### Bug Fixes

* deps ([a41fe42](https://github.com/jameslnewell/tradie-v4/commit/a41fe42))
* scripts ([27c7c65](https://github.com/jameslnewell/tradie-v4/commit/27c7c65))

### Features

* switched node-scripts to typescript ([e523d30](https://github.com/jameslnewell/tradie-v4/commit/e523d30))

<a name="1.1.0-alpha.4fedd406"></a>

# 1.1.0-alpha.4fedd406 (2018-06-04)

### Bug Fixes

* deps ([a41fe42](https://github.com/jameslnewell/tradie-v4/commit/a41fe42))
* scripts ([27c7c65](https://github.com/jameslnewell/tradie-v4/commit/27c7c65))

### Features

* switched node-scripts to typescript ([e523d30](https://github.com/jameslnewell/tradie-v4/commit/e523d30))

<a name="1.1.0-alpha.4fedd406"></a>

# 1.1.0-alpha.4fedd406 (2018-06-04)

### Bug Fixes

* deps ([a41fe42](https://github.com/jameslnewell/tradie-v4/commit/a41fe42))
* scripts ([27c7c65](https://github.com/jameslnewell/tradie-v4/commit/27c7c65))

### Features

* switched node-scripts to typescript ([e523d30](https://github.com/jameslnewell/tradie-v4/commit/e523d30))

<a name="1.1.0-alpha.4fedd406"></a>

# 1.1.0-alpha.4fedd406 (2018-06-02)

### Bug Fixes

* deps ([a41fe42](https://github.com/jameslnewell/tradie-v4/commit/a41fe42))
* scripts ([27c7c65](https://github.com/jameslnewell/tradie-v4/commit/27c7c65))

### Features

* switched node-scripts to typescript ([e523d30](https://github.com/jameslnewell/tradie-v4/commit/e523d30))

<a name="1.1.0-alpha.27c7c657"></a>

# 1.1.0-alpha.27c7c657 (2018-06-02)

### Bug Fixes

* scripts ([27c7c65](https://github.com/jameslnewell/tradie-v4/commit/27c7c65))

### Features

* switched node-scripts to typescript ([e523d30](https://github.com/jameslnewell/tradie-v4/commit/e523d30))

<a name="1.1.0-alpha.27c7c657"></a>

# 1.1.0-alpha.27c7c657 (2018-06-02)

### Bug Fixes

* scripts ([27c7c65](https://github.com/jameslnewell/tradie-v4/commit/27c7c65))

### Features

* switched node-scripts to typescript ([e523d30](https://github.com/jameslnewell/tradie-v4/commit/e523d30))

<a name="1.1.0-alpha.0bf35fa6"></a>

# 1.1.0-alpha.0bf35fa6 (2018-06-02)

### Features

* switched node-scripts to typescript ([e523d30](https://github.com/jameslnewell/tradie-v4/commit/e523d30))

<a name="1.1.0-alpha.f106bb76"></a>

# 1.1.0-alpha.f106bb76 (2018-06-02)

### Features

* switched node-scripts to typescript ([e523d30](https://github.com/jameslnewell/tradie-v4/commit/e523d30))

<a name="1.1.0-alpha.0a88ad7c"></a>

# 1.1.0-alpha.0a88ad7c (2018-03-08)

### Features

* switched node-scripts to typescript ([e523d30](https://github.com/jameslnewell/tradie-v4/commit/e523d30))

<a name="1.1.0-alpha.0a88ad7c"></a>

# 1.1.0-alpha.0a88ad7c (2018-03-08)

### Features

* switched node-scripts to typescript ([e523d30](https://github.com/jameslnewell/tradie-v4/commit/e523d30))

<a name="1.1.0-alpha.0a88ad7c"></a>

# 1.1.0-alpha.0a88ad7c (2018-03-08)

### Features

* switched node-scripts to typescript ([e523d30](https://github.com/jameslnewell/tradie-v4/commit/e523d30))

<a name="1.1.0-alpha.0a88ad7c"></a>

# 1.1.0-alpha.0a88ad7c (2018-03-08)

### Features

* switched node-scripts to typescript ([e523d30](https://github.com/jameslnewell/tradie-v4/commit/e523d30))

<a name="1.1.0-alpha.0a88ad7c"></a>

# 1.1.0-alpha.0a88ad7c (2018-03-08)

### Features

* switched node-scripts to typescript ([e523d30](https://github.com/jameslnewell/tradie-v4/commit/e523d30))

<a name="1.1.0-alpha.0a88ad7c"></a>

# 1.1.0-alpha.0a88ad7c (2018-03-08)

### Features

* switched node-scripts to typescript ([e523d30](https://github.com/jameslnewell/tradie-v4/commit/e523d30))

<a name="1.1.0-alpha.0a88ad7c"></a>

# 1.1.0-alpha.0a88ad7c (2018-03-08)

### Features

* switched node-scripts to typescript ([e523d30](https://github.com/jameslnewell/tradie-v4/commit/e523d30))
