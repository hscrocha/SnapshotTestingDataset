import sum from '../src';

console.log(`Question: What is 1 + 1?`);
console.log(`Answer: ${sum(1, 1)}`);
