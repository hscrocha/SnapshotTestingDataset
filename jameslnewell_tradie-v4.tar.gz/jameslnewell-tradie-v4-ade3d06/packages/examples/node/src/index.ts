
export default (...args: number[]): number => args.reduce((total: number, next: number) => total + next, 0);
