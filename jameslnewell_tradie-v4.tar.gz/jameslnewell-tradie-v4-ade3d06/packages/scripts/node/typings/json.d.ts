
declare module "*.json" {
  let version: string;
  export { version };
}
