
export const CODE_SRC = 'src';
export const CODE_DEST = 'lib';
export const EXAMPLES_SRC = 'examples';
export const TESTS_SRC = 'tests';
export const COVERAGE_DEST = 'coverage';
