var /\$;
