
const foo: number = 'abc';
