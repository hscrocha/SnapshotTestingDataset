// @flow

export const a: number = 'string';
