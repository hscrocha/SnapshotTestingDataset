export default function sum(x: number, y: number) {
  return x * y;
}
