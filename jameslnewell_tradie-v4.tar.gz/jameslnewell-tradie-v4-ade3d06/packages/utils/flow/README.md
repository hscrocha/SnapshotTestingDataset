# @tradie/flow-utils

Flow utilities for `tradie-scripts-*`.

## API
