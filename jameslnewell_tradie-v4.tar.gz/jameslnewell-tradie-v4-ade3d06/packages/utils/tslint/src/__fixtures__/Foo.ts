
export interface Foo {
  bar: string;
}

export const foo: Foo = { };
