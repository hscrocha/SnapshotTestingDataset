# @tradie/cli-utils

CLI utilities for `tradie-scripts-*`.

## API
