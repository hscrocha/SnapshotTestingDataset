# Change Log

All notable changes to this project will be documented in this file.
See [Conventional Commits](https://conventionalcommits.org) for commit guidelines.

<a name="1.1.0"></a>
# 1.1.0 (2018-06-28)


### Features

* preliminary support for workspaces ([e298285](https://github.com/jameslnewell/tradie-v4/commit/e298285))
