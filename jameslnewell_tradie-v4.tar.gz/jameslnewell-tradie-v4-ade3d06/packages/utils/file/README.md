# @tradie/file-utils

File utilities for `tradie-scripts-*`.

## API
