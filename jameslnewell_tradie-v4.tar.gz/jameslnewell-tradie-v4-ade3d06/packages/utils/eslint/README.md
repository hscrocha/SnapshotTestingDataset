# @tradie/eslint-utils

ESLint utilities for `tradie-scripts-*`.

## API
