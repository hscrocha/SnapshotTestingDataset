declare module "jest-cli";
