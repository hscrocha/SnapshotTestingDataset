# @tradie/jest-utils

Jest utilities for `tradie-scripts-*`.

## API

### `jestify(config : object[]) : Promise`

Run `jest`.

#### `config`
