export { clamp } from './clamp';
