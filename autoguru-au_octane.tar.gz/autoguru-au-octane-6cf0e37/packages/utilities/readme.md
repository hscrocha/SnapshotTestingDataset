# `@autoguru/utilities`

> A collection of smallish things that help
> [AutoGuru](https://www.autoguru.com.au/) write code.

## Usage

```sh
yarn add @autoguru/utilities
```

## Index

TODO

## Example

```js
import { warning } from '@autoguru/utilities/assert';

warning(false, 'This thing warned');
```
