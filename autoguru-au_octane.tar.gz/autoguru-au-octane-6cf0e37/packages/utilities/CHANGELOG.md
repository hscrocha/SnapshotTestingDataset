# @autoguru/utilities

## 1.1.1

### Patch Changes

-   8390261: GDU: Upgrades to webpak 5.7.x

## 1.1.0

### Minor Changes

-   d80a10b: Unicorn eslint rules: Upgraded to v33

    Prettier: Upgrades to v2.3

## 1.0.98

### Patch Changes

-   919e4a0: Upgraded all dev and prod deps

## 1.0.97

### Patch Changes

-   b0d77f1: Mass upgrade of dependencies
