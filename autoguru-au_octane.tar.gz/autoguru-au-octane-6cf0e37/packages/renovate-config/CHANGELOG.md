# renovate-config-autoguru

## 1.0.88

### Patch Changes

-   b0d77f1: Mass upgrade of dependencies
