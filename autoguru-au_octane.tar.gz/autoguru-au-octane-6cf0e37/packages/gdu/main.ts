export * from './lib/config';
export { PROJECT_ROOT, CALLING_WORKSPACE_ROOT, GDU_ROOT } from './lib/roots';
export { getApps } from './lib/apps';
