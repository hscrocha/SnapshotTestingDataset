import 'intersection-observer';
import { fetch } from 'whatwg-fetch';

window.fetch = fetch;
