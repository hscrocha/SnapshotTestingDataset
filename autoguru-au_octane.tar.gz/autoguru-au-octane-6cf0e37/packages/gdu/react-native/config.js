import gdu_config from 'gdu/babel/config.macro';

global['GDU_GLOBAL_CONFIG'] = gdu_config;
