# @autoguru/commitlint-config

## 1.1.0

### Minor Changes

-   d80a10b: Unicorn eslint rules: Upgraded to v33

    Prettier: Upgrades to v2.3

## 1.0.57

### Patch Changes

-   b0d77f1: Mass upgrade of dependencies

## 1.0.56

### Patch Changes

-   983bf9b: Allow ci type prefixes
