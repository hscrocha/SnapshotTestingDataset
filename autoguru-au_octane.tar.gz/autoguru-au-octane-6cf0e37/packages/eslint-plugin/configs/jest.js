// eslint-disable-next-line unicorn/prefer-module
module.exports = {
	extends: ['plugin:jest/recommended'],

	plugins: ['jest'],

	rules: {
		'jest/prefer-called-with': 'warn',
	},
};
