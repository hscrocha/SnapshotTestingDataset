# @autoguru/eslint-plugin

## 1.3.2

### Patch Changes

-   ae9cd96: Removes next eslint

## 1.3.1

### Patch Changes

-   ebee6d4: GDU: Adds CSP rules @autoguru/eslint-plugin: Adds nextjs defaults

## 1.3.0

### Minor Changes

-   d80a10b: Unicorn eslint rules: Upgraded to v33

    Prettier: Upgrades to v2.3

## 1.2.0

### Minor Changes

-   df57e1a: Upgrades eslint packages

## 1.1.5

### Patch Changes

-   3827266: Prettier just has itself (no more /react)

## 1.1.4

### Patch Changes

-   919e4a0: Upgraded all dev and prod deps

## 1.1.3

### Patch Changes

-   f1dd447: The react-in-scope rule is now mute

## 1.1.2

### Patch Changes

-   4260eb3: Bumps all deps

## 1.1.1

### Patch Changes

-   5567db1: Fixes some eslint rules breaking our things

## 1.1.0

### Minor Changes

-   bf0d849: Smaller more simple eslint config. Using less plugins, to help
    improve eslint runs and also more granular control.

## 1.0.85

### Patch Changes

-   b0d77f1: Mass upgrade of dependencies
