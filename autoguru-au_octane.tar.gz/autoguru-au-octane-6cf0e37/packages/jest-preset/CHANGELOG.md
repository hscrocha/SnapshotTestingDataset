# @autoguru/jest-preset

## 1.1.0

### Minor Changes

-   d80a10b: Unicorn eslint rules: Upgraded to v33

    Prettier: Upgrades to v2.3

### Patch Changes

-   Updated dependencies [d80a10b]
    -   @autoguru/babel-preset@1.2.0

## 1.0.98

### Patch Changes

-   919e4a0: Upgraded all dev and prod deps
-   Updated dependencies [941261e]
-   Updated dependencies [919e4a0]
    -   @autoguru/babel-preset@1.1.0

## 1.0.97

### Patch Changes

-   b0d77f1: Mass upgrade of dependencies
-   Updated dependencies [b0d77f1]
    -   @autoguru/babel-preset@1.0.97
