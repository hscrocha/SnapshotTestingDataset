# browserslist-config-autoguru

## 2.2.5

### Patch Changes

-   3068e69: Updated browserslist db

## 2.2.4

### Patch Changes

-   3617c76: Browserlist: Updated db

## 2.2.3

### Patch Changes

-   658158a: Broweserlist: Updated db

## 2.2.2

### Patch Changes

-   1f4007c: browserlist: gets updated db

## 2.2.1

### Patch Changes

-   8499104: Updates browserlist db

## 2.2.0

### Minor Changes

-   2553ae9: gdu: Generates supported browsers UA regex
    browserslist-config-autoguru: Upgrades browserlist version

## 2.1.4

### Patch Changes

-   e386918: Updates browserslit db

## 2.1.3

### Patch Changes

-   17eff6c: browserslist-config-autoguru: Gets updated browser versions

## 2.1.2

### Patch Changes

-   2ccb884: GDU: Updates nextjs default configs browserslist-config-autoguru:
    Updates browserlist db

## 2.1.1

### Patch Changes

-   28835a1: browserslist-config-autoguru: Updates browsers list

## 2.0.1

### Patch Changes

-   Upgrades browserlist

## 2.0.0

### Major Changes

-   14e78dc: browserlist config: Gets updates browser versions

## 1.1.0

### Minor Changes

-   d80a10b: Unicorn eslint rules: Upgraded to v33

    Prettier: Upgrades to v2.3

## 1.0.89

### Patch Changes

-   919e4a0: Upgraded all dev and prod deps

## 1.0.88

### Patch Changes

-   b0d77f1: Mass upgrade of dependencies
