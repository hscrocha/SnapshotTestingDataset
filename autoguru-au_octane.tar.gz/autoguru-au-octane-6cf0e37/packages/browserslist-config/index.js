// eslint-disable-next-line unicorn/prefer-module
module.exports = [
	'> 0.50% in au',
	'last 2 chrome versions',

	'last 2 firefox versions',
	'last 4 opera versions',
	'last 4 edge versions',
	'last 4 safari versions',
	'not ios_saf < 11',
	'last 6 samsung versions',

	'last 2 and_chr versions',
	'last 2 and_ff versions',
	'not ie 11',
	'not op_mini all',
	'not dead',
];
