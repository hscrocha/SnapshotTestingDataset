# create-guru

## 5.0.0

### Patch Changes

-   Updated dependencies [2553ae9]
    -   gdu@5.0.0

## 4.0.0-next.0

### Patch Changes

-   Updated dependencies [undefined]
    -   gdu@4.0.0-next.0

## 3.2.0

### Minor Changes

-   d80a10b: Unicorn eslint rules: Upgraded to v33

    Prettier: Upgrades to v2.3

### Patch Changes

-   Updated dependencies [d80a10b]
    -   gdu@3.2.0

## 3.0.0

### Patch Changes

-   Updated dependencies [41b6042]
    -   gdu@3.0.0

## 2.2.0

### Patch Changes

-   919e4a0: Upgraded all dev and prod deps
-   Updated dependencies [941261e]
-   Updated dependencies [68ae99c]
-   Updated dependencies [919e4a0]
-   Updated dependencies [00da6cc]
    -   gdu@2.2.0

## 2.1.2

### Patch Changes

-   4260eb3: Bumps deps and publishes new peerDeeps ranges
-   Updated dependencies [4260eb3]
    -   gdu@2.1.2

## 2.0.46

### Patch Changes

-   b0d77f1: Performance metrics added and better global app debug info
-   Updated dependencies [b0d77f1]
    -   gdu@2.0.46
