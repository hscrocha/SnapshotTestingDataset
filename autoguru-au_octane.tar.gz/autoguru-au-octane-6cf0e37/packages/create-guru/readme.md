# create guru

Please see docs at
[`gdu`](https://github.com/autoguru-au/octane/tree/master/packages/gdu#readme).
