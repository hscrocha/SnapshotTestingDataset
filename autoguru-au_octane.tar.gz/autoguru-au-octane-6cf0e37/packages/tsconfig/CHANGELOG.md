# @autoguru/tsconfig

## 1.0.80

### Patch Changes

-   eec2b71: GDU: generates better dev tools source mapping

## 1.0.79

### Patch Changes

-   919e4a0: Upgraded all dev and prod deps

## 1.0.78

### Patch Changes

-   b0d77f1: Mass upgrade of dependencies
