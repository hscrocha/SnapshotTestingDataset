# @autoguru/babel-preset

## 1.2.0

### Minor Changes

-   d80a10b: Unicorn eslint rules: Upgraded to v33

    Prettier: Upgrades to v2.3

## 1.1.0

### Minor Changes

-   941261e: Supporst new classes thing with node as well as some react changes
    for nextjs integration

### Patch Changes

-   919e4a0: Upgraded all dev and prod deps

## 1.0.98

### Patch Changes

-   4260eb3: New jsx-runtime config for react babel.

## 1.0.97

### Patch Changes

-   b0d77f1: Mass upgrade of dependencies
