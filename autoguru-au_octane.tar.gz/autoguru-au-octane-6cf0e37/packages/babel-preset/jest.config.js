/* eslint-disable unicorn/prefer-module */
module.exports = {
	displayName: require('./package.json').name,
};
