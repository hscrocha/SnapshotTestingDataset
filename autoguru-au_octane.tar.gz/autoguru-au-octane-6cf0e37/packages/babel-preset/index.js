// eslint-disable-next-line unicorn/prefer-module
module.exports = require('./web');
