import React from 'react';

export const TestMemo = React.memo(() => <h1>test</h1>);
