import { memo } from 'react';

const TestMemo = memo(() => <h1>test</h1>);
