import React, { memo } from 'react';

export const Test = withData(memo(() => <h1>test</h1>));
