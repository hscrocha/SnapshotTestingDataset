import React, { memo } from 'react';

export default memo(() => <h1>test</h1>);
