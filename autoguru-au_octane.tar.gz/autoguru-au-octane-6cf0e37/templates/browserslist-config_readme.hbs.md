# `browserslist-config-autoguru`

## Usage

```sh
yarn add --dev browserslist-config-autoguru
```

then in your `package.json` or `.browserslistrc` file:

```
extends browserslist-config-autoguru
```

### Support

[browserl.ist]({{ browsers_link }})
