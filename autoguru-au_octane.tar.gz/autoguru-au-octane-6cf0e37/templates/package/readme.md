# `@autoguru/{{ kebabCase name }}`

> {{ description }}

---

<a href="http://www.autoguru.com.au/"><img src="https://cdn.autoguru.com.au/images/logos/autoguru.svg" alt="AutoGuru" width="150" /></a>
