React Snapshot Demo
-------------------

[<img src="https://img.shields.io/badge/create-react--app-blue.svg">]((https://github.com/facebookincubator/create-react-app)) <img src="https://img.shields.io/badge/test-jest-blue.svg"> <img src="https://img.shields.io/badge/test-enzyme-blue.svg">

📖 Read the [blog post](./post/)





