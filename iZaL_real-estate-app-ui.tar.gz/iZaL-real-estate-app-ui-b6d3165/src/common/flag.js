const CountryFlags = {
  KW: require('./../../assets/country-flags/KW.png'),
  OM: require('./../../assets/country-flags/OM.png'),
  BH: require('./../../assets/country-flags/BH.png'),
  AE: require('./../../assets/country-flags/AE.png'),
  QA: require('./../../assets/country-flags/QA.png'),
  SA: require('./../../assets/country-flags/SA.png'),
};
export default CountryFlags;
