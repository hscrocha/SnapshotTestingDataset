const CountryBackgrounds = {
  KW: require('./../../assets/country-bg/KW.jpg'),
  OM: require('./../../assets/country-bg/OM.jpg'),
  BH: require('./../../assets/country-bg/BH.jpg'),
  AE: require('./../../assets/country-bg/AE.jpg'),
  QA: require('./../../assets/country-bg/QA.jpg'),
  SA: require('./../../assets/country-bg/SA.jpg'),
};
export default CountryBackgrounds;
