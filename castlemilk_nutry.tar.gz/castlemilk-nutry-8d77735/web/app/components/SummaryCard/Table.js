import styled from 'styled-components';

const Table = styled.div`
  display: table;
  width: 100%;
`;

export default Table;
