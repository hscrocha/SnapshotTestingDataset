import styled from 'styled-components';

const BodyGroup = styled.div`
  display: block;
  position: relative;
`;

export default BodyGroup;
