import styled from 'styled-components';

const ListViewItem = styled.div`
  display: inline-block;
  color: black;
  width: 100%;
  position: relative;
`;

export default ListViewItem;
