import styled from 'styled-components';

const Section = styled.div`
  display: inline-block;
  width: 100%;
  position: relative;
`;

export default Section;
