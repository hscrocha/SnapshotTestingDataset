export const HEADER = 'HEADER';
export const PARENT_ROW = 'PARENTR_ROW';
export const PARENT_NONAME_ROW = 'PARENT_NONAME_ROW';
export const CHILD_ROW = 'CHILD_ROW';
export const CHILD2_ROW = 'CHILD2_ROW';
