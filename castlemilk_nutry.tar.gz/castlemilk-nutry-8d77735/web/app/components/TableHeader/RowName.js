import styled from 'styled-components';

const RowName = styled.div`
  display: table-cell;
  width: 52%;
  font-family: 'Bitter', serif;
`;

export default RowName;
