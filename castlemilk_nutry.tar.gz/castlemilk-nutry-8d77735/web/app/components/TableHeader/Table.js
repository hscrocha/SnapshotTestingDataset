import styled from 'styled-components';

const Wrapper = styled.div`
  display: table;
  width: 100%;
  margin-left: 5px;
`;

export default Wrapper;
