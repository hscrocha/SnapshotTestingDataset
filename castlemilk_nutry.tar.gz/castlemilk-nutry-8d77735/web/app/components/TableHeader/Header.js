import styled from 'styled-components';

const Header = styled.div`
  display: table-header-group;
  font-weight: bold;
  width: 100%;
  font-size: 20px;
`;

export default Header;
