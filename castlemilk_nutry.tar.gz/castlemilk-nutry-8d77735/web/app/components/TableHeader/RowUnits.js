import styled from 'styled-components';

const RowUnits = styled.div`
  display: table-cell;
  text-align: center;
  width: 2%;
  font-family: 'Bitter', serif;
`;

export default RowUnits;
