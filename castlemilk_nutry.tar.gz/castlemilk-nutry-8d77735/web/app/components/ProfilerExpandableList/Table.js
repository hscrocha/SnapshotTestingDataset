import styled from 'styled-components';

const Table = styled.div`
  position: relative;
  display: table;
  width: 100%;
  overflow: visible;
`;

export default Table;
