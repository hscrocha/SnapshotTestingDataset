import styled from 'styled-components';

const ListViewItem = styled.div`
  margin-top: 10px;
  color: blue;
`;

export default ListViewItem;
