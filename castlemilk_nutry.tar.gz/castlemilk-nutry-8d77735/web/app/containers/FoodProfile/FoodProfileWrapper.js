import styled from 'styled-components';

const FoodProfileWrapper = styled.div`
  min-width: 1150px;
  height: auto;
`;

export default FoodProfileWrapper;
