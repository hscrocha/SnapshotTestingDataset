/*
 *
 * WikiView constants
 *
 */

export const DEFAULT_ACTION = 'app/WikiView/DEFAULT_ACTION';
