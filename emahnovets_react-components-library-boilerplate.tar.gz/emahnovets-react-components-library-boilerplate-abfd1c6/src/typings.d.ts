declare module '*.scss' {
  const classes: { [className: string]: string }
  export = classes
}
