<template>
    <div class="pane">
        <slot></slot>
    </div>
</template>

<script>
export default {
    name: 'Pane'
}
</script>
