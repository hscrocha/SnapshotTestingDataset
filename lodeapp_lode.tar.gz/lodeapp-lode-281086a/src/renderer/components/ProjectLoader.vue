<template>
    <main class="loading">
        <div class="loading-group">
            <div class="spinner"></div>
        </div>
    </main>
</template>

<script>
export default {
    name: 'ProjectLoader'
}
</script>
