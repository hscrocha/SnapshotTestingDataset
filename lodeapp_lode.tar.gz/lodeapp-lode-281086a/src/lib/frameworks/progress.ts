/**
 * A ledger of run progress.
 */
export type ProgressLedger = {
    run: number,
    total: number
}
