<?php

namespace LodeApp\PHPUnit;

use PHPUnit\TextUI\DefaultResultPrinter;

class Printer extends DefaultResultPrinter
{
}
