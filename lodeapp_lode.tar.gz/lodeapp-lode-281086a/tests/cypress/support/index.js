import electron from '../../mocks/electron'

import './ipc'
import './process'
import './assertions'

window.electron = electron
