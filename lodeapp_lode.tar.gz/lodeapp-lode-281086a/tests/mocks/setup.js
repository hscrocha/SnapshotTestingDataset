global.log = {
    debug: () => {},
    info: () => {},
    warn: () => {},
    error: () => {}
}
