---
name: "Feature request"
about: Request a feature that you think would improve Lode for everyone

---

### Describe the feature or problem you’d like to solve

A clear and concise description of what the feature or problem is.

### Proposed solution

How will it benefit Lode and its useΩrs?

### Additional context

Add any other context like screenshots or mockups are helpful, if applicable.
