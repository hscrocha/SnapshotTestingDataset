'use strict'

const init = require('./runners').init
init()
