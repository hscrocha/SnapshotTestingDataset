'use strict'

process.env.NODE_ENV = 'production'

const del = require('del')
const webpack = require('webpack')

const mainConfig = require('./webpack.main.config')
const preloadConfig = require('./webpack.preload.config')
const rendererConfig = require('./webpack.renderer.config')

build()

function build () {
    del.sync(['dist/*', '!.gitkeep'])
    pack(mainConfig)
    pack(preloadConfig)
    pack(rendererConfig)
}

function pack (config) {
    return new Promise((resolve, reject) => {
        config.mode = process.env.NODE_ENV === 'development' ? 'development' : 'production'
        webpack(config, (err, stats) => {
            if (err) reject(err.stack || err)
            else if (stats.hasErrors()) {
                let err = ''

                stats.toString({
                    chunks: false,
                    colors: true
                })
                    .split(/\r?\n/)
                    .forEach(line => {
                        err += `    ${line}\n`
                    })

                reject(err)
            } else {
                resolve(stats.toString({
                    chunks: false,
                    colors: true
                }))
            }
        })
    })
}
