New:
  - Copy a test's relative path from the context menu
  - Allow frameworks to process test result feedback messages
Changed:
  - Improved feedback on which process architecture Lode is running in
  - Upgrade to Electron v18
