New:
  - Group names with array items will be used as badges.
  - This is another array item (prefixed by a dash, parsed as YAML)
Changed:
  - This is another group. Colons will not show.
Fixed:
  - Also supports **markdown**
Removed:
  - New, Changed, Fixed and Removed are categories that have custom styling
Empty groups will be rendered as stand-alone notes (i.e. no badge prefix).
