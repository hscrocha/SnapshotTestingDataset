import { Note } from './note'

export const entities: ReadonlyArray<any> = [Note]
