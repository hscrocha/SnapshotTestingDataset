import { ZoneErrorHandler } from './zone-error-handler'

export const middlewares: ReadonlyArray<any> = [ZoneErrorHandler]
