# Manual Typings

When typings are not availabnle as part of the npm package or using @types repository, you can manual define the typed definitions for the javascript package.