declare module 'hash-files' {
  export function sync(options?: any): string;
}