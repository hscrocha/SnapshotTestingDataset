declare module '@expo/bunyan' {
  import * as bunyan from 'bunyan';
  export = bunyan;
}