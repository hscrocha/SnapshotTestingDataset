import 'jest-preset-angular';
import './jest.mocks';
