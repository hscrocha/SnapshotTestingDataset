React component example 1:

    <Button text="Hello ⚛" />

React component example 2:

    <Button text="Hello 🎅" />
