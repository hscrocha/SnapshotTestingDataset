// @flow strict

export { default as ConfigContext } from './ConfigContext';
