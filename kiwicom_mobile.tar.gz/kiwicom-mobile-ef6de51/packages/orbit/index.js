// @flow strict

export { defaultTokens } from '@kiwicom/orbit-design-tokens'; // eslint-disable-line no-restricted-imports
