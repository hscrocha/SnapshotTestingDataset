package com.skypicker.reactnative.nativemodules.translation

interface ResourceStringCallback {

  // region Public Methods

  fun getTranslation(key: String): String

  // endregion Public Methods

}
