package com.skypicker.reactnative.nativemodules.account

interface AccountCallback {
  fun accountDeleted()
}
