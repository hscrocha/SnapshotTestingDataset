package com.skypicker.reactnative.nativemodules.card

class Card {
  var number: String? = ""
  var expiryMonth: String? = ""
  var expiryYear: String? = ""
  var cardholder: String? = ""
}