package com.kiwi.rnkiwimobile.account

data class RNAccountInitialProperties(
        val token: String
)
