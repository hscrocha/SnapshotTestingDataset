package com.kiwi.rnkiwimobile

interface NativeBackButtonCallback {

  fun onInvokeDefaultBackButton()

}
