// @flow

export type Coordinates = {|
  +latitude: number,
  +longitude: number,
|};
