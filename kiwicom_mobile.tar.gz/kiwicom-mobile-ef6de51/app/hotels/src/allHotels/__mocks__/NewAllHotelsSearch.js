// @flow

import * as React from 'react';
import { View } from 'react-native';

export default function NewAllHotelsSearch() {
  return <View testID="NewAllHotelsSearch" />;
}
