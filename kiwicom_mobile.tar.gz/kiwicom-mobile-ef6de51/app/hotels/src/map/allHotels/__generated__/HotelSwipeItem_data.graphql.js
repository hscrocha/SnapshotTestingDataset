/**
 * @flow
 */

/* eslint-disable */
// flowlint untyped-type-import:off

import type { ReaderFragment } from 'relay-runtime';
import type { FragmentReference } from "relay-runtime";
declare export opaque type HotelSwipeItem_data$ref: FragmentReference;
declare export opaque type HotelSwipeItem_data$fragmentType: HotelSwipeItem_data$ref;
export type HotelSwipeItem_data = {|
  +hotelId: ?string,
  +name: ?string,
  +money: ?{|
    +currencyId: ?string,
    +amount: ?string,
  |},
  +mainPhoto: ?{|
    +thumbnailUrl: ?string
  |},
  +rating: ?{|
    +stars: ?number
  |},
  +review: ?{|
    +score: ?number
  |},
  +$refType: HotelSwipeItem_data$ref,
|};
export type HotelSwipeItem_data$data = HotelSwipeItem_data;
export type HotelSwipeItem_data$key = {
  +$data?: HotelSwipeItem_data$data,
  +$fragmentRefs: HotelSwipeItem_data$ref,
  ...
};


const node: ReaderFragment = {
  "kind": "Fragment",
  "name": "HotelSwipeItem_data",
  "type": "AllHotelsInterface",
  "metadata": null,
  "argumentDefinitions": [],
  "selections": [
    {
      "kind": "ScalarField",
      "alias": null,
      "name": "hotelId",
      "args": null,
      "storageKey": null
    },
    {
      "kind": "ScalarField",
      "alias": null,
      "name": "name",
      "args": null,
      "storageKey": null
    },
    {
      "kind": "LinkedField",
      "alias": null,
      "name": "money",
      "storageKey": null,
      "args": null,
      "concreteType": "Money",
      "plural": false,
      "selections": [
        {
          "kind": "ScalarField",
          "alias": null,
          "name": "currencyId",
          "args": null,
          "storageKey": null
        },
        {
          "kind": "ScalarField",
          "alias": null,
          "name": "amount",
          "args": null,
          "storageKey": null
        }
      ]
    },
    {
      "kind": "LinkedField",
      "alias": null,
      "name": "mainPhoto",
      "storageKey": null,
      "args": null,
      "concreteType": "HotelPhoto",
      "plural": false,
      "selections": [
        {
          "kind": "ScalarField",
          "alias": null,
          "name": "thumbnailUrl",
          "args": null,
          "storageKey": null
        }
      ]
    },
    {
      "kind": "LinkedField",
      "alias": null,
      "name": "rating",
      "storageKey": null,
      "args": null,
      "concreteType": "HotelRating",
      "plural": false,
      "selections": [
        {
          "kind": "ScalarField",
          "alias": null,
          "name": "stars",
          "args": null,
          "storageKey": null
        }
      ]
    },
    {
      "kind": "LinkedField",
      "alias": null,
      "name": "review",
      "storageKey": null,
      "args": null,
      "concreteType": "HotelReview",
      "plural": false,
      "selections": [
        {
          "kind": "ScalarField",
          "alias": null,
          "name": "score",
          "args": null,
          "storageKey": null
        }
      ]
    }
  ]
};
// prettier-ignore
(node: any).hash = '6d34760edc2e2aa3fec911b22595a8f0';
export default node;
