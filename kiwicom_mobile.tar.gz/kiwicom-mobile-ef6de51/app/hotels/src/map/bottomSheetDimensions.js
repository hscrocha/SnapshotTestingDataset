// @flow

export const openHeight = 150;
export const closedHeight = 80;
