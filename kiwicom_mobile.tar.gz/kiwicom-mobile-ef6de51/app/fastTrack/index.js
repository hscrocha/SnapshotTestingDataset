// @flow strict

export { default as FastTrackBanner } from './src/appRegistry/FastTrackBanner';
