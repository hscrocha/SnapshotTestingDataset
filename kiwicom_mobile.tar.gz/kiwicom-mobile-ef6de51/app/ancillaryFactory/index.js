// @flow strict

export { default as AncillaryFactory } from './src/appRegistry/AncillaryFactory';
