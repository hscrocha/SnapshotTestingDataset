// @flow

declare var device: Object;
declare var element: any;
declare var by: Object;
