#import <Foundation/Foundation.h>

@class RNKiwiConstants;

@interface RNKiwiConstants: NSObject;

+ (NSURL *)bundleURL;

@end
