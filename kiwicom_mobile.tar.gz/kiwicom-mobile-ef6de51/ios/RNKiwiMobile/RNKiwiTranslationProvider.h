@protocol RNKiwiTranslationProvider <NSObject>

- (nonnull NSString *)localizedStringWithKey:(nonnull NSString *)key;

@end
