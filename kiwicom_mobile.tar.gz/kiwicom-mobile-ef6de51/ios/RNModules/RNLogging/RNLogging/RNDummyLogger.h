#import <Foundation/Foundation.h>
#import "RNLogger.h"

NS_ASSUME_NONNULL_BEGIN

@interface RNDummyLogger : NSObject <RNLogger>

@end

NS_ASSUME_NONNULL_END
