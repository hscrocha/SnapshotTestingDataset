#import <Foundation/Foundation.h>
#import <React/RCTViewManager.h>

@interface RNKiwiAppleWalletManager : RCTViewManager
@end
