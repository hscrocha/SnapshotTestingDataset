#import <Foundation/Foundation.h>

@protocol RCTBridgeModule;

@interface RNDeviceInfo : NSObject <RCTBridgeModule>

@end
