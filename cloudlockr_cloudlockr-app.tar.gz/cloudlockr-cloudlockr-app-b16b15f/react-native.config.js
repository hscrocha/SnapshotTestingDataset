module.exports = {
    assets: ['./src/Assets/Fonts/']
}
