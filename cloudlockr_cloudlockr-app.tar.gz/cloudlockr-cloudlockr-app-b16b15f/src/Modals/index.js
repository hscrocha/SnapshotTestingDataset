export { default as DownloadDetail } from "./DownloadDetail";
export { default as UploadDetail } from "./UploadDetail";
