export { default as DownloadService } from "./Download";
export { default as UploadService } from "./Upload";
export { default as DeleteService } from "./Delete";
