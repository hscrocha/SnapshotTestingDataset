export { default as GetWifiNetworksService } from "./GetWifiNetworks";
export { default as GetLocationService } from "./GetLocation";
