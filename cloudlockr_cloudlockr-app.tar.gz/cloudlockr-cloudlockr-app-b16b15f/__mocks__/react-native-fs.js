export default readFile = (fileName, base) => {
  return jest.fn();
};
