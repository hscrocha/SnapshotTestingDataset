import mockAxios from 'jest-mock-axios';
export default mockAxios;
