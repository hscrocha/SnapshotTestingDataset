export default Geolocation = {
  getCurrentPosition: jest.fn(),
};
