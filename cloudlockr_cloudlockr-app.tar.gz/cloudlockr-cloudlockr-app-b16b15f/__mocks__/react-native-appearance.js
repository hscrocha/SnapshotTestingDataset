export * from 'react-native-appearance/src/mock'
