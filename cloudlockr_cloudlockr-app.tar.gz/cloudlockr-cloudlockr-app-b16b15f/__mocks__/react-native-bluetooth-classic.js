export default RNBluetoothClassic = {
  getBondedDevices: jest.fn(),
};
