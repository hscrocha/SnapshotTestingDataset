export default WifiManager = {
  loadWifiList: jest.fn(),
};
