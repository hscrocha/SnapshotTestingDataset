/**
 * test vis @AntV/G2Plot
 */

import { Line } from '@antv/g2plot';

describe('vis', () => {
  it('vis can pass', () => {
    const div = document.createElement('canvas');

    const line = new Line(div, {
      data: [
        { x: 'A', y: 10 },
        { x: 'B', y: 20 },
        { x: 'C', y: 30 },
      ],
      xField: 'x',
      yField: 'y',
    });

    line.render();

    expect(line.container.querySelector('canvas')).not.toBe(null);

    line.destroy();

    expect(line.container.querySelector('canvas')).toBe(null);
  });
});
