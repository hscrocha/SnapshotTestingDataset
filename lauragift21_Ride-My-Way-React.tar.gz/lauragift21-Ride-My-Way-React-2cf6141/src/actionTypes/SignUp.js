export const SIGN_UP_LOADING = "SIGN_UP_LOADING";
export const SIGN_UP_SUCCESS = "SIGN_UP_SUCCESS";
export const SIGN_UP_ERROR = "SIGN_UP_ERROR";
export const CLEAR_ERROR = "CLEAR_ERROR";
