import React from "react";

const App = () => <h2>This is the App component</h2>;

export default App;
