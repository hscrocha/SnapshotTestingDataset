import React from "react";

const Footer = () => (
  <footer className="copyright">
    <div className="container">
      <h4> © 2018 RideMyWay Inc.</h4>
    </div>
  </footer>
);

export default Footer;
