module.exports.MUST_BE_STRING = "libraryName mus't be a string!";

module.exports.LIBRARY_OPTS_ERROR =
  'Object is not correct. You should set { name: String, esm?:{ src: String, dist: String }, cjs?:{ src: String, dist: String } }';
