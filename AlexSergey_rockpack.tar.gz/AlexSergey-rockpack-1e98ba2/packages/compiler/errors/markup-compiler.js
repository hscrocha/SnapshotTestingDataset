module.exports.INVALID_PATH = 'Invalid path';

module.exports.PATH_CANT_BE_EMPTY = "Path can't be empty!";
