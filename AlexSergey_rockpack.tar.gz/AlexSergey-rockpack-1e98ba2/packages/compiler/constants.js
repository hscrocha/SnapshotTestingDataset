module.exports = {
  defaultDistFile: 'index',
  distExtension: '.js',
  moduleFormats: {
    cjs: 'cjs',
    esm: 'esm',
  },
};
