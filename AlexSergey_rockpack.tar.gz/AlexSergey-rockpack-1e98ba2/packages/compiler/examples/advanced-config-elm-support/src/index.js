const { Elm } = require('./Main');

Elm.Main.init({
  flags: 6,
  node: document.getElementById('root')
});
