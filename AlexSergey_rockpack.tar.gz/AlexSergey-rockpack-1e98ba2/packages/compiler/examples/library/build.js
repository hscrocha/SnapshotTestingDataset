const { libraryCompiler } = require('../../index');

libraryCompiler('MyLib');
