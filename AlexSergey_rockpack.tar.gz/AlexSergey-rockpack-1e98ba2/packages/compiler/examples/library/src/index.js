class MyLib {
  constructor(name) {
    this.name = name;
  }

  show() {
    return this.name;
  }
}

export default MyLib;
