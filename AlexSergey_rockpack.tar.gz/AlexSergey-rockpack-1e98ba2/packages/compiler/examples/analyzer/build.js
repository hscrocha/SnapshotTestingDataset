const { frontendCompiler } = require('../../index');

frontendCompiler({
  banner: true,
  styles: 'style.css'
});
