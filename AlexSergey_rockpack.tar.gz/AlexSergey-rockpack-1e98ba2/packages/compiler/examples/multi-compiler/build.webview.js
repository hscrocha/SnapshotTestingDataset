const { webViewCompiler } = require('../../index');

webViewCompiler();
