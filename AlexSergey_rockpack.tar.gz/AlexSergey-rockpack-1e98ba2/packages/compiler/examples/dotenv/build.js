const { frontendCompiler } = require('../../index');

frontendCompiler();
