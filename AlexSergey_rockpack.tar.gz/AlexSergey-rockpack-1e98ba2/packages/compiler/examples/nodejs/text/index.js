export default 'I am super text';
