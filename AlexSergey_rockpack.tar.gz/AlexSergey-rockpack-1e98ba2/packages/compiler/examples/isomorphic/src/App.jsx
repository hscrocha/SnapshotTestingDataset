import React from 'react';

export const App = () => {
  return (
    <div>
      <h1>Hello world!</h1>
    </div>
  );
};
