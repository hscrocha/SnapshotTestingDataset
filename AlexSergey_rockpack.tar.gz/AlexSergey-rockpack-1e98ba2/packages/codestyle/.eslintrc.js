const { makeConfig } = require('./index');

module.exports = makeConfig();
