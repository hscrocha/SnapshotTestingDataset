const { localazer } = require('@rockpack/compiler');

localazer.makePot();
