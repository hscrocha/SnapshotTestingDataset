import './assets/css/material-dashboard-react.css';

import { createDocumentation } from './core';

export default createDocumentation;
