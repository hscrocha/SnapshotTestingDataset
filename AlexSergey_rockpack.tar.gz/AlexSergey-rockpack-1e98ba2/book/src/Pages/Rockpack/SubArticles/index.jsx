import About from './About-Rockpack';
import FastSetup from './Fast-setup';
import GettingStarted from './Getting-started';

const pages = [About, GettingStarted, FastSetup];

export default pages;
