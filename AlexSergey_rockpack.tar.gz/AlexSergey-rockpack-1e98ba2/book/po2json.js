const { localazer } = require('../../compiler');

localazer.po2json();
