const { makeConfig } = require('@rockpack/codestyle');

module.exports = makeConfig();
