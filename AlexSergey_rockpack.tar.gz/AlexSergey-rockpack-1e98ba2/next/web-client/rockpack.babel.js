module.exports = {
  plugins: [
    '@issr/babel-plugin'
  ]
};
