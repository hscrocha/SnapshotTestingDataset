const po2json = require('@localazer/po2json');

po2json({
  src: './locales',
  dist: './src/locales'
});
