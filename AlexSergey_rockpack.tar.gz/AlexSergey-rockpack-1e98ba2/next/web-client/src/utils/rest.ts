/* eslint-disable @typescript-eslint/no-explicit-any */
import fetch from 'node-fetch';

interface IOpts {
  [key: string]: unknown;
}

export interface IRest {
  get: (url: string) => Promise<any>;
  post: (url: string, body?: IOpts | FormData, options?: IOpts) => Promise<any>;
  put: (url: string, body?: IOpts | FormData, options?: IOpts) => Promise<any>;
  delete: (url: string) => Promise<any>;
}

const commonHeaders = (token: string): { Authorization: string } | Record<string, never> => {
  if (token) {
    return {
      Authorization: token,
    };
  }

  return {};
};

export const createRestClient = (getToken: () => string): IRest => ({
  delete: <T>(url, options?): Promise<T> => {
    const headers = commonHeaders(getToken());

    if (options && typeof options.headers === 'object') {
      Object.assign(headers, options.headers);
    }

    return fetch(url, {
      // eslint-disable-next-line @typescript-eslint/ban-ts-comment
      // @ts-ignore
      credentials: 'include',
      headers,
      method: 'DELETE',
    })
      .then((res) => res.json())
      .then((res) => (res.statusCode !== 200 ? Promise.reject(res.message) : Promise.resolve(res)));
  },

  get: <T>(url): Promise<T> =>
    fetch(url, {
      // eslint-disable-next-line @typescript-eslint/ban-ts-comment
      // @ts-ignore
      credentials: 'include',

      headers: commonHeaders(getToken()),
    })
      .then((res) => res.json())
      .then((res) => {
        if (res.domain) {
          return Promise.resolve(res);
        }

        return res.statusCode !== 200 ? Promise.reject(res.message) : Promise.resolve(res);
      }),

  post: <T>(url, body?, options?): Promise<T> => {
    const isFormData = body instanceof FormData;

    const headers = commonHeaders(getToken());

    if (typeof body === 'object' && !isFormData) {
      Object.assign(headers, {
        Accept: 'application/json',
        'Content-Type': 'application/json',
      });
    }

    if (options && typeof options.headers === 'object') {
      Object.assign(headers, options.headers);
    }

    return fetch(url, {
      // eslint-disable-next-line @typescript-eslint/ban-ts-comment
      // @ts-ignore
      credentials: 'include',
      headers,
      method: 'POST',
      ...(typeof body === 'object'
        ? {
            body: isFormData ? body : JSON.stringify(body),
          }
        : {}),
    })
      .then((res) => res.json())
      .then((res) => (res.statusCode !== 200 ? Promise.reject(res.message) : Promise.resolve(res)));
  },

  put: <T>(url, body?, options?): Promise<T> => {
    const isFormData = body instanceof FormData;

    const headers = commonHeaders(getToken());

    if (typeof body === 'object' && !isFormData) {
      Object.assign(headers, {
        Accept: 'application/json',
        'Content-Type': 'application/json',
      });
    }

    if (options && typeof options.headers === 'object') {
      Object.assign(headers, options.headers);
    }

    return fetch(url, {
      // eslint-disable-next-line @typescript-eslint/ban-ts-comment
      // @ts-ignore
      credentials: 'include',
      headers,
      method: 'PUT',
      ...(typeof body === 'object'
        ? {
            body: isFormData ? body : JSON.stringify(body),
          }
        : {}),
    })
      .then((res) => res.json())
      .then((res) => (res.statusCode !== 200 ? Promise.reject(res.message) : Promise.resolve(res)));
  },
});
