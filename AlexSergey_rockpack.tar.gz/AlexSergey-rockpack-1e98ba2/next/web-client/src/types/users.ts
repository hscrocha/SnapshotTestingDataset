import { IUser } from './user';

export type IUsersState = IUser[];
