import { Layout as LayoutPage } from 'antd';
import React from 'react';

export const Footer = (): JSX.Element => (
  <LayoutPage.Header>
    <div>Footer</div>
  </LayoutPage.Header>
);
