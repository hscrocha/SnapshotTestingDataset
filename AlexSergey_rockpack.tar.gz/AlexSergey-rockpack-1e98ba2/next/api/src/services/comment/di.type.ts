export const CommentServiceDIType = Symbol.for('CommentServiceDIType');
