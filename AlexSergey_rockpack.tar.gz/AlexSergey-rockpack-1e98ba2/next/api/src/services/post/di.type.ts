export const PostServiceDIType = Symbol.for('PostServiceDIType');
