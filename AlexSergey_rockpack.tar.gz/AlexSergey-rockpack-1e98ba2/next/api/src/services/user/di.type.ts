export const UserServiceDIType = Symbol.for('UserServiceDIType');
