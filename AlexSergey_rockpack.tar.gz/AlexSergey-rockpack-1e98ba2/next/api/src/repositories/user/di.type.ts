export const UserRepositoryDIType = Symbol.for('UserRepositoryDIType');
