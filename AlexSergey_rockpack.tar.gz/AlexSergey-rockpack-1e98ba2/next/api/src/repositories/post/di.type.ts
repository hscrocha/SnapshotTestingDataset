export const PostRepositoryDIType = Symbol.for('PostRepositoryDIType');
