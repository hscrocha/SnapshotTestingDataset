export const CommentRepositoryDIType = Symbol.for('CommentRepositoryDIType');
