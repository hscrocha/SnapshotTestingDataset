export const PostControllerDIType = Symbol.for('PostControllerDIType');
