export const UserControllerDIType = Symbol.for('UserControllerDIType');
