export const CommentControllerDIType = Symbol.for('CommentControllerDIType');
