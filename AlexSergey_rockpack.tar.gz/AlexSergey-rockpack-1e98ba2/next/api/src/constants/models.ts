export const ROLE_MODEL_NAME = 'Role';

export const STATISTIC_MODEL_NAME = 'Statistic';

export const USER_MODEL_NAME = 'User';

export const PREVIEW_MODEL_NAME = 'Preview';

export const PHOTOS_MODEL_NAME = 'Photos';
