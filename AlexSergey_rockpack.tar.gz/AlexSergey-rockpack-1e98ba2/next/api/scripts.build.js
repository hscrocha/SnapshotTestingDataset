const { backendCompiler } = require('@rockpack/compiler');

backendCompiler();
