const tester = require('@rockpack/tester');

tester();
