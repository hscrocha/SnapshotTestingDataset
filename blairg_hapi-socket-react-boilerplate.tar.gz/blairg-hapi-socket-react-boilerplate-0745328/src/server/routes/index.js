import Controller from '../controllers/index';

export default [
  {
    method: 'GET',
    path: '/index',
    config: Controller.index,
  },
];
