import Public from './public';
import Api from './api';
import Index from './index';

export default {
  Public,
  Api,
  Index,
};
