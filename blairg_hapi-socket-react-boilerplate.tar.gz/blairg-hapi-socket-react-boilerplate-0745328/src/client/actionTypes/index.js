export const SET_TITLE = 'SET_TITLE';
export const SET_BODY = 'SET_BODY';
export const ADD_POST = 'ADD_POST';
export const SET_TODOS = 'SET_TODOS';
