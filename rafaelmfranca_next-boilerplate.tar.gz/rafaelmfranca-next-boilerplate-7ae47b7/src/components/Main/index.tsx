import * as S from './styles';

export default function Main({ title = 'Boilerplate' }) {
	return <S.Title>{title}</S.Title>;
}
