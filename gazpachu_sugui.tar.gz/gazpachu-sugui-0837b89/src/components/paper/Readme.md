The Paper component is just a container with a shadow applied to it. It can be used to create cards or panels.

For more info, please refer to the <a href="https://github.com/gazpachu/sugui/tree/master/src/components/paper/index.jsx" target="_blank">component implementation</a>

```jsx
<Paper>
  <div style={{ padding: '20px' }}>
    Lorem ipsum dolor sit amet, consectetur adipiscing elit. Nullam ac arcu id ipsum molestie semper id a nisl. Etiam nec justo purus. In hac habitasse platea dictumst. Morbi vitae iaculis leo. Maecenas sit amet lorem ut odio vestibulum tristique in vehicula turpis. Aliquam erat volutpat. In mi enim, suscipit in suscipit vel, placerat vitae elit. Vestibulum in auctor mi. Praesent quis odio in libero lacinia fermentum. Integer ipsum ligula, tempor eget aliquam feugiat, tincidunt at nunc. Orci varius natoque penatibus et magnis dis parturient montes, nascetur ridiculus mus. Vestibulum imperdiet sit amet ex in ultricies.
  </div>
</Paper>
```
