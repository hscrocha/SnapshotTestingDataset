The sideNav component sits on the left side of the screen. It contains by default one link to the homepage.

It can be extended with more items by passing the `<li>` tags as children.

For more info, please refer to the <a href="https://github.com/gazpachu/sugui/tree/master/src/components/sidenav/index.jsx" target="_blank">component implementation</a>

Due to the sidebar frame styleguide layout, the sidenav component example will be ommitted.
