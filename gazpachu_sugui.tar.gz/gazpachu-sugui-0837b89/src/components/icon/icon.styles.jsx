import styled from 'styled-components';

export const Container = styled.svg`
  width: 20px;
  height: 20px;
  vertical-align: middle;
`;
