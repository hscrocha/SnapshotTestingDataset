# Core Dev Configuration Files

> Reusable config files to set up git, bash, ssh and other OS utilities.
