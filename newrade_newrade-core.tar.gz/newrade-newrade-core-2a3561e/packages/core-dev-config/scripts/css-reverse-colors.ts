document.documentElement.style.filter = `invert(1) hue-rotate(180deg)`;
