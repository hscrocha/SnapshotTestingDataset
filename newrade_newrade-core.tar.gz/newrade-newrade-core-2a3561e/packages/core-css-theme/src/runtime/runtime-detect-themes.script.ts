// @ts-ignore
import detectCssDsThemes from './runtime-detect-themes.js?raw';

export const minifiedScript = `${detectCssDsThemes}`
  // .replace(/\n/g, ' ')
  // .replace(/"use strict";/g, '')
  // .replace(/ {2}/g, '')
  .replace(/export \{ \};/g, '');
// .replace(/\n/g, ' ')
// .replace(/"use strict";/g, '')
// .replace(/ {2}/g, '')
// .replace(/Object\.defineProperty\(exports, "__esModule", \{ value: true \}\);/g, '');

export default minifiedScript;
