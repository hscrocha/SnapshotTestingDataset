import { AppError, ERROR_TYPE } from '@newrade/core-common';

import {
  CSSDesignSystemConfig,
  CSSDesignSystemConfigIds,
  CSSDesignSystemConfigs,
  CSSDesignSystemSliceConfig,
  CSSDesignSystemThemeConfig,
} from '../design-system-css/index.js';
import { logDebug, logErrorDebug, logWarnDebug } from '../utilities/log.utilities.js';

/**
 * Find default themes for each "slice" of a design system configuration object
 */
export function getDefaultThemes({
  config,
}: {
  config: CSSDesignSystemConfig;
}): CSSDesignSystemConfigIds {
  const { colors, typography, sizing, iconography, effects, layout, components, others } = config;

  const defaultColorTheme = colors.themes.find(defaultSlicePredicate(colors));
  const defaultTypographyTheme = typography.themes.find(defaultSlicePredicate(typography));
  const defaultSizingTheme = sizing.themes.find(defaultSlicePredicate(sizing));
  const defaultIconographyTheme = iconography.themes.find(defaultSlicePredicate(iconography));
  const defaultEffectsTheme = effects.themes.find(defaultSlicePredicate(effects));
  const defaultLayoutTheme = layout.themes.find(defaultSlicePredicate(layout));

  /**
   *
   * Components
   *
   */

  const defaultLogosTheme = components.logos.themes.find(defaultSlicePredicate(components.logos));
  const defaultButtonsTheme = components.buttons.themes.find(
    defaultSlicePredicate(components.buttons)
  );

  /**
   *
   * Others
   *
   */

  const defaultResetTheme = others.resets.themes.find(defaultSlicePredicate(others.resets));
  const defaultScrollbarsTheme = others.scrollbars.themes.find(
    defaultSlicePredicate(others.scrollbars)
  );

  function defaultSlicePredicate(
    slice: CSSDesignSystemSliceConfig
  ): (
    theme: CSSDesignSystemThemeConfig,
    themeIndex: number,
    themes: CSSDesignSystemThemeConfig[]
  ) => any {
    return (theme, themeIndex, themes) => {
      //
      // if a forced theme id is set, prioritize this over other props
      //
      if (slice.forcedThemeId) {
        logDebug(`using (forced) ${slice.forcedThemeId} for slice ${slice.name}`);
        return theme.id === slice.forcedThemeId;
      }
      //
      // if a user has set a theme, we try to find it
      //
      if (slice.userSetThemeId) {
        logDebug(`using (user set) ${slice.userSetThemeId} for slice ${slice.name}`);
        return theme.id === slice.userSetThemeId;
      }
      //
      // if a preferred theme id is set, we prioritize this over other props
      //
      if (slice.preferredThemeId) {
        logDebug(`using (preferred) ${slice.preferredThemeId} for slice ${slice.name}`);
        return theme.id === slice.preferredThemeId;
      }
      //
      // fallback to the first theme with defautl set to true
      //
      if (theme.default) {
        logDebug(`using (default) ${theme.id} for slice ${slice.name}`);
        return true;
      }
      //
      // if we are at the last theme and no conditions have been met, use that theme
      //
      if (themeIndex === themes.length - 1) {
        logDebug(`using (last) ${theme.id} for slice ${slice.name}`);
        return true;
      }

      return false;
    };
  }

  return {
    colors: defaultColorTheme?.id || '',
    typography: defaultTypographyTheme?.id || '',
    sizing: defaultSizingTheme?.id || '',
    iconography: defaultIconographyTheme?.id || '',
    effects: defaultEffectsTheme?.id || '',
    layout: defaultLayoutTheme?.id || '',
    buttons: defaultButtonsTheme?.id || '',
    logos: defaultLogosTheme?.id || '',
    resets: defaultResetTheme?.id || '',
    scrollbars: defaultScrollbarsTheme?.id || '',
  };
}

/**
 * Find selected themes for each "slice" of a design system configuration object
 */
export function getSelectedThemesFromConfig(
  selected?: CSSDesignSystemConfigIds,
  config?: CSSDesignSystemConfig
): CSSDesignSystemConfigs {
  if (!selected) {
    return {
      colors: undefined,
      typography: undefined,
      sizing: undefined,
      iconography: undefined,
      effects: undefined,
      layout: undefined,
      buttons: undefined,
      logos: undefined,
      resets: undefined,
      scrollbars: undefined,
    };
  }

  if (!config) {
    return {
      colors: undefined,
      typography: undefined,
      sizing: undefined,
      iconography: undefined,
      effects: undefined,
      layout: undefined,
      buttons: undefined,
      logos: undefined,
      resets: undefined,
      scrollbars: undefined,
    };
  }

  const { colors, typography, sizing, iconography, effects, layout, components, others } = config;

  const selectedColorTheme = colors.themes.find((theme) => theme.id === selected.colors);
  const selectedTypographyTheme = typography.themes.find(
    (theme) => theme.id === selected.typography
  );
  const selectedSizingTheme = sizing.themes.find((theme) => theme.id === selected.sizing);
  const selectedIconographyTheme = iconography.themes.find(
    (theme) => theme.id === selected.iconography
  );
  const selectedEffectsTheme = effects.themes.find((theme) => theme.id === selected.effects);
  const selectedLayoutTheme = layout.themes.find((theme) => theme.id === selected.layout);

  /**
   *
   * Components
   *
   */

  const selectedLogosTheme = components.logos.themes.find((theme) => theme.id === selected.logos);
  const selectedButtonsTheme = components.buttons.themes.find(
    (theme) => theme.id === selected.buttons
  );

  /**
   *
   * Others
   *
   */

  const selectedResetTheme = others.resets.themes.find((theme) => theme.id === selected.resets);
  const selectedScrollbarsTheme = others.scrollbars.themes.find(
    (theme) => theme.id === selected.scrollbars
  );

  return {
    colors: selectedColorTheme,
    typography: selectedTypographyTheme,
    sizing: selectedSizingTheme,
    iconography: selectedIconographyTheme,
    effects: selectedEffectsTheme,
    layout: selectedLayoutTheme,
    buttons: selectedButtonsTheme,
    logos: selectedLogosTheme,
    resets: selectedResetTheme,
    scrollbars: selectedScrollbarsTheme,
  };
}

/**
 * Find default themes for each "slice" of a design system configuration object
 */
export function getThemeConfigById({
  config,
  themeId,
}: {
  config: CSSDesignSystemConfig;
  themeId: string;
}): CSSDesignSystemThemeConfig {
  const { colors, typography, sizing, iconography, effects, layout, components, others } = config;

  const colorTheme = colors.themes.find(themeByIdPredicate(colors));
  const typographyTheme = typography.themes.find(themeByIdPredicate(typography));
  const sizingTheme = sizing.themes.find(themeByIdPredicate(sizing));
  const iconographyTheme = iconography.themes.find(themeByIdPredicate(iconography));
  const effectsTheme = effects.themes.find(themeByIdPredicate(effects));
  const layoutTheme = layout.themes.find(themeByIdPredicate(layout));

  /**
   *
   * Components
   *
   */

  const logosTheme = components.logos.themes.find(themeByIdPredicate(components.logos));
  const buttonsTheme = components.buttons.themes.find(themeByIdPredicate(components.buttons));

  /**
   *
   * Others
   *
   */

  const resetTheme = others.resets.themes.find(themeByIdPredicate(others.resets));
  const scrollbarsTheme = others.scrollbars.themes.find(themeByIdPredicate(others.scrollbars));

  function themeByIdPredicate(
    slice: CSSDesignSystemSliceConfig
  ): (
    theme: CSSDesignSystemThemeConfig,
    themeIndex: number,
    themes: CSSDesignSystemThemeConfig[]
  ) => any {
    return (theme, themeIndex, themes) => {
      return theme.id === themeId;
    };
  }

  const found = [
    colorTheme,
    typographyTheme,
    sizingTheme,
    iconographyTheme,
    effectsTheme,
    layoutTheme,
    logosTheme,
    buttonsTheme,
    resetTheme,
    scrollbarsTheme,
  ].filter((theme) => !!theme)[0];

  if (!found) {
    throw new AppError({
      name: ERROR_TYPE.LIB_ERROR,
      message: `No theme found for themeId: ${themeId}`,
    });
  }

  return found;
}

/**
 * Get a CSS class selector (e.g. '.global-colors-default-light') based on the theme id
 */
export function getThemeSelector({
  config,
  themeId,
}: {
  config: CSSDesignSystemConfig;
  themeId: string;
}): `.${string}` {
  const foundTheme = getThemeConfigById({ config, themeId });
  return `.${config.runtime.prefix}-${foundTheme.id}`;
}

type LoadThemesOptions = {
  importLocalThemesFn?: (themeId: string) => Promise<any>;
  /**
   * When enabled, the loadThemes utility will fallback to default theme in case a local theme is missing
   * @default true
   */
  fallbackToDefaultThemes?: boolean;
};

const defaultLoadThemesOptions: LoadThemesOptions = { fallbackToDefaultThemes: true };

/**
 * Dynamically load themes for each design system slice defined in the config object
 *
 * @see https://webpack.js.org/api/module-methods/#dynamic-expressions-in-import
 */
export function loadThemes({
  config,
  options,
}: {
  config: CSSDesignSystemConfig;
  options?: LoadThemesOptions;
}): void {
  const validatedOptions = { ...defaultLoadThemesOptions, ...options };
  logDebug(`loading themes for config: ${config.id}`);

  // importing from node >16 exports field does not work
  // see https://github.com/webpack/webpack/issues/13865

  const themesToLoad = [
    ...config.others.resets.themes,
    ...config.colors.themes,
    ...config.typography.themes,
    ...config.sizing.themes,
    ...config.iconography.themes,
    ...config.effects.themes,
    ...config.layout.themes,
    ...config.components.buttons.themes,
    ...config.components.logos.themes,
    ...config.others.scrollbars.themes,
  ];

  themesToLoad.forEach((theme) => {
    importLocalTheme(theme.id);
  });

  function importLocalTheme(themeId: string) {
    const importLocalThemeFn = validatedOptions.importLocalThemesFn
      ? validatedOptions.importLocalThemesFn
      : (themeId: string) =>
          import(
            /* webpackMode: "eager" */
            /* webpackPreload: true */
            `../css/${themeId}.css.js`
          );

    importLocalThemeFn(themeId)
      .then((module) => {
        logDebug(`local theme: ${themeId} imported successfully`);
      })
      .catch((error) => {
        logWarnDebug(`could not load local theme ${themeId}`);

        if (validatedOptions.fallbackToDefaultThemes) {
          logDebug(`trying to load the default theme instead...`);
          importDefaultTheme(themeId);
        }
      });
  }

  function importDefaultTheme(themeId: string) {
    import(
      /* webpackMode: "eager" */
      /* webpackPreload: true */
      `../../../core-default-design-system/dist/css/${themeId}.css.js`
    )
      .then((module) => {
        logDebug(`theme: ${themeId} imported successfully`);
      })
      .catch((error) => {
        logWarnDebug(`could not load default theme ${themeId} in core-default-design-system`);
      });
  }
}
