/**
 *
 * Special selectors and other constants
 *
 */

/**
 * Special classname used to reverse the *color* theme
 */
export const GLOBAL_CSS_COLORS_SCHEME_REVERSE = 'global-css-colors-scheme-reversed';

/**
 * The theme scheme indicate if the user's browser is using light or dark color scheme.
 */
export enum GLOBAL_CSS_COLORS_THEME_SCHEME {
  LIGHT = 'global-css-colors-scheme-light',
  DARK = 'global-css-colors-scheme-dark',
}
