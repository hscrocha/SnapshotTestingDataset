import type {
  CSSDesignSystemColorSchemeClassname,
  CSSDesignSystemSliceName,
  CSSDesignSystemThemeClassname,
} from '../design-system-css/index.js';

import type {
  CSSDesignSystemLocalStorageProps,
  CssRuntimeDsLocalStorageThemeValue,
} from './runtime-localstorage.js';

/**
 * This script is designed to be inlined and executed in the head of the page.
 *
 * Its goal is to restore previously set CSS theme classes on the html element so that
 * rendering can happen immediately without having to wait for the actual application to load and configure the themes.
 *
 * The script (IFFE) does the following:
 *  - detects the user's color scheme
 *  - set a class on the html element to indicates what color scheme is selected
 *  - save the color scheme value in localstorage
 *  - it also checks for previously set color theme value in localstorage, if defined, it will add its classname
 *  - similarly, it will check for previously set values for
 *    other theme slices in localstorage and set the classnames accordingly
 *
 * **Note**: _do not_ imports (import from ...) in this file since
 * the content of this file is inlined in a script tag at build time. If you need
 * to import a type, use `import type {} from ''; which does not actually import source code.
 */

(function detectCssDsThemes() {
  const log = (str: string) => console.log(`nr:core-css-theme-script: ${str}`);
  const logError = (str: string) => console.error(`nr:core-css-theme-script:error: ${str}`);
  const logWarn = (str: string) => console.warn(`nr:core-css-theme-script:warn: ${str}`);

  const localStorageThemeProps: CSSDesignSystemLocalStorageProps = {
    colorScheme: 'global-css-colors-scheme-name',
    colors: 'global-css-colors-theme-name',
    typography: 'global-css-typography-theme-name',
    sizing: 'global-css-sizing-theme-name',
    iconography: 'global-css-iconography-theme-name',
    effects: 'global-css-effects-theme-name',
    layout: 'global-css-layout-theme-name',
    buttons: 'global-css-buttons-theme-name',
    logos: 'global-css-logos-theme-name',
    resets: 'global-css-resets-theme-name',
    scrollbars: 'global-css-scrollbars-theme-name',
  };

  if (typeof window === 'undefined') {
    log(
      `${detectCssDsThemes.name} should be executed in the browser, continuing without further action`
    );
    return;
  }

  let themesFromLocalStorage: Partial<CssRuntimeDsLocalStorageThemeValue> = {};

  function setGlobalCssThemeScheme(themeClassname: CSSDesignSystemColorSchemeClassname) {
    log(`adding theme scheme classname: ${themeClassname}`);

    if (themeClassname === 'global-css-colors-scheme-dark') {
      log(`adding the dark scheme classname`);
      if (!document.documentElement.classList.contains('global-css-colors-scheme-dark')) {
        document.documentElement.classList.add('global-css-colors-scheme-dark');
      }
      return;
    }

    if (themeClassname === 'global-css-colors-scheme-light') {
      log(`adding the light scheme classname`);
      if (!document.documentElement.classList.contains('global-css-colors-scheme-light')) {
        document.documentElement.classList.add('global-css-colors-scheme-light');
      }
      return;
    }
  }

  function setGlobalCssTheme(
    themeClassname: CSSDesignSystemThemeClassname<CSSDesignSystemSliceName, string>
  ) {
    log(`adding theme classname: ${themeClassname}`);

    if (!document.documentElement.classList.contains(themeClassname)) {
      document.documentElement.classList.add(themeClassname);
    }
  }

  function setGlobalPreferredThemeScheme(
    themeSchemeClassname: CSSDesignSystemColorSchemeClassname
  ) {
    try {
      log(`saving theme scheme to localStorage: ${themeSchemeClassname}`);
      window.localStorage.setItem(localStorageThemeProps.colorScheme, themeSchemeClassname);
    } catch (error) {
      logError(`error while detecting color scheme: ${error}`);
    }
  }

  try {
    log('getting preferred theme color scheme from localStorage');

    function getThemeValuesFromLocalStorage() {
      Object.entries(localStorageThemeProps).forEach(([themeName, themeValue]) => {
        const value = window.localStorage.getItem(themeValue);
        if (!value) {
          return;
        }
        const themeNameAsProp = themeName as keyof CSSDesignSystemLocalStorageProps;
        themesFromLocalStorage[themeNameAsProp] = value as any;
      });
    }

    getThemeValuesFromLocalStorage();

    log(`found color scheme: ${themesFromLocalStorage.colorScheme}`);
    log(`found colors theme: ${themesFromLocalStorage.colors}`);
  } catch (error: any) {
    logWarn(`got error: ${error}`);
    logWarn(`continuing...`);
  }

  //
  // execute the match media once
  //
  var mediaQuery;
  if (!themesFromLocalStorage.colorScheme) {
    mediaQuery = window.matchMedia('(prefers-color-scheme: dark)');
  }

  // set the correct color scheme classname depending on the user's color scheme
  const colorScheme =
    themesFromLocalStorage.colorScheme ||
    (mediaQuery?.matches ? 'global-css-colors-scheme-dark' : 'global-css-colors-scheme-light');
  setGlobalPreferredThemeScheme(colorScheme);
  setGlobalCssThemeScheme(colorScheme);
  // if set in local storage set the theme classname depending on the user's previously saved value
  const colorsTheme = themesFromLocalStorage.colors;
  if (colorsTheme) {
    setGlobalCssTheme(colorsTheme);
  }
})();
