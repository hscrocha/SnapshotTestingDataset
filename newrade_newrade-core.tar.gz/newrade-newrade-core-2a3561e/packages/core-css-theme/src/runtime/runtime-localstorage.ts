import {
  CSSDesignSystemConfigProps,
  CSSDesignSystemThemeClassname,
} from '../design-system-css/index.js';

/**
 * Object for each design system slice name in localStorage
 */
export type CSSDesignSystemLocalStorageProps = {
  colorScheme: string;
} & {
  [prop in CSSDesignSystemConfigProps]: GlobalRuntimeDsSliceLocalStoragePropName;
};

/**
 * Object for each design system slice name in localStorage
 */
export type CssRuntimeDsLocalStorageThemeValue = {
  colorScheme: CSSDesignSystemThemeClassname<'colors-scheme', 'light' | 'dark'>;
} & {
  [prop in CSSDesignSystemConfigProps]: CSSDesignSystemThemeClassname<prop, string>;
};

/**
 * Pattern for the design system's slice names, in localStorage
 * @example 'global-css-colors-scheme-name'
 */
export type GlobalRuntimeDsSliceLocalStoragePropName =
  | `${'global-css-colors-scheme-name'}`
  | `global-css-${CSSDesignSystemConfigProps}-theme-name`;

/**
 * Property names used to save the current (or previously set) themes in window.localStorage
 */
export const localStorageThemeProps: CSSDesignSystemLocalStorageProps = {
  colorScheme: 'global-css-colors-scheme-name',
  colors: 'global-css-colors-theme-name',
  typography: 'global-css-typography-theme-name',
  sizing: 'global-css-sizing-theme-name',
  iconography: 'global-css-iconography-theme-name',
  effects: 'global-css-effects-theme-name',
  layout: 'global-css-layout-theme-name',
  logos: 'global-css-logos-theme-name',
  buttons: 'global-css-buttons-theme-name',
  scrollbars: 'global-css-scrollbars-theme-name',
  resets: 'global-css-resets-theme-name',
};
