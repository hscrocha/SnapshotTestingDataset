import { COLOR_SCHEME } from '@newrade/core-design-system';

import { CSSDesignSystemConfig } from '../../design-system-css/css-design-system.config.js';
import { CSSDesignSystemConfigIds } from '../../design-system-css/css-design-system-types.js';
import { getDefaultThemes } from '../runtime.utilities.js';

export const testConfig: CSSDesignSystemConfig = {
  id: 'test-config',
  runtime: {
    prefix: 'global',
  },
  colors: {
    name: 'Colors',
    preferredThemeId: 'colors-default-dark',
    themes: [
      {
        id: 'colors-default-light',
        name: 'Light',
        default: true,
        colorScheme: COLOR_SCHEME.LIGHT,
      },
      {
        id: 'colors-default-dark',
        name: 'Dark',
        default: false,
        colorScheme: COLOR_SCHEME.DARK,
      },
    ],
  },
  sizing: {
    name: 'Sizing',
    themes: [
      {
        id: 'sizing-dense',
        name: 'Sizing Dense',
        default: true,
      },
      {
        id: 'sizing-default',
        name: 'Default',
        default: false,
      },
    ],
  },
  typography: {
    name: 'Typography',
    themes: [
      {
        id: 'typography-default',
        name: 'Default',
        default: true,
      },
    ],
  },
  iconography: {
    name: 'Iconography',
    themes: [
      {
        id: 'iconography-default',
        name: 'Default',
        default: true,
      },
    ],
  },
  effects: {
    name: 'Effects',
    themes: [
      {
        id: 'effects-default',
        name: 'Default',
        default: true,
      },
    ],
  },
  layout: {
    name: 'Layout',
    themes: [
      {
        id: 'layout-default',
        name: 'Default',
        default: true,
      },
    ],
  },
  components: {
    logos: {
      name: 'Logos',
      themes: [
        {
          id: 'logos-default',
          name: 'Default',
          default: true,
        },
      ],
    },
    buttons: {
      name: 'Buttons',
      themes: [
        {
          id: 'buttons-default',
          name: 'Default',
          default: true,
        },
      ],
    },
  },
  others: {
    resets: {
      name: 'Resets',
      themes: [
        {
          id: 'resets-default',
          name: 'Default',
          default: true,
        },
      ],
    },
    scrollbars: {
      name: 'Scrollbars',
      themes: [
        {
          id: 'scrollbars-default',
          name: 'Default',
          default: true,
        },
      ],
    },
  },
};

describe('css runtime utilities', () => {
  const defaultThemes = getDefaultThemes({ config: testConfig });

  describe(`${getDefaultThemes.name}`, () => {
    it(`should retrieve default themes in a design system configuration object`, () => {
      expect(defaultThemes).toEqual({
        colors: 'colors-default-dark',
        typography: 'typography-default',
        iconography: 'iconography-default',
        effects: 'effects-default',
        sizing: 'sizing-dense',
        layout: 'layout-default',
        buttons: 'buttons-default',
        logos: 'logos-default',
        resets: 'resets-default',
        scrollbars: 'scrollbars-default',
      } as CSSDesignSystemConfigIds);
    });
  });

  // describe(`${getSelectedThemesFromConfig.name}`, () => {
  //   it(`should retrieve default themes in a design system configuration object`, () => {
  //     expect(getSelectedThemesFromConfig(defaultThemes, cssRuntimeDsConfig)).toEqual({
  //       colors: cssRuntimeDsConfig.colors,
  //       typography: cssRuntimeDsConfig.typography,
  //       iconography: cssRuntimeDsConfig.iconography,
  //       effects: cssRuntimeDsConfig.effects,
  //       sizing: cssRuntimeDsConfig.sizing,
  //       layout: cssRuntimeDsConfig.layout,
  //       buttons: cssRuntimeDsConfig.buttons,
  //       logos: cssRuntimeDsConfig.logos,
  //       resets: cssRuntimeDsConfig.resets,
  //       scrollbars: cssRuntimeDsConfig.scrollbars,
  //     } as CSSDesignSystemConfigIds);
  //   });
  // });
});
