import {
  COLOR_SCHEME,
  DesignSystemSliceConfig,
  DesignSystemThemeConfig,
} from '@newrade/core-design-system';

import { CSSButtons } from './css-buttons.js';
import { CSSColorsV2 } from './css-colors.js';
import { CSSDesignSystemThemeId } from './css-design-system-types.js';
import { CSSEffects } from './css-effects.js';
import { CSSIconography } from './css-iconography.js';
import { CSSLayoutV2 } from './css-layout.js';
import { CSSResets } from './css-resets.js';
import { CSSScrollbars } from './css-scrollbars.js';
import { CssSizingV2 } from './css-sizing.js';
import { CSSTypographyV2 } from './css-typography.js';

/**
 * Object to hold runtime configuration values for
 * each design system slice
 */
export type CSSDesignSystemSliceConfig<
  ThemeConfig extends CSSDesignSystemThemeConfig = CSSDesignSystemThemeConfig,
  ThemeValue extends object = {}
> = DesignSystemSliceConfig<ThemeConfig, ThemeValue>;

/**
 * Object to hold runtime configuration values for
 * each design system theme
 */
export type CSSDesignSystemThemeConfig = DesignSystemThemeConfig & {
  /**
   * Unique id associated with the theme
   * @example global-css-colors-default-light
   */
  readonly id: CSSDesignSystemThemeId<`${string}`>;
};

/**
 * CSS version of the DesignSystemConfig configuration object
 *
 * The main difference are:
 * - values for themes (Colors, Sizing, etc) are optional – this is normal since themes configuration exist
 *   as actual files (e.g. colors-default-light.theme.ts) and we don't actually need
 *   the full value objects to be provided in the configuration object
 * - values for themes are the CSS variants (CSSColors instead of Colors) – since we do not want to bundle
 *   utility code in client-only applications
 * - additional properties for classnames options
 * - more specific types for CSS usage
 */
export type CSSDesignSystemConfig = {
  /**
   * UUID for the config
   * @example
   */
  id: string;
  /**
   * Option for the CSS runtime
   */
  runtime: {
    /**
     * Prefix used for themes and other values such as classnames
     * @default 'global'
     */
    prefix: string;
  };
  colors: CSSDesignSystemSliceConfig<
    Omit<CSSDesignSystemThemeConfig, 'id'> & {
      /**
       * Unique id associated with the theme
       * @example global-css-colors-default-light
       */
      readonly id: CSSDesignSystemThemeId<`${string}-${'light' | 'dark'}`>;
    },
    {
      /**
       * Whether the defined theme is a light or dark variant
       */
      colorScheme: COLOR_SCHEME;
      /**
       * Color values
       */
      colors?: CSSColorsV2;
    }
  >;
  typography: CSSDesignSystemSliceConfig<
    CSSDesignSystemThemeConfig,
    {
      /**
       * Typography values for the theme
       */
      typography?: CSSTypographyV2;
    }
  >;
  sizing: CSSDesignSystemSliceConfig<
    CSSDesignSystemThemeConfig,
    {
      /**
       * Sizing values for the theme
       */
      sizing?: CssSizingV2;
    }
  >;

  iconography: CSSDesignSystemSliceConfig<
    CSSDesignSystemThemeConfig,
    {
      /**
       * Iconography values for the theme
       */
      iconography?: CSSIconography;
    }
  >;
  effects: CSSDesignSystemSliceConfig<
    CSSDesignSystemThemeConfig,
    {
      /**
       * Effects values for the theme
       */
      effects?: CSSEffects;
    }
  >;
  layout: CSSDesignSystemSliceConfig<
    CSSDesignSystemThemeConfig,
    {
      /**
       * Layout values
       */
      layout?: CSSLayoutV2;
    }
  >;
  // animations
  components: {
    // figure out what to do with assets/files here, how is it going to look like in DB?
    logos: CSSDesignSystemSliceConfig<
      CSSDesignSystemThemeConfig,
      {
        /**
         * Logos values
         */
        logos?: {};
      }
    >;
    buttons: CSSDesignSystemSliceConfig<
      CSSDesignSystemThemeConfig,
      {
        /**
         * Buttons values
         */
        buttons?: CSSButtons;
      }
    >;
  };
  others: {
    resets: CSSDesignSystemSliceConfig<
      CSSDesignSystemThemeConfig,
      {
        /**
         * Resets values
         */
        resets?: CSSResets;
      }
    >;
    scrollbars: CSSDesignSystemSliceConfig<
      CSSDesignSystemThemeConfig,
      {
        /**
         * Scrollbars values
         */
        scrollbars?: CSSScrollbars;
      }
    >;
  };
};
