import { CSSResets } from './css-resets.js';
import { CSSScrollbars } from './css-scrollbars.js';

export type CSSOthers = {
  resets: CSSResets;
  scrollbars: CSSScrollbars;
};
