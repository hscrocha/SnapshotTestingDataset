import { Buttons } from '@newrade/core-design-system';

export type CSSButtons = Omit<Buttons<string>, 'vars'>;
