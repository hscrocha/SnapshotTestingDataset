import { Iconography } from '@newrade/core-design-system';

export type CSSIconography = Iconography<string> & {};
