import { CSSButtons } from './css-buttons.js';

export type CSSComponents = {
  buttons: CSSButtons;
};
