import { CSSDesignSystemConfig, CSSDesignSystemThemeConfig } from './css-design-system.config.js';

/**
 *
 * Additional types for the CSSDesignSystemConfig object
 *
 */

/**
 * Properties of the design system config object
 */
export type CSSDesignSystemConfigProps =
  | keyof Omit<CSSDesignSystemConfig, 'id' | 'runtime' | 'components' | 'others'>
  | keyof Pick<CSSDesignSystemConfig, 'components'>['components']
  | keyof Pick<CSSDesignSystemConfig, 'others'>['others'];

/**
 * Pattern for the design system's slice names to match
 * @example 'colors'
 */
export type CSSDesignSystemSliceName = `${CSSDesignSystemConfigProps}`;

/**
 * Convention for theme's classnames to follow
 * @example 'colors-default'
 */
export type CSSDesignSystemThemeId<ThemeName extends string> =
  `${CSSDesignSystemSliceName}-${ThemeName}`;

/**
 * Alias for GlobalCssThemeId
 */
export type CSSDesignSystemThemeClassname<
  SliceName extends string = CSSDesignSystemSliceName,
  ThemeName extends string = CSSDesignSystemSliceName
> = `global-css-${SliceName}-${ThemeName}`;

/**
 * Classname for the color scheme
 */
export type CSSDesignSystemColorSchemeClassname = `global-css-colors-scheme-${'light' | 'dark'}`;

/**
 * Object to hold which themes (ids) are currently selected
 */
export type CSSDesignSystemConfigIds = {
  [prop in CSSDesignSystemConfigProps]: string;
};

/**
 * Object to hold which themes (full object) are currently selected
 */
export type CSSDesignSystemConfigs = {
  [prop in CSSDesignSystemConfigProps]: CSSDesignSystemThemeConfig | undefined;
};
