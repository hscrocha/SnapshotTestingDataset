/**
 * Re-export stub so VSCode can find
 * source files instead of compiled .d.ts.
 *
 * This file should be set as "types" in package.json ("types": "dist/index.types.d.ts")
 */
export * from '../../src/design-system-css/index.js';
