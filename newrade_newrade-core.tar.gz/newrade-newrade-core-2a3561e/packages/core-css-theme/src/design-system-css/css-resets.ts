import { Resets } from '@newrade/core-design-system';

export type CSSResets = Omit<Resets<string>, 'vars'>;
