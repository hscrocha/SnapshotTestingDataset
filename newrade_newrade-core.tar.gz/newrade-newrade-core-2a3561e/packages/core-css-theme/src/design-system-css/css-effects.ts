import { Effects } from '@newrade/core-design-system';

export type CSSEffects = Omit<Effects<string>, 'vars'>;
