import { Scrollbars } from '@newrade/core-design-system';

export type CSSScrollbars = Omit<Scrollbars<string>, 'vars'>;
