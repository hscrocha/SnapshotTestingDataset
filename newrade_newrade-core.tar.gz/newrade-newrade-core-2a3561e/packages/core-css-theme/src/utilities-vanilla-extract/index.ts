/**
 *
 * Utilities for use in vanilla-extract (.css.ts) files only
 *
 */

export * from './typography-css.utilities.js';
