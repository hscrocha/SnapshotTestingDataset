import { kebab } from '@newrade/core-iso-utils';

/**
 * Formatting function used to have plain (with short content hash) variable names
 * e.g. --fonts-sans-alternate: ...
 */
export const formatContractProp: (
  prefix?: string
) => (value: string | null, path: string[]) => string = (prefix) => {
  return (value, path) => {
    return [prefix ? kebab(prefix) : '', ...path.map(kebab)].filter((part) => !!part).join('-');
  };
};
