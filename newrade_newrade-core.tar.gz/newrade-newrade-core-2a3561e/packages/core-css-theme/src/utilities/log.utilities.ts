import chalk from 'chalk';

import { logger } from '@newrade/core-iso-utils';
import { debugInstance } from '@newrade/core-react-ui-utilities-iso';

/**
 * Default CLI debug/log namespace
 */
export const NS = 'nr:core-css-theme';

/**
 *
 * Debug utilities
 *
 */

export const logDebug = debugInstance(`${NS}`);
export const logWarnDebug = debugInstance(`${NS}:warn`);
export const logErrorDebug = debugInstance(`${NS}:error`);

/**
 *
 * Configuration of the normal logger
 *
 */

const debugColor = Number(logDebug.color);
const colorText = chalk.ansi256(debugColor);

export const log = logger(`${colorText(NS)}`);
export const logWarn = logger(`${colorText(NS)}:warn`);
export const logError = logger(`${colorText(NS)}:error`);
