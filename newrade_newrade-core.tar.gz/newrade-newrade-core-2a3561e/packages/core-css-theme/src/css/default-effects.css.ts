import { createGlobalThemeContract } from '@vanilla-extract/css';
import { CSSVarFunction, MapLeafNodes } from '@vanilla-extract/private';

import { defaultEffects } from '../design-system/default-effects.js';
import { CSSEffects } from '../design-system-css/css-effects.js';
import { getCSSEffects } from '../utilities-css/effects.utilities.js';
import { formatContractProp } from '../utilities-vanilla-extract/contract.utilities.js';

/**
 *
 * Create and export vanilla-extract theme contracts for the
 * core-design-system and the core-react-ui components
 *
 * Those are derived from the default themes to create reference variables objects
 */

/**
 *
 * Effects
 *
 */

export const defaultCSSEffects = getCSSEffects(defaultEffects);

export const effectsVars: MapLeafNodes<CSSEffects, CSSVarFunction> =
  createGlobalThemeContract<CSSEffects>(defaultCSSEffects, formatContractProp());
export const effectsCSS = defaultCSSEffects;
