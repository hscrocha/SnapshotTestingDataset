import { createGlobalThemeContract } from '@vanilla-extract/css';
import { CSSVarFunction, MapLeafNodes } from '@vanilla-extract/private';

import { defaultIconography } from '../design-system/default-iconography.js';
import { CSSIconography } from '../design-system-css/css-iconography.js';
import { getCSSIconography } from '../utilities-css/iconography.utilities.js';
import { formatContractProp } from '../utilities-vanilla-extract/contract.utilities.js';

/**
 *
 * Create and export vanilla-extract theme contracts for the
 * core-design-system and the core-react-ui components
 *
 * Those are derived from the default themes to create reference variables objects
 */

/**
 *
 * Iconography
 *
 */

export const defaultCSSIconography = getCSSIconography(defaultIconography);

export const iconographyVars: MapLeafNodes<CSSIconography, CSSVarFunction> =
  createGlobalThemeContract<CSSIconography>(defaultCSSIconography, formatContractProp('icons'));
