import { createGlobalThemeContract } from '@vanilla-extract/css';
import { CSSVarFunction, MapLeafNodes } from '@vanilla-extract/private';

import { defaultScrollbars } from '../design-system/default-scrollbars.js';
import { CSSScrollbars } from '../design-system-css/css-scrollbars.js';
import { getCSSScrollbars } from '../utilities-css/scrollbars.utilities.js';
import { formatContractProp } from '../utilities-vanilla-extract/contract.utilities.js';

export const defaultCSSScrollbars: CSSScrollbars = getCSSScrollbars(defaultScrollbars);

export const scrollbarsVars: MapLeafNodes<CSSScrollbars, CSSVarFunction> =
  createGlobalThemeContract<CSSScrollbars>(defaultCSSScrollbars, formatContractProp('scrollbars'));
