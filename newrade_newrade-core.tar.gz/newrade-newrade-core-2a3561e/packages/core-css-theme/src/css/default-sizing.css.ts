import { createGlobalThemeContract } from '@vanilla-extract/css';
import { CSSVarFunction, MapLeafNodes } from '@vanilla-extract/private';

import { defaultSizing } from '../design-system/default-sizing.js';
import { CssSizingV2 } from '../design-system-css/css-sizing.js';
import * as s from '../utilities-css/sizing.utilities.js';
import { formatContractProp } from '../utilities-vanilla-extract/contract.utilities.js';

/**
 *
 * Create and export vanilla-extract theme contracts for the
 * core-design-system and the core-react-ui components
 *
 * Those are derived from the default themes to create reference variables objects
 */

/**
 *
 * Sizing variables
 *
 */

export const defaultCSSSizing = s.getCSSSizingV2(defaultSizing);

export const sizingVars: MapLeafNodes<CssSizingV2, CSSVarFunction> =
  createGlobalThemeContract<CssSizingV2>(defaultCSSSizing, formatContractProp());
export const sizeVars = s.defaultSizesCSSVarV2;
export const sizeVarNames = s.defaultSizesCSSVarNamesV2;
export const ratioVars = s.defaultRatiosCSSVar;
export const ratioVarNames = s.defaultRatiosCSSVarNamesV2;
export const sizingCSS = defaultCSSSizing;
