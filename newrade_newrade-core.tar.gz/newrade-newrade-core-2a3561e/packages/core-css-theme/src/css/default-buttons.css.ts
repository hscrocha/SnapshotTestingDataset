import { createGlobalThemeContract } from '@vanilla-extract/css';
import { CSSVarFunction, MapLeafNodes } from '@vanilla-extract/private';

import { defaultButtons } from '../design-system/default-buttons.js';
import { CSSButtons } from '../design-system-css/css-buttons.js';
import { getCSSButtons } from '../utilities-css/buttons.utilities.js';
import { formatContractProp } from '../utilities-vanilla-extract/contract.utilities.js';

/**
 *
 * Create and export vanilla-extract theme contracts for the
 * core-design-system and the core-react-ui components
 *
 * Those are derived from the default themes to create reference variables objects
 */

/**
 * Components
 */
export const defaultCSSButtons: CSSButtons = getCSSButtons(defaultButtons);

export const buttonsVars: MapLeafNodes<CSSButtons, CSSVarFunction> =
  createGlobalThemeContract<CSSButtons>(defaultCSSButtons, formatContractProp('buttons'));
