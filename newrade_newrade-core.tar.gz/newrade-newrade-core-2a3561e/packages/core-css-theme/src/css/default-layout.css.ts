import { createGlobalThemeContract } from '@vanilla-extract/css';
import { CSSVarFunction, MapLeafNodes } from '@vanilla-extract/private';

import { defaultLayout } from '../design-system/default-layout.js';
import { CSSLayoutV2 } from '../design-system-css/css-layout.js';
import { getCSSLayoutV2 } from '../utilities-css/layout.utilities.js';
import { formatContractProp } from '../utilities-vanilla-extract/contract.utilities.js';

/**
 *
 * Create and export vanilla-extract theme contracts for the
 * core-design-system and the core-react-ui components
 *
 * Those are derived from the default themes to create reference variables objects
 */

/**
 * Layout
 */

export const defaultCSSLayout = getCSSLayoutV2(defaultLayout);

export const layoutVars: MapLeafNodes<CSSLayoutV2, CSSVarFunction> =
  createGlobalThemeContract<CSSLayoutV2>(defaultCSSLayout, formatContractProp());
export const layoutCSS = defaultCSSLayout;
