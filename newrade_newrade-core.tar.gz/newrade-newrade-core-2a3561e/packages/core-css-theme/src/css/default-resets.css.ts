import { createGlobalThemeContract } from '@vanilla-extract/css';
import { CSSVarFunction, MapLeafNodes } from '@vanilla-extract/private';

import { defaultResets } from '../design-system/default-resets.js';
import { CSSResets } from '../design-system-css/css-resets.js';
import { getCSSResets } from '../utilities-css/resets.utilities.js';
import { formatContractProp } from '../utilities-vanilla-extract/contract.utilities.js';

export const defaultCSSResets: CSSResets = getCSSResets(defaultResets);

export const resetVars: MapLeafNodes<CSSResets, CSSVarFunction> =
  createGlobalThemeContract<CSSResets>(defaultCSSResets, formatContractProp('resets'));
