import { createGlobalThemeContract } from '@vanilla-extract/css';
import { CSSVarFunction, MapLeafNodes } from '@vanilla-extract/private';

import { defaultTypography } from '../design-system/default-typography.js';
import { CSSTypographyV2 } from '../design-system-css/css-typography.js';
import { getCSSTypographyV2 } from '../utilities-css/typography-v2.utilities.js';
import { formatContractProp } from '../utilities-vanilla-extract/contract.utilities.js';

/**
 *
 * Create and export vanilla-extract theme contracts for the
 * core-design-system and the core-react-ui components
 *
 * Those are derived from the default themes to create reference variables objects
 */

/**
 * Typography
 */

export const defaultCSSTypography = getCSSTypographyV2({
  ...defaultTypography,
  baseFontSize: 16,
  vars: undefined,
});

export const typographyVars: MapLeafNodes<CSSTypographyV2, CSSVarFunction> =
  createGlobalThemeContract<CSSTypographyV2>(defaultCSSTypography, formatContractProp());
export const typographyCSS = defaultCSSTypography;
export const typoSpaceVars = typographyVars.spaces;
