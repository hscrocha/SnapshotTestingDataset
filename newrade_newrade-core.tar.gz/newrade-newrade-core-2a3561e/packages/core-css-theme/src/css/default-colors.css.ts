import { createGlobalThemeContract } from '@vanilla-extract/css';
import { CSSVarFunction, MapLeafNodes } from '@vanilla-extract/private';

import { defaultColors } from '../design-system/default-colors.js';
import { CSSColorsV2 } from '../design-system-css/css-colors.js';
import { getCSSColorsV2 } from '../utilities-css/colors.utilities.js';
import { formatContractProp } from '../utilities-vanilla-extract/contract.utilities.js';

/**
 *
 * Create and export vanilla-extract theme contracts for the
 * core-design-system and the core-react-ui components
 *
 * Those are derived from the default themes to create reference variables objects
 */

/**
 *
 * Colors
 *
 */
export const defaultCSSColors = getCSSColorsV2(defaultColors);

export const colorVars: MapLeafNodes<CSSColorsV2, CSSVarFunction> =
  createGlobalThemeContract<CSSColorsV2>(defaultCSSColors, formatContractProp());
export const colorCSS = defaultCSSColors;
