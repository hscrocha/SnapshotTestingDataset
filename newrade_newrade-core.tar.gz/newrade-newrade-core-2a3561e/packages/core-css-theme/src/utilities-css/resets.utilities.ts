import { Resets, ResetsColors } from '@newrade/core-design-system';

import { CSSResets } from '../design-system-css/css-resets.js';

import { getCSSColor } from './colors.utilities.js';
import { setVarsValuesToStyleObject } from './component.utilities.js';

export function getCSSResets(resets: Resets): CSSResets {
  //
  // first, create CSSResets from raw styles
  //
  const cssResets: CSSResets = {
    colors: getCSSResetsColors(resets.colors),
  };

  if (!resets.vars) {
    return cssResets;
  }

  //
  // if vars is passed, traverse the CSSResets object and replace the defined values
  //
  return setVarsValuesToStyleObject<CSSResets>(cssResets, resets.vars);
}

function getCSSResetsColors(resets: ResetsColors): ResetsColors<string> {
  return {
    textColor: getCSSColor(resets.textColor),
    backgroundColor: getCSSColor(resets.backgroundColor),
  };
}
