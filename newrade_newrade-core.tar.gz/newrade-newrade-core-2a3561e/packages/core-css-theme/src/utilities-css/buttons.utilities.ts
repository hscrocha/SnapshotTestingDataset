import {
  ButtonColors,
  ButtonIconStyle,
  ButtonOutline,
  Buttons,
  ButtonSizes,
  ButtonVariants,
} from '@newrade/core-design-system';
import { keys, px } from '@newrade/core-react-ui-utilities-iso';

import { CSSButtons } from '../design-system-css/css-buttons.js';

import {
  getCSSBorderStyles,
  getCSSBoxMargin,
  getCSSBoxPadding,
  getCSSBoxRadius,
} from './box.utilities.js';
import { getCSSColor } from './colors.utilities.js';
import { setVarsValuesToStyleObject } from './component.utilities.js';

export function getCSSButtons(buttons: Buttons): CSSButtons {
  //
  // first, create CSSButtons from raw styles
  //
  const cssButtons: CSSButtons = {
    variants: getCSSButtonVariants(buttons.variants),
    sizes: getCSSButtonSizes(buttons.sizes),
  };

  if (!buttons.vars) {
    return cssButtons;
  }

  //
  // if vars is passed, traverse the CSSButtons object and replace the defined values
  //
  return setVarsValuesToStyleObject<CSSButtons>(cssButtons, buttons.vars);
}

function getCSSButtonVariants(buttons: ButtonVariants): ButtonVariants<string> {
  return keys(buttons).reduce((previous, current) => {
    const variantColorStyles: ButtonColors<string> = {
      textColor: getCSSColor(buttons[current].textColor),
      textColorActive: getCSSColor(buttons[current].textColorActive),
      textColorDisabled: getCSSColor(buttons[current].textColorDisabled),
      iconColor: getCSSColor(buttons[current].iconColor),
      iconColorActive: getCSSColor(buttons[current].iconColorActive),
      iconColorDisabled: getCSSColor(buttons[current].iconColorDisabled),
      backgroundColor: getCSSColor(buttons[current].backgroundColor),
      backgroundColorActive: getCSSColor(buttons[current].backgroundColorActive),
      backgroundColorDisabled: getCSSColor(buttons[current].backgroundColorDisabled),
      borderColor: getCSSColor(buttons[current].borderColor),
      borderColorActive: getCSSColor(buttons[current].borderColorActive),
      borderColorDisabled: getCSSColor(buttons[current].borderColorDisabled),
      outlineColor: getCSSColor(buttons[current].outlineColor),
      outlineColorActive: getCSSColor(buttons[current].outlineColorActive),
      outlineColorDisabled: getCSSColor(buttons[current].outlineColorDisabled),
    };
    previous[current] = variantColorStyles;
    return previous;
  }, {} as ButtonVariants<string>);
}

function getCSSButtonSizes(buttons: ButtonSizes): ButtonSizes<string> {
  return keys(buttons).reduce((previous, current) => {
    const button = buttons[current];
    const sizes = keys(button);
    previous[current] = {
      ...sizes.reduce((previousSize, currentSize) => {
        previousSize[currentSize] = {
          height: px({ value: button[currentSize].height }),
          padding: getCSSBoxPadding(button[currentSize].padding),
          border: getCSSBorderStyles(button[currentSize].border),
          outline: getCSSButtonOutlineStyles(button[currentSize].outline),
          ...getCSSButtonIconStyle(button[currentSize]),
        };
        return previousSize;
      }, {} as ButtonSizes<string>['desktop']),
    };
    return previous;
  }, {} as ButtonSizes<string>);
}

function getCSSButtonIconStyle(buttonStyle: ButtonIconStyle): ButtonIconStyle<string> {
  return {
    iconSize: buttonStyle.iconSize ? px({ value: buttonStyle.iconSize }) : '',
    iconMargin: getCSSBoxMargin(buttonStyle.iconMargin),
    iconPadding: getCSSBoxPadding({ default: buttonStyle.iconPadding }).default,
    iconOnlyPadding: getCSSBoxPadding({ default: buttonStyle.iconOnlyPadding }).default,
  };
}

export function getCSSButtonOutlineStyles(outline?: ButtonOutline): ButtonOutline<string> {
  if (!outline) {
    return {
      width: '',
      radius: '',
      style: '',
    };
  }

  if (!(outline.width || outline.radius || outline.style)) {
    return {
      width: '',
      radius: '',
      style: '',
    };
  }

  return {
    width: outline.width ? px({ value: outline.width }) : '',
    style: outline.style || 'solid',
    radius: getCSSBoxRadius(outline.radius),
  };
}
