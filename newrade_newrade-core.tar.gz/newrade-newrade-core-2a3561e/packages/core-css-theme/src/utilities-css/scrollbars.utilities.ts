import { Scrollbars, ScrollbarsColors, ScrollbarsSizes } from '@newrade/core-design-system';
import { px } from '@newrade/core-react-ui-utilities-iso';

import { CSSScrollbars } from '../design-system-css/css-scrollbars.js';

import { getCSSColor } from './colors.utilities.js';
import { setVarsValuesToStyleObject } from './component.utilities.js';

export function getCSSScrollbars(scrollbars: Scrollbars): CSSScrollbars {
  //
  // first, create CSSScrollbars from raw styles
  //
  const cssScrollbars: CSSScrollbars = {
    colors: getCSSScrollbarsColors(scrollbars.colors),
    sizes: getCSSScrollbarsSizes(scrollbars.sizes),
  };

  if (!scrollbars.vars) {
    return cssScrollbars;
  }

  //
  // if vars is passed, traverse the CSSScrollbars object and replace the defined values
  //
  return setVarsValuesToStyleObject<CSSScrollbars>(cssScrollbars, scrollbars.vars);
}

function getCSSScrollbarsColors(scrollbars: ScrollbarsColors): ScrollbarsColors<string> {
  return {
    backgroundColor: getCSSColor(scrollbars.backgroundColor),
    thumbBackgroundColor: getCSSColor(scrollbars.thumbBackgroundColor),
    thumbBorderColor: getCSSColor(scrollbars.thumbBorderColor),
  };
}

function getCSSScrollbarsSizes(scrollbars: ScrollbarsSizes): ScrollbarsSizes<string> {
  return {
    barHeight: px({ value: scrollbars.barHeight }),
    barWidth: px({ value: scrollbars.barWidth }),
    thumbWidth: px({ value: scrollbars.thumbWidth }),
    thumbBorderWidth: px({ value: scrollbars.thumbBorderWidth }),
    thumbThumbRadius: px({ value: scrollbars.thumbThumbRadius }),
  };
}
