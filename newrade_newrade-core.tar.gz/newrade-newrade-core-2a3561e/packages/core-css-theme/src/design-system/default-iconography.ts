import { ICON_FAMILY, Iconography, VIEWPORT } from '@newrade/core-design-system';

export const defaultIconography: Iconography = {
  family: ICON_FAMILY.IONICONS_OUTLINE,
  sizes: {
    [VIEWPORT.desktop]: {
      small: 20,
      medium: 24,
      large: 32,
    },
    [VIEWPORT.tablet]: {
      small: 20,
      medium: 24,
      large: 32,
    },
    [VIEWPORT.mobile]: {
      small: 20,
      medium: 24,
      large: 32,
    },
  },
};
