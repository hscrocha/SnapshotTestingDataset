import { DataVizColors } from '@newrade/core-design-system';

import { generateColorPalette11 } from '../utilities-css/colors.utilities.js';

export const defaultDataVizColors: DataVizColors = {
  palette1: generateColorPalette11({
    color: { h: 222, s: 50, l: 50 },
    light: 90,
    dark: 20,
  }),
  palette2: generateColorPalette11({
    color: { h: 222, s: 50, l: 50 },
    light: 90,
    dark: 20,
  }),
  palette3: generateColorPalette11({
    color: { h: 222, s: 50, l: 50 },
    light: 90,
    dark: 20,
  }),
  palette4: generateColorPalette11({
    color: { h: 222, s: 50, l: 50 },
    light: 90,
    dark: 20,
  }),
  palette5: generateColorPalette11({
    color: { h: 222, s: 50, l: 50 },
    light: 90,
    dark: 20,
  }),
  palette6: generateColorPalette11({
    color: { h: 222, s: 50, l: 50 },
    light: 90,
    dark: 20,
  }),
  palette7: generateColorPalette11({
    color: { h: 222, s: 50, l: 50 },
    light: 90,
    dark: 20,
  }),
};
