import { Resets } from '@newrade/core-design-system';

import { defaultColorIntents } from './default-colors.js';

export const defaultResets: Resets = {
  colors: {
    textColor: defaultColorIntents.primaryText,
    backgroundColor: defaultColorIntents.elevation0,
  },
};

/**
 * Resets object without the `vars` property which is used only
 * in application-defined theme configuration
 */
export type DefaultResets = Omit<Resets, 'vars'>;
