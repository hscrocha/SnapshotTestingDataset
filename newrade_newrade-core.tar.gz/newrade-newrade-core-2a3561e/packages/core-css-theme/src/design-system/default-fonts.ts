import { FontMetrics } from '@capsizecss/core';
// @ts-ignore
import arialMetrics from '@capsizecss/metrics/arial.js';

import { Font } from '@newrade/core-design-system';

export const defaultSerifFont: Font = {
  id: 'pt-serif',
  name: 'PT Serif',
  link: 'https://fonts.google.com/specimen/PT+Serif',
  systemFont: false,
  fontMetrics: {
    capHeight: 700,
    ascent: 1039,
    descent: -286,
    lineGap: 0,
    unitsPerEm: 1000,
  },
};

export const defaultSansFont: Font = {
  id: 'inter',
  name: 'Inter',
  link: 'https://fonts.google.com/specimen/Inter',
  systemFont: false,
  fontMetrics: {
    capHeight: 2048,
    ascent: 2728,
    descent: -680,
    lineGap: 0,
    unitsPerEm: 2816,
  },
};

export const defaultSansAlternateFont: Font = defaultSansFont;

export const defaultMonospaceFont: Font = {
  id: 'source-sans-pro',
  name: 'Source Sans Pro',
  link: 'https://fonts.google.com/specimen/Source+Sans+Pro',
  systemFont: false,
  fontMetrics: {
    capHeight: 660,
    ascent: 984,
    descent: -273,
    lineGap: 0,
    unitsPerEm: 1000,
  },
};

export const SFProFontMetric: FontMetrics = {
  capHeight: 1443,
  ascent: 1950,
  descent: -494,
  lineGap: 0,
  unitsPerEm: 2048,
};

export const SFMonoFontMetric: FontMetrics = {
  capHeight: 1443,
  ascent: 1950,
  descent: -494,
  lineGap: 0,
  unitsPerEm: 2048,
};

/**
 * System fonts fallback
 *
 * Note: since font metrics can't be computed dynamically
 * (we don't know what system fonts users will have), we fallback on the SF Pro metrics
 *
 * @see https://seek-oss.github.io/capsize/
 * @see https://developer.apple.com/fonts/
 * @see https://meowni.ca/font-style-matcher/
 */
export const defaultFallbackSansFonts: Font[] = [
  {
    name: 'ui-sans-serif',
    fontMetrics: SFProFontMetric,
    systemFont: true,
  },
  {
    name: 'system-ui',
    fontMetrics: SFProFontMetric,
    systemFont: true,
  },
  {
    name: '-apple-system',
    fontMetrics: SFProFontMetric,
    systemFont: true,
  },
  {
    name: 'BlinkMacSystemFont',
    fontMetrics: SFProFontMetric,
    systemFont: true,
  },
  {
    name: '"Segoe UI"',
    fontMetrics: SFProFontMetric,
    systemFont: true,
  },
  {
    name: 'Roboto',
    fontMetrics: SFProFontMetric,
    systemFont: true,
  },
  {
    name: 'Arial',
    fontMetrics: arialMetrics,
    systemFont: true,
  },
  {
    name: '"Apple Color Emoji"',
    fontMetrics: SFProFontMetric,
    systemFont: true,
  },
  {
    name: '"Segoe UI Emoji"',
    fontMetrics: SFProFontMetric,
    systemFont: true,
  },
  {
    name: '"Segoe UI Symbol"',
    fontMetrics: SFProFontMetric,
    systemFont: true,
  },
  {
    name: '"Noto Color Emoji"',
    fontMetrics: SFProFontMetric,
    systemFont: true,
  },
];

/**
 * System fonts fallback (serif)
 *
 * Note: since font metrics can't be computed dynamically
 * (we don't know what system fonts users will have), we fallback on the SF Pro metrics
 *
 * @see https://seek-oss.github.io/capsize/
 * @see https://developer.apple.com/fonts/
 */
export const defaultFallbackSerifFonts: Font[] = [
  {
    name: 'ui-serif',
    fontMetrics: { capHeight: 1456, ascent: 1900, descent: -500, lineGap: 0, unitsPerEm: 2048 },
    systemFont: true,
  },
  {
    name: 'Georgia',
    fontMetrics: { capHeight: 1456, ascent: 1900, descent: -500, lineGap: 0, unitsPerEm: 2048 },
    systemFont: true,
  },
  {
    name: 'Cambria',
    fontMetrics: { capHeight: 1456, ascent: 1900, descent: -500, lineGap: 0, unitsPerEm: 2048 },
    systemFont: true,
  },
  {
    name: '"Times New Roman"',
    fontMetrics: { capHeight: 1456, ascent: 1900, descent: -500, lineGap: 0, unitsPerEm: 2048 },
    systemFont: true,
  },
  {
    name: 'Times',
    fontMetrics: { capHeight: 1456, ascent: 1900, descent: -500, lineGap: 0, unitsPerEm: 2048 },
    systemFont: true,
  },
  {
    name: 'serif',
    fontMetrics: { capHeight: 1456, ascent: 1900, descent: -500, lineGap: 0, unitsPerEm: 2048 },
    systemFont: true,
  },
];

/**
 * System fonts fallback (mono)
 *
 * Note: since font metrics can't be computed dynamically
 * (we don't know what system fonts users will have), we fallback on the SFMono-Regular metrics
 *
 * @see https://seek-oss.github.io/capsize/
 * @see https://developer.apple.com/fonts/
 */
export const defaultFallbackMonospaceFonts: Font[] = [
  {
    name: 'ui-monospace',
    fontMetrics: SFMonoFontMetric,
    systemFont: true,
  },
  {
    name: 'SFMono-Regular',
    fontMetrics: SFMonoFontMetric,
    systemFont: true,
  },
  {
    name: 'Consolas',
    fontMetrics: SFMonoFontMetric,
    systemFont: true,
  },
  {
    name: '"Courier New"',
    fontMetrics: SFMonoFontMetric,
    systemFont: true,
  },
  {
    name: 'monospace',
    fontMetrics: SFMonoFontMetric,
    systemFont: true,
  },
];
