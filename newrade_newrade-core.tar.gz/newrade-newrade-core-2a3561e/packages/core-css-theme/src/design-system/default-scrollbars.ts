import { Scrollbars } from '@newrade/core-design-system';

import { defaultColorIntents, defaultColorsColors } from './default-colors.js';

export const defaultScrollbars: Scrollbars = {
  sizes: {
    barWidth: 14,
    barHeight: 14,
    thumbWidth: 14,
    thumbBorderWidth: 3,
    thumbThumbRadius: 10,
  },
  colors: {
    thumbBorderColor: defaultColorIntents.elevation0,
    thumbBackgroundColor: defaultColorsColors.grey[300],
    backgroundColor: defaultColorIntents.elevation0,
  },
};

/**
 * Scrollbars object without the `vars` property which is used only
 * in application-defined theme configuration
 */
export type DefaultScrollbars = Omit<Scrollbars, 'vars'>;
