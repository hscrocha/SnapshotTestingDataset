# Core CSS Theme

While `core-design-system` contains the platform-agnostic models representing
the design system, `core-css-theme` adds what is needed to consume the theme
values in CSS code.

This package contains the following exports (sub packages):

| Export                                              | Name                                 | Usage                                                                                                           |
| --------------------------------------------------- | ------------------------------------ | --------------------------------------------------------------------------------------------------------------- |
| `@newrade/core-css-theme/design-system-css`         | **CSS Design System**                | Define CSS version of each design system models.                                                                |
| `@newrade/core-css-theme/design-system`             | **Default DS values**                | Provide default values of every model of the design system.                                                     |
| `@newrade/core-css-theme/css`                       | **Default DS values for CSS**        | Provide CSS default values of every model of the design system.                                                 |
| `@newrade/core-css-theme/runtime`                   | **CSS Runtime Design System Config** | Provide configuration (classnames, defaults, etc) used to apply each theme of the design system in the browser. |
| `@newrade/core-css-theme/utilities`                 | **DS Utilities**                     | Utility functions to transform design system values.                                                            |
| `@newrade/core-css-theme/utilities-css`             | **CSS Utilities**                    | Utility functions to transform pure design system values in to CSS compatible ones.                             |
| `@newrade/core-css-theme/utilities-vanilla-extract` | **Vanilla-Extract Utilities**        | Utility functions related to Vanilla-Extract styles.                                                            |

---
