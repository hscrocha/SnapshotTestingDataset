---
title: Design
subtitle: Color Theory
tags:
  - color
  - design
status: draft
published: false
---

<DocHeader props={props}/>

## Color Spaces

- ASEC: https://en.wikipedia.org/wiki/Academy_Color_Encoding_System
- Apple's DCI-P3: https://en.wikipedia.org/wiki/DCI-P3

## Implementation

https://webkit.org/blog/6682/improving-color-on-the-web/
