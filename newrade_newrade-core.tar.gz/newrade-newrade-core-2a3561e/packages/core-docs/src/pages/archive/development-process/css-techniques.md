---
title: CSS Techniques
subtitle: CSS Tip and Tricks
tags:
  - css
  - design
status: draft
published: false
---

<DocHeader props={props}/>

https://css-tricks.com/svg-favicons-and-all-the-fun-things-we-can-do-with-them/#other-media-queries
