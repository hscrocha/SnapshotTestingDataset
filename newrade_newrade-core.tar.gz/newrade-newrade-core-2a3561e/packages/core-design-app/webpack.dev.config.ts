/// <reference path="../../node_modules/webpack-dev-server/types/lib/Server.d.ts"/>

// remove tsconfig file used for ts-node, so ts-loader does not use it
delete process.env.TS_NODE_PROJECT;

import path, { dirname } from 'path';
import { fileURLToPath } from 'url';

import { Configuration } from 'webpack';
import * as webpackMerge from 'webpack-merge';

import * as core from '@newrade/core-webpack-config';

import { commonConfig, env } from './webpack.common.config.js';

const ___filename = fileURLToPath(import.meta.url);
const ___dirname = dirname(___filename);

const devConfig: Configuration = {
  mode: 'development',
  cache: {
    type: 'memory',
    // type: 'filesystem',
  },
  watchOptions: {
    ...core.devServerConfig.watchOptions,
    ignored: [
      '**/.git/**',
      '**/node_modules/**',
      '**/.cache/**',
      '**/*.d.ts',
      '**/*.js.map',
      'graphql-types.ts',
    ],
  },
  devtool: 'cheap-source-map',
  devServer: {
    host: '0.0.0.0',
    hot: true,
    port: env.APP_PORT,
    static: path.join(___dirname, 'public'),
    proxy: {
      // '/api': 'http://localhost:10003',
    },
    historyApiFallback: {
      index: '/',
    },
    // client: {
    //   overlay: false,
    //   logging: 'warn', // Want to set this to 'warn' or 'error'
    // },
  },
  plugins: [],
  stats: core.stats.dev,
  output: core.output.dev,
};

const config = webpackMerge.merge(commonConfig, devConfig);

export default config;
