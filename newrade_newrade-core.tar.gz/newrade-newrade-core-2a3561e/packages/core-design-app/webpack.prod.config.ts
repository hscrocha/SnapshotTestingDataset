// remove tsconfig file used for ts-node, so ts-loader does not use it
delete process.env.TS_NODE_PROJECT;

import { Configuration } from 'webpack';
import * as webpackMerge from 'webpack-merge';

import * as core from '@newrade/core-webpack-config';

import { commonConfig } from './webpack.common.config.js';

const prodConfig: Configuration = {
  mode: 'production',
  optimization: {
    minimizer: [core.terserPlugin],
  },
  performance: {
    hints: false,
    maxAssetSize: 800000,
    maxEntrypointSize: 800000,
  },
  plugins: [],
  stats: core.stats.prod,
  output: core.output.prod,
};

const config = webpackMerge.merge(commonConfig, prodConfig);

export default config;
