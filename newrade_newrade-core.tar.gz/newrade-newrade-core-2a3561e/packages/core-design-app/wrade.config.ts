import { InferType, string } from 'yup';

import { CommonEnv } from '@newrade/core-node-utils';

/**
 * Local, typed representation of the .env file.
 */
export const Env = CommonEnv.shape({
  /**
   * Wrade CMS
   */
  WRADE_CONTENT_TOKEN: string(),
  WRADE_MANAGEMENT_TOKEN: string(),
});
export type ENV = InferType<typeof Env>;

export type WradeConfig = {
  /**
   * Org id
   * @example 'My Org'
   * @see TODO to find your org id
   */
  orgId: string;
  /**
   * Project id for this package
   * @example 'docs-website'
   * @see TODO to find your project id
   */
  projectId: string;
  /**
   * @default 'src'
   */
  outputDir: string;
  /**
   * Options for the Content API
   * @see TODO: put url
   */
  content: {
    enabled: boolean;
    outputFilesLocally: boolean;
  };
  /**
   * Options for the Design System API
   * @see TODO: put url
   */
  designSystem: {
    enabled: boolean;
    outputFilesLocally: boolean;
    /**
     * When enabled, the CLI will create plain CSS files (in /css-tokens/[theme-id].css.ts) with variables and selectors
     * the design system themes in /css/[theme-id].css.ts
     */
    outputCssTokens: boolean;
  };
  /**
   * Options for the Assets API
   * @see TODO: put url
   */
  assets: {
    /**
     * When enabled, the CLI will output the different assets under /assets/ (e.g. /assets/icons/ionicons-outline/...)
     */
    enabled: boolean;
    outputFilesLocally: boolean;
  };
};

export const wradeConfig: WradeConfig = {
  orgId: 'org123213',
  projectId: '13214',
  outputDir: 'src',
  content: {
    enabled: true,
    outputFilesLocally: true,
  },
  designSystem: {
    enabled: true,
    outputFilesLocally: true,
    outputCssTokens: true,
  },
  assets: {
    enabled: true,
    outputFilesLocally: true,
  },
};
