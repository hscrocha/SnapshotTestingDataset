/* eslint-disable simple-import-sort/imports */

/**
 *
 * Design System global styles
 *
 */

import '@newrade/core-default-design-system/css/resets-default.css';

/**
 *
 * React and components imports
 *
 */

import React, { StrictMode } from 'react';
import { createRoot } from 'react-dom/client';
import { createBrowserRouter, RouteObject, RouterProvider } from 'react-router-dom';

import { AppError, ERROR_TYPE } from '@newrade/core-common';
import { getReactRouterRoutesFromLayouts } from '@newrade/core-react-ui-utilities-react-router';

import { layouts } from './content/layouts.content.js';

/**
 *
 * Website content setup
 *
 */

/**
 *
 * React Router setup
 *
 */

export const routes: RouteObject[] = getReactRouterRoutesFromLayouts(layouts);
export const router = createBrowserRouter(routes);

/**
 *
 * HMR setup
 *
 */

// @ts-ignore
// if (import.meta.webpackHot) {
// @ts-ignore
// import.meta.webpackHot.accept('./content/layouts.content.js', () => {
//   render();
// });
// @ts-ignore
// import.meta.webpackHot.dispose(() => router.dispose());
// @ts-ignore
// import.meta.webpackHot.accept();
// }

/**
 *
 * React setup
 *
 */

render();

function render() {
  const container = document.getElementById('index');
  let root;

  if (!container) {
    throw new AppError({
      name: ERROR_TYPE.APP_ERROR,
      message: 'Could not find react container',
    });
  }
  // const containerIsRoot = Object.keys(container).find((key) => /__reactContainer/.test(key));
  // if (!containerIsRoot) {
  //   root = createRoot(container);
  // }
  root = createRoot(container);
  if (root) {
    root.render(
      <StrictMode>
        <RouterProvider router={router} />
      </StrictMode>
    );
  }
}
