import { globalStyle, style } from '@vanilla-extract/css';

import { colorVars, layoutVars, sizeVars } from '@newrade/core-css-theme/css';

export const layout = style({
  background: colorVars.colorIntents.elevation0,
});

export const outlet = style({
  padding: `${sizeVars.x5} 0`,
  minHeight: `calc(100vh + ${layoutVars.var.navbarHeight})`,
});

globalStyle('html,body', {
  background: colorVars.colorIntents.elevation0,
});
