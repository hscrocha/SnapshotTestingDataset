import { getFormattedAnchorId } from '@newrade/core-react-ui-utilities-iso';

/**
 * Types and utilities to load modules using Webpack's require.context
 *
 * @see https://webpack.js.org/guides/dependency-management/#require-context
 * @see https://webpack.js.org/api/module-methods/#requirecontext
 */

// @ts-ignore
export declare interface WebpackNodeRequire extends NodeJS.Require {
  /**
   * A context module exports a (require) function that takes one argument: the request.
   */
  context: (
    directory: string,
    useSubdirectories: boolean,
    regExp: RegExp,
    mode: 'sync' | 'lazy'
  ) => RequireComponentFunction;
}

type RequireMode = 'sync' | 'lazy';

interface RequireComponentFunction<TMode extends RequireMode = 'sync'> extends Function {
  (id: string): TMode extends 'lazy' ? Promise<{ [prop: string]: any }> : any;
  /**
   * resolve is a function and returns the module id of the parsed request.
   */
  resolve: () => string;
  /**
   * keys is a function that returns an array of all possible requests that the context module can handle.
   */
  keys: () => string[];
  /**
   * id is the module id of the context module. This may be useful for module.hot.accept
   */
  id: string;
}

declare var require: WebpackNodeRequire;

function importComponentsLazy(
  requireFn: RequireComponentFunction
): { moduleId: string; requireFn: RequireComponentFunction<'lazy'>; slug: string }[] {
  return requireFn.keys().map((moduleId) => {
    return {
      moduleId,
      requireFn,
      slug: getFormattedAnchorId(
        moduleId
          .replaceAll(/^\./g, '')
          .replaceAll(/\.tsx$/g, '')
          .replaceAll(/\./g, '-')
      ),
    };
  });
}

/**
 * Lazy load examples from @newrade/core-design-system-docs
 */
export const lazyComponentImports = importComponentsLazy(
  require.context('../../../core-design-system-docs/src/code/', true, /(.*)\.code\.tsx$/i, 'lazy')
);
