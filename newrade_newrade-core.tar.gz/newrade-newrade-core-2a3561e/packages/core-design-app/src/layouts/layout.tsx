import React, { PropsWithChildren } from 'react';
import { Outlet, useLocation } from 'react-router';
import { Link, matchPath } from 'react-router-dom';

import { layoutVars, sizeVars } from '@newrade/core-css-theme/css';
import { useCssDsRuntime } from '@newrade/core-react-ui-design-system-css';
import { ErrorBoundary } from '@newrade/core-react-ui-errors';
import {
  Center,
  MAIN_DOCS_LAYOUT_SLOT,
  MainDocs,
  MainDocsWrapper,
  Stack,
} from '@newrade/core-react-ui-layout-components';
import { MarkdownCSS } from '@newrade/core-react-ui-markdown';
import { NavbarLinkItem, NavbarLogoTextItem } from '@newrade/core-react-ui-navbar-items';
import { NavbarModular } from '@newrade/core-react-ui-navbars';
import { SidebarDocs } from '@newrade/core-react-ui-sidebars-docs';
import { useViewportBreakpoint } from '@newrade/core-react-ui-viewport';
import { LayoutAPI } from '@newrade/core-website-api';

import * as styles from './layout.css.js';

type Props = { layout?: LayoutAPI };

export const Layout: React.FC<PropsWithChildren<Props>> = function Layout({
  children,
  layout,
  ...props
}) {
  /**
   *
   * Theming
   *
   */

  const cssDsRuntimeConfig = useCssDsRuntime();

  function handleChangeTheme(event: React.ChangeEvent<HTMLSelectElement>) {
    const value = event.target.value;
    if (!value) {
      return;
    }
    // if (currentCSSTheme.onChangeTheme) {
    //   currentCSSTheme.onChangeTheme(value);
    // }
  }

  /**
   *
   * Router
   *
   */

  const routerLocation = useLocation();

  /**
   *
   * Layout
   *
   */

  const { viewport } = useViewportBreakpoint();
  const contentWidth = [
    layoutVars.contentMargins[viewport],
    layoutVars.sidebarWidth[viewport],
    layoutVars.contentWidth.desktopDocsMaxWidth,
    layoutVars.asideWidth,
    layoutVars.contentMargins[viewport],
  ];
  const contentMaxWidth = `calc(${contentWidth.join(' + ')})`;

  /**
   *
   * Navbar
   *
   */

  const NavbarLeftItems = <NavbarLogoTextItem text={'Design App'} collapsePadding={'left'} />;

  const pathMath = !!matchPath(
    '/design-system-theme-configuration',
    routerLocation?.pathname || ''
  );

  const NavbarRightItems = (
    <>
      <NavbarLinkItem href={'/design-system-theme-configuration'} active={pathMath}>
        Theming
      </NavbarLinkItem>
    </>
  );

  /**
   *
   * Sidebar
   *
   */

  /**
   * Rendering
   */

  return (
    <MainDocsWrapper className={styles.layout}>
      {/**
       *
       * Navbars
       *
       */}

      <NavbarModular
        maxWidth={contentMaxWidth}
        navbarMode={'normal'}
        leftDesktop={NavbarLeftItems}
        left={NavbarLeftItems}
        rightDesktop={NavbarRightItems}
        right={NavbarRightItems}
      ></NavbarModular>

      <MainDocs
        contentPadding={false}
        navbarPadding={false}
        minHeight={true}
        maxWidth={contentMaxWidth}
      >
        {/**
         *
         * Sidebar (desktop)
         *
         */}

        <SidebarDocs
          style={{ gridArea: MAIN_DOCS_LAYOUT_SLOT.SIDEBAR }}
          activePathname={routerLocation?.pathname}
          sidebar={layout?.sidebar}
          LinkComponent={Link}
        ></SidebarDocs>

        {/**
         *
         * Content
         *
         */}

        <Center>
          <Stack gap={[sizeVars.x5]} style={{ paddingBottom: sizeVars.x6 }}>
            <div className={styles.outlet}>
              <ErrorBoundary>
                <MarkdownCSS>
                  {/* react-router outlet */}
                  <Outlet />
                  {/* normal children, if passed to the layout component */}
                  {children}
                </MarkdownCSS>
              </ErrorBoundary>
            </div>
          </Stack>
        </Center>
      </MainDocs>

      {/**
       *
       * Footer
       *
       */}
      <footer>hey</footer>
    </MainDocsWrapper>
  );
};
