import { getFormattedAnchorId } from '@newrade/core-react-ui-utilities-iso';
import { FrontmatterAPI } from '@newrade/core-website-api';

/**
 * Types and utilities to load modules using Webpack's require.context
 *
 * @see https://webpack.js.org/guides/dependency-management/#require-context
 * @see https://webpack.js.org/api/module-methods/#requirecontext
 */

// @ts-ignore
interface NodeRequire extends NodeJS.Require {
  /**
   * A context module exports a (require) function that takes one argument: the request.
   */
  context: (
    directory: string,
    useSubdirectories: boolean,
    regExp: RegExp,
    mode: 'sync' | 'lazy'
  ) => RequireMdxFunction;
}

type RequireMode = 'sync' | 'lazy';

interface RequireMdxFunction<TMode extends RequireMode = 'sync'> extends Function {
  (id: string): TMode extends 'lazy' ? Promise<{ default: any; frontmatter: FrontmatterAPI }> : any;
  /**
   * resolve is a function and returns the module id of the parsed request.
   */
  resolve: () => string;
  /**
   * keys is a function that returns an array of all possible requests that the context module can handle.
   */
  keys: () => string[];
  /**
   * id is the module id of the context module. This may be useful for module.hot.accept
   */
  id: string;
}

declare var require: NodeRequire;

function importMdxPagesLazy(
  requireFn: RequireMdxFunction
): { moduleId: string; requireFn: RequireMdxFunction<'lazy'>; slug: string }[] {
  return requireFn.keys().map((moduleId) => {
    return {
      moduleId,
      requireFn,
      slug: getFormattedAnchorId(
        moduleId
          .replaceAll(/(\/(en|fr))/g, '-$1')
          .replaceAll(/\.mdx?$/g, '')
          .replaceAll(/\./g, '-')
          .replace(/^-+/g, '')
      ),
    };
  });
}

/**
 * Lazy load pages from @newrade/core-design-system-docs
 */
export const lazyMdxDsPageImports = importMdxPagesLazy(
  require.context('../../../core-design-system-docs/docs/', true, /(.*)\.mdx?$/i, 'lazy')
);
