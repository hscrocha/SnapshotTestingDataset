import React, { PropsWithChildren } from 'react';
import { Outlet, useLocation, useRouteError } from 'react-router';
import { Link, matchPath } from 'react-router-dom';

import { layoutVars, sizeVars } from '@newrade/core-css-theme/css';
import { title } from '@newrade/core-iso-utils';
import { ErrorBoundary } from '@newrade/core-react-ui-errors';
import {
  Center,
  MAIN_DOCS_LAYOUT_SLOT,
  MainDocs,
  MainDocsWrapper,
  Stack,
} from '@newrade/core-react-ui-layout-components';
import { NavbarLinkItem, NavbarLogoTextItem } from '@newrade/core-react-ui-navbar-items';
import { NavbarModular } from '@newrade/core-react-ui-navbars';
import { SidebarDocs } from '@newrade/core-react-ui-sidebars-docs';
import { useViewportBreakpoint } from '@newrade/core-react-ui-viewport';
import { LinkAPI, SidebarAPI } from '@newrade/core-website-api';

import { lazyComponentImports } from './context-require-component.js';
import { lazyMdxDsPageImports } from './context-require-mdx.js';
import * as styles from './layout.css.js';

type Props = {};

export const ErrorLayout: React.FC<PropsWithChildren<Props>> = function ErrorLayout({
  children,
  ...props
}) {
  /**
   *
   * Router
   *
   */
  const error = useRouteError() as Error;
  const routerLocation = useLocation();

  /**
   *
   * Layout
   *
   */

  const { viewport } = useViewportBreakpoint();

  const contentWidth = [
    layoutVars.sidebarWidth[viewport],
    layoutVars.contentWidth.desktopDocsMaxWidth,
    layoutVars.asideWidth,
    layoutVars.contentMargins[viewport],
    layoutVars.contentMargins[viewport],
  ];
  const contentMaxWidth = `calc(${contentWidth.join(' + ')})`;

  /**
   *
   * Navbar
   *
   */

  const NavbarLeftItems = <NavbarLogoTextItem text={'Design App'} collapsePadding={'left'} />;

  const pathMath = !!matchPath(
    '/design-system-theme-configuration',
    routerLocation?.pathname || ''
  );

  const NavbarRightItems = (
    <>
      <NavbarLinkItem href={'/design-system-theme-configuration'} active={pathMath}>
        Theming
      </NavbarLinkItem>
    </>
  );

  /**
   *
   * Sidebar
   *
   */

  const sidebar: SidebarAPI = {
    name: 'Docs Sidebar',
    layout: 'docs',
    navigation: {
      subNavigation: [
        {
          label: 'Design',
          links: [
            {
              name: 'Theming Configuration',
              label: 'Theming Configuration',
              // label: title(lazyImport.slug.replace(/\.(fr|en)/, ' ')),
              page: {
                name: 'Theming Configuration',
                path: `design-system-theme-configuration`,
              },
            } as LinkAPI,
          ],
        },
        {
          label: 'Pages',
          links: lazyMdxDsPageImports.map((lazyImport, lazyImportIndex) => {
            return {
              name: lazyImport.moduleId,
              label: title(lazyImport.slug),
              page: {
                name: lazyImport.moduleId,
                path: `pages/${lazyImport.slug}`,
              },
            } as LinkAPI;
          }),
        },
        {
          label: 'Components',
          links: lazyComponentImports.map((lazyImport, lazyImportIndex) => {
            return {
              name: lazyImport.moduleId,
              label: title(lazyImport.slug.replace(/-?code$/gi, '')),
              page: {
                name: lazyImport.moduleId,
                path: `components/${lazyImport.slug}`,
              },
            } as LinkAPI;
          }),
        },
      ],
    },
  };

  /**
   * Rendering
   */

  return (
    <MainDocsWrapper className={styles.layout}>
      {/**
       *
       * Navbars
       *
       */}

      <NavbarModular
        maxWidth={contentMaxWidth}
        navbarMode={'normal'}
        leftDesktop={NavbarLeftItems}
        left={NavbarLeftItems}
        rightDesktop={NavbarRightItems}
        right={NavbarRightItems}
      ></NavbarModular>

      <MainDocs
        contentPadding={false}
        navbarPadding={false}
        minHeight={true}
        maxWidth={contentMaxWidth}
      >
        {/**
         *
         * Sidebar (desktop)
         *
         */}

        <SidebarDocs
          style={{ gridArea: MAIN_DOCS_LAYOUT_SLOT.SIDEBAR }}
          sidebar={sidebar}
          LinkComponent={Link}
        ></SidebarDocs>

        <Center>
          <Stack gap={[sizeVars.x5]} style={{ paddingBottom: sizeVars.x6 }}>
            <div className={styles.outlet}>
              <ErrorBoundary>
                <Outlet />
                {children}
              </ErrorBoundary>
            </div>
          </Stack>
        </Center>
      </MainDocs>
      {/* <footer>hey</footer> */}
    </MainDocsWrapper>
  );
};
