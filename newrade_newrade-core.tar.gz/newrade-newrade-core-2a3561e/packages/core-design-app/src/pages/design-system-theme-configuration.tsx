import React from 'react';

import { setElementVars } from '@vanilla-extract/dynamic';

import { colorVars, sizeVars } from '@newrade/core-css-theme/css';
import { CSSDesignSystemSliceConfig } from '@newrade/core-css-theme/ds';
import { ButtonSize, HEADING } from '@newrade/core-design-system';
import { ColorPrimary } from '@newrade/core-design-system-docs/code/color-primary.code';
import { Button } from '@newrade/core-react-ui-buttons';
import { useCssDsRuntime } from '@newrade/core-react-ui-design-system-css';
import { ErrorBoundary } from '@newrade/core-react-ui-errors';
import { InputSelect, InputWrapper } from '@newrade/core-react-ui-forms';
import { Cluster } from '@newrade/core-react-ui-layout-components';
import { DocHeader, MarkdownCSS } from '@newrade/core-react-ui-markdown';
import { useRouterContext } from '@newrade/core-react-ui-router';
import { Heading, Hr, Paragraph } from '@newrade/core-react-ui-text';

/**
 * @typedef {Object} ThemeConfigurationPageProps
 */
type Props = {};

type ComponentWithReactDocGen = React.FC<Props> & {
  __docgenInfo?: object;
};

/**
 * CSS Design System Configuration page where user can choose each sub-theme.
 */
export const DesignSystemThemeConfigPage: ComponentWithReactDocGen = (props) => {
  const ds = useCssDsRuntime();
  const routerContext = useRouterContext();

  // useEffect(() => {
  //   const loadColorThemeById = async (colorThemeId: string) => {
  //     try {
  //       await import(
  //         /* webpackChunkName: "[request]" */ `webpack-design-system-plugin/generated/${colorThemeId}/colors.css`
  //       );
  //     } catch (error) {
  //       console.warn(
  //         `The \`ThemeProvider\` failed to properly fetch the global CSS file for \`${colorThemeId}\`. Falling back to the default theme.`
  //       );
  //       // await import(/* webpackChunkName: "default-theme-css" */ `themes/default/theme.css`);
  //     }
  //   };

  //   if (ds?.selected?.colors) {
  //     loadColorThemeById(ds?.selected?.colors);
  //   }
  // }, [ds?.selected?.colors]);

  if (!routerContext) {
    return (
      <div>
        <MarkdownCSS>
          <DocHeader
            props={{
              frontmatter: {
                title: 'CSS Design System Theme Configuration',
                subtitle: 'Configuration page for each sub-theme of the design system CSS theme.',
              },
            }}
          />

          <ErrorBoundary error={new Error('Could not find routerContext')}></ErrorBoundary>
        </MarkdownCSS>
      </div>
    );
  }

  if (!ds?.config) {
    return (
      <div>
        <MarkdownCSS>
          <DocHeader
            props={{
              frontmatter: {
                title: 'CSS Design System Theme Configuration',
                subtitle: 'Configuration page for each sub-theme of the design system CSS theme.',
              },
            }}
          />

          <ErrorBoundary error={new Error('Could not find CssDsRuntimeContext')}></ErrorBoundary>
        </MarkdownCSS>
      </div>
    );
  }

  const config = ds.config;
  const selectedThemes = ds.selected;

  const colors = ds.config?.['colors'];
  const selectedColorTheme = ds.config?.['colors'].themes.find(
    (theme) => theme.id === selectedThemes?.colors
  );

  function handleChangeTheme(
    slice: CSSDesignSystemSliceConfig
  ): (event: React.ChangeEvent<HTMLSelectElement>) => any {
    return (event) => {
      const themeId = event.target.value;
      console.log(themeId);
      console.log(slice.name);

      setElementVars(window.document.documentElement, {
        [colorVars.colorIntents.primaryText]: 'red',
      });
    };
  }

  const Link = routerContext.components.LinkComponent;

  return (
    <div>
      <MarkdownCSS>
        <DocHeader
          props={{
            frontmatter: {
              title: 'CSS Design System Theme Configuration',
              subtitle: 'Configuration page for each slice (sub-theme) of the design system.',
            },
          }}
        />

        <Heading variant={HEADING.h2}>Introduction</Heading>

        <Link to="/">Link Test</Link>

        <Paragraph>
          Our design system is organized in multiple parts that are indepedent of each other. For
          instance, you may choose a dark theme, a dense typographic setting.
        </Paragraph>

        <Heading variant={HEADING.h2}>Colors</Heading>

        <Paragraph>
          Choose the desired color theme. Nearly every component uses the variables defined in this
          sub-theme. While other sub-themes are choosen manually, the color theme might change
          according to the user's device preferred color scheme.
        </Paragraph>

        <Cluster justifyContent={['flex-start']} alignItems={['flex-start']} gap={[sizeVars.x1]}>
          <InputWrapper style={{ minWidth: 200 }}>
            <InputSelect
              id={'colors'}
              value={selectedColorTheme?.id}
              onChange={handleChangeTheme(colors)}
            >
              {colors?.themes.map((theme) => (
                <option key={theme.id} value={theme.id}>
                  {theme.name} - ({theme.colorScheme})
                </option>
              ))}
            </InputSelect>
          </InputWrapper>
          <Button size={ButtonSize.small}>Reset to default</Button>
        </Cluster>

        <ColorPrimary />

        <Cluster justifyContent={['flex-start']} alignItems={['flex-start']} gap={[sizeVars.x1]}>
          <svg viewBox={'0 0 20 20'} height={20} width={20}>
            <circle r={10} cx={10} cy={10} fill={colorVars.colors.primary[100]}></circle>
          </svg>
          <svg viewBox={'0 0 20 20'} height={20} width={20}>
            <circle r={10} cx={10} cy={10} fill={colorVars.colors.primary[500]}></circle>
          </svg>
          <svg viewBox={'0 0 20 20'} height={20} width={20}>
            <circle r={10} cx={10} cy={10} fill={colorVars.colors.primary[900]}></circle>
          </svg>
        </Cluster>

        <Hr />

        <Heading variant={HEADING.h2}>Typography</Heading>

        <Paragraph>
          Choose the desired color theme. Nearly every component uses the variables defined in this
          sub-theme. While other sub-themes are choosen manually, the color theme might change
          according to the user's device preferred color scheme.
        </Paragraph>

        <Hr />

        {/* <Heading variant={HEADING.h2}>Typography</Heading>
        Available themes: {ds.config?.['typography'].name}
        <Heading variant={HEADING.h2}>Sizing</Heading>
        Available themes: {ds.config?.['sizing'].name}
        <Heading variant={HEADING.h2}>Iconography</Heading>
        Available themes: {ds.config?.['iconography'].name}
        <Heading variant={HEADING.h2}>Effects</Heading>
        Available themes: {ds.config?.['effects'].name}
        <Heading variant={HEADING.h2}>Layout</Heading>
        Available themes: {ds.config?.['layout'].name}
        <Heading variant={HEADING.h2}>Components</Heading>
        Available themes: {ds.config?.['components']['buttons'].name}
        <Heading variant={HEADING.h2}>Others</Heading>
        Available themes: {ds.config?.['others']['reset'].name} */}
      </MarkdownCSS>
    </div>
  );
};

DesignSystemThemeConfigPage.displayName = DesignSystemThemeConfigPage.name;
DesignSystemThemeConfigPage.defaultProps = {};
