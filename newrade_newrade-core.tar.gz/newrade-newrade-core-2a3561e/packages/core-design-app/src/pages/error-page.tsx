import React from 'react';
import { useRouteError } from 'react-router';

import { ErrorBoundary } from '@newrade/core-react-ui-errors';
import { ListItems, ListItemV2 } from '@newrade/core-react-ui-list-items';
import { DocHeader, MarkdownCSS } from '@newrade/core-react-ui-markdown';
import { Hr, Link, Paragraph } from '@newrade/core-react-ui-text';

type Props = {};

export const ErrorPage: React.FC<Props> = (props) => {
  const routerError = useRouteError() as { data: any; status: number; statusText: string };
  const errorMessage = [
    routerError.status,
    routerError.statusText,
    routerError.data ? JSON.stringify(routerError.data, null, 2) : undefined,
  ].join(' ');
  return (
    <div>
      <MarkdownCSS>
        <DocHeader
          props={{
            frontmatter: {
              title: 'Oops! This page could not be rendered.',
              subtitle: 'We have been notified of this error and will investigate.',
            },
          }}
        />

        <Paragraph>Here are some helpful links :</Paragraph>

        <ListItems>
          <ListItemV2>
            <Link>Docs home page</Link>
          </ListItemV2>
          <ListItemV2>
            <Link>Theme configuration page</Link>
          </ListItemV2>
          <ListItemV2>
            <Link>Foundations overview</Link>
          </ListItemV2>
          <ListItemV2>
            <Link>Components overview</Link>
          </ListItemV2>
        </ListItems>

        <Hr />

        <ErrorBoundary
          title={''}
          error={new Error(errorMessage)}
          hasError={true}
          showErrorStack={false}
        ></ErrorBoundary>
      </MarkdownCSS>
    </div>
  );
};

ErrorPage.displayName = ErrorPage.name;
ErrorPage.defaultProps = {};
