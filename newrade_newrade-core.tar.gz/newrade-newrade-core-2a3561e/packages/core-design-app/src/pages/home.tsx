import React from 'react';

import { DocHeader } from '@newrade/core-react-ui-markdown';

type Props = {};

export const HomePage: React.FC<Props> = (props) => {
  return (
    <div>
      <DocHeader
        props={{
          frontmatter: {
            title: 'Home',
          },
        }}
      />
    </div>
  );
};

HomePage.displayName = HomePage.name;
HomePage.defaultProps = {};
