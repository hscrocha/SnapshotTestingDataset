import React, { lazy, Suspense } from 'react';
import { RouteObject } from 'react-router';

import { ErrorBoundary } from '@newrade/core-react-ui-errors';
import { docsMdxComponents, MarkdownCSS } from '@newrade/core-react-ui-markdown';
import {
  LayoutAPI,
  LayoutComponent,
  LinkAPI,
  NavComponent,
  PageEntryAPI,
  SidebarAPI,
  WEBSITE_LOCALE,
} from '@newrade/core-website-api';

import { clientEnv } from '../../types/dot-env-client.js';
import { lazyMdxDsPageImports } from '../layouts/context-require-mdx.js';
import { Layout } from '../layouts/layout.js';
import { DesignSystemThemeConfigPage } from '../pages/design-system-theme-configuration.js';
import { ErrorPage } from '../pages/error-page.js';
import { HomePage } from '../pages/home.js';
import TeamPage from '../pages/team.mdx';
import { Providers } from '../providers/providers.js';

import { companyInfos } from './company-infos.content.js';
import { Locales } from './translation.content.js';

export type LayoutData = { route: RouteObject };
export type PageEntryData = { route: RouteObject };

export const designSystemPages = lazyMdxDsPageImports.map((pageModule) => {
  const LoadedMdxPage = lazy(() => pageModule.requireFn(pageModule.moduleId));
  const pageEntry: PageEntryAPI<PageEntryData> = {
    path: `${pageModule.slug}`,
    data: {
      route: {
        element: (
          <Suspense fallback={<div>...</div>}>
            <ErrorBoundary>
              <MarkdownCSS>
                <LoadedMdxPage components={docsMdxComponents} />
              </MarkdownCSS>
            </ErrorBoundary>
          </Suspense>
        ),
        errorElement: <ErrorPage />,
      },
    },
  };
  return pageEntry;
});

export const designSystemSidebar: SidebarAPI = {
  name: 'Design system sidebar',
  layout: 'docs',
  navigation: {
    component: NavComponent.sidebar,
    links: lazyMdxDsPageImports.map((pageModule) => {
      const link: LinkAPI = {
        label: pageModule.slug,
        page: {
          path: `design-system/${pageModule.slug}`,
        },
      };
      return link;
    }),
  },
  companyInfo: companyInfos,
  version: clientEnv.APP_VERSION,
};

export function RootLayout() {
  return (
    <Providers>
      <Layout layout={{ sidebar: designSystemSidebar }} />
    </Providers>
  );
}

export function ErrorLayout() {
  return (
    <Providers>
      <Layout>
        <ErrorPage />
      </Layout>
    </Providers>
  );
}

export const layouts: LayoutAPI<Locales, LayoutData, PageEntryAPI<PageEntryData>>[] = [
  {
    name: 'Root layout',
    type: 'root',
    component: LayoutComponent.root,
    path: '/',
    routing: {
      localePaths: {
        [WEBSITE_LOCALE.EN]: '',
        [WEBSITE_LOCALE.FR]: 'fr',
      },
    },
    data: {
      route: {
        path: '/',
        element: <RootLayout />,
        errorElement: <ErrorLayout />,
      },
    },
    entries: [
      {
        path: '/',
        data: {
          route: {
            element: <HomePage />,
          },
        },
      },
      {
        path: '/team',
        data: {
          route: {
            element: <TeamPage components={docsMdxComponents} />,
          },
        },
      },
    ],
    children: [
      {
        name: 'Pages layout',
        path: 'pages',
        entries: [],
        data: {
          route: {},
        },
      },
      {
        name: 'Docs layout',
        path: 'docs',
        entries: [],
        data: {
          route: {},
        },
      },
      {
        name: 'Design System',
        component: LayoutComponent.docs,
        path: 'design-system',
        entries: [
          {
            name: 'Design system configuration page',
            path: 'configuration',
            data: {
              route: {
                element: <DesignSystemThemeConfigPage />,
              },
            },
          },
          ...designSystemPages,
        ],
        data: {
          route: {},
        },
      },
    ],
  },
];
