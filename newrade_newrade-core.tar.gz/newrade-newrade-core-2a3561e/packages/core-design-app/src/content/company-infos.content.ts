import { CompanyInfoAPI } from '@newrade/core-website-api';

export const companyInfos: CompanyInfoAPI = {
  companyName: 'Newrade',
};
