import { WebsiteAPI } from '@newrade/core-website-api';

import { companyInfos } from './company-infos.content.js';
import { layouts } from './layouts.content.js';
import { languages } from './translation.content.js';

export const website: WebsiteAPI = {
  name: 'Design App',
  companyInfo: companyInfos,
  language: languages,
  layouts: layouts,
};
