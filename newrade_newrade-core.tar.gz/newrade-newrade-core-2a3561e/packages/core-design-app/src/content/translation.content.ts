import { LanguageAPI, WEBSITE_LOCALE } from '@newrade/core-website-api';

import { translation } from '../i18n/locales.js';

export type Locales = WEBSITE_LOCALE.EN | WEBSITE_LOCALE.FR;

export const languages: LanguageAPI<WEBSITE_LOCALE.EN | WEBSITE_LOCALE.FR> = {
  defaultLocale: WEBSITE_LOCALE.EN,
  locales: [WEBSITE_LOCALE.EN, WEBSITE_LOCALE.FR],
  translation: translation,
};
