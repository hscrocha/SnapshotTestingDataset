import React from 'react';

import { ReactRouterProvider as RouterProvider } from '@newrade/core-react-ui-react-router';

import { DesignSystemProviders } from './design-system.providers.js';

/**
 *
 * Place other React providers in this file.
 *
 */

export const Providers: React.FC<React.PropsWithChildren<{}>> = (props) => {
  return (
    <DesignSystemProviders>
      <RouterProvider>
        {/* <SectionsProvider> */}
        {/* <BlocksProvider> */}
        {props.children}
        {/* </BlocksProvider> */}
        {/* </SectionsProvider> */}
      </RouterProvider>
    </DesignSystemProviders>
  );
};
