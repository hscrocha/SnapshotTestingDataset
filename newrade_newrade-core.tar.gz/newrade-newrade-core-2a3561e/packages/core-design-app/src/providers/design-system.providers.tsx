/* eslint-disable simple-import-sort/imports */

/**
 *
 * Design System Providers
 *
 * Import required providers, styles, variables and assets from the design system
 *
 * Required imports:
 * - imports of each sub-theme .css.ts file
 * - imports of font assets
 *
 * Required React providers:
 * - ViewportProvider
 * - CssDsRuntimeProvider
 * - LogosProvider
 * - IconProvider
 *
 * **Note**: import order is important, please use eslint-disable simple-import-sort/imports for this file
 *
 */

/**
 *
 * Import .css.ts style files below
 *
 */

import '@newrade/core-default-design-system/css/transitions.css';

/**
 *
 * Import React and providers below
 *
 */

import React from 'react';

import { loadThemes } from '@newrade/core-css-theme/runtime';
import { logosComponents } from '@newrade/core-default-design-system';
import { ICON, LOGO } from '@newrade/core-design-system';
import { cssDesignSystemConfig } from '../css/design-system-css.config.js';
import { ioniconsOutlineKit } from '@newrade/core-react-ui-icon-kit-ionicons';
import { IconProvider } from '@newrade/core-react-ui-icons';
import { LogosProvider } from '@newrade/core-react-ui-logos';
import { viewportContext, ViewportProvider } from '@newrade/core-react-ui-viewport';

import { CSSDesignSystemProvider } from '@newrade/core-react-ui-design-system-css';

/**
 *
 * Import assets (fonts, icons, ...)
 *
 */

import '@newrade/core-default-design-system/assets/fonts/inter/index.css';

loadThemes({
  config: cssDesignSystemConfig,
  options: {
    importLocalThemesFn: (themeId: string) =>
      import(
        /* webpackMode: "eager" */
        /* webpackPreload: true */
        `../css/${themeId}.css.ts`
      ),
  },
});

/**
 *
 * Configure providers
 *
 */

export const DesignSystemProviders: React.FC<React.PropsWithChildren<{}>> = (props) => {
  return (
    <ViewportProvider context={viewportContext}>
      <CSSDesignSystemProvider
        value={{
          config: cssDesignSystemConfig,
        }}
        options={{ applyClassnamesToRootElement: true, syncToLocalStorage: true }}
      >
        {/* <Suspense>
          {cssDesignSystemConfig.colors.preferredThemeId === 'colors-default-dark' ? (
            <LoadColorsDarkTheme></LoadColorsDarkTheme>
          ) : null}
        </Suspense> */}
        <LogosProvider<LOGO> logoComponents={logosComponents}>
          <IconProvider<ICON>
            iconsConfig={ioniconsOutlineKit.config}
            iconComponents={ioniconsOutlineKit.components}
          >
            {props.children}
          </IconProvider>
        </LogosProvider>
      </CSSDesignSystemProvider>
    </ViewportProvider>
  );
};
