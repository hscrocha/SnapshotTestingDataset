import { designSystemConfig as defaultDesignSystemConfig } from '@newrade/core-default-design-system';
import { DesignSystemConfig } from '@newrade/core-design-system';

export const designSystemConfig: DesignSystemConfig = {
  ...defaultDesignSystemConfig,
};
