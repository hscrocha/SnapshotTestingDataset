import { LocaleAPI } from '@newrade/core-website-api';

import { LocaleKeys } from './locales.js';

export const frTranslation: LocaleAPI<LocaleKeys> = {
  Welcome: 'Bienvenue',
  welcome: 'Bienvenue',
};
