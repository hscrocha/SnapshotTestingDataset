import { defaultEnLocales } from '@newrade/core-website-api';

export const enTranslation = {
  ...defaultEnLocales,
  Welcome: 'Welcome',
};
