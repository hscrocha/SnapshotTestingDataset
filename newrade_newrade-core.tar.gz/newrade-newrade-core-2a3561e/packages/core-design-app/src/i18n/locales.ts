import { TranslationAPI, WEBSITE_LOCALE } from '@newrade/core-website-api';

import { enTranslation } from './en.locale.js';
import { frTranslation } from './fr.locale.js';

export type LocaleKeys = keyof typeof enTranslation;

export const translation: TranslationAPI<WEBSITE_LOCALE.EN | WEBSITE_LOCALE.FR, LocaleKeys> = {
  [WEBSITE_LOCALE.EN]: {
    translation: enTranslation,
  },
  [WEBSITE_LOCALE.FR]: {
    translation: frTranslation,
  },
};
