import { CSSDesignSystemConfig } from '@newrade/core-css-theme/ds';
import { cssDesignSystemConfig as defaultCssDesignSystemConfig } from '@newrade/core-default-design-system/css';

/**
 *
 * Default css design system configuration object
 *
 */
export const cssDesignSystemConfig: CSSDesignSystemConfig = {
  ...defaultCssDesignSystemConfig,
  id: 'core-design-app',
  runtime: {
    prefix: 'global',
  },
  layout: {
    name: 'Layout',
    themes: [
      {
        id: 'layout-design-app',
        name: 'Design App Layout',
        default: true,
      },
      {
        ...defaultCssDesignSystemConfig.layout.themes[0],
        default: false,
      },
    ],
  },
};
