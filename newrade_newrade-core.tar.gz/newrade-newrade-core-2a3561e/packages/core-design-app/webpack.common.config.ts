import fs from 'fs';
import path, { dirname } from 'path';
import { fileURLToPath } from 'url';

import webpack, { Configuration } from 'webpack';
import * as webpackMerge from 'webpack-merge';

import { loadDotEnv } from '@newrade/core-node-utils';
import * as core from '@newrade/core-webpack-config';
import { getReactCommonConfigV2 } from '@newrade/core-webpack-config';

import { ENV, Env } from './types/dot-env.js';
import type { CLIENT_ENV } from './types/dot-env-client.js';

const packageJsonFile = fs.readFileSync('./package.json');
const packageJson = JSON.parse(packageJsonFile.toString()) as typeof import('./package.json');

const ___filename = fileURLToPath(import.meta.url);
const ___dirname = dirname(___filename);

export const env = loadDotEnv<ENV>({
  schema: Env,
  dotEnvPath: path.resolve(___dirname, '.env'),
  printEnvVariables: true,
  packageName: 'core-figma-app',
});

const clientEnv: CLIENT_ENV = {
  APP_ENV: JSON.stringify(env.APP_ENV),
  APP_VERSION: JSON.stringify(packageJson.version),
};

const localCommonConfig: Configuration = {
  entry: {
    index: path.resolve(___dirname, 'src/index.tsx'),
  },
  cache: false,
  output: {
    publicPath: '/',
    path: path.join(___dirname, 'public'),
  },
  plugins: [
    /**
     * Templates
     */
    core.getHtmlPlugin({
      template: path.resolve(___dirname, 'src/index.ejs'),
    }),
    core.getManifestJsonHtmlPlugin({
      template: path.resolve(___dirname, 'src/manifest.json.ejs'),
    }),
    core.getBrowserconfigHtmlPlugin({
      template: path.resolve(___dirname, 'src/browserconfig.xml.ejs'),
    }),
    /**
     * CSS
     */
    core.getVanillaExtractPlugin(),
    /**
     * Env variables
     */
    new webpack.DefinePlugin(clientEnv),
  ],
};

export const commonConfig: Configuration = webpackMerge.merge(
  getReactCommonConfigV2({ isDevelopment: core.isDevelopment() }),
  localCommonConfig
);
