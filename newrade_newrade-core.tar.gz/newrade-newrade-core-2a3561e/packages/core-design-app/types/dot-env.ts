import { InferType } from 'yup';

import { CommonEnv } from '@newrade/core-node-utils';

/**
 * Local, typed representation of the .env file.
 */
export const Env = CommonEnv;
export type ENV = InferType<typeof Env>;
