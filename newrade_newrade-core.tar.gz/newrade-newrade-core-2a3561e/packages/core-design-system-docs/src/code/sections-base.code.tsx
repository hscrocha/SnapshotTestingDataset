import React from 'react';

import { sizeVars } from '@newrade/core-css-theme/css';
import { Variant } from '@newrade/core-design-system';
import { BlockMarkdown } from '@newrade/core-react-ui-blocks';
import { PlaceholderMarkdown } from '@newrade/core-react-ui-doc-components';
import { Stack } from '@newrade/core-react-ui-layout-components';
import { SectionBase } from '@newrade/core-react-ui-sections';

type Props = {};

export const SectionsBase: React.FC<Props> = (props) => {
  return (
    <Stack gap={[sizeVars.x1]}>
      <SectionBase section={{ variant: Variant.primary }}>
        <BlockMarkdown>
          <PlaceholderMarkdown />
          <PlaceholderMarkdown />
        </BlockMarkdown>
      </SectionBase>

      <SectionBase section={{ variant: Variant.secondary }}>
        <BlockMarkdown>
          <PlaceholderMarkdown />
          <PlaceholderMarkdown />
        </BlockMarkdown>
      </SectionBase>

      <SectionBase section={{ variant: Variant.tertiary }}>
        <BlockMarkdown>
          <PlaceholderMarkdown />
          <PlaceholderMarkdown />
        </BlockMarkdown>
      </SectionBase>
    </Stack>
  );
};
