import React, { useState } from 'react';

import { sizeVars } from '@newrade/core-css-theme/css';
import { Cluster, Stack } from '@newrade/core-react-ui-layout-components';
import { NavbarLinkItem } from '@newrade/core-react-ui-navbar-items';

type Props = {};

export const NavbarButtonItems: React.FC<Props> = (props) => {
  const [activeLink, setActiveLink] = useState(0);
  function handleClick(id: number) {
    return () => {
      setActiveLink(id);
    };
  }

  return (
    <Stack gap={[sizeVars.x3]}>
      <Cluster justifyContent={['flex-start']}>
        <NavbarLinkItem active={activeLink === 0} onClick={handleClick(0)}></NavbarLinkItem>
        <NavbarLinkItem active={activeLink === 1} onClick={handleClick(1)}></NavbarLinkItem>
        <NavbarLinkItem active={activeLink === 2} onClick={handleClick(2)}></NavbarLinkItem>
        <NavbarLinkItem active={false} disabled={true}></NavbarLinkItem>
      </Cluster>
    </Stack>
  );
};
