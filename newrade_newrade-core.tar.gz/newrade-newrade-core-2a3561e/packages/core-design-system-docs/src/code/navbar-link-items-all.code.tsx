import React from 'react';

import { sizeVars } from '@newrade/core-css-theme/css';
import { LOGO } from '@newrade/core-design-system';
import { Cluster, Stack } from '@newrade/core-react-ui-layout-components';
import {
  NavbarExternalLinkItem,
  NavbarLinkItem,
  NavbarLogoLinkItem,
  NavbarSeparatorItem,
} from '@newrade/core-react-ui-navbar-items';

type Props = {};

export const AllNavbarLinkItems: React.FC<Props> = (props) => {
  return (
    <Stack gap={[sizeVars.x3]}>
      <Cluster justifyContent={['flex-start']}>
        <NavbarLogoLinkItem kind={LOGO.SYMBOL} />
        <NavbarLogoLinkItem />

        <NavbarLinkItem active={true}></NavbarLinkItem>
        <NavbarLinkItem active={false}></NavbarLinkItem>

        <NavbarSeparatorItem />

        <NavbarExternalLinkItem href={'https://www.google.com'}>
          External link
        </NavbarExternalLinkItem>
      </Cluster>
    </Stack>
  );
};
