import React from 'react';

import { sizeVars } from '@newrade/core-css-theme/css';
import { CSSAnimation } from '@newrade/core-react-ui-animations';
import { Placeholder } from '@newrade/core-react-ui-doc-components';
import { Stack } from '@newrade/core-react-ui-layout-components';

type Props = {};

export const CSSAnimationAttentionSeeker: React.FC<Props> = (props) => {
  return (
    <Stack gap={[sizeVars.x3]}>
      <CSSAnimation
        animation={{
          name: 'bounce',
          iterationCount: 'infinity',
        }}
        showControls={true}
      >
        <Placeholder>Bounce</Placeholder>
      </CSSAnimation>

      <CSSAnimation
        animation={{
          name: 'pulse',
          iterationCount: 'infinity',
        }}
        showControls={true}
      >
        <Placeholder>Pulse</Placeholder>
      </CSSAnimation>
    </Stack>
  );
};
