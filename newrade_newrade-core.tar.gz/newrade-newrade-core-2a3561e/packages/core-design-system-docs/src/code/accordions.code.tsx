import React from 'react';

import { lorenipsum } from '@newrade/core-react-ui-doc-components';
import { Stack } from '@newrade/core-react-ui-layout-components';
import { Details, Paragraph, Summary } from '@newrade/core-react-ui-text';

type Props = {};

export const Accordions: React.FC<Props> = (props) => {
  return (
    <Stack>
      <Details>
        <Summary>Summary 1</Summary>
        <Paragraph>{lorenipsum}</Paragraph>
      </Details>

      <Details>
        <Summary>Summary 2</Summary>
        <Paragraph>{lorenipsum}</Paragraph>
      </Details>

      <Details>
        <Summary>Summary 3</Summary>
        <Paragraph>{lorenipsum}</Paragraph>
      </Details>
    </Stack>
  );
};
