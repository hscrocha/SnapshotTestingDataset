import React from 'react';

import { sizeVars } from '@newrade/core-css-theme/css';
import { ButtonVariant, HEADING } from '@newrade/core-design-system';
import { Button } from '@newrade/core-react-ui-buttons';
import { InputLabel, InputText, InputWrapper } from '@newrade/core-react-ui-forms';
import { Cluster, Stack, Switcher } from '@newrade/core-react-ui-layout-components';
import { Heading } from '@newrade/core-react-ui-text';

type Props = {};

export const FormGroupedButtons: React.FC<Props> = (props) => {
  return (
    <>
      <Stack gap={[sizeVars.x4]}>
        <Heading variant={HEADING.h4}>Contact</Heading>
        <Stack gap={[sizeVars.x3]}>
          <Switcher gap={[sizeVars.x3]}>
            <InputWrapper>
              <InputLabel htmlFor={'firstName'}>First Name</InputLabel>
              <InputText name="firstName" autoComplete="given-name" placeholder={''} />
            </InputWrapper>
            <InputWrapper>
              <InputLabel htmlFor={'lastName'}>Last Name</InputLabel>
              <InputText name="firstName" autoComplete="given-name" placeholder={''} />
            </InputWrapper>
          </Switcher>
          <InputWrapper>
            <InputLabel htmlFor={'email'}>Email</InputLabel>
            <InputText name="email" autoComplete="given-name" placeholder={''} />
          </InputWrapper>
          <InputWrapper>
            <InputLabel htmlFor={'company'}>Company (optional)</InputLabel>
            <InputText name="company" autoComplete="given-name" placeholder={''} />
          </InputWrapper>
          <InputWrapper>
            <InputLabel htmlFor={'message'}>Message</InputLabel>
            <InputText name="message" autoComplete="given-name" placeholder={''} />
          </InputWrapper>
          <Cluster wrap={true} gap={[sizeVars.x2]} justifyContent={['flex-start']}>
            <Button variant={ButtonVariant.secondary}>Cancel</Button>
            <Button variant={ButtonVariant.primary}>Send</Button>
          </Cluster>
        </Stack>
      </Stack>
    </>
  );
};
