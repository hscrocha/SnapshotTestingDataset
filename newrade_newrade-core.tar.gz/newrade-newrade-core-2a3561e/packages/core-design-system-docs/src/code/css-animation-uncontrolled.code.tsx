import React from 'react';

import { sizeVars } from '@newrade/core-css-theme/css';
import { ButtonVariant } from '@newrade/core-design-system';
import {
  CSSAnimation,
  CSSAnimationHandle,
  CSSAnimationState,
} from '@newrade/core-react-ui-animations';
import { Button } from '@newrade/core-react-ui-buttons';
import { Placeholder } from '@newrade/core-react-ui-doc-components';
import { Cluster, Stack } from '@newrade/core-react-ui-layout-components';

type Props = {};

export const CSSAnimationUncontrolled: React.FC<Props> = (props) => {
  return (
    <>
      <CSSAnimation
        animation={{
          name: 'bounce',
        }}
        showControls={true}
      >
        <Placeholder>Bounce Uncontrolled</Placeholder>
      </CSSAnimation>
    </>
  );
};
