import React from 'react';

import { sizeVars } from '@newrade/core-css-theme/css';
import { PARAGRAPH_SIZE, TEXT_STYLE } from '@newrade/core-design-system';
import { lorenipsum } from '@newrade/core-react-ui-doc-components';
import { Stack } from '@newrade/core-react-ui-layout-components';
import { Paragraph } from '@newrade/core-react-ui-text';
import { keys } from '@newrade/core-react-ui-utilities-iso';

type Props = {};

export const Paragraphs: React.FC<Props> = (props) => {
  return (
    <Stack gap={[sizeVars.x4]}>
      {keys(PARAGRAPH_SIZE).map((variant, index) => (
        <Paragraph key={index} size={PARAGRAPH_SIZE[variant]}>
          {variant} - {lorenipsum}
        </Paragraph>
      ))}

      {keys(TEXT_STYLE).map((style, index) => (
        <Paragraph key={index} textStyle={TEXT_STYLE[style]}>
          {style} - {lorenipsum}
        </Paragraph>
      ))}
    </Stack>
  );
};
