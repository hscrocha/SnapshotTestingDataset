import React from 'react';

import { sizeVars, typoSpaceVars } from '@newrade/core-css-theme/css';
import { TITLE, Variant } from '@newrade/core-design-system';
import { lorenipsumMedium } from '@newrade/core-react-ui-doc-components';
import { Stack } from '@newrade/core-react-ui-layout-components';
import { Heading } from '@newrade/core-react-ui-text';

type Props = {};

export const Titles: React.FC<Props> = (props) => {
  return (
    <Stack gap={[sizeVars.x5]}>
      <Stack gap={[typoSpaceVars.titles.t1.after]}>
        <Heading variant={TITLE.t1} variantLevel={Variant.primary}>
          {lorenipsumMedium}
        </Heading>
      </Stack>

      <Heading variant={TITLE.t2} variantLevel={Variant.primary}>
        {lorenipsumMedium}
      </Heading>
    </Stack>
  );
};
