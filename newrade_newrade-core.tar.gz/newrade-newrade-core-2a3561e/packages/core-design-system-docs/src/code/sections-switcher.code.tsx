import React from 'react';

import { COLOR_MODE } from '@newrade/core-design-system';
import { BlockMarkdown } from '@newrade/core-react-ui-blocks';
import { PlaceholderMarkdown } from '@newrade/core-react-ui-doc-components';
import { SectionSwitcher } from '@newrade/core-react-ui-sections';

type Props = {};

export const SectionsSwitcher: React.FC<Props> = (props) => {
  return (
    <SectionSwitcher
      LeftBlock={
        <BlockMarkdown>
          <PlaceholderMarkdown />
          <PlaceholderMarkdown />
        </BlockMarkdown>
      }
      RightBlock={
        <BlockMarkdown>
          <PlaceholderMarkdown />
          <PlaceholderMarkdown />
        </BlockMarkdown>
      }
    ></SectionSwitcher>
  );
};

export const SectionsSwitcherReversed: React.FC<Props> = (props) => {
  return (
    <SectionSwitcher
      section={{
        colorMode: COLOR_MODE.REVERSED,
      }}
      LeftBlock={
        <BlockMarkdown>
          <PlaceholderMarkdown />
          <PlaceholderMarkdown />
        </BlockMarkdown>
      }
      RightBlock={
        <BlockMarkdown>
          <PlaceholderMarkdown />
          <PlaceholderMarkdown />
        </BlockMarkdown>
      }
    ></SectionSwitcher>
  );
};
