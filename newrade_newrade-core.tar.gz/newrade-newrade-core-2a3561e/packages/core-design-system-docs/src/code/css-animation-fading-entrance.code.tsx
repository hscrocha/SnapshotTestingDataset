import React from 'react';

import { sizeVars } from '@newrade/core-css-theme/css';
import { CSSAnimation } from '@newrade/core-react-ui-animations';
import { Placeholder } from '@newrade/core-react-ui-doc-components';
import { Stack } from '@newrade/core-react-ui-layout-components';

type Props = {};

export const CSSFadingEntrance: React.FC<Props> = (props) => {
  return (
    <Stack gap={[sizeVars.x3]}>
      <CSSAnimation
        animation={{
          name: 'fadeIn',
          iterationCount: 'infinity',
        }}
        showControls={true}
      >
        <Placeholder>Fade In</Placeholder>
      </CSSAnimation>

      <CSSAnimation
        animation={{
          name: 'fadeInDown',
          iterationCount: 'infinity',
        }}
        showControls={true}
      >
        <Placeholder>Fade In Down</Placeholder>
      </CSSAnimation>

      <CSSAnimation
        animation={{
          name: 'fadeInLeft',
          iterationCount: 'infinity',
        }}
        showControls={true}
      >
        <Placeholder>Fade In Left</Placeholder>
      </CSSAnimation>

      <CSSAnimation
        animation={{
          name: 'fadeInRight',
          iterationCount: 'infinity',
        }}
        showControls={true}
      >
        <Placeholder>Fade In Right</Placeholder>
      </CSSAnimation>

      <CSSAnimation
        animation={{
          name: 'fadeInUp',
          iterationCount: 'infinity',
        }}
        showControls={true}
      >
        <Placeholder>Fade In Up</Placeholder>
      </CSSAnimation>
    </Stack>
  );
};
