import React from 'react';

import { sizeVars } from '@newrade/core-css-theme/css';
import { ButtonVariant } from '@newrade/core-design-system';
import {
  CSSAnimation,
  CSSAnimationHandle,
  CSSAnimationState,
} from '@newrade/core-react-ui-animations';
import { Button } from '@newrade/core-react-ui-buttons';
import { Placeholder } from '@newrade/core-react-ui-doc-components';
import { Cluster, Stack } from '@newrade/core-react-ui-layout-components';
type Props = {};

export const CSSZoomingEntrance: React.FC<Props> = (props) => {
  return (
    <Stack gap={[sizeVars.x3]}>
      <CSSAnimation
        animation={{
          name: 'zoomIn',
          iterationCount: 'infinity',
        }}
        showControls={true}
      >
        <Placeholder>Zoom In</Placeholder>
      </CSSAnimation>

      <CSSAnimation
        animation={{
          name: 'zoomInDown',
          iterationCount: 'infinity',
        }}
        showControls={true}
      >
        <Placeholder>Zoom In Down</Placeholder>
      </CSSAnimation>

      <CSSAnimation
        animation={{
          name: 'zoomInLeft',
          iterationCount: 'infinity',
        }}
        showControls={true}
      >
        <Placeholder>Zoom In Left</Placeholder>
      </CSSAnimation>

      <CSSAnimation
        animation={{
          name: 'zoomInRight',
          iterationCount: 'infinity',
        }}
        showControls={true}
      >
        <Placeholder>Zoom In Right</Placeholder>
      </CSSAnimation>

      <CSSAnimation
        animation={{
          name: 'zoomInUp',
          iterationCount: 'infinity',
        }}
        showControls={true}
      >
        <Placeholder>Zoom In Up</Placeholder>
      </CSSAnimation>
    </Stack>
  );
};
