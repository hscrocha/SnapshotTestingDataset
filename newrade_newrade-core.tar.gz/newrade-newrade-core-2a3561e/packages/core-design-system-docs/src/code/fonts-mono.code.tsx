import React from 'react';

import { FontMono } from '@newrade/core-react-ui-doc-components';

type Props = {};

export const FontsMono: React.FC<Props> = (props) => {
  return <FontMono></FontMono>;
};
