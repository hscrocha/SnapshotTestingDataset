import React from 'react';

import { sizeVars } from '@newrade/core-css-theme/css';
import { Placeholder } from '@newrade/core-react-ui-doc-components';
import { Stack } from '@newrade/core-react-ui-layout-components';

type Props = {};

export const LayoutStack: React.FC<Props> = (props) => {
  return (
    <>
      <Stack gap={[sizeVars.x3]}>
        <Placeholder></Placeholder>
        <Placeholder></Placeholder>
        <Placeholder></Placeholder>
      </Stack>
    </>
  );
};
