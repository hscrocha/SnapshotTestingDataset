import React from 'react';

import { colorVars, sizeVars } from '@newrade/core-css-theme/css';
import { ButtonVariant } from '@newrade/core-design-system';
import { Button } from '@newrade/core-react-ui-buttons';
import { ColorPalette, ReversedBox } from '@newrade/core-react-ui-doc-components';
import { Stack } from '@newrade/core-react-ui-layout-components';

type Props = {};

export const ButtonColors: React.FC<Props> = (props) => {
  return (
    <Stack gap={[sizeVars.x5]}>
      <Stack gap={[sizeVars.x3]}>
        <Button variant={ButtonVariant.primary}></Button>
        <Button variant={ButtonVariant.secondary}></Button>
        <Button variant={ButtonVariant.tertiary}></Button>
      </Stack>

      <ReversedBox>
        <Stack gap={[sizeVars.x3]}>
          <Button variant={ButtonVariant.primary}></Button>
          <Button variant={ButtonVariant.secondary}></Button>
          <Button variant={ButtonVariant.tertiary}></Button>
        </Stack>
      </ReversedBox>

      <Stack>
        <ColorPalette
          colorName={''}
          color={{
            primary: colorVars.colorIntents.primary,
          }}
        ></ColorPalette>
        <ColorPalette
          colorName={''}
          color={{
            secondary: colorVars.colorIntents.secondary,
          }}
        ></ColorPalette>
      </Stack>
    </Stack>
  );
};
