// plain (non-jsx) javascript file

function func(arg) {
  return '';
}

func('hey');

var foo;
var bar = 'foo';
var barLiteral = `foo`;
