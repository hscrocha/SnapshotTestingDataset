import React from 'react';

import { sizeVars } from '@newrade/core-css-theme/css';
import { NavbarItemSize } from '@newrade/core-design-system';
import { Cluster, Stack } from '@newrade/core-react-ui-layout-components';
import { NavbarExternalLinkItem } from '@newrade/core-react-ui-navbar-items';

type Props = {};

export const NavbarLinkExternalItems: React.FC<Props> = (props) => {
  return (
    <Stack gap={[sizeVars.x3]}>
      <Cluster justifyContent={['flex-start']}>
        <NavbarExternalLinkItem href={'https://www.google.com'} size={NavbarItemSize.medium}>
          External link medium
        </NavbarExternalLinkItem>

        <NavbarExternalLinkItem href={'https://www.google.com'} size={NavbarItemSize.small}>
          External link small
        </NavbarExternalLinkItem>
      </Cluster>
    </Stack>
  );
};
