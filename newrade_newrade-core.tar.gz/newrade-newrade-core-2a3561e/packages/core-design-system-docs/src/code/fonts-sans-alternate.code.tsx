import React from 'react';

import { FontSansAlternate } from '@newrade/core-react-ui-doc-components';

type Props = {};

export const FontsSansAlternate: React.FC<Props> = (props) => {
  return <FontSansAlternate></FontSansAlternate>;
};
