import React from 'react';

import { sizeVars } from '@newrade/core-css-theme/css';
import { GestureDragExample } from '@newrade/core-react-ui-gestures';
import { Stack } from '@newrade/core-react-ui-layout-components';

type Props = {};

export const GestureDrag: React.FC<Props> = (props) => {
  return (
    <Stack gap={[sizeVars.x5]}>
      <GestureDragExample />
    </Stack>
  );
};
