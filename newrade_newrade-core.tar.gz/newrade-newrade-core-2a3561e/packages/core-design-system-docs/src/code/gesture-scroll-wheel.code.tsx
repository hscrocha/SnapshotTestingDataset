import React from 'react';

import { sizeVars } from '@newrade/core-css-theme/css';
import { GestureScrollWheelExample } from '@newrade/core-react-ui-gestures';
import { Stack } from '@newrade/core-react-ui-layout-components';

type Props = {};

export const GestureScrollWheel: React.FC<Props> = (props) => {
  return (
    <Stack gap={[sizeVars.x5]}>
      <GestureScrollWheelExample />
    </Stack>
  );
};
