import React from 'react';

import { colorVars } from '@newrade/core-css-theme/css';
import { ColorPalette } from '@newrade/core-react-ui-doc-components';

type Props = {};

export const ColorPrimary: React.FC<Props> = (props) => {
  return <ColorPalette colorName={'Primary'} color={colorVars.colors.primary}></ColorPalette>;
};
