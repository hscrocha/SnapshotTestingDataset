import React from 'react';

import { BlockMarkdown } from '@newrade/core-react-ui-blocks';
import { PlaceholderMarkdown } from '@newrade/core-react-ui-doc-components';

type Props = {};

export const Blocks: React.FC<Props> = (props) => {
  return (
    <>
      <BlockMarkdown>
        <PlaceholderMarkdown />
      </BlockMarkdown>
    </>
  );
};
