import React from 'react';

import { sizeVars } from '@newrade/core-css-theme/css';
import { GestureScrollExample } from '@newrade/core-react-ui-gestures';
import { Stack } from '@newrade/core-react-ui-layout-components';

type Props = {};

export const GestureScroll: React.FC<Props> = (props) => {
  return (
    <Stack gap={[sizeVars.x5]}>
      <GestureScrollExample />
    </Stack>
  );
};
