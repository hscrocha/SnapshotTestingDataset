import React from 'react';

import { colorVars } from '@newrade/core-css-theme/css';
import { ColorPalette } from '@newrade/core-react-ui-doc-components';
import { Stack } from '@newrade/core-react-ui-layout-components';

type Props = {};

export const TextColorIntents: React.FC<Props> = (props) => {
  return (
    <Stack>
      <ColorPalette
        colorName={'PrimaryText'}
        color={colorVars.colorIntents.primaryText}
      ></ColorPalette>

      <ColorPalette
        colorName={'SecondaryText'}
        color={colorVars.colorIntents.secondaryText}
      ></ColorPalette>

      <ColorPalette
        colorName={'TertiaryText'}
        color={colorVars.colorIntents.tertiaryText}
      ></ColorPalette>
    </Stack>
  );
};
