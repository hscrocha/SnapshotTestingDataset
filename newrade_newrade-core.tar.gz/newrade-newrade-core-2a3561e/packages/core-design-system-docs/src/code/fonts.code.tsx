import React from 'react';

import { FontShowcase } from '@newrade/core-react-ui-doc-components';

type Props = {};

export const Fonts: React.FC<Props> = (props) => {
  return <FontShowcase></FontShowcase>;
};
