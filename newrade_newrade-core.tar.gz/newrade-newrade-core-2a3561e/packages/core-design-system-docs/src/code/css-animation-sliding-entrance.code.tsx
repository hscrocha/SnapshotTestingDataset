import React from 'react';

import { sizeVars } from '@newrade/core-css-theme/css';
import { ButtonVariant } from '@newrade/core-design-system';
import {
  CSSAnimation,
  CSSAnimationHandle,
  CSSAnimationState,
} from '@newrade/core-react-ui-animations';
import { Button } from '@newrade/core-react-ui-buttons';
import { Placeholder } from '@newrade/core-react-ui-doc-components';
import { Cluster, Stack } from '@newrade/core-react-ui-layout-components';

type Props = {};

export const CSSSlidingEntrance: React.FC<Props> = (props) => {
  return (
    <Stack gap={[sizeVars.x3]}>
      <CSSAnimation
        animation={{
          name: 'slideInDown',
          iterationCount: 'infinity',
        }}
        showControls={true}
      >
        <Placeholder>Slide In Down</Placeholder>
      </CSSAnimation>

      <CSSAnimation
        animation={{
          name: 'slideInLeft',
          iterationCount: 'infinity',
        }}
        showControls={true}
      >
        <Placeholder>Slide In Left</Placeholder>
      </CSSAnimation>

      <CSSAnimation
        animation={{
          name: 'slideInRight',
          iterationCount: 'infinity',
        }}
        showControls={true}
      >
        <Placeholder>Slide In Right</Placeholder>
      </CSSAnimation>

      <CSSAnimation
        animation={{
          name: 'slideInUp',
          iterationCount: 'infinity',
        }}
        showControls={true}
      >
        <Placeholder>Slide In Up</Placeholder>
      </CSSAnimation>
      <CSSAnimation
        animation={{
          name: 'slideOutDown',
          iterationCount: 'infinity',
        }}
        showControls={true}
      >
        <Placeholder>Slide Out Down</Placeholder>
      </CSSAnimation>

      <CSSAnimation
        animation={{
          name: 'slideOutLeft',
          iterationCount: 'infinity',
        }}
        showControls={true}
      >
        <Placeholder>Slide Out Left</Placeholder>
      </CSSAnimation>

      <CSSAnimation
        animation={{
          name: 'slideOutRight',
          iterationCount: 'infinity',
        }}
        showControls={true}
      >
        <Placeholder>Slide Out Right</Placeholder>
      </CSSAnimation>

      <CSSAnimation
        animation={{
          name: 'slideOutUp',
          iterationCount: 'infinity',
        }}
        showControls={true}
      >
        <Placeholder>Slide Out Up</Placeholder>
      </CSSAnimation>
    </Stack>
  );
};
