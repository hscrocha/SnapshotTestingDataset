import React, { useState } from 'react';

import { sizeVars } from '@newrade/core-css-theme/css';
import { LOGO } from '@newrade/core-design-system';
import { Cluster, Stack } from '@newrade/core-react-ui-layout-components';
import { NavbarLogoLinkItem, NavbarLogoTextItem } from '@newrade/core-react-ui-navbar-items';
import { NavbarMenuLinkItem } from '@newrade/core-react-ui-navbar-menus';

type Props = {};

export const NavbavMenuItems: React.FC<Props> = (props) => {
  const [activeLink, setActiveLink] = useState(0);
  function handleClick(id: number) {
    return () => {
      setActiveLink(id);
    };
  }

  return (
    <Stack gap={[sizeVars.x3]}>
      <Cluster justifyContent={['flex-start']}>
        <NavbarMenuLinkItem>Menu</NavbarMenuLinkItem>
        <NavbarMenuLinkItem>Menu</NavbarMenuLinkItem>
        <NavbarMenuLinkItem>Menu</NavbarMenuLinkItem>
      </Cluster>
    </Stack>
  );
};
