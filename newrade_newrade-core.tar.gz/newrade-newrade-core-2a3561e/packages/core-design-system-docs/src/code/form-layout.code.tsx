import React from 'react';

import { sizeVars } from '@newrade/core-css-theme/css';
import { ButtonVariant, LABEL_SIZE, TEXT_STYLE, Variant } from '@newrade/core-design-system';
import { Button } from '@newrade/core-react-ui-buttons';
import { InputLabel, InputText, InputWrapper } from '@newrade/core-react-ui-forms';
import { Stack } from '@newrade/core-react-ui-layout-components';
import { Label } from '@newrade/core-react-ui-text';

type Props = {};

export const FormLayout: React.FC<Props> = (props) => {
  return (
    <>
      <Stack gap={[sizeVars.x3]}>
        <InputWrapper>
          <InputLabel htmlFor={'label'}>Label</InputLabel>
          <Label textStyle={TEXT_STYLE.normal} variant={LABEL_SIZE.xSmall}>
            Helper Text
          </Label>
          <InputText
            name="placeholderText"
            autoComplete="given-name"
            placeholder={'Placeholder Text'}
          />
          <Label variant={LABEL_SIZE.xSmall}> Validation</Label>
        </InputWrapper>

        <Button variant={ButtonVariant.primary}>Action</Button>
      </Stack>
    </>
  );
};
