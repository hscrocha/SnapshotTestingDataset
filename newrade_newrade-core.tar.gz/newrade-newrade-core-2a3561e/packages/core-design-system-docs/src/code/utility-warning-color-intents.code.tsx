import React from 'react';

import { colorVars } from '@newrade/core-css-theme/css';
import { ColorPalette } from '@newrade/core-react-ui-doc-components';
import { Stack } from '@newrade/core-react-ui-layout-components';

type Props = {};

export const UtilityWarningColorIntents: React.FC<Props> = (props) => {
  return (
    <Stack>
      <ColorPalette colorName={''} color={colorVars.colorIntents.warningText}></ColorPalette>
      <ColorPalette colorName={''} color={colorVars.colorIntents.warningAction}></ColorPalette>
      <ColorPalette colorName={''} color={colorVars.colorIntents.warningBackground}></ColorPalette>
    </Stack>
  );
};
