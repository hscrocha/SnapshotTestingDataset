import React from 'react';

import { sizeVars } from '@newrade/core-css-theme/css';
import { PARAGRAPH_SIZE } from '@newrade/core-design-system';
import { lorenipsum, lorenipsumShort } from '@newrade/core-react-ui-doc-components';
import { Stack } from '@newrade/core-react-ui-layout-components';
import { ListItemV2 } from '@newrade/core-react-ui-list-items';

type Props = {};

export const ListItemsMultiLine: React.FC<Props> = (props) => {
  return (
    <>
      <Stack as={'ul'} gap={[sizeVars.x2]}>
        <ListItemV2 size={PARAGRAPH_SIZE.large}>{lorenipsumShort}</ListItemV2>
        <ListItemV2 size={PARAGRAPH_SIZE.large}>{lorenipsum}</ListItemV2>

        <ListItemV2>{lorenipsumShort}</ListItemV2>
        <ListItemV2>{lorenipsum}</ListItemV2>

        <ListItemV2 size={PARAGRAPH_SIZE.xSmall}>{lorenipsumShort}</ListItemV2>
        <ListItemV2 size={PARAGRAPH_SIZE.xSmall}>{lorenipsum}</ListItemV2>
      </Stack>

      <Stack as={'ol'} gap={[sizeVars.x4]}>
        <ListItemV2 size={PARAGRAPH_SIZE.large}>{lorenipsumShort}</ListItemV2>
        <ListItemV2 size={PARAGRAPH_SIZE.large}>{lorenipsum}</ListItemV2>

        <ListItemV2>{lorenipsumShort}</ListItemV2>
        <ListItemV2>{lorenipsum}</ListItemV2>

        <ListItemV2 size={PARAGRAPH_SIZE.xSmall}>{lorenipsumShort}</ListItemV2>
        <ListItemV2 size={PARAGRAPH_SIZE.xSmall}>{lorenipsum}</ListItemV2>
      </Stack>
    </>
  );
};
