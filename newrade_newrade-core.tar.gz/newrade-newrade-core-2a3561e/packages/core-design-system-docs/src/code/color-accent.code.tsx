import React from 'react';

import { colorVars, sizeVars } from '@newrade/core-css-theme/css';
import { ColorPalette } from '@newrade/core-react-ui-doc-components';
import { Stack } from '@newrade/core-react-ui-layout-components';

type Props = {};

export const ColorAccent: React.FC<Props> = (props) => {
  return (
    <Stack gap={[sizeVars.x5]}>
      <ColorPalette colorName={'Accent1'} color={colorVars.colors.accent1}></ColorPalette>

      <ColorPalette colorName={'Accent2'} color={colorVars.colors.accent2}></ColorPalette>

      <ColorPalette colorName={'Accent3'} color={colorVars.colors.accent3}></ColorPalette>

      <ColorPalette colorName={'Accent4'} color={colorVars.colors.accent4}></ColorPalette>

      <ColorPalette colorName={'Accent5'} color={colorVars.colors.accent5}></ColorPalette>

      <ColorPalette colorName={'Accent6'} color={colorVars.colors.accent6}></ColorPalette>
    </Stack>
  );
};
