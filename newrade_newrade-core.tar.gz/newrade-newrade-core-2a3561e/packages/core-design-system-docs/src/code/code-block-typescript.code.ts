// plain (non-jsx) typescript file

function func<Generic>(arg: Generic): string {
  return '';
}

enum ENUM {
  A = 'A',
  B = 'B',
}

func(ENUM.A);

type Generic<Type = string> = Type extends ENUM ? string : undefined;

export { func };
