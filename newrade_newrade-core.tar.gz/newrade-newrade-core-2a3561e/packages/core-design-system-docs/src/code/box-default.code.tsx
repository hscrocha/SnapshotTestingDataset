import React from 'react';

import { sizeVars } from '@newrade/core-css-theme/css';
import { Placeholder } from '@newrade/core-react-ui-doc-components';
import { BoxV2 } from '@newrade/core-react-ui-layout-components';

type Props = {};

export const LayoutBoxV2: React.FC<Props> = (props) => {
  return (
    <>
      <BoxV2 padding={[sizeVars.x4]} style={{ border: '2px solid red' }}>
        <Placeholder></Placeholder>
      </BoxV2>
    </>
  );
};
