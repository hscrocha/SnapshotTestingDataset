import React, { useState } from 'react';

import { sizeVars } from '@newrade/core-css-theme/css';
import { ICON } from '@newrade/core-design-system';
import { Cluster, Stack } from '@newrade/core-react-ui-layout-components';
import { NavbarSelectItem } from '@newrade/core-react-ui-navbar-items';

type Props = {};

export const NavbavSelectItems: React.FC<Props> = (props) => {
  type ThemeValue = 'Light' | 'Dark';

  const [selectedTheme, setSelectedTheme] = useState<ThemeValue>('Light');

  function handleChangeTheme(event: React.ChangeEvent<HTMLSelectElement>) {
    const value = event.target.value;
    if (!value) {
      return;
    }
    setSelectedTheme(value as ThemeValue);
  }

  return (
    <Stack gap={[sizeVars.x3]}>
      <Cluster justifyContent={['flex-start']}>
        <NavbarSelectItem
          Icon={ICON.ARROW_UP}
          select={{
            placeholder: 'Choose Theme',
            value: selectedTheme,
            onChange: handleChangeTheme,
          }}
        >
          <option value={'Light'}>Light</option>
          <option value={'Dark'}>Dark</option>
        </NavbarSelectItem>
      </Cluster>
    </Stack>
  );
};
