import React from 'react';

import { FontSans } from '@newrade/core-react-ui-doc-components';

type Props = {};

export const FontsSans: React.FC<Props> = (props) => {
  return <FontSans></FontSans>;
};
