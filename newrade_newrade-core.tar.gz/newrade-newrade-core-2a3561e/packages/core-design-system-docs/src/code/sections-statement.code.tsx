import React from 'react';

import { Variant } from '@newrade/core-design-system';
import { BlockMarkdown } from '@newrade/core-react-ui-blocks';
import { PlaceholderMarkdown } from '@newrade/core-react-ui-doc-components';
import { SectionStatement } from '@newrade/core-react-ui-sections';
import { Heading } from '@newrade/core-react-ui-text';

type Props = {};

export const SectionsStatement: React.FC<Props> = (props) => {
  return (
    <>
      <SectionStatement
        section={{ variant: Variant.primary }}
        TopBlock={
          <BlockMarkdown>
            <Heading>Lorem Ipsum</Heading>
            <PlaceholderMarkdown />
          </BlockMarkdown>
        }
        RightBlock={
          <BlockMarkdown>
            <PlaceholderMarkdown />
          </BlockMarkdown>
        }
        LeftBlock={
          <BlockMarkdown>
            <PlaceholderMarkdown />
          </BlockMarkdown>
        }
      ></SectionStatement>
    </>
  );
};
