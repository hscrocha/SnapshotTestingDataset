import React from 'react';

import { sizeVars } from '@newrade/core-css-theme/css';
import { LOGO } from '@newrade/core-design-system';
import { Cluster, Stack } from '@newrade/core-react-ui-layout-components';
import { NavbarLogoLinkItem, NavbarLogoTextItem } from '@newrade/core-react-ui-navbar-items';

type Props = {};

export const NavbarLinkLogoItems: React.FC<Props> = (props) => {
  return (
    <Stack gap={[sizeVars.x3]}>
      <Cluster justifyContent={['flex-start']} gap={[sizeVars.x3]}>
        <NavbarLogoTextItem kind={LOGO.SYMBOL} text={'ProductName'} />

        <NavbarLogoLinkItem kind={LOGO.STANDARD} />
        <NavbarLogoLinkItem kind={LOGO.STANDARD} active={true} />

        <NavbarLogoLinkItem kind={LOGO.SYMBOL} />
        <NavbarLogoLinkItem kind={LOGO.SYMBOL} active={true} />
      </Cluster>
    </Stack>
  );
};
