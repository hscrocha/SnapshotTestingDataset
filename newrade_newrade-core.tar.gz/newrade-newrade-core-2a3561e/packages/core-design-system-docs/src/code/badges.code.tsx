import React from 'react';

import { sizeVars } from '@newrade/core-css-theme/css';
import { Badge } from '@newrade/core-react-ui-badges';
import { Cluster } from '@newrade/core-react-ui-layout-components';

type Props = {};

export const Badges: React.FC<Props> = (props) => {
  return (
    <>
      <Cluster justifyContent={['flex-start']} gap={[sizeVars.x1]} wrap={true}>
        <Badge name="Neutral" status="Yes"></Badge>
        <Badge name="Success" status="OK" kind={'success'}></Badge>
        <Badge name="Build" status="failed" kind={'error'}></Badge>
      </Cluster>
    </>
  );
};
