import React from 'react';

import { Placeholder } from '@newrade/core-react-ui-doc-components';
import { Center } from '@newrade/core-react-ui-layout-components';

type Props = {};

export const LayoutCenter: React.FC<Props> = (props) => {
  return (
    <>
      <Center>
        <Placeholder>Content</Placeholder>
      </Center>
    </>
  );
};
