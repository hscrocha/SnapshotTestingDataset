import React from 'react';

import { sizeVars } from '@newrade/core-css-theme/css';
import { Cluster } from '@newrade/core-react-ui-layout-components';
import { Switch } from '@newrade/core-react-ui-switches';

type Props = {};

export const Switches: React.FC<Props> = (props) => {
  return (
    <Cluster justifyContent={['flex-start']} gap={[sizeVars.x4]} wrap={true}>
      <Switch value={'on'}></Switch>
      <Switch value={'off'}></Switch>
      <Switch value={'on'} disabled={true}></Switch>
      <Switch value={'off'} disabled={true}></Switch>
    </Cluster>
  );
};
