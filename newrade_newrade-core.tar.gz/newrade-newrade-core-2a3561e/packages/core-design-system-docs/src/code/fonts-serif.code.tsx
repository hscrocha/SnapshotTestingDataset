import React from 'react';

import { FontSerif } from '@newrade/core-react-ui-doc-components';

type Props = {};

export const FontsSerif: React.FC<Props> = (props) => {
  return <FontSerif></FontSerif>;
};
