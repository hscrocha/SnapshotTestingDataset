import React from 'react';

import { sizingCSS } from '@newrade/core-css-theme/css';
import { ScaleSteps } from '@newrade/core-react-ui-doc-components';

type Props = {};

export const SizingTablet: React.FC<Props> = (props) => {
  return <ScaleSteps steps={sizingCSS.sizes.tablet} />;
};
