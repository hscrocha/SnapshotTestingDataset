import React from 'react';

import { sizeVars } from '@newrade/core-css-theme/css';
import { Cluster, Stack } from '@newrade/core-react-ui-layout-components';
import { NavbarLinkItem, NavbarSeparatorItem } from '@newrade/core-react-ui-navbar-items';

type Props = {};

export const NavbarSeparatorItems: React.FC<Props> = (props) => {
  return (
    <Stack gap={[sizeVars.x3]}>
      <Cluster justifyContent={['flex-start']} gap={['0px']}>
        <NavbarLinkItem />
        <NavbarLinkItem />
        <NavbarSeparatorItem kind={'empty'} />

        <NavbarLinkItem />

        <NavbarSeparatorItem />

        <NavbarLinkItem />
        <NavbarLinkItem />
      </Cluster>
    </Stack>
  );
};
