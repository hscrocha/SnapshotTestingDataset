import React from 'react';

import { ButtonVariant } from '@newrade/core-design-system';
import { Button } from '@newrade/core-react-ui-buttons';

type Props = {};

export const ButtonsStates: React.FC<Props> = (props) => {
  return (
    <>
      <Button disabled={true} variant={ButtonVariant.primary}>
        Primary
      </Button>
      <Button disabled={true} variant={ButtonVariant.secondary}>
        Secondary
      </Button>
      <Button disabled={true} variant={ButtonVariant.tertiary}>
        Tertiary
      </Button>
      <Button disabled={true} variant={ButtonVariant.primaryPositive}>
        Positive
      </Button>
      <Button disabled={true} variant={ButtonVariant.primaryWarning}>
        Warning
      </Button>
      <Button disabled={true} variant={ButtonVariant.primaryDanger}>
        Danger
      </Button>
    </>
  );
};
