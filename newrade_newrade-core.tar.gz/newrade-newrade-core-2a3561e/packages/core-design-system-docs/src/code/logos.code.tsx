import React from 'react';

import { GLOBAL_CSS_COLORS_THEME_SCHEME } from '@newrade/core-css-theme/runtime';
import { LOGO } from '@newrade/core-design-system';
import { SvgDownloader } from '@newrade/core-react-ui-images';
import { Logo } from '@newrade/core-react-ui-logos';

type Props = {};

export const Logos: { [key in LOGO]: React.FC<Props> } = {
  [LOGO.STANDARD]: (props) => {
    return (
      <>
        <SvgDownloader filename={'logo-standard'}>
          <Logo name={LOGO.STANDARD} style={{ height: 100 }} />
        </SvgDownloader>
      </>
    );
  },
  [LOGO.SYMBOL]: (props) => {
    return (
      <>
        <SvgDownloader filename={'logo-symbol'}>
          <Logo name={LOGO.SYMBOL} style={{ height: 100 }} />
        </SvgDownloader>
      </>
    );
  },
  [LOGO.FAVICON]: (props) => {
    return (
      <>
        <SvgDownloader filename={'logo-favicon'}>
          <Logo
            name={LOGO.FAVICON}
            style={{ height: 32, width: 32 }}
            className={GLOBAL_CSS_COLORS_THEME_SCHEME.LIGHT}
          />
        </SvgDownloader>
      </>
    );
  },
};
