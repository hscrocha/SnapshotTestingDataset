import React from 'react';

import { sizeVars } from '@newrade/core-css-theme/css';
import { ButtonVariant } from '@newrade/core-design-system';
import { Button } from '@newrade/core-react-ui-buttons';
import { Cluster } from '@newrade/core-react-ui-layout-components';

type Props = {};

export const Buttons: React.FC<Props> = (props) => {
  return (
    <Cluster gap={[sizeVars.x2]} justifyContent={['flex-start']} wrap={true}>
      <Button variant={ButtonVariant.primary}>Primary</Button>
      <Button variant={ButtonVariant.secondary}>Secondary</Button>
      <Button variant={ButtonVariant.tertiary}>Tertiary</Button>
      <Button variant={ButtonVariant.primaryPositive}>Positive</Button>
      <Button variant={ButtonVariant.primaryWarning}>Warning</Button>
      <Button variant={ButtonVariant.primaryDanger}>Danger</Button>
    </Cluster>
  );
};
