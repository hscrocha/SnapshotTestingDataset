# Core Design System Docs

> Generic but comprehensive documentation of everything found in the
> core-design-system.

Demo: https://zedesignsystem.com/design-system/

---
