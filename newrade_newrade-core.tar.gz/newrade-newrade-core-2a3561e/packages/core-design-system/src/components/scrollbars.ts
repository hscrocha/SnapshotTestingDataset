import { ColorType, DeepPartial, NumberType } from '../types.js';

/**
 * Properties to control the layout the scrollbar and thumb
 */
export type ScrollbarsSizes<Override extends undefined | string = undefined> = {
  barWidth: NumberType<Override>;
  barHeight: NumberType<Override>;
  thumbWidth: NumberType<Override>;
  thumbBorderWidth: NumberType<Override>;
  thumbThumbRadius: NumberType<Override>;
};

/**
 * Properties for each color in scrollbars
 */
export type ScrollbarsColors<Override extends undefined | string = undefined> = {
  thumbBorderColor: ColorType<Override>;
  thumbBackgroundColor: ColorType<Override>;
  backgroundColor: ColorType<Override>;
};

/**
 * Scrollbars
 */
export type Scrollbars<Override extends undefined | string = undefined> = {
  colors: ScrollbarsColors<Override>;
  sizes: ScrollbarsSizes<Override>;

  /**
   * Reference to variables (string) to be used in place of defined values when a theme is created.
   * This should not be used for default themes since they are used to generate the base contracts.
   */
  vars?: Omit<ScrollbarsVars, 'vars'>;
};

export type ScrollbarsVars = DeepPartial<Scrollbars<string>>;
