import { ICON } from '../foundations/iconography.js';

export type IconMetadata<Icons extends string | undefined = ICON> = {
  [key in Icons extends string ? Icons : string]: {
    /**
     * Short description of the icon and how it should be used
     */
    description?: string;
    /**
     * Keywords associated with the icon
     */
    tags?: string[];
    /**
     * Group icons together around a common subject or similarities
     */
    categories?: string[];
  };
};
