export enum CheckboxState {
  checked = 'checked',
  unchecked = 'unchecked',
  focused = 'focused',
  disabled = 'disabled',
}
