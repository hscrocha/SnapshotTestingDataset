/**
 * General size for component
 */
export enum ComponentSize {
  large = 'large',
  medium = 'medium',
  small = 'small',
  xSmall = 'xSmall',
}
