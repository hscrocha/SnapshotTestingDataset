import { Buttons } from './components/buttons.js';
import { Scrollbars } from './components/scrollbars.js';
import { Animations } from './foundations/animations.js';
import { COLOR_SCHEME } from './foundations/color-scheme.js';
import { Colors } from './foundations/colors.js';
import { Effects } from './foundations/effects.js';
import { Iconography } from './foundations/iconography.js';
import { Layout, LayoutV2 } from './foundations/layout.js';
import { Sizing } from './foundations/sizing.js';
import { Typography, TypographyV2 } from './foundations/typography.js';
import { Resets } from './global/resets.js';

/**
 * @deprecated use DesignSystemV2
 */
export interface DesignSystem<Override extends undefined | string = undefined> {
  /**
   * Theme unique name
   * @example 'ze-light', 'ze-dark'
   */
  name: string;
  /**
   * Theme variation
   * @default 'light'
   */
  colorScheme: COLOR_SCHEME;
  /**
   * Every color defined in the system.
   */
  colors: Colors<Override>;
  /**
   * Defines every text styles.
   */
  typography: Typography<Override>;
  /**
   * Defines the system's sizing values.
   */
  sizing: Sizing<Override>;
  /**
   * TODO
   */
  iconography: Iconography<Override>;
  /**
   * TODO
   */
  // illustrations: any;
  /**
   * TODO
   */
  // photography: any;
  /**
   * Shadows, elevation, blurs and other visual effects.
   */
  effects: Effects<Override>;
  /**
   * Breakpoints, common content margins for different viewports.
   */
  layout: Layout<Override>;
  /**
   * Curves, delays and other defaults for animations.
   */
  animations: Animations;
  /**
   * Components' specific settings.
   */
  components: {
    buttons: Buttons<Override>;
  };
  /**
   * Everything dataviz
   */
  // dataviz: any;
}

export interface DesignSystemV2<Override extends undefined | string = undefined> {
  /**
   * Theme unique name
   * @example 'ze-light', 'ze-dark'
   */
  name: string;
  /**
   * Theme variation
   * @default 'light'
   * @deprecated use colors.colorScheme instead
   */
  colorScheme: COLOR_SCHEME;
  /**
   * Every color defined in the system.
   */
  colors: Colors<Override>;
  /**
   * Defines every text styles.
   */
  typography: TypographyV2<Override>;
  /**
   * Defines the system's sizing values.
   */
  sizing: Sizing<Override>;
  /**
   * TODO
   */
  iconography: Iconography<Override>;
  /**
   * TODO
   */
  // illustrations: any;
  /**
   * Shadows, elevation, blurs and other visual effects.
   */
  effects: Effects<Override>;
  /**
   * Breakpoints, common content margins for different viewports.
   */
  layout: LayoutV2<Override>;
  /**
   * Curves, delays and other defaults for animations.
   */
  animations: Animations;
  /**
   * Components' specific settings.
   */
  components: {
    /**
     * Styles
     */

    /**
     *
     * Atoms
     *
     */

    /**
     * Text
     */

    // titles: {};
    // headings: {};
    // paragraphs: {};
    // labels: {};
    // links: {};

    /**
     * Brand
     */

    // logos: {};
    // images: {};
    // illustrations: {};

    /**
     * Layout
     */

    // dividers: {};
    // backgrounds: {};

    /**
     *
     * Molecules
     *
     */

    /**
     * Buttons
     */

    buttons: Buttons<Override>;
    // keyboardButtons: {};
    // toggleButtons: Buttons<Override>;

    /**
     * Inputs
     */

    // inputs: {
    //  text: {};
    //  switch: {};
    //  number: {};
    //  dropdown: {};
    //  radio: {};
    //  checkbox: {};
    //  date: {};
    //  dateRange: {};
    //  time: {};
    //  textArea: {};
    // };
    // tags: {};

    /**
     * Content sectioning
     */

    // accordions: {};

    /**
     * Navigation
     */

    // navbarMenuItem: {};
    // navbarItem: {};
    // breadcrumbs: {
    //  separatorIcon: {};
    // };
    // tabs: {};
    // tabsGroup: {};
    // steppers: {};

    /**
     * Feedback
     */

    // notifications: {};
    // tooltips: {};
    // statusDot: {};

    /**
     * Dataviz
     */

    // progressBar: {};
    // progressCircle: {};

    /**
     *
     * Organisms
     *
     */

    // avatars: {};
    // tables: {};
    // dialogs: {};
    // carousels: {};

    /**
     * Dataviz
     */

    // plots: {
    //  axis: {};
    //  lines: {};
    //  legend: {};
    // };

    /**
     * Content sectioning
     */

    // cards: {};

    /**
     * Forms
     */

    // forms: {
    //  text: {};
    //  switch: {};
    //  number: {};
    //  dropdown: {};
    //  radio: {};
    //  checkbox: {};
    //  date: {};
    //  dateRange: {};
    //  time: {};
    //  textArea: {};
    // };

    /**
     * Navigation
     */

    //  navbar: {};
    //  navbarMenu: {};
    //  sidebar: {};
    //  main: {};
    //  aside: {};
    //  footer: {};

    /**
     * Layout
     */

    // sections: {
    //  divider: {
    //    // backgroundColor
    //    // padding
    //    leftBlockWidth: number;
    //    gap: number;
    //  };
    // };

    /**
     *
     * Others
     *
     */
  };

  others: {
    resets: Resets<Override>;
    scrollbars: Scrollbars<Override>;
  };
}
