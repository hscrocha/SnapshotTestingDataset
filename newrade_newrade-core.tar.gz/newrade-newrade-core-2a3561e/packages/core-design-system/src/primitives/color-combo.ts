import { Color } from './color.js';

/**
 * A color combo is simply a predefined list of precise colors
 */
export type ColorCombo<
  Override extends undefined | string = undefined,
  ColorShades extends string = ColorDatavizCombo,
  ColorType = Color
> = Record<ColorShades, ColorType>;

/**
 * Combo for dataviz colors
 */
export type ColorDatavizCombo = '1' | '2' | '3' | '4' | '5' | '6' | '7' | '8' | '9';
