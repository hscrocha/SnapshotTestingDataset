import { Buttons } from './components/buttons.js';
import { Scrollbars } from './components/scrollbars.js';
import { COLOR_SCHEME } from './foundations/color-scheme.js';
import { Colors } from './foundations/colors.js';
import { Effects } from './foundations/effects.js';
import { Iconography } from './foundations/iconography.js';
import { LayoutV2 } from './foundations/layout.js';
import { Sizing } from './foundations/sizing.js';
import { Resets } from './global/resets.js';
import { TypographyV2 } from './index.types.js';

/**
 *
 * Design System Configuration
 *
 */

/**
 * General configuration object for each design system's slice
 */
export type DesignSystemSliceConfig<
  ThemeConfig extends DesignSystemThemeConfig,
  ThemeValue extends object
> = {
  /**
   * User-facing name for the theme
   * @example 'Colors'
   */
  name: string;
  /**
   * Forces the scheme to a specific one, by configuration
   *
   * This will override `preferredThemeId`, `userSetThemeId`
   * or any previously set value in localstorage
   * @default undefined
   */
  forcedThemeId?: string;
  /**
   * Id of the theme previously manually set by the user (e.g. in localstorage)
   * @default undefined
   */
  userSetThemeId?: string;
  /**
   * Option to choose the default theme when it has not been set before by `userSetThemeId`
   * @default undefined
   */
  preferredThemeId?: string;
  /**
   * List of available theme for the slice
   */
  themes: (ThemeConfig & ThemeValue)[];
};

export type DesignSystemThemeConfig = {
  /**
   * Identifier of the theme, it is also used to import a theme file (e.g. colors-default-light.theme.ts)
   * @example 'name-default'
   */
  id: string;
  /**
   * User-facing name for the theme
   * @example 'Default'
   */
  name: string;
  /**
   * User-facing description for the theme
   * @example ''
   */
  description?: string;
  /**
   * Whether this theme is the default
   */
  default: boolean;
};

/**
 * Configuration object to support multiple themes for each design system slice.
 */
export type DesignSystemConfig = {
  /**
   * UUID for the config
   * @example
   */
  id: string;
  /**
   * Option for the CSS runtime
   */
  runtime: {
    /**
     * Prefix used for themes and other values such as classnames
     * @default 'global'
     */
    prefix: string;
  };
  colors: DesignSystemSliceConfig<
    DesignSystemThemeConfig,
    {
      /**
       * Whether the defined theme is a light or dark variant
       */
      colorScheme: COLOR_SCHEME;
      /**
       * Color values
       */
      colors?: Colors;
    }
  >;
  typography: DesignSystemSliceConfig<
    DesignSystemThemeConfig,
    {
      /**
       * Typography values for the theme
       */
      typography?: TypographyV2;
    }
  >;
  sizing: DesignSystemSliceConfig<
    DesignSystemThemeConfig,
    {
      /**
       * Sizing values for the theme
       */
      sizing?: Sizing;
    }
  >;
  iconography: DesignSystemSliceConfig<
    DesignSystemThemeConfig,
    {
      /**
       * Iconography values for the theme
       */
      iconography?: Iconography;
    }
  >;
  effects: DesignSystemSliceConfig<
    DesignSystemThemeConfig,
    {
      /**
       * Effects values for the theme
       */
      effects?: Effects;
    }
  >;
  layout: DesignSystemSliceConfig<
    DesignSystemThemeConfig,
    {
      /**
       * Layout values
       */
      layout?: LayoutV2;
    }
  >;
  // animations
  components: {
    // figure out what to do with assets/files here, how is it going to look like in DB?
    logos: {};
    buttons: DesignSystemSliceConfig<
      DesignSystemThemeConfig,
      {
        /**
         * Buttons values
         */
        buttons?: Buttons;
      }
    >;
  };

  others: {
    resets: DesignSystemSliceConfig<
      DesignSystemThemeConfig,
      {
        /**
         * Resets values
         */
        resets?: Resets;
      }
    >;
    scrollbars: DesignSystemSliceConfig<
      DesignSystemThemeConfig,
      {
        /**
         * Scrollbars values
         */
        scrollbars?: Scrollbars;
      }
    >;
  };
};
