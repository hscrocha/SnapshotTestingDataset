import { ColorType, DeepPartial } from '../types.js';

/**
 * Base colors for the reset
 */
export type ResetsColors<Override extends undefined | string = undefined> = {
  textColor: ColorType<Override>;
  backgroundColor: ColorType<Override>;
};

/**
 * Resets
 */
export type Resets<Override extends undefined | string = undefined> = {
  colors: ResetsColors<Override>;
  /**
   * Reference to variables (string) to be used in place of defined values when a theme is created.
   * This should not be used for default themes since they are used to generate the base contracts.
   */
  vars?: Omit<ResetsVars, 'vars'>;
};

export type ResetsVars = DeepPartial<Resets<string>>;
