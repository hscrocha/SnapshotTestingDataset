import { ColorCombo, ColorDatavizCombo } from '../primitives/color-combo.js';
import { ColorPalette, ColorShades11 } from '../primitives/color-palette.js';
import { ColorType, DeepPartial } from '../types.js';

/**
 * Additional colors for use in dataviz
 */
export type DataVizColors<Override extends undefined | string = undefined> = {
  palette1: ColorPalette<Override, ColorShades11, ColorType<Override>>;
  palette2: ColorPalette<Override, ColorShades11, ColorType<Override>>;
  palette3: ColorPalette<Override, ColorShades11, ColorType<Override>>;
  palette4: ColorPalette<Override, ColorShades11, ColorType<Override>>;
  palette5: ColorPalette<Override, ColorShades11, ColorType<Override>>;
  palette6: ColorPalette<Override, ColorShades11, ColorType<Override>>;
  palette7: ColorPalette<Override, ColorShades11, ColorType<Override>>;
};

/**
 * Specific color for dataviz UI elements
 */
export type DataVizColorIntents<Override extends undefined | string = undefined> = {
  combo1: ColorCombo<Override, ColorDatavizCombo, ColorType<Override>>;
  combo2: ColorCombo<Override, ColorDatavizCombo, ColorType<Override>>;
  combo3: ColorCombo<Override, ColorDatavizCombo, ColorType<Override>>;

  labels: ColorType<Override>;
  axis: ColorType<Override>;
  tick: ColorType<Override>;
  line: ColorType<Override>;
  gridPrimary: ColorType<Override>;
  gridSecondary: ColorType<Override>;

  /**
   * Reference to variables (string) to be used in place of defined values when a theme is created.
   * This should not be used for default themes since they are used to generate the base contracts.
   */
  vars?: Omit<DeepPartial<DataVizColors<string>>, 'vars'>;
};

/**
 * DataVizColors object without the `vars` property which is used only
 * in application-defined theme configuration
 */
export type DefaultColorsDataViz = Omit<DataVizColors, 'vars'>;
