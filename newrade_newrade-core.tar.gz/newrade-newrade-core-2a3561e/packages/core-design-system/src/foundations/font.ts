/**
 * @see @capsizecss/core
 * @see https://github.com/seek-oss/capsize/tree/master/packages/metrics for system fonts
 */
export interface FontMetrics {
  ascent: number;
  descent: number;
  lineGap: number;
  unitsPerEm: number;
  capHeight: number;
}

/**
 * Font configuration object
 */
export type Font = {
  /**
   * Identifier of the font
   * @example 'font-name'
   */
  id?: string;
  /**
   * Name of the font or typeface
   * @example 'Helvetica'
   */
  name: string;
  systemFont: boolean;
  vendor?: string;
  link?: string;
  /**
   * Font-specific metric for capsize.
   * @see https://seek-oss.github.io/capsize/
   */
  fontMetrics: FontMetrics;
};
