import { ERROR_TYPE } from './error.constant.js';

/**
 * Augmented error with known 'name' as ERROR_TYPE
 */
export class AppError extends Error {
  name!: ERROR_TYPE;
  message!: string;
  value?: any;
  stack?: string;
  constructor(options: AppError) {
    super(options.message);
    this.name = options.name as ERROR_TYPE;
    this.stack = options.stack ? options.stack : undefined;
    this.value = options.value ? options.value : undefined;
  }
}
