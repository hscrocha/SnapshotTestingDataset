// @ts-check

/**
 * @type {import('@newrade/core-figma-extractor').Configuration}
 */
const config = {
  outputDir: 'src/figma-tokens',
};

module.exports = config;
