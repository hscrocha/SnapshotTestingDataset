import {
  ionicons5OutlineComponents,
  ioniconsOutlineConfig,
} from '@newrade/core-react-ui-icon-kit-ionicons';
import { IconKit } from '@newrade/core-react-ui-icons';

export const ioniconsOutlineKit: IconKit = {
  config: ioniconsOutlineConfig,
  components: ionicons5OutlineComponents,
};

export default ioniconsOutlineKit;
