import { createGlobalTheme, globalStyle } from '@vanilla-extract/css';

import { scrollbarsVars } from '@newrade/core-css-theme/css';
import { getThemeSelector } from '@newrade/core-css-theme/runtime';
import { getCSSScrollbars } from '@newrade/core-css-theme/utilities-css';

import { scrollbars } from '../design-system/scrollbars-default.theme.js';
import { cssDesignSystemConfig } from '../css/design-system-css.config.js';

/**
 * Scrollbars
 *
 * @see https://css-tricks.com/almanac/properties/s/scrollbar/
 * @see https://css-tricks.com/the-current-state-of-styling-scrollbars/
 *
 * ::-webkit-scrollbar addresses the background of the bar itself. It is usually covered by the other elements
 * ::-webkit-scrollbar-button addresses the directional buttons on the scrollbar
 * ::-webkit-scrollbar-track addresses the empty space "below" the progress bar
 * ::-webkit-scrollbar-track-piece is the top-most layer of the the progress bar not covered by the draggable scrolling element (thumb)
 * ::-webkit-scrollbar-thumb addresses the draggable scrolling element that resizes depending on the size of the scrollable element
 * ::-webkit-scrollbar-corner addresses the (usually) bottom corner of the scrollable element, where two scrollbars might meet
 * ::-webkit-resizer addresses the draggable resizing handle that appears above the scrollbar-corner at the bottom corner of some elements
 */

const cssScrollbars = getCSSScrollbars(scrollbars);

const themeSelector = getThemeSelector({
  config: cssDesignSystemConfig,
  themeId: 'scrollbars-default',
});

createGlobalTheme(themeSelector, scrollbarsVars, cssScrollbars);

globalStyle(`${themeSelector} *::-webkit-scrollbar`, {
  scrollbarWidth: `${scrollbarsVars.sizes.barWidth}`,
  scrollbarColor: `${scrollbarsVars.colors.thumbBackgroundColor}`,
});

globalStyle(`${themeSelector} *::-webkit-scrollbar`, {
  width: scrollbarsVars.sizes.barWidth,
  height: scrollbarsVars.sizes.barHeight, // only applies for horizontal scrollbars
  backgroundColor: scrollbarsVars.colors.backgroundColor,
});

globalStyle(`${themeSelector} *::-webkit-scrollbar-track`, {
  borderRadius: scrollbarsVars.sizes.thumbThumbRadius,
  backgroundColor: scrollbarsVars.colors.backgroundColor,

  WebkitBoxShadow: 'none',
});

globalStyle(`${themeSelector} *::-webkit-scrollbar-thumb`, {
  borderRadius: scrollbarsVars.sizes.thumbThumbRadius,
  backgroundColor: scrollbarsVars.colors.thumbBackgroundColor,
  borderWidth: `${scrollbarsVars.sizes.thumbBorderWidth}`,
  borderStyle: `solid`,
  borderColor: `${scrollbarsVars.colors.thumbBorderColor}`,

  WebkitBoxShadow: 'none',
});
