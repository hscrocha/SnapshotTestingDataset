import { createGlobalTheme } from '@vanilla-extract/css';

import { colorVars } from '@newrade/core-css-theme/css';
import { getThemeSelector } from '@newrade/core-css-theme/runtime';
import { getCSSColorsV2 } from '@newrade/core-css-theme/utilities-css';

import { colors } from '../design-system/colors-default-light.theme.js';
import { cssDesignSystemConfig } from '../css/design-system-css.config.js';

/**
 *
 * Light theme
 *
 */

const cssLightColors = getCSSColorsV2(colors);

const themeSelector = getThemeSelector({
  config: cssDesignSystemConfig,
  themeId: 'colors-default-light',
});

createGlobalTheme(
  themeSelector,
  colorVars,
  // @ts-ignore
  cssLightColors
);
