import { createGlobalTheme } from '@vanilla-extract/css';

import { buttonsVars } from '@newrade/core-css-theme/css';
import { getThemeSelector } from '@newrade/core-css-theme/runtime';
import { getCSSButtons } from '@newrade/core-css-theme/utilities-css';

import { cssDesignSystemConfig } from '../css/design-system-css.config.js';
import { buttons } from '../design-system/buttons-default.theme.js';

const cssButtons = getCSSButtons(buttons);

const themeSelector = getThemeSelector({
  config: cssDesignSystemConfig,
  themeId: 'buttons-default',
});

createGlobalTheme(themeSelector, buttonsVars, cssButtons);
