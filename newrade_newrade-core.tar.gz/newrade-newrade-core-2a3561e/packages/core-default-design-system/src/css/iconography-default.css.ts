import { createGlobalTheme } from '@vanilla-extract/css';

import { iconographyVars } from '@newrade/core-css-theme/css';
import { getThemeSelector } from '@newrade/core-css-theme/runtime';
import { getCSSIconography } from '@newrade/core-css-theme/utilities-css';

import { iconography } from '../design-system/iconography-default.theme.js';
import { cssDesignSystemConfig } from '../css/design-system-css.config.js';

const cssIconography = getCSSIconography(iconography);

const themeSelector = getThemeSelector({
  config: cssDesignSystemConfig,
  themeId: 'iconography-default',
});

createGlobalTheme(themeSelector, iconographyVars, cssIconography);
