import { globalStyle } from '@vanilla-extract/css';

import { resetVars } from '@newrade/core-css-theme/css';
import { getThemeSelector } from '@newrade/core-css-theme/runtime';

import { cssDesignSystemConfig } from '../css/design-system-css.config.js';

const themeSelector = getThemeSelector({
  config: cssDesignSystemConfig,
  themeId: 'resets-default',
});

//
// border-box for everything
//
globalStyle(`${themeSelector} *, ${themeSelector} *::before, ${themeSelector} *::after `, {
  boxSizing: 'border-box',
});

//
// no margin or padding by default
//
globalStyle(`${themeSelector} *`, {
  margin: 0,
  padding: 0,
});

//
// by default no text is selectable
//
globalStyle(`${themeSelector} *`, {
  userSelect: 'none',
  wordBreak: 'break-word',
});

//
// reset font inheritance
//
globalStyle(`${themeSelector} *`, {
  font: 'inherit',
});

//
// set default colors
//
globalStyle(`html${themeSelector}, html${themeSelector} body`, {
  color: resetVars.colors.textColor,
});

//
// set default scrolling behavior
//
globalStyle(`html${themeSelector}, html${themeSelector} body`, {
  overscrollBehavior: 'none',
});

//
// default behavior for svgs
//
globalStyle(`${themeSelector} svg:not(:root)`, {
  overflow: 'visible',
});
