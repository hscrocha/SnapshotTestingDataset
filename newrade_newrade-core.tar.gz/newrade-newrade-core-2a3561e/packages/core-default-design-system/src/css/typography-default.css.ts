import { createGlobalTheme } from '@vanilla-extract/css';

import { typographyVars } from '@newrade/core-css-theme/css';
import { CSSTypographyV2 } from '@newrade/core-css-theme/ds';
import { getThemeSelector } from '@newrade/core-css-theme/runtime';
import { getCSSTypographyV2 } from '@newrade/core-css-theme/utilities-css';

import { cssDesignSystemConfig } from '../css/design-system-css.config.js';
import { typography } from '../design-system/typography-default.js';

export const cssTypography: CSSTypographyV2 = getCSSTypographyV2({
  ...typography,
  baseFontSize: 16,
});

const themeSelector = getThemeSelector({
  config: cssDesignSystemConfig,
  themeId: 'typography-default',
});

createGlobalTheme(themeSelector, typographyVars, cssTypography);
