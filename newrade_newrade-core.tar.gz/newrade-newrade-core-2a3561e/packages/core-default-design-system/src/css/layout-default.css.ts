import { createGlobalTheme, globalStyle } from '@vanilla-extract/css';

import { layoutVars } from '@newrade/core-css-theme/css';
import { CSSLayoutV2 } from '@newrade/core-css-theme/ds';
import { getThemeSelector } from '@newrade/core-css-theme/runtime';
import { getCSSLayoutV2 } from '@newrade/core-css-theme/utilities-css';

import { cssDesignSystemConfig } from '../css/design-system-css.config.js';
import { layout } from '../design-system/layout-default.theme.js';

export const cssLayout: CSSLayoutV2 = getCSSLayoutV2(layout);

const themeSelector = getThemeSelector({
  config: cssDesignSystemConfig,
  themeId: 'layout-default',
});

createGlobalTheme(themeSelector, layoutVars, cssLayout);

globalStyle(themeSelector, {
  vars: {
    /**
     * Mobile
     */
    [cssLayout.varNames.asideWidth]: layoutVars.asideWidth,
    [cssLayout.varNames.contentWidth.desktopBlogMaxWidth]:
      layoutVars.contentWidth.desktopBlogMaxWidth,
    [cssLayout.varNames.contentWidth.desktopDocsMaxWidth]:
      layoutVars.contentWidth.desktopDocsMaxWidth,
    [cssLayout.varNames.contentWidth.desktopMaxWidth]: layoutVars.contentWidth.desktopMaxWidth,

    [cssLayout.varNames.contentMargins]: layoutVars.contentMargins.mobile,
    [cssLayout.varNames.navbarHeight]: layoutVars.navbarHeight.mobile,
    [cssLayout.varNames.sidebarWidth]: layoutVars.sidebarWidth.mobile,
    [cssLayout.varNames.navbarHeight]: layoutVars.navbarHeight.mobile,
    [cssLayout.varNames.footerHeight]: layoutVars.footerHeight.mobile,
  },
  '@media': {
    [cssLayout.media.tablet]: {
      vars: {
        /**
         * Tablet
         */
        [cssLayout.varNames.contentMargins]: layoutVars.contentMargins.tablet,
        [cssLayout.varNames.navbarHeight]: layoutVars.navbarHeight.tablet,
        [cssLayout.varNames.sidebarWidth]: layoutVars.sidebarWidth.tablet,
        [cssLayout.varNames.navbarHeight]: layoutVars.navbarHeight.tablet,
        [cssLayout.varNames.footerHeight]: layoutVars.footerHeight.tablet,
      },
    },
    [cssLayout.media.desktopSmall]: {
      vars: {
        /**
         * Desktop
         */
        [cssLayout.varNames.contentMargins]: layoutVars.contentMargins.desktop,
        [cssLayout.varNames.navbarHeight]: layoutVars.navbarHeight.desktop,
        [cssLayout.varNames.sidebarWidth]: layoutVars.sidebarWidth.desktop,
        [cssLayout.varNames.navbarHeight]: layoutVars.navbarHeight.desktop,
        [cssLayout.varNames.footerHeight]: layoutVars.footerHeight.desktop,
      },
    },
  },
});
