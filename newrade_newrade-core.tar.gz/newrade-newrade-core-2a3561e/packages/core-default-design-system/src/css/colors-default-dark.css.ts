import { createGlobalTheme } from '@vanilla-extract/css';

import { colorVars } from '@newrade/core-css-theme/css';
import { getThemeSelector } from '@newrade/core-css-theme/runtime';
import { getCSSColorsV2 } from '@newrade/core-css-theme/utilities-css';

import { cssDesignSystemConfig } from '../css/design-system-css.config.js';
import { colorsDark } from '../design-system/colors-default-dark.theme.js';

/**
 *
 * Dark theme
 *
 */

const cssDarkColors = getCSSColorsV2(colorsDark);

const themeSelector = getThemeSelector({
  config: cssDesignSystemConfig,
  themeId: 'colors-default-dark',
});

createGlobalTheme(
  themeSelector,
  colorVars,
  // @ts-ignore
  cssDarkColors
);
