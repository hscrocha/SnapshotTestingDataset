import { CSSDesignSystemConfig } from '@newrade/core-css-theme/ds';
import { COLOR_SCHEME } from '@newrade/core-design-system';

/**
 *
 * Default css design system configuration object
 *
 */
export const cssDesignSystemConfig: CSSDesignSystemConfig = {
  id: 'core-default-design-system',
  runtime: {
    prefix: 'global',
  },
  colors: {
    name: 'Colors',
    preferredThemeId: 'colors-default-dark',
    themes: [
      {
        id: 'colors-default-light',
        name: 'Light',
        default: true,
        colorScheme: COLOR_SCHEME.LIGHT,
      },
      {
        id: 'colors-default-dark',
        name: 'Dark',
        default: false,
        colorScheme: COLOR_SCHEME.DARK,
      },
    ],
  },
  sizing: {
    name: 'Sizing',
    themes: [
      {
        id: 'sizing-default',
        name: 'Default',
        default: true,
      },
    ],
  },
  typography: {
    name: 'Typography',
    themes: [
      {
        id: 'typography-default',
        name: 'Default',
        default: true,
      },
    ],
  },
  iconography: {
    name: 'Iconography',
    themes: [
      {
        id: 'iconography-default',
        name: 'Default',
        default: true,
      },
    ],
  },
  effects: {
    name: 'Effects',
    themes: [
      {
        id: 'effects-default',
        name: 'Default',
        default: true,
      },
    ],
  },
  layout: {
    name: 'Layout',
    themes: [
      {
        id: 'layout-default',
        name: 'Default',
        default: true,
      },
    ],
  },
  components: {
    logos: {
      name: 'Logos',
      themes: [
        {
          id: 'logos-default',
          name: 'Default',
          default: true,
        },
      ],
    },
    buttons: {
      name: 'Buttons',
      themes: [
        {
          id: 'buttons-default',
          name: 'Default',
          default: true,
        },
      ],
    },
  },
  others: {
    resets: {
      name: 'Resets',
      themes: [
        {
          id: 'resets-default',
          name: 'Default',
          default: true,
        },
      ],
    },
    scrollbars: {
      name: 'Scrollbars',
      themes: [
        {
          id: 'scrollbars-default',
          name: 'Default',
          default: true,
        },
      ],
    },
  },
};
