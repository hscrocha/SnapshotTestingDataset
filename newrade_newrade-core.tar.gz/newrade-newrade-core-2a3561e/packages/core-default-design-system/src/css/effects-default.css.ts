import { createGlobalTheme } from '@vanilla-extract/css';

import { effectsVars } from '@newrade/core-css-theme/css';
import { getThemeSelector } from '@newrade/core-css-theme/runtime';
import { getCSSEffects } from '@newrade/core-css-theme/utilities-css';

import { cssDesignSystemConfig } from '../css/design-system-css.config.js';
import { effects } from '../design-system/effects-default.theme.js';

const cssEffects = getCSSEffects(effects);

const themeSelector = getThemeSelector({
  config: cssDesignSystemConfig,
  themeId: 'effects-default',
});

createGlobalTheme(themeSelector, effectsVars, cssEffects);
