import { COLOR_SCHEME, DesignSystemConfig } from '@newrade/core-design-system';

import { buttons } from './buttons-default.theme.js';
import { colorsDark } from './colors-default-dark.theme.js';
import { colors } from './colors-default-light.theme.js';
import { effects } from './effects-default.theme.js';
import { iconography } from './iconography-default.theme.js';
import { layout } from './layout-default.theme.js';
import { resets } from './resets-default.theme.js';
import { scrollbars } from './scrollbars-default.theme.js';
import { sizing } from './sizing-default.theme.js';
import { typography } from './typography-default.js';

/**
 *
 * Default design system configuration object
 *
 */
export const designSystemConfig: DesignSystemConfig = {
  id: '',
  runtime: {
    prefix: 'global',
  },
  colors: {
    name: 'Colors',
    preferredThemeId: 'colors-default-dark',
    themes: [
      {
        id: 'colors-default-light',
        name: 'Light',
        default: true,
        colorScheme: COLOR_SCHEME.LIGHT,
        colors: colors,
      },
      {
        id: 'colors-default-dark',
        name: 'Dark',
        default: false,
        colorScheme: COLOR_SCHEME.DARK,
        colors: colorsDark,
      },
    ],
  },
  sizing: {
    name: 'Sizing',
    themes: [
      {
        id: 'sizing-default',
        name: 'Default',
        default: true,
        sizing: sizing,
      },
    ],
  },
  typography: {
    name: 'Typography',
    themes: [
      {
        id: 'typography-default',
        name: 'Default',
        default: true,
        typography: typography,
      },
    ],
  },
  iconography: {
    name: 'Iconography',
    themes: [
      {
        id: 'iconography-default',
        name: 'Default',
        default: true,
        iconography: iconography,
      },
    ],
  },
  effects: {
    name: 'Effects',
    themes: [
      {
        id: 'effects-default',
        name: 'Default',
        default: true,
        effects: effects,
      },
    ],
  },
  layout: {
    name: 'Layout',
    themes: [
      {
        id: 'layout-default',
        name: 'Default',
        default: true,
        layout: layout,
      },
    ],
  },
  components: {
    logos: {
      name: 'Logos',
      themes: [
        {
          id: 'logos-default',
          name: 'Default',
          default: true,
        },
      ],
    },
    buttons: {
      name: 'Buttons',
      themes: [
        {
          id: 'buttons-default',
          name: 'Default',
          default: true,
          buttons: buttons,
        },
      ],
    },
  },
  others: {
    resets: {
      name: 'Resets',
      themes: [
        {
          id: 'reset-default',
          name: 'Default',
          default: true,
          resets: resets,
        },
      ],
    },
    scrollbars: {
      name: 'Scrollbars',
      themes: [
        {
          id: 'scrollbars-default',
          name: 'Default',
          default: true,
          scrollbars: scrollbars,
        },
      ],
    },
  },
};
