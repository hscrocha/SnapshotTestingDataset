import { colorVars } from '@newrade/core-css-theme/css';
import { defaultResets } from '@newrade/core-css-theme/defaults';
import { Resets } from '@newrade/core-design-system';

export const resets: Resets = {
  ...defaultResets,
  vars: {
    colors: {
      textColor: colorVars.colorIntents.primaryText,
      backgroundColor: colorVars.colorIntents.elevation0,
    },
  },
};
