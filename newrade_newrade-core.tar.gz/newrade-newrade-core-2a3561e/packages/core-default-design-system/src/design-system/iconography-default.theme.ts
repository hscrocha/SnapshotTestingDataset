import { defaultIconography } from '@newrade/core-css-theme/defaults';
import { Iconography } from '@newrade/core-design-system';

export const iconography: Iconography = {
  ...defaultIconography,
};
