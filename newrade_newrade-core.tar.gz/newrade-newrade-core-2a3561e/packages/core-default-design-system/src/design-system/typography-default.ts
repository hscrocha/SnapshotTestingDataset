import { typographyVars } from '@newrade/core-css-theme/css';
import { defaultTypography } from '@newrade/core-css-theme/defaults';
import { Fonts, TypographyV2 } from '@newrade/core-design-system';

export const fonts: Fonts = defaultTypography.fonts;

export const typography: TypographyV2 = {
  ...defaultTypography,
  vars: {
    titles: {
      fontFamily: typographyVars.fonts.sans,
    },
  },
};
