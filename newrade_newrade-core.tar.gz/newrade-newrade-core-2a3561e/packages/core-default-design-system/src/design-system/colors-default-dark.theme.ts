import {
  defaultColorIntentsDark,
  defaultColorsColorsDark,
  defaultColorsGradientsDark,
} from '@newrade/core-css-theme/defaults';
import { COLOR_SCHEME, Colors } from '@newrade/core-design-system';

export const colorsDark: Colors = {
  colorScheme: COLOR_SCHEME.DARK,
  colors: defaultColorsColorsDark,
  colorIntents: defaultColorIntentsDark,
  gradients: defaultColorsGradientsDark,
};
