import { defaultButtons } from '@newrade/core-css-theme/defaults';
import { Buttons } from '@newrade/core-design-system';

export const buttons: Buttons = {
  ...defaultButtons,
  //
  // vars: reference to colorVars
};
