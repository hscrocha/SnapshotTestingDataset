import { colorVars } from '@newrade/core-css-theme/css';
import { defaultScrollbars } from '@newrade/core-css-theme/defaults';
import { Scrollbars } from '@newrade/core-design-system';

export const scrollbars: Scrollbars = {
  ...defaultScrollbars,
  vars: {
    colors: {
      thumbBorderColor: colorVars.colorIntents.elevation0,
      thumbBackgroundColor: colorVars.colors.grey[300],
      backgroundColor: colorVars.colorIntents.elevation0,
    },
  },
};
