import { defaultSizing } from '@newrade/core-css-theme/defaults';

export const sizing = defaultSizing;
