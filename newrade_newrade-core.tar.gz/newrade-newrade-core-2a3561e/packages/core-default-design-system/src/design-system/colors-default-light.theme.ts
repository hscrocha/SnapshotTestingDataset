import {
  defaultColorIntents,
  defaultColorsColors,
  defaultColorsGradients,
} from '@newrade/core-css-theme/defaults';
import { COLOR_SCHEME, Colors } from '@newrade/core-design-system';

export const colors: Colors = {
  colorScheme: COLOR_SCHEME.LIGHT,
  colors: defaultColorsColors,
  colorIntents: defaultColorIntents,
  gradients: defaultColorsGradients,
};
