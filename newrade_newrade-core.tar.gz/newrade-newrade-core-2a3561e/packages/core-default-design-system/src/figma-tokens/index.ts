/**
 *
 * The /figma-tokens entry point contains generated files from the figma-extractor command (see core-figma-extractor)
 *
 */

export * from './figma-colors.js';
