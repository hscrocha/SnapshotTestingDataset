/// <reference path="../../core-types/src/svg.d.ts" />
/// <reference path="../../core-types/src/github-slugger.d.ts" />

/**
 *
 * The /index entry point contains design system values
 *
 */

export * from './assets/logos/logos-default/index.js';
export * from './design-system/buttons-default.theme.js';
export * from './design-system/colors-default-dark.theme.js';
export * from './design-system/colors-default-light.theme.js';
export * from './design-system/design-system.config.js';
export * from './design-system/effects-default.theme.js';
export * from './design-system/iconography-default.theme.js';
export * from './design-system/layout-default.theme.js';
export * from './design-system/resets-default.theme.js';
export * from './design-system/scrollbars-default.theme.js';
export * from './design-system/typography-default.js';
