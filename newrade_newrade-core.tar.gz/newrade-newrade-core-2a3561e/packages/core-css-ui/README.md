# Core CSS UI

This package contains style definitions (`.css.ts`) that

- injects CSS variables needed for themes of the design system
- apply a few resets on native html elements

Additionally, we have styles that compile down to a minimal CSS-only framework
that can be used to apply basic styles (colors, typography, etc.) to HTML
markup.

The CSS-only solution can be useful if you are building applications in
non-JS/React environments.

## Non-JS Usage

// TODO

## React Usage

**Note for Core React UI users**: theme and reset styles are already imported by
the `CSSThemeProvider` component, so there is no need to manually include the
files in this package.
