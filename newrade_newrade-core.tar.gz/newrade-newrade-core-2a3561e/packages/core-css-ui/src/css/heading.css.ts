import { globalStyle } from '@vanilla-extract/css';

const GLOBAL_TYPOGRAPHY_CLASSNAME = `global-css-theme-cdpq-typography`;

import { layoutCSS, typographyVars } from '@newrade/core-css-theme/css';
import { getNormalTextStyles } from '@newrade/core-css-theme/utilities-vanilla-extract';

globalStyle(`.${GLOBAL_TYPOGRAPHY_CLASSNAME} h1.h1`, {
  fontFamily: typographyVars.headings.fontFamily,
  wordBreak: 'normal',
  userSelect: 'text',

  fontWeight: typographyVars.headings.mobile.h1.fontWeight,
  ...getNormalTextStyles(typographyVars.headings.mobile.h1.capsize),
  '@media': {
    [layoutCSS.media.tablet]: getNormalTextStyles(typographyVars.headings.tablet.h1.capsize),
    [layoutCSS.media.desktopSmall]: getNormalTextStyles(typographyVars.headings.desktop.h1.capsize),
  },
});

globalStyle(`.${GLOBAL_TYPOGRAPHY_CLASSNAME} .text--readably-width`, {
  maxWidth: '25ch',
});
