import debug from 'debug';

import { logger } from '@newrade/core-node-utils';

/**
 * Default CLI debug/log namespace
 */
export const NS = 'nr:cli';

/**
 *
 * debug configuration
 *
 */

export const debugInstance = debug;

/**
 *
 * logger configuration
 *
 */

export const processWrite = (msg: any) => process.stdout.write.bind(process.stdout)(`${msg}\n`);

export const log = logger(NS, { printMethod: processWrite });
export const logWarn = logger(`${NS}:warn`, { printMethod: processWrite });
export const logError = logger(`${NS}:error`, { printMethod: processWrite });
