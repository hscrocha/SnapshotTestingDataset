import { spawnSync } from 'child_process';
import fs from 'fs';
import path from 'path';

import { Config, Flags } from '@oclif/core';
import prettier from 'prettier';

import { getShellForPlatform } from '@newrade/core-node-utils';

import { BaseCommand } from '../base-command.js';

type PackageJsonWorkspaces =
  | {
      workspaces?: {
        packages?: string[];
      };
    }
  | undefined;

/**
 * Command that execute `lerna version` but let the user include only the packages to version bump
 *
 * To include only packages prefixed with my-org-* in a release, run:
 *
 * ```bash
 * lerna-version --packages=my-org/*
 * ```
 *
 * which is equivalent to set the workspaces temporarily as:
 * ```json
 * "workspaces": {
 *   "packages": [
 *     "packages/my-org/*"
 *   ]
 * },
 * ```
 *
 * Once the command is finished or cancelled the `workspaces.packages` prop will be set back to its original value
 */
export default class LernaVersion extends BaseCommand {
  static description =
    'Wrapper for lerna version command, allowing to run version on specific packages';

  static examples = [`$ nr lerna-version`];

  static args = [{ name: 'args' }];

  static flags = {
    packages: Flags.string({
      description: 'packages glob to be included in lerna version bump, e.g. --packages=packages/*',
      required: false,
    }),
  };

  constructor(argv: string[], config: Config) {
    super(argv, config, { name: 'lerna' });
  }

  async run() {
    const { args, flags } = await this.parse(LernaVersion);

    this.log(`running in ${process.cwd()}`);

    try {
      /**
       *
       * Prettier
       *
       */

      const prettierOptions = await prettier.resolveConfig(
        path.join(process.cwd(), '.prettierrc'),
        { useCache: false, editorconfig: true }
      );
      function format(str: string): string {
        return prettier.format(str, {
          ...prettierOptions,
          parser: 'json-stringify',
        });
      }

      /**
       *
       * Command
       *
       */

      this.log(`reading package.json's workspaces config`);

      const packageJsonFilePath = path.resolve(process.cwd(), 'package.json');
      const packageJsonFile = fs.readFileSync(packageJsonFilePath, {
        encoding: 'utf8',
      });
      const packageJson = JSON.parse(packageJsonFile) as PackageJsonWorkspaces;

      if (!packageJson?.workspaces?.packages?.length) {
        this.logWarn(`missing packages in package.workspaces, aborting command`);
        return;
      }

      if (flags.packages?.length) {
        this.log(
          `replacing workspace.packages value with: ${this.chalk.greenBright(flags.packages)}`
        );
      }

      const temporaryPackageJson = flags.packages?.length
        ? JSON.stringify(
            {
              ...packageJson,
              workspaces: { packages: [flags.packages] },
            } as PackageJsonWorkspaces,
            null,
            2
          )
        : JSON.stringify(packageJson, null, 2);

      fs.writeFileSync(packageJsonFilePath, format(temporaryPackageJson));

      this.log(`updating index for package.json as --assume-unchanged`);

      assumeUnchanged('package.json');

      this.log(`executing lerna version`);

      const command = spawnSync(`yarn lerna version ${args.args || ''}`, {
        shell: getShellForPlatform(),
        stdio: 'inherit',
        env: process.env,
      });

      this.log(`restoring original package.json`);

      fs.writeFileSync(packageJsonFilePath, format(JSON.stringify(packageJson, null, 2)), {
        encoding: 'utf8',
      });

      this.log(`updating index for package.json as --no-assume-unchanged`);

      unAssumeUnchanged('package.json');
    } catch (error: any) {
      this.logError(`error occured, aborting: ${error}`);
      this.log(`updating index for package.json as --no-assume-unchanged`);
      unAssumeUnchanged('package.json');
    }

    function assumeUnchanged(filename: string) {
      spawnSync(`git update-index --assume-unchanged ${filename}`, {
        shell: getShellForPlatform(),
        stdio: 'inherit',
        env: process.env,
      });
    }

    function unAssumeUnchanged(filename: string) {
      spawnSync(`git update-index --no-assume-unchanged ${filename}`, {
        shell: getShellForPlatform(),
        stdio: 'inherit',
        env: process.env,
      });
    }
  }
}
