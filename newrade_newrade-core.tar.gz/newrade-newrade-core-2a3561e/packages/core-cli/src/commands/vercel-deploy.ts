import { spawnSync } from 'child_process';

import { Config, Flags } from '@oclif/core';
import { InferType, object, string } from 'yup';

import { getShellForPlatform, loadDotEnv } from '@newrade/core-node-utils';

import { BaseCommand } from '../base-command.js';

type ENV = InferType<typeof Env>;
let Env = object({
  VERCEL_PROJECT_ID: string().required(),
  VERCEL_ORG_ID: string().required(),
  VERCEL_TOKEN: string().required(),
  VERCEL_SCOPE: string().required(),
});

export default class VercelDeploy extends BaseCommand {
  static description = 'deploy site with vercel using env variables';

  static examples = [`$ nr vercel-deploy`];

  static flags = {
    help: Flags.help({ char: 'h' }),
  };

  static args = [];

  constructor(argv: string[], config: Config) {
    super(argv, config, { name: 'vercel-deploy' });
  }

  async init() {}

  async run() {
    this.log(`running in ${process.cwd()}`);
    this.log('validating env variables');
    this.log('loading .env file');

    const env = loadDotEnv<ENV>({
      schema: Env,
      dotEnvPath: '.env',
      dotEnvRootPath: '../../.env',
      packageName: 'core-cli',
    });

    this.log('running vercel deploy');

    // use yarn to use the locally installed vercel-cli
    spawnSync(`yarn vercel public --token $VERCEL_TOKEN --scope $VERCEL_SCOPE --confirm`, {
      cwd: '.',
      shell: getShellForPlatform(),
      stdio: 'inherit',
      env: env,
    });

    this.log('done! ✅');
  }
}
