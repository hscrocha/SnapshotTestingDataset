import path from 'path';

import { Config, Flags } from '@oclif/core';

import { Configuration, ENV, Env, extract } from '@newrade/core-figma-extractor';
import { loadConfigFile, loadDotEnv } from '@newrade/core-node-utils';

import { BaseCommand } from '../base-command.js';

export default class FigmaExtractor extends BaseCommand {
  static description = 'sync design tokens from figma file';

  static examples = [`$ nr figma-sync`];

  static flags = {
    test: Flags.boolean({
      char: 't',
      description:
        'the test flag is used in integration tests, it will not output versions or dates',
    }),
    help: Flags.help({ char: 'h' }),
  };

  static args = [{ name: 'path', description: 'relative output path' }];

  constructor(argv: string[], config: Config) {
    super(argv, config, { name: 'figma-extractor' });
  }

  async run() {
    // import '@newrade/core-figma-extractor' with dynamic import since deps(lodash-es are not packaged as CJS)
    // const _importDynamic = new Function('modulePath', 'return import(modulePath)');
    // const { extract, configurationSchema } = (await _importDynamic(
    //   '@newrade/core-figma-extractor'
    // )) as typeof import('@newrade/core-figma-extractor');

    this.log(`loading configuration`);
    const configResult = loadConfigFile<Configuration>('figma-extractor');

    if (!configResult) {
      this.logError(
        `could not find a configuration file, did you create a figma-extractor.config.cjs file?`
      );
      this.logError(`aborting`);
      throw new Error('missing configuration file');
    }

    this.log(`found configuration file: ${configResult.filepath}`);

    const config = configResult.config;

    const env = loadDotEnv<ENV>({
      schema: Env,
      dotEnvPath: '.env',
      packageName: 'core-cli',
    });

    this.log(`found ENV variables`);

    const { args, flags } = await this.parse(FigmaExtractor);

    this.log(`running: extract command`);
    this.log(`test flag passed, disabling date and version in output`);

    await extract({
      figmaFile: env.FIGMA_FILE,
      figmaToken: env.FIGMA_TOKEN,
      ...config,
      outputDate: flags.test ? false : true,
      outputVersion: flags.test ? false : true,
    });

    this.log(`running: extract command`);
  }
}
