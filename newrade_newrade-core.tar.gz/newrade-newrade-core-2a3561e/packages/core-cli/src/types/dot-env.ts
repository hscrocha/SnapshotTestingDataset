import { InferType, string } from 'yup';

import { CommonEnv } from '@newrade/core-node-utils';

/**
 * Local, typed representation of the .env file.
 */
export const Env = CommonEnv.shape({
  /**
   * Figma
   */
  FIGMA_TOKEN: string(),
  FIGMA_FILE: string(),
});
export type ENV = InferType<typeof Env>;
