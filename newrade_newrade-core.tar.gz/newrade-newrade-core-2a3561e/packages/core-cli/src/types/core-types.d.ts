/**
 * @see https://www.typescriptlang.org/docs/handbook/triple-slash-directives.html#-reference-types-
 */
/// <reference path="../../core-types/src/morgan.d.ts" />
/// <reference path="../../core-types/src/copy-webpack-plugin.d.ts" />
