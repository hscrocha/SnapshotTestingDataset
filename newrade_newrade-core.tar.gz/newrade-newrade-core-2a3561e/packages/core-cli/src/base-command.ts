import { Command, Config } from '@oclif/core';
import chalk from 'chalk';
import debug from 'debug';

import { logger } from '@newrade/core-node-utils';

import {
  debugInstance,
  log,
  logError,
  logWarn,
  NS,
  processWrite,
} from './utilities/log.utilities.js';

export class BaseCommand extends Command {
  chalk = chalk;
  commandConfig;
  log = log;
  logWarn = logWarn;
  logError = logError;

  logDebug: debug.Debugger = debugInstance(`${NS}`);
  logWarnDebug: debug.Debugger = debugInstance(`${NS}:warn`);
  logErrorDebug: debug.Debugger = debugInstance(`${NS}:error`);

  constructor(argv: string[], config: Config, commandConfig?: { name?: string }) {
    super(argv, config);

    if (commandConfig?.name) {
      //
      // save configuration
      //
      this.commandConfig = commandConfig;

      //
      // configure the debug instance
      //
      this.logDebug = debugInstance(`${NS}:${commandConfig.name}`);
      this.logWarnDebug = debugInstance(`${NS}:${commandConfig.name}:warn`);
      this.logErrorDebug = debugInstance(`${NS}:${commandConfig.name}:error`);

      //
      // set the logger output to the same color as the debug instance
      //
      const debugColor = Number(this.logDebug.color);
      const colorText = this.chalk.ansi256(debugColor);
      this.log = logger(colorText(`${NS}:${this.commandConfig.name}`), {
        printMethod: processWrite,
      });
      this.logWarn = logger(colorText(`${NS}:${this.commandConfig.name}:warn`), {
        printMethod: processWrite,
      });
      this.logError = logger(colorText(`${NS}:${this.commandConfig.name}:error`), {
        printMethod: processWrite,
      });
    }
  }

  async run() {}
}
