import { InferType, object, string } from 'yup';

export const Env = object({
  /**
   * The master repository's git host
   * @default 'github.com'
   */
  MASTER_GIT_HOST: string().required(),
  /**
   * The master repository's organization
   * @example '@newrade'
   */
  MASTER_REPO_ORG: string().required(),
  /**
   * The master repository's name
   * @example 'repo-name' in @<org>/<repo-name>
   */
  MASTER_REPO_NAME: string().required(),
  /**
   * The repository git host
   * @default 'github.com'
   */
  PROJECT_GIT_HOST: string().required(),
  /**
   * The repository's organization
   * @example '@newrade'
   */
  PROJECT_REPO_ORG: string().required(),
  /**
   * The repository name
   * @example 'repo-name' in @<org>/<repo-name>
   */
  PROJECT_REPO_NAME: string().required(),
});
export type ENV = InferType<typeof Env>;

// scriptLog(`forking master repo...`);

// const clone = spawn(
//   `git clone --bare git@${dotEnvProcess.MASTER_GIT_HOST}:${dotEnvProcess.MASTER_REPO_ORG}/${dotEnvProcess.MASTER_REPO_NAME}.git \
//   cd ${dotEnvProcess.MASTER_REPO_NAME}`,
//   {
//     cwd: '..',
//     shell: getShellForPlatform(),
//     stdio: 'inherit',
//     env: process.env,
//   }
// );

// const cd = spawn(
//   `git clone --bare git@${dotEnvProcess.MASTER_GIT_HOST}:${dotEnvProcess.MASTER_REPO_ORG}/${dotEnvProcess.MASTER_REPO_NAME}.git`,
//   {
//     cwd: '..',
//     shell: getShellForPlatform(),
//     stdio: 'inherit',
//     env: process.env,
//   }
// );
