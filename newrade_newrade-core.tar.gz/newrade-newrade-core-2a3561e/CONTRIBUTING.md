# Contributing

We welcome feedback, bug reports or features suggestion.

Please follow our guides on how to setup your dev environment and on how to fork
and submit a PR.
