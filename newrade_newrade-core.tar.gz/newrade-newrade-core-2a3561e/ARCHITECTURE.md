# Architecture

See our repository architecture documentation
[here](https://zedesignsystem.com/core-docs/architecture)
