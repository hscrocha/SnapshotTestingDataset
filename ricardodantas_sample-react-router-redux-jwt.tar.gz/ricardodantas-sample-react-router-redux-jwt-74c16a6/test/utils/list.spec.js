import List from '../../src/utils/list'

describe('List', () => {

  it('should has getList method', () => {
    expect(List.getList).toBeDefined()
  })

})
