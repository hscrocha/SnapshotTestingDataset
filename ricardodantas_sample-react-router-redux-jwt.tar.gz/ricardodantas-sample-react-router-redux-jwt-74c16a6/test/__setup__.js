require('./__mocks__/sessionStorage')
global.axios = require('axios')
