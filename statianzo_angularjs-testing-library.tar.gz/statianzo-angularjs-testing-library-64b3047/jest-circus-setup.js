// Shim for angular-mocks
window.jasmine = window.jasmine || {};