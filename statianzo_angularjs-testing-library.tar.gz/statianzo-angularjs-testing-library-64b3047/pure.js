// makes it so people can import from 'angular-testing-library/pure'
module.exports = require('./dist/pure')
