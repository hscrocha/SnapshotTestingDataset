import React from 'react';

const Spiner = () => {
  return (
    <section className="spiner">
      <div className="spiner__wrapper">
        <div className="spiner__spiner">
          <div></div>
        </div>
      </div>
    </section>
  );
};

export default Spiner;
