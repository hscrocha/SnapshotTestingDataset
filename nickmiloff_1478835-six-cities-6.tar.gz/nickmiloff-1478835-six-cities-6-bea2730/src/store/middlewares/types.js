export const REDIRECT_TO_ROUTE = `middlewares/redirectToRoute`;
