export const SET_AUTH = `app/setAuth`;
