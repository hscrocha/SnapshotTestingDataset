export const getIsAuth = (state) => !!state.app.authorized;
export const getUser = (state) => state.app.authorized;
