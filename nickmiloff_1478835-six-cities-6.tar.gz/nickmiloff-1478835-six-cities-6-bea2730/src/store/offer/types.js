export const SET_OFFER = `offer/setOffer`;
export const SET_NEARBY = `offer/setNearby`;
export const SET_REVIEWS = `offer/setReviews`;
export const SET_LOADED = `offer/setLoaded`;
export const SET_REVIEW_LOADED = `offer/setReviewLoaded`;
export const CHANGE_NEARBY = `offer/changeNearby`;
