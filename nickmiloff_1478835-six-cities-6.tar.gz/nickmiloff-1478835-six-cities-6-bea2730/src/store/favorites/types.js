export const SET_CARDS = `favorites/setCards`;
export const SET_LOADED = `favorites/setLoaded`;
export const CHANGE_CARD = `favorites/changeCard`;
