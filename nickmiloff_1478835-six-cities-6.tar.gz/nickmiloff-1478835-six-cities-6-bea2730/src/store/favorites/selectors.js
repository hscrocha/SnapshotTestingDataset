export const getCards = (state) => state.favorites.cards;
export const getIsLoaded = (state) => state.favorites.loaded;
