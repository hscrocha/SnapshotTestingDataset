export const SET_LOCATION = `main/setLocation`;
export const SET_CARDS = `main/setCards`;
export const SET_TYPE = `main/setType`;
export const SET_LOADED = `main/setLoaded`;
export const CHANGE_CARD = `main/changeCard`;
