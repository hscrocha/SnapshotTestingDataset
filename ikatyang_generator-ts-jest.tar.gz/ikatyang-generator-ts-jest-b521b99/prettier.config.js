module.exports = require("prettier-config-ikatyang");
