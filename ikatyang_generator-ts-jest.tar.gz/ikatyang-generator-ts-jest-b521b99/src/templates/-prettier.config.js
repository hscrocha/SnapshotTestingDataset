module.exports = <%- prettier_config_preset.length === 0 ? '{}' : `require('${prettier_config_preset}')` %>;
