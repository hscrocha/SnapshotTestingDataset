export { default as App } from "./app.component";
export { default as router } from "./app.routes";
