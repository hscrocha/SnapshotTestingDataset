export { default as NotFound } from "./not-found.component";
