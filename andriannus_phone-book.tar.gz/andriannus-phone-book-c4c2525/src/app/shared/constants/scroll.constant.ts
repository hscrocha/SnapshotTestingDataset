export const SCROLL_INTERVAL = 15;
export const SCROLL_STEP_DIVIDER = 30;
