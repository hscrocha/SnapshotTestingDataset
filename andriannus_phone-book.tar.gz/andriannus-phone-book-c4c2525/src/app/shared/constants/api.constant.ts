export const API = {
  baseUrl: "https://randomuser.me/api",
  timeout: 10000,
};
