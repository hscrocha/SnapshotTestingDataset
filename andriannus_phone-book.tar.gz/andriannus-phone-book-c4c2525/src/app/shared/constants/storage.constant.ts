export const QOA_POSITION_X = "_qoaX";
export const QOA_POSITION_Y = "_qoaY";
export const QOA_USERS = "_qoaUsers";
