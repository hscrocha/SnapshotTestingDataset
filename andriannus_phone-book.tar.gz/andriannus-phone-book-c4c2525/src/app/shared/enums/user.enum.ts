export enum UserColor {
  Blue = "blue",
  Green = "green",
  Red = "red",
}

export enum UserSort {
  City = "city",
  Color = "color",
}
