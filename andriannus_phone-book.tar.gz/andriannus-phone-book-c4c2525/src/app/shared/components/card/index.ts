export { default as QoaCard } from "./card.component";
