export { default as QoaButtonToTop } from "./button-to-top.component";
