export interface ButtonToTopState {
  isShowButton: boolean;
}
