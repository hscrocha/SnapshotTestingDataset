export { default as QoaButtonToLeft } from "./button-to-left.component";
