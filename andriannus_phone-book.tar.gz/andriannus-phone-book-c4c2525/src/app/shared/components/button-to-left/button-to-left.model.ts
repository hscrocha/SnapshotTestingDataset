export interface ButtonToLeftState {
  container: Element | null;
  isShowButton: boolean;
}
