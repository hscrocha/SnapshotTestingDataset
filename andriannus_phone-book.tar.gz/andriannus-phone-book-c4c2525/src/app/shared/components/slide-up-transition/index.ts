export { default as QoaSlideUpTransition } from "./slide-up-transition.component";
