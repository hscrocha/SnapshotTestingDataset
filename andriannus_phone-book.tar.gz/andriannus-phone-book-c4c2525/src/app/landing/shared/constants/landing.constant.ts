export const QUERY_PARAMS =
  "?results=100&inc=name,dob,registered,email,location,picture";
