export interface LandingMobileState {
  container: Element | null;
  scrollTop: number;
}
