export interface LandingDesktopState {
  container: Element | null;
}
