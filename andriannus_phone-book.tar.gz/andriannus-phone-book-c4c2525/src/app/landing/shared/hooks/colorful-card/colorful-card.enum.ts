export enum CardClass {
  Blue = "BgColor-secondary",
  Default = "",
  Green = "BgColor-primary",
  Red = "BgColor-danger",
}
