import { CardClass } from "./colorful-card.enum";

export interface ColorfulCardState {
  colorfulCard: CardClass;
}
