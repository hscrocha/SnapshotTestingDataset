---
name: Bug report
about: Create a report to help us improve
title: ''
labels: ''
assignees: ''

---

Follow these steps:

https://github.com/risenforces/craco-alias#ran-into-a-problem

Then describe your problem and paste the plugin output.
