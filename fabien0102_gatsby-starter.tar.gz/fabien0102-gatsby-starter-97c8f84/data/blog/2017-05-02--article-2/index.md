---
title: 'Article #2'
createdDate: '2017-05-02'
updatedDate: '2017-05-06'
author: Fabien BERNARD
tags:
  - test
image: cup-of-coffee-laptop-office-macbook-89786.jpeg
draft: false
---

My awesome article

## TODO

-   [x] Replace image
-   [ ] Write an awesome article
