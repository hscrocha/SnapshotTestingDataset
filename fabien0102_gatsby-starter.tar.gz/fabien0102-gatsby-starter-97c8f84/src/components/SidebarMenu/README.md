# SidebarMenu component

Sidebar menu component.

## Source

    <SidebarMenu visible={visible}  />
