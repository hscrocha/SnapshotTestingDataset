# BlogPagination component

Blog pagination component.

## Source

    <BlogPagination pathname={pathname}  Link={Link}  pageCount={pageCount}  />
