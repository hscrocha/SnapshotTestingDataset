type ErrorResponse = {
  response?: { status: number }
}

export type ErrorApi = ErrorResponse
