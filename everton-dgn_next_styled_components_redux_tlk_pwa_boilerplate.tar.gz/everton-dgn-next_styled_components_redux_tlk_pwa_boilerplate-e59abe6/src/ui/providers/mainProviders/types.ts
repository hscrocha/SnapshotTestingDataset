import { ReactNode } from 'react'

export type MainProvidersProps = {
  children: ReactNode
  setTheme?: 'dark' | 'light'
}
