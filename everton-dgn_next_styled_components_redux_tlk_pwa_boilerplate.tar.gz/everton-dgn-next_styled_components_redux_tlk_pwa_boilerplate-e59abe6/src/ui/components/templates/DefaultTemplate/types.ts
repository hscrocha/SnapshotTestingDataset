import { ReactNode } from 'react'

export type DefaultProps = { children: ReactNode }
