import { ReactNode } from 'react'

export type ErrorProps = { children: ReactNode }
