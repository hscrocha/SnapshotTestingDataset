import { ReactNode } from 'react'

export type ExampleProps = { children: ReactNode }
