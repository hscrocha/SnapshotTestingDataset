export type TitleProps = {
  title: string
}
