export const windowSizes = {
  sm: 0,
  md: 600,
  lg: 1024
}
