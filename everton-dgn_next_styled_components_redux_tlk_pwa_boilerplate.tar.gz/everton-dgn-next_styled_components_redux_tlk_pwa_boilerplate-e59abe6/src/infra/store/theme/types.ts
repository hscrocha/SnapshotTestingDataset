export type ThemeType = {
  isDark: boolean
}
