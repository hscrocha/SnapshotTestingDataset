export type GetClientType = {
  data: []
  error: string
}
