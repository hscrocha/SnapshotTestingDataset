import Home from './home/index.page'
export default Home
