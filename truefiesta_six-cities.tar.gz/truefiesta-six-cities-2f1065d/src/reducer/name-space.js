const NameSpace = {
  ERROR: `ERROR`,
  FILTERS: `FILTERS`,
  OFFERS: `OFFERS`,
  USER: `USER`,
};

export {NameSpace};
