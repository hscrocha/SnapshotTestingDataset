module.exports = {
    extends: 'get-off-my-lawn',
    rules: {
        'import/no-extraneous-dependencies': 0,
        'node/no-extraneous-import': 0
    }
};
