/* eslint-disable sort-keys */
export const spacing = {
    extraLarge: '32px',
    large: '24px',
    medium: '16px',
    small: '8px',
    extraSmall: '4px'
};
/* eslint-enable */
