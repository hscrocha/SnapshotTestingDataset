import React from 'react';

import Layout from './layout';

export default {
  title: 'Layout',
};

export const example = () => (
  <Layout>
    <p>Content in layout component!</p>
  </Layout>
);
