import React from 'react';
import './App.scss';
import Form from "./components/form"

function App() {
  return (
    <div className="app">
      <Form />
    </div>
  );
}

export default App;
