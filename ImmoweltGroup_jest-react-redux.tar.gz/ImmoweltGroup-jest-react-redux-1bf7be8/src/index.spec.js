// @flow

const {createMapStateToPropsSnapshot} = require('./index.js');

describe('exports', () => {
  it('should export a property of key "createMapStateToPropsSnapshot".', () => {
    expect(createMapStateToPropsSnapshot).toBeDefined();
  });
});
