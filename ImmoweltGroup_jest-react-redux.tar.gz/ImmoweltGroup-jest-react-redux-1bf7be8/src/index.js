// @flow

const createMapStateToPropsSnapshot = require('./createMapStateToPropsSnapshot.js');

module.exports = {
  createMapStateToPropsSnapshot
};
