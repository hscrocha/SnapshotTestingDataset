# Table of Contents

* [Read Me](/README.md)
* [Introduction](/docs/introduction/README.md)
  * [Motivation](/docs/introduction/Motivation.md)
* [API Reference](/docs/api/README.md)
  * [createMapStateToPropsSnapshot](/docs/api/createMapStateToPropsSnapshot.md)
* [FAQ](/docs/FAQ.md)
