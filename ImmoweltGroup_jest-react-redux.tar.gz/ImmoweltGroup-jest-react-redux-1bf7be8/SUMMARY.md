# Summary

* [Read me](README.md)
* [1. Introduction](docs/introduction/README.md)
  * [1.1 Motivation](docs/introduction/Motivation.md)
* [2. API](docs/api/README.md)
  * [2.1 createMapStateToPropsSnapshot](docs/api/createMapStateToPropsSnapshot.md)
* [3. FAQ](docs/FAQ.md)
