import React from 'react';

const SomethingWrong = () => (
  <div>
    <h1>Something Went Wrong</h1>
    <p>Please try refreshing and make sure you&apos;re connected to the Internet</p>
  </div>
);

export default SomethingWrong;
