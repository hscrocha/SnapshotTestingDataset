const HOST_URL_DEV = 'http://localhost:3000/';
const HOST_URL_PROD = 'https://anewman15-dev-point.herokuapp.com/';

export { HOST_URL_DEV, HOST_URL_PROD };
