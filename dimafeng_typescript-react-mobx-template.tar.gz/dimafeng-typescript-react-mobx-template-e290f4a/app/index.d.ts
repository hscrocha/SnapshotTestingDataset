/// <reference path="node_modules/rx/ts/rx.all.d.ts" />
declare const process: any;