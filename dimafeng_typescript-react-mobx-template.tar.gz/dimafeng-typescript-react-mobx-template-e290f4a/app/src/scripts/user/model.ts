export interface User {
    id: number;
    firstName: string;
    lastName: string;
}

export interface Transaction {
    id: number;
    description: string;
}