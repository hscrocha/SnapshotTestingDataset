import * as React from 'react';

export const SettingsView = () => <div><h1>Settings</h1></div>;