import { combineReducers } from 'redux'
import AppReducer from './appReducer'

const tleApp = combineReducers({
  AppReducer
})

export default tleApp
