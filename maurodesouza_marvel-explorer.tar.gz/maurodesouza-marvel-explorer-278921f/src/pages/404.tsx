import Page404Template from 'templates/404';

const Page404 = () => {
  return <Page404Template />;
};

export default Page404;
