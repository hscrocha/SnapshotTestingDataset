import HomeTemplate from 'templates/Home';

const Home = () => {
  return <HomeTemplate />;
};

export default Home;
