import FavoritesTemplate from 'templates/Favorites';

const Favorites = () => {
  return <FavoritesTemplate />;
};

export default Favorites;
