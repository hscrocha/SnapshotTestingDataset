import minew from './minew';
import mocks from './mocks';
import molkky from './molkky';

export default {
  minew,
  molkky,
  mocks,
};
