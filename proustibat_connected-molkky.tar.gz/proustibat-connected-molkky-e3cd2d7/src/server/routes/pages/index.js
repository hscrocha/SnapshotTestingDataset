import home from './home';
import molkky from './molkky';

export default {
  home,
  molkky,
};
