export default {
  points: {
    width: '80px',
    padding: '1rem',
    height: '80px',
    lineHeight: '3.5rem',
    margin: 'auto',
    fontSize: '2.5rem',
    textAlign: 'center',
    marginTop: '3rem',
  },
};
