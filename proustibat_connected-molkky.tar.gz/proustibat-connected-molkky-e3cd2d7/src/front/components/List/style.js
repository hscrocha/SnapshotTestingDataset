export default {
  collectionHeader: {
    background: 'rgba(0, 0, 0, 0.05)',
    padding: '1rem 1rem 1rem 0',
  },
  collectionHeader__content: {
    borderLeft: '0.5rem solid',
    padding: '0 1rem',
    margin: 0,
  },
};
