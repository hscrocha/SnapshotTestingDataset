// eslint-disable-next-line import/prefer-default-export
export const gatewayPostData = [
  {
    timestamp: '2019-11-17T18:41:45Z',
    type: 'Gateway',
    mac: 'AC233FC04B5E',
    gatewayFree: 97,
    gatewayLoad: 0.61,
  }, {
    timestamp: '2019-11-17T18:41:45Z',
    type: 'Unknown',
    mac: 'AC233FA247F5',
    bleName: '',
    rssi: -38,
    rawData: '0201060303E1FF1216E1FFA1036400020000FF03F547A23F23AC',
  },
];
