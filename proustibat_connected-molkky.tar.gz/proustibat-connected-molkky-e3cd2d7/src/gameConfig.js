export default {
  END_SCORE: 50,
  LEVEL_POINTS: 25,
  MAX_TRIES: 3,
  socketServer: '192.168.99.103:8888',
  // socketServer: 'localhost:8888',
};
