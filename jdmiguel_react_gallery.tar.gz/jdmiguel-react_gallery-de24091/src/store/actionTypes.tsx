export const ADD_IMAGES = 'ADD_IMAGES';
export const SET_PAGE = 'SET_PAGE';

