export const THUMB_PROPS_MOCKED = {
  id: 3063284,
  src: "https://pixabay.com/get/55e0d340485aa814f1dc84609629327f113dd7e05b4c704f752f78d79744c15e_640.jpg",
  title: "flower"
};
export const PHOTO_PROPS_MOCKED = {
  src: "https://pixabay.com/get/55e0d340485aa814f1dc84609629327f113dd7e05b4c704f752f78d79744c15e_1200.jpg",
  title: "flower"
};
export const BUTTON_TEXT_MOCKED = "default button";
export const Pill_TEXT_MOCKED = "default pill";