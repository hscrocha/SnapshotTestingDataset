export interface Quote {
  id: number;
  quote: string;
}
