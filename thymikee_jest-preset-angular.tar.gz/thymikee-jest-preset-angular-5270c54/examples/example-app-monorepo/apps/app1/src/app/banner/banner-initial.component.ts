import { Component } from '@angular/core';

@Component({
  selector: 'app-banner',
  template: `<p>banner works!</p>`,
  styles: [],
})
export class BannerComponent {}
