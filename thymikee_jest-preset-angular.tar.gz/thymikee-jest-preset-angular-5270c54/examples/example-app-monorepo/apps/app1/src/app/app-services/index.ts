import * as Services from './app.service';

export { Services };
