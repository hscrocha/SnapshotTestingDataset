import 'jest-preset-angular/setup-jest.mjs';
import './jest-global-mocks';
