export default class Unmocked {
  readonly isUnmocked: boolean;

  constructor() {
    this.isUnmocked = true;
  }
}
