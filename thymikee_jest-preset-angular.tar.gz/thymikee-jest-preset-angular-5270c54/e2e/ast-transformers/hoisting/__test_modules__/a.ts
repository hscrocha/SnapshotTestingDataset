export default (): string => 'unmocked';
