export default class Mocked {
  readonly isMocked: boolean;

  constructor() {
    this.isMocked = true;
  }
}
