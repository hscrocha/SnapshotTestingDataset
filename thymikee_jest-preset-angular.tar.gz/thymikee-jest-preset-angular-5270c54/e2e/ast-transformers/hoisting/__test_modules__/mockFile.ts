jest.mock('./banana', () => {
  const exports = 'apple';

  return exports;
});
