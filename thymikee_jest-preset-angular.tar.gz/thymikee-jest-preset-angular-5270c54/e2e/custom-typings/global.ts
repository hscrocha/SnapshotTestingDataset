// eslint-disable-next-line @typescript-eslint/no-unused-vars
type TerminatedReason = 'culled' | 'died' | 'transferred';
