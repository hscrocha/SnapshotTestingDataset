module.exports = {
  transform: { '^.+\\.(ts|js|html)$': '<rootDir>/../../build/index.js' },
};
