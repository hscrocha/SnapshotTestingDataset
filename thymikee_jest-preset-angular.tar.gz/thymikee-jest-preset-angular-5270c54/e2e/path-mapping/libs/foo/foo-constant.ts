export const foo = 2;
