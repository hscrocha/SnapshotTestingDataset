var createSerializer = require('./createSerializer');

module.exports = createSerializer();
