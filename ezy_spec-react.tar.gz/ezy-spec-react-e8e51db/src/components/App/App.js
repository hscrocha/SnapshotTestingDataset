import React from 'react';
import { Blog } from '../Blog/Blog';
import './App.css';

export const App = () => {
  return <Blog title="Typicode" />;
};

export { App as default };
