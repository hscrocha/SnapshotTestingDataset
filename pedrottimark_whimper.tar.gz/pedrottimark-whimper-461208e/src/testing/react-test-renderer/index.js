export {
  irrelevant,
  relevantTestObject,
} from './relevantTestObject';
