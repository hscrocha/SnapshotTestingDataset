const Categories = [
    {value:"Strony www", label:"Strony www", id:1},
    {value:"Excel", label:"Excel",id:2},
    {value:"Korepetycje", label:"Korepetycje", id:3},
    {value:"Opieka nad dziećmi", label:"Opieka nad dziećmi", id:4},
    {value:"Wyprowadzanie psów", label:"Wyprowadzanie psów", id:5},
    {value:"Fotografia", label:"Fotografia", id:6},
    {value:"Tłumaczenia", label:"Tłumaczenia", id:7},
    ]
  
    export default Categories;