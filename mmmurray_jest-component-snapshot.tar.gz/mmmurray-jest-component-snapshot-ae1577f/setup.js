module.exports = () => require('./lib/index').globalSetup()
