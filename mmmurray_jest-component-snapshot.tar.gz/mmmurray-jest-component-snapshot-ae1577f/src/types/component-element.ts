import { ReactElement } from 'react'

type ComponentElement = string | HTMLElement | ReactElement

export default ComponentElement
