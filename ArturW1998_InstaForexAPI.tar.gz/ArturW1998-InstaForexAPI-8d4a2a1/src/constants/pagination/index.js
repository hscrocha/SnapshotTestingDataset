export const NEXT = 'next';
export const PREV = 'prev';

export const GO_TO_FIRST_PAGE = 'goToFirstPage';
export const FIRST_PAGE = 1;
