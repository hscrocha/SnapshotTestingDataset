export const SECONDARY_DETAILS_LIST = [
  { title: 'Ask' },
  { title: 'Bid' },
  { title: 'Change' },
  { title: 'Change 24h' },
];

export const PRIMARY_DETAILS_LIST = [
  { title: 'Symbol' },
  { title: 'Description' },
  { title: 'Digits' },
];
