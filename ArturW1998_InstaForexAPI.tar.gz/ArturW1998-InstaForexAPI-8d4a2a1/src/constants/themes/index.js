export const PRIMARY_COLOR = '#434343';
export const SECONDARY_COLOR = '#757575';
export const DANGER_COLOR = '#dc322e';
export const LIGHT_COLOR = '#fff';
export const MUTED_COLOR = '#808080';
export const PADDING_HORIZONTAL = 10;
