export const BASE_PATH = 'https://quotes.instaforex.com/api';
export const QUOTES_LIST = '/quotesList';
export const QUOTES_TICK = '/quotesTick';
export const FIELDS_PARAM = 'f=';
export const INSTRUMENTS_PARAM = 'q=';
