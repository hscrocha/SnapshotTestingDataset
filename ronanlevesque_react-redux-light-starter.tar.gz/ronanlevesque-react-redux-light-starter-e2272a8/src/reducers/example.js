export default function example(state = {}, action) {
  switch (action.type) {
    default:
      return state;
  }
}
