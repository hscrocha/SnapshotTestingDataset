---
title: Year in Review 2016
id: review-2016
created: 2017-01-01
updated: 2017-01-01
categories:
  - Others
tags:
  - Diary
cover: ./cover.png
---

# Year in Review 2016

## The Year Not bad

> 今年只能算是不差的一年.

下半年没怎么更新博客,因为一直打算在用`angular2`+`SpringBoot Series`来更新下一代系统.

反复修改都赶不上最新的 Dev Guideline..

后来`Material2` beta component 也越来越多了.

家里也有一些烦心的事情,几度接近崩溃.

(并不是因为 7.0 开了好吗)

## Study Progress

新年定下好几个目标, 加上公司制定的一些学习计划. 到现在只能说完成了一半,有一部分没有达到所谓的进阶的目的.(花的时间应该差不多了,但是效率奇低,没有质变的提升)

硬要从语言层次划分的话

- JS/TS \*\*\*\*
- Java \*\*

接下来的半年计划,应该是以完成去年定下的学习目标为主

## New PC

一开始换了 4K 显示器的时候,老 PC 的 GTX460 估摸着不能输出 2K 以上分辨率的信号. 适逢老黄 1000 系列的卡横空出世,看到 GTX1060 以相同的功耗性能怒草上一代 GTX980 的评测,一下长草就下单了个 1060.

结果回来插在 H61 主板上面,把电源和主板炸了..

真是"3000 预算进卡吧 四路泰坦带回家"的节奏.立马把 1060 退了,老的 CPU 出了二手,准备下单新 PC.

结果就变成这样了...

老黄坑了一把,说好的新架构 Mac WebDriver 呢?

我一直在等待 WebDriver 的出现带动黑苹果

![6700K+32G+GTX1070](./hardware-info.png)

## Google Pixel

新一代亲儿子,贵的出汁.

除了三星 P 拍 AMOLED 屏 比 Nexus5 的 IPS 观感要差之外,其他完美.

## Summary

On the way go.
