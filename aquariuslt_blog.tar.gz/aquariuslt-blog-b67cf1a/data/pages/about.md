---
title: 'About Me'
id: about
created: 2019-11-25
updated: 2020-02-02
categories:
  - Blog
tags:
  - Link
cover: ./about.png
---

# About Me

一个无名小卒。

曾在珠海读大学 + 工作三年。

现在在深圳打工。

## Social

- [Github](https://github.com/aquariuslt)
- [Instagram](https://instagram.com/supaquariuslt)
- [Zhihu](https://zhihu.com/people/Aquariuslt)

## Friend Links

- [wxsm's space](https://wxsm.space): Kary Gor 博客 - 金山前端之神
- [lz's blog](https://lz5z.com): 振哥博客
- [lousama](http://lousama.com): 楼鸽鸽博客
- [koala](http://ikoala.net): 考拉博客 - 君合何大状
- [supremebb](http://supremebb.cc): 13c 博客 - 服装潮人
- [maview](https://frankxfz.me): 马老师博客 - CMU 未来之星
- [arhi](https://xuyanxin.top): 阿狸博客
- [yulai](https://yulaiz.com): Yulai 博客
- [witt](https://unix.bio): 维特，吹比工程师，自由开发者。
- [reckful](http://reckful.studio/): 小张
- [nancheung's blog](https://blog.nancheung.com/): 一个纯洁天真的男孩。
- [yoshino's blog](https://yoshino.now.sh/): Mezzo。
- [mifan.im](https://mifan.im): 🍚 米饭 - 区块链大师，老板克星
- [shamisen](https://yuanbo.online/hexo/): Soso - 切图仔，不算开发
- [kisin](https://www.kisin.tech)：还在学习的Kisin，没啥内容的博客

> 如需添加友情链接，请留言(+Issue/+Pull Request)
