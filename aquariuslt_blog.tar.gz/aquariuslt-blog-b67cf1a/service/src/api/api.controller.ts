import { Controller } from '@nestjs/common';

@Controller('api')
export class ApiController {}
