# `@blog/router`

Tools for generating routes
