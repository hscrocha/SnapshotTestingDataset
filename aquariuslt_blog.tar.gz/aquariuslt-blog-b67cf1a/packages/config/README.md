# `@blog/config`

> TODO: description

## Usage

```
const config = require('@blog/config');

// TODO: DEMONSTRATE API
```
