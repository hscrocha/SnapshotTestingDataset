# `@blog/api`

> TODO: description

## Usage

```
const apiGenerator = require('@blog/api');

// TODO: DEMONSTRATE API
```
