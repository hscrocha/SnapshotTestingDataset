export enum Layout {
  LIST = 'LIST',
  DETAIL = 'DETAIL',
  TABLE = 'TABLE',
}
