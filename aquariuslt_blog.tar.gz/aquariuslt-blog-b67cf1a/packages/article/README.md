# `@blog/article`

Tools to processing source markdown files to articles content

## Features

- lookup markdown files
- parse markdown file and merge article markdown context
- move article asset files (image, video, ...etc) to destination directory
