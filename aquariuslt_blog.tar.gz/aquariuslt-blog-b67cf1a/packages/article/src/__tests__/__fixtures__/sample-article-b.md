---
title: 'Introducing JSON Properties Loader'
id: introducing-json-properties-loader
created: 2019-09-10
updated: 2019-09-10
cover: ./cover.jpg
categories:
  - Blog
tags:
  - NPM
  - Node
  - Typescript
---

# A beautiful day

This is an example markdown content with all one-pass test cases.

## Getting Started

Getting started snippet

### Installing

```shell script
yarn add -D properteis-json-loader
```

or, using npm

```shell script
npm install --save-dev properties-json-loader
```

### Update webpack configuration

You should use it to load as one of webpack loader configuration matching `*.properties` file.

## Deep Understanding

## References

![Absolute Image](https://img.aquariuslt.com/posts/2019/08/migrating-github-actions.png)
