## [6.26.272](https://github.com/aquariuslt/blog/compare/v6.26.271...v6.26.272) (2021-10-02)


### Bug Fixes

* **deps:** update dependency axios to v0.22.0 ([e54aee6](https://github.com/aquariuslt/blog/commit/e54aee68e905c04e342b427611d1a0dcd3f5f315))

## [6.26.271](https://github.com/aquariuslt/blog/compare/v6.26.270...v6.26.271) (2021-10-02)


### Bug Fixes

* **deps:** update dependency slate-react to v0.66.4 ([29d4ae2](https://github.com/aquariuslt/blog/commit/29d4ae241a60bcc599bd4b3ee4f7c95c1c17706a))

## [6.26.270](https://github.com/aquariuslt/blog/compare/v6.26.269...v6.26.270) (2021-10-02)


### Bug Fixes

* **deps:** update dependency slate to v0.66.5 ([b08058a](https://github.com/aquariuslt/blog/commit/b08058a1267cd49b890cdf3b9780a1ac6b9b0e37))

## [6.26.269](https://github.com/aquariuslt/blog/compare/v6.26.268...v6.26.269) (2021-09-26)


### Bug Fixes

* **deps:** update dependency vanilla-lazyload to v17.5.0 ([252d169](https://github.com/aquariuslt/blog/commit/252d1693b5b8e53c294a7609ec05a76a327a1d2f))

## [6.26.268](https://github.com/aquariuslt/blog/compare/v6.26.267...v6.26.268) (2021-09-26)


### Bug Fixes

* **deps:** update dependency slate-react to v0.66.2 ([2ed5216](https://github.com/aquariuslt/blog/commit/2ed5216452c8878b771da7d0640948c8ee188fbd))

## [6.26.267](https://github.com/aquariuslt/blog/compare/v6.26.266...v6.26.267) (2021-09-25)


### Bug Fixes

* **deps:** update dependency slate to v0.66.2 ([174a19e](https://github.com/aquariuslt/blog/commit/174a19e55dcfd0f7987d9549d27a6fee8953acd8))

## [6.26.266](https://github.com/aquariuslt/blog/compare/v6.26.265...v6.26.266) (2021-09-19)


### Bug Fixes

* **deps:** update dependency slate-react to v0.66.1 ([ab09cad](https://github.com/aquariuslt/blog/commit/ab09cad4336e6b82d16b25940d0731d81049a72e))

## [6.26.265](https://github.com/aquariuslt/blog/compare/v6.26.264...v6.26.265) (2021-09-18)


### Bug Fixes

* **deps:** update dependency slate-history to v0.66.0 ([af943e4](https://github.com/aquariuslt/blog/commit/af943e4eee1585f399b04fd5c25e3e7a1b00f289))

## [6.26.264](https://github.com/aquariuslt/blog/compare/v6.26.263...v6.26.264) (2021-09-18)


### Bug Fixes

* **deps:** update dependency slate to v0.66.1 ([1a59020](https://github.com/aquariuslt/blog/commit/1a5902014250177475ea723e87523ee84d0a2ea2))

## [6.26.263](https://github.com/aquariuslt/blog/compare/v6.26.262...v6.26.263) (2021-09-18)


### Bug Fixes

* **deps:** update dependency date-fns to v2.24.0 ([7f2f2c2](https://github.com/aquariuslt/blog/commit/7f2f2c2c2486887e94225073383c7962df9976d7))

## [6.26.262](https://github.com/aquariuslt/blog/compare/v6.26.261...v6.26.262) (2021-09-11)


### Bug Fixes

* **deps:** update dependency sharp to v0.29.1 ([b22fb81](https://github.com/aquariuslt/blog/commit/b22fb8171d9e8cae29b229d24b95fff86e5b7567))

## [6.26.261](https://github.com/aquariuslt/blog/compare/v6.26.260...v6.26.261) (2021-09-11)


### Bug Fixes

* **deps:** update dependency axios to v0.21.4 ([c2f6a98](https://github.com/aquariuslt/blog/commit/c2f6a9826f1cb04e94e951b5372c9a75eac087f7))

## [6.26.260](https://github.com/aquariuslt/blog/compare/v6.26.259...v6.26.260) (2021-09-04)


### Bug Fixes

* **deps:** update dependency axios to v0.21.3 ([2fea6a9](https://github.com/aquariuslt/blog/commit/2fea6a95d791a004f1725fde0d4182acafc26a33))

## [6.26.259](https://github.com/aquariuslt/blog/compare/v6.26.258...v6.26.259) (2021-09-04)


### Bug Fixes

* **deps:** update dependency react-router-dom to v5.3.0 ([7e4aad8](https://github.com/aquariuslt/blog/commit/7e4aad882bf8ec6278ce984f199cbe544b9347a0))

## [6.26.258](https://github.com/aquariuslt/blog/compare/v6.26.257...v6.26.258) (2021-09-04)


### Bug Fixes

* **deps:** update dependency axios to v0.21.2 ([1a6a43d](https://github.com/aquariuslt/blog/commit/1a6a43d7d208a1e94aa99802cd0d59a076c101cd))

## [6.26.257](https://github.com/aquariuslt/blog/compare/v6.26.256...v6.26.257) (2021-08-28)


### Bug Fixes

* **deps:** update dependency react-router-dom to v5.2.1 ([5d43e92](https://github.com/aquariuslt/blog/commit/5d43e92277821cc05acccdf462b3140125151824))

## [6.26.256](https://github.com/aquariuslt/blog/compare/v6.26.255...v6.26.256) (2021-08-22)


### Bug Fixes

* **deps:** update dependency sharp to v0.29.0 ([e321a6a](https://github.com/aquariuslt/blog/commit/e321a6a41a874fd6e26f9af81059c2f17aad33dd))

## [6.26.255](https://github.com/aquariuslt/blog/compare/v6.26.254...v6.26.255) (2021-08-22)


### Bug Fixes

* **deps:** update dependency schema-dts to v0.11.0 ([c523fb5](https://github.com/aquariuslt/blog/commit/c523fb5f5babe6d54cd8306150fc5068d5dd7600))

## [6.26.254](https://github.com/aquariuslt/blog/compare/v6.26.253...v6.26.254) (2021-08-22)


### Bug Fixes

* **deps:** update dependency cosmiconfig to v7.0.1 ([467d3b2](https://github.com/aquariuslt/blog/commit/467d3b20704b332fd82793ce991a2ff7ff864c09))

## [6.26.253](https://github.com/aquariuslt/blog/compare/v6.26.252...v6.26.253) (2021-08-14)


### Bug Fixes

* **deps:** update dependency slate-history to v0.65.3 ([888a0b8](https://github.com/aquariuslt/blog/commit/888a0b83438e4eef7feb6917d71404998ca17d51))

## [6.26.252](https://github.com/aquariuslt/blog/compare/v6.26.251...v6.26.252) (2021-08-14)


### Bug Fixes

* **deps:** update dependency slate to v0.65.3 ([4bed13a](https://github.com/aquariuslt/blog/commit/4bed13ac7cca4af5dfc228c749721c45b6e5a801))

## [6.26.251](https://github.com/aquariuslt/blog/compare/v6.26.250...v6.26.251) (2021-08-14)


### Bug Fixes

* **deps:** update dependency slate-react to v0.65.3 ([00fbf94](https://github.com/aquariuslt/blog/commit/00fbf945c8a019236304e8d3bc49a9d0e8211bf2))

## [6.26.250](https://github.com/aquariuslt/blog/compare/v6.26.249...v6.26.250) (2021-08-07)


### Bug Fixes

* **deps:** update dependency schema-dts to v0.10.0 ([5f526cb](https://github.com/aquariuslt/blog/commit/5f526cbf5d3a27114cf179f907093d64328cb4fa))

## [6.26.249](https://github.com/aquariuslt/blog/compare/v6.26.248...v6.26.249) (2021-07-31)


### Bug Fixes

* **deps:** update dependency notistack to v1.0.10 ([130e3d6](https://github.com/aquariuslt/blog/commit/130e3d6ed657d61874d1b8825341740f5b02c6d8))

## [6.26.248](https://github.com/aquariuslt/blog/compare/v6.26.247...v6.26.248) (2021-07-31)


### Bug Fixes

* **deps:** update dependency @material-ui/core to v4.12.3 ([40511f6](https://github.com/aquariuslt/blog/commit/40511f62c7e768080cc22acb4860d05e161347eb))

## [6.26.247](https://github.com/aquariuslt/blog/compare/v6.26.246...v6.26.247) (2021-07-24)


### Bug Fixes

* **deps:** update dependency date-fns to v2.23.0 ([47876e5](https://github.com/aquariuslt/blog/commit/47876e5184ade1317d52b40a203a23ce70162d65))

## [6.26.246](https://github.com/aquariuslt/blog/compare/v6.26.245...v6.26.246) (2021-07-24)


### Bug Fixes

* **deps:** update dependency @material-ui/core to v4.12.2 ([7c7437f](https://github.com/aquariuslt/blog/commit/7c7437f4c298b8cf002f920d0c56084a0f92c349))

## [6.26.245](https://github.com/aquariuslt/blog/compare/v6.26.244...v6.26.245) (2021-07-19)


### Bug Fixes

* **deps:** update dependency schema-dts to v0.9.0 ([a4143f6](https://github.com/aquariuslt/blog/commit/a4143f69ad1e8d60915574e65cbd1554f857f2a7))

## [6.26.244](https://github.com/aquariuslt/blog/compare/v6.26.243...v6.26.244) (2021-07-17)


### Bug Fixes

* **deps:** update dependency @nestjs/serve-static to v2.2.2 ([a961318](https://github.com/aquariuslt/blog/commit/a9613181671139c8acaf955e40f530e9695a4dd2))

## [6.26.243](https://github.com/aquariuslt/blog/compare/v6.26.242...v6.26.243) (2021-07-10)


### Bug Fixes

* **deps:** update dependency @material-ui/core to v4.12.1 ([61ccca3](https://github.com/aquariuslt/blog/commit/61ccca39d4628bd12ac9d4a392b1ae0d8965884f))

## [6.26.242](https://github.com/aquariuslt/blog/compare/v6.26.241...v6.26.242) (2021-06-30)


### Bug Fixes

* **deps:** update dependency vanilla-lazyload to v17.4.0 ([a9b5584](https://github.com/aquariuslt/blog/commit/a9b5584758d47ff10f42fd2f0bd3370efd020871))

## [6.26.241](https://github.com/aquariuslt/blog/compare/v6.26.240...v6.26.241) (2021-06-27)


### Bug Fixes

* **deps:** update dependency vue-router to v3.5.2 ([8069ac9](https://github.com/aquariuslt/blog/commit/8069ac9b4d26ea6c5f97a8f355c4a38d6ba431e1))

## [6.26.240](https://github.com/aquariuslt/blog/compare/v6.26.239...v6.26.240) (2021-06-19)


### Bug Fixes

* **deps:** update nest monorepo to v7.6.18 ([81cb82b](https://github.com/aquariuslt/blog/commit/81cb82b3b54cc357216b7b07f55738c67f2e2803))

## [6.26.239](https://github.com/aquariuslt/blog/compare/v6.26.238...v6.26.239) (2021-06-14)


### Bug Fixes

* **deps:** update dependency slate-react to v0.65.2 ([5b3d537](https://github.com/aquariuslt/blog/commit/5b3d537e91d8c03223d28f7e4beb787ff7ec84c6))

## [6.26.238](https://github.com/aquariuslt/blog/compare/v6.26.237...v6.26.238) (2021-06-12)


### Bug Fixes

* **deps:** update dependency cheerio to v1.0.0-rc.10 ([b65da9c](https://github.com/aquariuslt/blog/commit/b65da9cedb29b0a08245e3e200a90926e914aaf6))

## [6.26.237](https://github.com/aquariuslt/blog/compare/v6.26.236...v6.26.237) (2021-06-05)


### Bug Fixes

* **deps:** update dependency slate-react to v0.65.0 ([804dbe8](https://github.com/aquariuslt/blog/commit/804dbe8c5138cff69e979661caa5edc1bc613db4))

## [6.26.236](https://github.com/aquariuslt/blog/compare/v6.26.235...v6.26.236) (2021-06-05)


### Bug Fixes

* **deps:** update vue monorepo to v2.6.13 ([9143495](https://github.com/aquariuslt/blog/commit/91434950562db15c50e2698020a2cfeea254c74e))

## [6.26.235](https://github.com/aquariuslt/blog/compare/v6.26.234...v6.26.235) (2021-06-05)


### Bug Fixes

* **deps:** update dependency schema-dts to v0.8.3 ([662149d](https://github.com/aquariuslt/blog/commit/662149db58664dfe22777d3b3b668da249fdf073))

## [6.26.234](https://github.com/aquariuslt/blog/compare/v6.26.233...v6.26.234) (2021-06-05)


### Bug Fixes

* **deps:** update dependency highlight.js to v10.7.3 ([f4a9163](https://github.com/aquariuslt/blog/commit/f4a9163de77fc09861806807fe0c5122b3ac42e5))

## [6.26.233](https://github.com/aquariuslt/blog/compare/v6.26.232...v6.26.233) (2021-05-30)


### Bug Fixes

* **deps:** update dependency vanilla-lazyload to v17.3.2 ([634a510](https://github.com/aquariuslt/blog/commit/634a510740e63d1a693f1737f323f2d5a08c0ffc))

## [6.26.232](https://github.com/aquariuslt/blog/compare/v6.26.231...v6.26.232) (2021-05-29)


### Bug Fixes

* **deps:** update dependency date-fns to v2.22.1 ([00d112e](https://github.com/aquariuslt/blog/commit/00d112e8b722062de434b91a48d944f5ed5e4a04))

## [6.26.231](https://github.com/aquariuslt/blog/compare/v6.26.230...v6.26.231) (2021-05-29)


### Bug Fixes

* **deps:** update dependency sharp to v0.28.3 ([c3ff1a8](https://github.com/aquariuslt/blog/commit/c3ff1a87dc81b5ac79fb1f41ff7c266939dca58e))

## [6.26.230](https://github.com/aquariuslt/blog/compare/v6.26.229...v6.26.230) (2021-05-22)


### Bug Fixes

* **deps:** update nest monorepo to v7.6.17 ([e8d742b](https://github.com/aquariuslt/blog/commit/e8d742b8173a70cd38e9cb268c6813d589f1a74f))

## [6.26.229](https://github.com/aquariuslt/blog/compare/v6.26.228...v6.26.229) (2021-05-22)


### Bug Fixes

* **deps:** update dependency notistack to v1.0.9 ([081117e](https://github.com/aquariuslt/blog/commit/081117ee02d0ccbde3032a93cc6bb09529cbf90a))

## [6.26.228](https://github.com/aquariuslt/blog/compare/v6.26.227...v6.26.228) (2021-05-16)


### Bug Fixes

* **deps:** update dependency slate-react to v0.63.0 ([56c1120](https://github.com/aquariuslt/blog/commit/56c1120c3afed07efea2fa7ed7235800c053ad69))

## [6.26.227](https://github.com/aquariuslt/blog/compare/v6.26.226...v6.26.227) (2021-05-16)


### Bug Fixes

* **deps:** update dependency slate to v0.63.0 ([e87f79c](https://github.com/aquariuslt/blog/commit/e87f79ca93da4664780008741b41e4acaf096522))

## [6.26.226](https://github.com/aquariuslt/blog/compare/v6.26.225...v6.26.226) (2021-05-15)


### Bug Fixes

* **deps:** update dependency sharp to v0.28.2 ([fd68143](https://github.com/aquariuslt/blog/commit/fd681435c6b4454d29ece8a704f749fd3c29f2ae))

## [6.26.225](https://github.com/aquariuslt/blog/compare/v6.26.224...v6.26.225) (2021-05-08)


### Bug Fixes

* **deps:** update dependency dotenv to v8.6.0 ([367c313](https://github.com/aquariuslt/blog/commit/367c313e2dab8925d2f3a2fb8837be21c9bd103b))

## [6.26.224](https://github.com/aquariuslt/blog/compare/v6.26.223...v6.26.224) (2021-05-08)


### Bug Fixes

* **deps:** update dependency @loadable/component to v5.15.0 ([6fd207e](https://github.com/aquariuslt/blog/commit/6fd207eec357063df3ca676a604d7ef2ca9b7425))

## [6.26.223](https://github.com/aquariuslt/blog/compare/v6.26.222...v6.26.223) (2021-05-08)


### Bug Fixes

* **deps:** update dependency slate-react to v0.62.1 ([9ad89da](https://github.com/aquariuslt/blog/commit/9ad89da92498f9a9eacbed8a23e26ab73cd31a23))

## [6.26.222](https://github.com/aquariuslt/blog/compare/v6.26.221...v6.26.222) (2021-05-08)


### Bug Fixes

* **deps:** update dependency slate to v0.62.1 ([32f2dc0](https://github.com/aquariuslt/blog/commit/32f2dc05211ded9e3f7819823e0b013ada7ed313))

## [6.26.221](https://github.com/aquariuslt/blog/compare/v6.26.220...v6.26.221) (2021-05-08)


### Bug Fixes

* **deps:** update dependency notistack to v1.0.7 ([c05fb47](https://github.com/aquariuslt/blog/commit/c05fb477eb6a2b3b2fabb6edacdf9133e5e711be))

## [6.26.220](https://github.com/aquariuslt/blog/compare/v6.26.219...v6.26.220) (2021-05-08)


### Bug Fixes

* **deps:** update dependency date-fns to v2.21.3 ([fe9604e](https://github.com/aquariuslt/blog/commit/fe9604e58c20adb1296e6e5fe9d4b7682eec0b19))

## [6.26.219](https://github.com/aquariuslt/blog/compare/v6.26.218...v6.26.219) (2021-05-08)


### Bug Fixes

* **deps:** update dependency cheerio to v1.0.0-rc.9 ([7fa58ab](https://github.com/aquariuslt/blog/commit/7fa58ab831ea39759a3a6637c023c5b07b3e639f))

## [6.26.218](https://github.com/aquariuslt/blog/compare/v6.26.217...v6.26.218) (2021-05-01)


### Bug Fixes

* **deps:** update dependency @material-ui/core to v4.11.4 ([9200912](https://github.com/aquariuslt/blog/commit/92009120683555715f00aca721da7287a66a55ac))

## [6.26.217](https://github.com/aquariuslt/blog/compare/v6.26.216...v6.26.217) (2021-04-25)


### Bug Fixes

* **deps:** update dependency gray-matter to v4.0.3 ([ee556ba](https://github.com/aquariuslt/blog/commit/ee556ba65b1777e80da5b5e6d7a858ca857197f4))

## [6.26.216](https://github.com/aquariuslt/blog/compare/v6.26.215...v6.26.216) (2021-04-18)


### Bug Fixes

* **deps:** update dependency notistack to v1.0.6 ([1f5a86c](https://github.com/aquariuslt/blog/commit/1f5a86cfda0db643ffecb9538176ac34a60ed7ea))

## [6.26.215](https://github.com/aquariuslt/blog/compare/v6.26.214...v6.26.215) (2021-04-18)


### Bug Fixes

* **deps:** update dependency date-fns to v2.21.1 ([c75007a](https://github.com/aquariuslt/blog/commit/c75007a7a299900be514c78d69ece7c8fdc3b32b))

## [6.26.214](https://github.com/aquariuslt/blog/compare/v6.26.213...v6.26.214) (2021-04-17)


### Bug Fixes

* **deps:** downgrade `less-loader`, `sass-loader` ([16980b8](https://github.com/aquariuslt/blog/commit/16980b856c68e799a78ebc095da697d4c07a5ad1))

## [6.26.213](https://github.com/aquariuslt/blog/compare/v6.26.212...v6.26.213) (2021-04-10)


### Bug Fixes

* **deps:** update dependency sharp to v0.28.1 ([3fd3de1](https://github.com/aquariuslt/blog/commit/3fd3de1af54c9e2acd182b0a632c775b18bded32))

## [6.26.212](https://github.com/aquariuslt/blog/compare/v6.26.211...v6.26.212) (2021-04-10)


### Bug Fixes

* **deps:** update dependency date-fns to v2.20.1 ([d2ca373](https://github.com/aquariuslt/blog/commit/d2ca373b69889bf24326bc85b181f0605a2bf817))

## [6.26.211](https://github.com/aquariuslt/blog/compare/v6.26.210...v6.26.211) (2021-04-10)


### Bug Fixes

* **deps:** update dependency cheerio to v1.0.0-rc.6 ([3e5dcde](https://github.com/aquariuslt/blog/commit/3e5dcde4928296b8f040ea781aeb7659d6120723))

## [6.26.210](https://github.com/aquariuslt/blog/compare/v6.26.209...v6.26.210) (2021-04-04)


### Bug Fixes

* **deps:** update dependency highlight.js to v10.7.2 ([6837dd5](https://github.com/aquariuslt/blog/commit/6837dd5de0f0923ac7288ad370fde854f8297d8b))

## [6.26.209](https://github.com/aquariuslt/blog/compare/v6.26.208...v6.26.209) (2021-04-03)


### Bug Fixes

* **deps:** update dependency slate-react to v0.62.0 ([705fecc](https://github.com/aquariuslt/blog/commit/705feccf02ff79294a18947ee62f1cae6e81e600))

## [6.26.208](https://github.com/aquariuslt/blog/compare/v6.26.207...v6.26.208) (2021-04-03)


### Bug Fixes

* **deps:** update dependency slate-history to v0.62.0 ([b2c742f](https://github.com/aquariuslt/blog/commit/b2c742fd4886c22d2474d1f8e9abf3105df1914f))

## [6.26.207](https://github.com/aquariuslt/blog/compare/v6.26.206...v6.26.207) (2021-04-03)


### Bug Fixes

* **deps:** update dependency slate to v0.62.0 ([19f04f3](https://github.com/aquariuslt/blog/commit/19f04f38ec7bdb0dd42b0dd31f5667d1901eb57d))

## [6.26.206](https://github.com/aquariuslt/blog/compare/v6.26.205...v6.26.206) (2021-04-03)


### Bug Fixes

* **deps:** update dependency rxjs to v6.6.7 ([1914587](https://github.com/aquariuslt/blog/commit/1914587ff07f53e5f5fb229292aaf104d291d1e2))

## [6.26.205](https://github.com/aquariuslt/blog/compare/v6.26.204...v6.26.205) (2021-04-03)


### Bug Fixes

* **deps:** update dependency classnames to v2.3.1 ([6df1e9d](https://github.com/aquariuslt/blog/commit/6df1e9d25f21b67677c53e439df144a4e1d92795))

## [6.26.204](https://github.com/aquariuslt/blog/compare/v6.26.203...v6.26.204) (2021-03-30)


### Bug Fixes

* **deps:** update dependency highlight.js to v10.7.1 ([#1108](https://github.com/aquariuslt/blog/issues/1108)) ([023f7cf](https://github.com/aquariuslt/blog/commit/023f7cf8151a6b78c5ffcdd867c44f57d12c4a6f))
* **deps:** update dependency patch-package to v6.4.7 ([#1109](https://github.com/aquariuslt/blog/issues/1109)) ([4a3388b](https://github.com/aquariuslt/blog/commit/4a3388b799e90cf72433f66d153421657d683f91))
* **deps:** update dependency sharp to v0.28.0 ([#1101](https://github.com/aquariuslt/blog/issues/1101)) ([4297ee6](https://github.com/aquariuslt/blog/commit/4297ee6b182d60e5a2b995f208922f79387f9bac))

## [6.26.203](https://github.com/aquariuslt/blog/compare/v6.26.202...v6.26.203) (2021-03-29)


### Bug Fixes

* **deps:** update dependency scroll-into-view-if-needed to v2.2.28 ([#1110](https://github.com/aquariuslt/blog/issues/1110)) ([c9f47a2](https://github.com/aquariuslt/blog/commit/c9f47a2b51f6a0cf9891ecb78522f654b433ed55))

## [6.26.202](https://github.com/aquariuslt/blog/compare/v6.26.201...v6.26.202) (2021-03-28)


### Bug Fixes

* **theme-react:** resolve webpack v5 stat type error ([cfb9ddb](https://github.com/aquariuslt/blog/commit/cfb9ddb171bd37dbae8229faf7fcd3ea3492d2cf))

## [6.26.201](https://github.com/aquariuslt/blog/compare/v6.26.200...v6.26.201) (2021-03-28)


### Bug Fixes

* **deps:** update react monorepo to v17.0.2 ([#1096](https://github.com/aquariuslt/blog/issues/1096)) ([94eddf0](https://github.com/aquariuslt/blog/commit/94eddf04f4089f166f84db97adc16b490150ee4b))

## [6.26.200](https://github.com/aquariuslt/blog/compare/v6.26.199...v6.26.200) (2021-03-28)


### Bug Fixes

* revert CHANGELOG ([c0208e9](https://github.com/aquariuslt/blog/commit/c0208e9824abaecffcb36118d2d450ecde340778))

# [6.26.198](https://github.com/aquariuslt/blog/compare/v6.26.197...v6.26.198) (2021-03-07)

### Bug Fixes

- **deps:** update dependency date-fns to v2.19.0 ([f6bee4c](https://github.com/aquariuslt/blog/commit/f6bee4c038331a04e359c0ec55377676ab15bc59))
- **deps:** update dependency notistack to v1.0.5 ([242c45d](https://github.com/aquariuslt/blog/commit/242c45d53c1e3bef3fd74d4cc6abd438359918be))
- **deps:** update dependency patch-package to v6.4.5 ([4346b73](https://github.com/aquariuslt/blog/commit/4346b73d3fe845dcd2daee6158de52cab531b17d))

## [6.26.197](https://github.com/aquariuslt/blog/compare/v6.26.196...v6.26.197) (2021-03-01)

### Bug Fixes

- **deps:** update dependency scroll-into-view-if-needed to v2.2.27 ([88bd17c](https://github.com/aquariuslt/blog/commit/88bd17c73be2914a023885ee2afc0f32c88434ba))

## [6.26.196](https://github.com/aquariuslt/blog/compare/v6.26.195...v6.26.196) (2021-02-28)

### Bug Fixes

- **deps:** update dependency class-transformer to v0.4.0 ([82e5684](https://github.com/aquariuslt/blog/commit/82e568491e403d42deab4a084014a59bbe52408a))
- **deps:** update dependency notistack to v1.0.4 ([b2606b9](https://github.com/aquariuslt/blog/commit/b2606b9600832e53d85d86d0e86feb753334091e))
- **deps:** update dependency patch-package to v6.4.0 ([ebe102a](https://github.com/aquariuslt/blog/commit/ebe102a18ea0135881d71b7c7764185ac63722d8))
- **deps:** update dependency rxjs to v6.6.6 ([905d30b](https://github.com/aquariuslt/blog/commit/905d30b8fb788456640e3c2e98e5b062d2f9e08d))
- **deps:** update dependency sharp to v0.27.2 ([d2c6095](https://github.com/aquariuslt/blog/commit/d2c6095ea4b97262e7fb9810b9be2118c7990e95))

## [6.26.195](https://github.com/aquariuslt/blog/compare/v6.26.194...v6.26.195) (2021-02-27)

### Bug Fixes

- **deps:** update dependency highlight.js to v10.6.0 ([f6b6b07](https://github.com/aquariuslt/blog/commit/f6b6b076f133c4af1d5b9c1a5e4bcb3fc1ffecdd))

## [6.26.194](https://github.com/aquariuslt/blog/compare/v6.26.193...v6.26.194) (2021-02-08)

### Bug Fixes

- **deps:** update dependency date-fns to v2.17.0 ([e4ff29e](https://github.com/aquariuslt/blog/commit/e4ff29ef430df1da64aec43ae9f4a03d035f8d8f))

## [6.26.193](https://github.com/aquariuslt/blog/compare/v6.26.192...v6.26.193) (2021-02-07)

### Bug Fixes

- **deps:** update dependency vanilla-lazyload to v17.3.1 ([8ae785d](https://github.com/aquariuslt/blog/commit/8ae785d5e377dfdd666d6921f2482fc5b6c71718))
- **deps:** update nest monorepo to v7.6.11 ([e4204ee](https://github.com/aquariuslt/blog/commit/e4204ee7312572c970fa561b6397238b780c74d6))

## [6.26.192](https://github.com/aquariuslt/blog/compare/v6.26.191...v6.26.192) (2021-01-30)

### Bug Fixes

- **deps:** update nest monorepo to v7.6.7 ([746c2f4](https://github.com/aquariuslt/blog/commit/746c2f4f2af43339b66b99fa14a854caff040807))

## [6.26.191](https://github.com/aquariuslt/blog/compare/v6.26.190...v6.26.191) (2021-01-30)

### Bug Fixes

- **deps:** update dependency vue-router to v3.5.1 ([181e15b](https://github.com/aquariuslt/blog/commit/181e15bf741e22910912e1ca84c5968b8c61258b))

## [6.26.190](https://github.com/aquariuslt/blog/compare/v6.26.189...v6.26.190) (2021-01-30)

### Bug Fixes

- **deps:** update dependency sharp to v0.27.1 ([335c075](https://github.com/aquariuslt/blog/commit/335c075e18a377ef181ecbbc9e01b2fc94ae3dff))

## [6.26.189](https://github.com/aquariuslt/blog/compare/v6.26.188...v6.26.189) (2021-01-30)

### Bug Fixes

- **deps:** update dependency @material-ui/core to v4.11.3 ([1978d0c](https://github.com/aquariuslt/blog/commit/1978d0c1985bb426be17fbba9f59eaeb919dd400))

## [6.26.188](https://github.com/aquariuslt/blog/compare/v6.26.187...v6.26.188) (2021-01-23)

### Bug Fixes

- **deps:** update dependency fs-extra to v9.1.0 ([969fdf8](https://github.com/aquariuslt/blog/commit/969fdf8101da3e3c33601f015b17fcff73d704fd))

## [6.26.187](https://github.com/aquariuslt/blog/compare/v6.26.186...v6.26.187) (2021-01-17)

### Bug Fixes

- **deps:** update dependency @mdi/font to v5.9.55 ([3a91c35](https://github.com/aquariuslt/blog/commit/3a91c3589be63f2f9da2bc938836dcb09f976a04))

## [6.26.186](https://github.com/aquariuslt/blog/compare/v6.26.185...v6.26.186) (2021-01-16)

### Bug Fixes

- **deps:** update dependency class-validator to v0.13.1 ([8142a9c](https://github.com/aquariuslt/blog/commit/8142a9c6bbde544cbddcde2a59f867287fa7f8b5))

## [6.26.185](https://github.com/aquariuslt/blog/compare/v6.26.184...v6.26.185) (2021-01-16)

### Bug Fixes

- **deps:** update dependency class-transformer to v0.3.2 ([6332995](https://github.com/aquariuslt/blog/commit/63329953e004f6d21886f0a60f98014cc57eab6f))

## [6.26.184](https://github.com/aquariuslt/blog/compare/v6.26.183...v6.26.184) (2021-01-03)

### Bug Fixes

- **deps:** update nest monorepo to v7.6.5 ([e9a1f15](https://github.com/aquariuslt/blog/commit/e9a1f15fbd31de69f3c0f87b723983d349472ff4))

## [6.26.183](https://github.com/aquariuslt/blog/compare/v6.26.182...v6.26.183) (2020-12-26)

### Bug Fixes

- **deps:** update nest monorepo to v7.6.4 ([d75bd25](https://github.com/aquariuslt/blog/commit/d75bd2543d3a853c60f9c5596f88f5d2686317fc))

## [6.26.182](https://github.com/aquariuslt/blog/compare/v6.26.181...v6.26.182) (2020-12-26)

### Bug Fixes

- **deps:** update dependency cheerio to v1.0.0-rc.5 ([61ae8ff](https://github.com/aquariuslt/blog/commit/61ae8ff6e5a9da250877689dc93a409bdf6d403f))

## [6.26.181](https://github.com/aquariuslt/blog/compare/v6.26.180...v6.26.181) (2020-12-26)

### Bug Fixes

- **deps:** update dependency sharp to v0.27.0 ([5f3fd81](https://github.com/aquariuslt/blog/commit/5f3fd81cb1192e4a0dffe02b0d01e7459178763c))

## [6.26.180](https://github.com/aquariuslt/blog/compare/v6.26.179...v6.26.180) (2020-12-26)

### Bug Fixes

- **deps:** update dependency highlight.js to v10.5.0 ([4e7f049](https://github.com/aquariuslt/blog/commit/4e7f049512233ae96a68475975abccf068d46dfc))

## [6.26.179](https://github.com/aquariuslt/blog/compare/v6.26.178...v6.26.179) (2020-12-26)

### Bug Fixes

- **deps:** update dependency notistack to v1.0.3 ([d7cc29e](https://github.com/aquariuslt/blog/commit/d7cc29e3992c2328e2d621467e2622e90658ee8e))

## [6.26.178](https://github.com/aquariuslt/blog/compare/v6.26.177...v6.26.178) (2020-12-26)

### Bug Fixes

- **deps:** update dependency axios to v0.21.1 ([f25c0f6](https://github.com/aquariuslt/blog/commit/f25c0f6781bd10a371468f0713fb100971da5206))

## [6.26.177](https://github.com/aquariuslt/blog/compare/v6.26.176...v6.26.177) (2020-12-19)

### Bug Fixes

- **deps:** update nest monorepo to v7.6.3 ([cae5475](https://github.com/aquariuslt/blog/commit/cae54755c4c7a6cf26cbba5b62d0767fa511513c))

## [6.26.176](https://github.com/aquariuslt/blog/compare/v6.26.175...v6.26.176) (2020-12-12)

### Bug Fixes

- **deps:** update dependency register-service-worker to v1.7.2 ([2f981d6](https://github.com/aquariuslt/blog/commit/2f981d66a417e5ad1e9d35fc16e528f6e300afe4))

## [6.26.175](https://github.com/aquariuslt/blog/compare/v6.26.174...v6.26.175) (2020-12-12)

### Bug Fixes

- **deps:** update dependency markdown-it to v12.0.3 ([4f1cc5f](https://github.com/aquariuslt/blog/commit/4f1cc5fdd1d29c3c1cc287fda82af580fb94fd94))

## [6.26.174](https://github.com/aquariuslt/blog/compare/v6.26.173...v6.26.174) (2020-12-05)

### Bug Fixes

- **deps:** update mui monorepo to v4.11.2 ([aab1166](https://github.com/aquariuslt/blog/commit/aab1166a85e3043b6aeb9976fa5a963a284c2bdb))

## [6.26.173](https://github.com/aquariuslt/blog/compare/v6.26.172...v6.26.173) (2020-12-05)

### Bug Fixes

- **deps:** update dependency schema-dts to v0.8.2 ([1a3bc56](https://github.com/aquariuslt/blog/commit/1a3bc56bd677ff277d18005d98414a2680c0604b))

## [6.26.172](https://github.com/aquariuslt/blog/compare/v6.26.171...v6.26.172) (2020-12-04)

### Bug Fixes

- **deps:** update dependency highlight.js to v10.4.1 [security] ([61cb781](https://github.com/aquariuslt/blog/commit/61cb781d352f4c62b41dd7faceca0931ddb075ad))

## [6.26.171](https://github.com/aquariuslt/blog/compare/v6.26.170...v6.26.171) (2020-11-28)

### Bug Fixes

- **deps:** update nest monorepo to v7.5.5 ([2f84e80](https://github.com/aquariuslt/blog/commit/2f84e8022b0308d1b85a76174e65b0481c65d5a4))

## [6.26.170](https://github.com/aquariuslt/blog/compare/v6.26.169...v6.26.170) (2020-11-28)

### Bug Fixes

- **deps:** update dependency vanilla-lazyload to v17.3.0 ([522d08e](https://github.com/aquariuslt/blog/commit/522d08e585866b53d86927c7fb2ac868e6f4a926))

## [6.26.169](https://github.com/aquariuslt/blog/compare/v6.26.168...v6.26.169) (2020-11-28)

### Bug Fixes

- **deps:** update dependency schema-dts to v0.8.1 ([3843f57](https://github.com/aquariuslt/blog/commit/3843f57dc1a37d33fc32f758f2377a932c75b257))

## [6.26.168](https://github.com/aquariuslt/blog/compare/v6.26.167...v6.26.168) (2020-11-28)

### Bug Fixes

- **deps:** update dependency notistack to v1.0.2 ([0426c4c](https://github.com/aquariuslt/blog/commit/0426c4cb11af6894a428c5ef97625b6dd8a39671))

## [6.26.167](https://github.com/aquariuslt/blog/compare/v6.26.166...v6.26.167) (2020-11-28)

### Bug Fixes

- **deps:** update dependency @material-ui/core to v4.11.1 ([12a5070](https://github.com/aquariuslt/blog/commit/12a50708a7c7cc44bc35e4b2b355260cd918d5e7))

## [6.26.166](https://github.com/aquariuslt/blog/compare/v6.26.165...v6.26.166) (2020-11-21)

### Bug Fixes

- **deps:** update dependency vue-property-decorator to v9.1.2 ([425aa29](https://github.com/aquariuslt/blog/commit/425aa291a1841bcd9e2bea1bfdb154ff176d9253))

## [6.26.165](https://github.com/aquariuslt/blog/compare/v6.26.164...v6.26.165) (2020-11-21)

### Bug Fixes

- **deps:** update dependency sharp to v0.26.3 ([8e45274](https://github.com/aquariuslt/blog/commit/8e45274c677f6159637eb6ec4278d173515110d5))

## [6.26.164](https://github.com/aquariuslt/blog/compare/v6.26.163...v6.26.164) (2020-11-21)

### Bug Fixes

- **deps:** update dependency puppeteer to v5.5.0 ([5e6968f](https://github.com/aquariuslt/blog/commit/5e6968fc702b82189ef59be5314b141f8ddde389))

## [6.26.163](https://github.com/aquariuslt/blog/compare/v6.26.162...v6.26.163) (2020-11-21)

### Bug Fixes

- **deps:** update dependency @nestjs/serve-static to v2.1.4 ([041df41](https://github.com/aquariuslt/blog/commit/041df4135e53a23477ac44872df4823d0c3955f3))
- **deps:** update dependency markdown-it-anchor to v6.0.1 ([ef2f523](https://github.com/aquariuslt/blog/commit/ef2f5237fa83234f2269fb14f65b934a9b2940df))

## [6.26.162](https://github.com/aquariuslt/blog/compare/v6.26.161...v6.26.162) (2020-11-21)

### Bug Fixes

- **deps:** update dependency highlight.js to v10.4.0 ([cc94c60](https://github.com/aquariuslt/blog/commit/cc94c60bf79a9d9a61f534013c4955d7688be0d1))

## [6.26.161](https://github.com/aquariuslt/blog/compare/v6.26.160...v6.26.161) (2020-11-14)

### Bug Fixes

- **deps:** update nest monorepo to v7.5.2 ([0458fe5](https://github.com/aquariuslt/blog/commit/0458fe551a826a33f8bab675e529f598b6cb8f0d))

## [6.26.160](https://github.com/aquariuslt/blog/compare/v6.26.159...v6.26.160) (2020-11-07)

### Bug Fixes

- **deps:** update dependency vue-router to v3.4.9 ([6a24e19](https://github.com/aquariuslt/blog/commit/6a24e1980714f8ab154e0108820e2c226e814d45))

## [6.26.159](https://github.com/aquariuslt/blog/compare/v6.26.158...v6.26.159) (2020-10-31)

### Bug Fixes

- **deps:** update dependency vue-router to v3.4.8 ([4e56e5e](https://github.com/aquariuslt/blog/commit/4e56e5ec38edaa82a8aba574e4d41e53b581c5b9))

## [6.26.158](https://github.com/aquariuslt/blog/compare/v6.26.157...v6.26.158) (2020-10-31)

### Bug Fixes

- **deps:** update dependency puppeteer to v5.4.1 ([b15ec59](https://github.com/aquariuslt/blog/commit/b15ec59d49a5540f51b07903a10c73208685d703))

## [6.26.157](https://github.com/aquariuslt/blog/compare/v6.26.156...v6.26.157) (2020-10-31)

### Bug Fixes

- **deps:** update dependency highlight.js to v10.3.2 ([26956c6](https://github.com/aquariuslt/blog/commit/26956c624f6edd589f0569b4ede30d5f2b9ae9ce))

## [6.26.156](https://github.com/aquariuslt/blog/compare/v6.26.155...v6.26.156) (2020-10-27)

### Bug Fixes

- **deps:** update dependency markdown-it to v12 ([#760](https://github.com/aquariuslt/blog/issues/760)) ([8b2c667](https://github.com/aquariuslt/blog/commit/8b2c6678fb1f63ef3c45f8a3a9c6f79d870eb1db))
- **deps:** update react monorepo to v17 ([#780](https://github.com/aquariuslt/blog/issues/780)) ([417b1ad](https://github.com/aquariuslt/blog/commit/417b1ad205ed5da87cf8d5ed5197bbfefbfce07b))

## [6.26.155](https://github.com/aquariuslt/blog/compare/v6.26.154...v6.26.155) (2020-10-24)

### Bug Fixes

- **deps:** update dependency @mdi/font to v5.8.55 ([e25f590](https://github.com/aquariuslt/blog/commit/e25f5902b2b77c5dca6df8556f21ddbe6e944801))

## [6.26.154](https://github.com/aquariuslt/blog/compare/v6.26.153...v6.26.154) (2020-10-24)

### Bug Fixes

- **deps:** update dependency puppeteer to v5.4.0 ([b90b79c](https://github.com/aquariuslt/blog/commit/b90b79c267347e842b6c9d26e23d5e439f171d8c))

## [6.26.153](https://github.com/aquariuslt/blog/compare/v6.26.152...v6.26.153) (2020-10-24)

### Bug Fixes

- **deps:** update dependency axios to v0.21.0 ([8b992a2](https://github.com/aquariuslt/blog/commit/8b992a2fa39958cb2357aaf1fec8c41fc0181bb2))

## [6.26.152](https://github.com/aquariuslt/blog/compare/v6.26.151...v6.26.152) (2020-10-24)

### Bug Fixes

- **deps:** update dependency @loadable/component to v5.14.1 ([477e44d](https://github.com/aquariuslt/blog/commit/477e44da29d276dd2d9c72d589002710922a791d))

## [6.26.151](https://github.com/aquariuslt/blog/compare/v6.26.150...v6.26.151) (2020-10-23)

### Bug Fixes

- **deps:** update dependency typeface-roboto to v1 ([#740](https://github.com/aquariuslt/blog/issues/740)) ([55e8c82](https://github.com/aquariuslt/blog/commit/55e8c8291c2b2c520f56ebd357fe12da6368ddd5))

## [6.26.150](https://github.com/aquariuslt/blog/compare/v6.26.149...v6.26.150) (2020-10-18)

### Bug Fixes

- **deps:** update dependency highlight.js to v10.3.1 ([9c5a840](https://github.com/aquariuslt/blog/commit/9c5a8402758118842e8bd1451621d138b946b702))

## [6.26.149](https://github.com/aquariuslt/blog/compare/v6.26.148...v6.26.149) (2020-10-17)

### Bug Fixes

- **deps:** update dependency vanilla-lazyload to v17.1.3 ([5b1cb63](https://github.com/aquariuslt/blog/commit/5b1cb63dc5fbb9a65e0d1c0c36854e610b6f439a))

## [6.26.148](https://github.com/aquariuslt/blog/compare/v6.26.147...v6.26.148) (2020-10-17)

### Bug Fixes

- **deps:** update dependency highlight.js to v10.3.0 ([ea7bf72](https://github.com/aquariuslt/blog/commit/ea7bf7271b999e8bfb426e8d2b6d21f3421466fe))

## [6.26.147](https://github.com/aquariuslt/blog/compare/v6.26.146...v6.26.147) (2020-10-17)

### Bug Fixes

- **deps:** update dependency notistack to v1.0.1 ([b1b2d7f](https://github.com/aquariuslt/blog/commit/b1b2d7f5e0e91f552de9cb0d3a90f34890a9f787))

## [6.26.146](https://github.com/aquariuslt/blog/compare/v6.26.145...v6.26.146) (2020-10-17)

### Bug Fixes

- **deps:** update react monorepo to v16.14.0 ([903cc5f](https://github.com/aquariuslt/blog/commit/903cc5f184440555f3608acb54900b75e6e89290))

## [6.26.145](https://github.com/aquariuslt/blog/compare/v6.26.144...v6.26.145) (2020-10-17)

### Bug Fixes

- **deps:** update dependency vue-router to v3.4.7 ([98f128f](https://github.com/aquariuslt/blog/commit/98f128f65b5be67e6084422bbbbbf28dea34c804))

## [6.26.144](https://github.com/aquariuslt/blog/compare/v6.26.143...v6.26.144) (2020-10-17)

### Bug Fixes

- **deps:** update dependency sharp to v0.26.2 ([eb87368](https://github.com/aquariuslt/blog/commit/eb8736806288c1c54a7b4faa83f4348bc5e83395))

## [6.26.143](https://github.com/aquariuslt/blog/compare/v6.26.142...v6.26.143) (2020-10-17)

### Bug Fixes

- **deps:** update dependency @mdi/font to v5.7.55 ([426fca6](https://github.com/aquariuslt/blog/commit/426fca6b2c8e284ce65789424108fc0b47efb02b))

## [6.26.142](https://github.com/aquariuslt/blog/compare/v6.26.141...v6.26.142) (2020-10-06)

### Bug Fixes

- **deps:** update dependency vue-property-decorator to v9.0.2 ([7637afe](https://github.com/aquariuslt/blog/commit/7637afe102def5573cca7013d55ff8955491c4c3))

## [6.26.141](https://github.com/aquariuslt/blog/compare/v6.26.140...v6.26.141) (2020-10-02)

### Bug Fixes

- **deps:** update dependency markdown-it-anchor to v6 ([#712](https://github.com/aquariuslt/blog/issues/712)) ([fc3a22a](https://github.com/aquariuslt/blog/commit/fc3a22a549d7f026ae200415ec67e6a49926b127))

## [6.26.140](https://github.com/aquariuslt/blog/compare/v6.26.139...v6.26.140) (2020-10-01)

### Bug Fixes

- **deps:** update dependency highlight.js to v10.2.1 ([69f8f34](https://github.com/aquariuslt/blog/commit/69f8f345c4c0a16443b681ab02dd1c33fc7d028b))

## [6.26.139](https://github.com/aquariuslt/blog/compare/v6.26.138...v6.26.139) (2020-09-29)

### Bug Fixes

- **deps:** update dependency path-to-regexp to v6.2.0 ([ad84641](https://github.com/aquariuslt/blog/commit/ad846410b840fc9dd1eb98ec229514b680c41144))

## [6.26.138](https://github.com/aquariuslt/blog/compare/v6.26.137...v6.26.138) (2020-09-26)

### Bug Fixes

- **deps:** update dependency vue-router to v3.4.5 ([7f09418](https://github.com/aquariuslt/blog/commit/7f09418bdd54f4ec1fdf1909aa9db6b2cd26df22))

## [6.26.137](https://github.com/aquariuslt/blog/compare/v6.26.136...v6.26.137) (2020-09-25)

### Bug Fixes

- **deps:** update dependency slate-history to v0.59.0 ([b75b6ed](https://github.com/aquariuslt/blog/commit/b75b6ed6ef8e42cc1113f14a8e8ebf4b8b015020))

## [6.26.136](https://github.com/aquariuslt/blog/compare/v6.26.135...v6.26.136) (2020-09-25)

### Bug Fixes

- **deps:** update dependency slate-react to v0.59.0 ([5b33823](https://github.com/aquariuslt/blog/commit/5b33823ad9544bab51ab1e8d0a6552fd86db0b5b))

## [6.26.135](https://github.com/aquariuslt/blog/compare/v6.26.134...v6.26.135) (2020-09-25)

### Bug Fixes

- **deps:** update dependency slate to v0.59.0 ([9d5d0a2](https://github.com/aquariuslt/blog/commit/9d5d0a2fc86ba6305818a0092996d4e80bbef015))

## [6.26.134](https://github.com/aquariuslt/blog/compare/v6.26.133...v6.26.134) (2020-09-24)

### Bug Fixes

- **deps:** update dependency vue-router to v3.4.4 ([dfab486](https://github.com/aquariuslt/blog/commit/dfab4866de65c309d46e0551e8062d33c9ed2b06))

## [6.26.133](https://github.com/aquariuslt/blog/compare/v6.26.132...v6.26.133) (2020-09-22)

### Bug Fixes

- **deps:** update dependency puppeteer to v5.3.1 ([ef6d82e](https://github.com/aquariuslt/blog/commit/ef6d82e66369ee5b2e82b0d61895dc539635efd2))

## [6.26.132](https://github.com/aquariuslt/blog/compare/v6.26.131...v6.26.132) (2020-09-20)

### Bug Fixes

- **deps:** update dependency sharp to v0.26.1 ([0ae5eeb](https://github.com/aquariuslt/blog/commit/0ae5eeb831357ba41927c192b09a246f7534b667))

## [6.26.131](https://github.com/aquariuslt/blog/compare/v6.26.130...v6.26.131) (2020-09-20)

### Bug Fixes

- **deps:** update dependency rxjs to v6.6.3 ([fca95ba](https://github.com/aquariuslt/blog/commit/fca95ba0664736a7f876e1c2dd26caacbb3dee84))

## [6.26.130](https://github.com/aquariuslt/blog/compare/v6.26.129...v6.26.130) (2020-09-17)

### Bug Fixes

- **deps:** update dependency vue-class-component to v7.2.6 ([c87e424](https://github.com/aquariuslt/blog/commit/c87e424a7c943cc60f50234d7097c613d1ed7b12))

## [6.26.129](https://github.com/aquariuslt/blog/compare/v6.26.128...v6.26.129) (2020-09-17)

### Bug Fixes

- **deps:** update dependency @mdi/font to v5.6.55 ([62c20e2](https://github.com/aquariuslt/blog/commit/62c20e2c004ad299b2f1c74ad7ddeb1112a262e1))

## [6.26.128](https://github.com/aquariuslt/blog/compare/v6.26.127...v6.26.128) (2020-09-14)

### Bug Fixes

- **deps:** update dependency @loadable/component to v5.13.2 ([034a90e](https://github.com/aquariuslt/blog/commit/034a90ea52a72a970418c31864408cb905719909))
- **deps:** update dependency markdown-it to v11.0.1 ([15893b8](https://github.com/aquariuslt/blog/commit/15893b8f24a19383f7789297a4f02542bfc08eaf))

## [6.26.127](https://github.com/aquariuslt/blog/compare/v6.26.126...v6.26.127) (2020-09-12)

### Bug Fixes

- **deps:** update dependency puppeteer to v5.3.0 ([#656](https://github.com/aquariuslt/blog/issues/656)) ([b0eeff3](https://github.com/aquariuslt/blog/commit/b0eeff35d7a7f7904eae4a773a92234ac0f035b9))

## [6.26.126](https://github.com/aquariuslt/blog/compare/v6.26.125...v6.26.126) (2020-09-09)

### Bug Fixes

- **deps:** update dependency highlight.js to v10.2.0 ([#643](https://github.com/aquariuslt/blog/issues/643)) ([a48512f](https://github.com/aquariuslt/blog/commit/a48512fe7ea9f09b47cd34cfb83d4100db8b8956))

## [6.26.125](https://github.com/aquariuslt/blog/compare/v6.26.124...v6.26.125) (2020-09-06)

### Bug Fixes

- **deps:** update dependency notistack to v1 ([#595](https://github.com/aquariuslt/blog/issues/595)) ([44e3cf0](https://github.com/aquariuslt/blog/commit/44e3cf074a126797d110c44fc65ddbc280ea564a))
- **deps:** update dependency scroll-into-view-if-needed to v2.2.26 ([#631](https://github.com/aquariuslt/blog/issues/631)) ([63e9481](https://github.com/aquariuslt/blog/commit/63e9481ecefee1da8d70d989c11678907a814ff0))

## [6.26.124](https://github.com/aquariuslt/blog/compare/v6.26.123...v6.26.124) (2020-08-31)

### Bug Fixes

- **deps:** update dependency date-fns to v2.16.1 ([df3f0e1](https://github.com/aquariuslt/blog/commit/df3f0e134978603c11089d83009c96e3cd112b4b))

## [6.26.123](https://github.com/aquariuslt/blog/compare/v6.26.122...v6.26.123) (2020-08-26)

### Bug Fixes

- **deps:** update vue monorepo to v2.6.12 ([779ab1f](https://github.com/aquariuslt/blog/commit/779ab1ff225f9e639a35f893cf752c19e003acaa))

## [6.26.122](https://github.com/aquariuslt/blog/compare/v6.26.121...v6.26.122) (2020-08-25)

### Bug Fixes

- **deps:** update dependency sharp to v0.26.0 ([99552f0](https://github.com/aquariuslt/blog/commit/99552f0caef25b063f2e38189ed14c2785b100bf))

## [6.26.121](https://github.com/aquariuslt/blog/compare/v6.26.120...v6.26.121) (2020-08-24)

### Bug Fixes

- **deps:** update dependency schema-dts to v0.7.1 ([1b7ef7a](https://github.com/aquariuslt/blog/commit/1b7ef7adbb93b62deb783a355168907de0761d8e))

## [6.26.120](https://github.com/aquariuslt/blog/compare/v6.26.119...v6.26.120) (2020-08-21)

### Bug Fixes

- **deps:** update dependency schema-dts to v0.7.0 ([7cd67bb](https://github.com/aquariuslt/blog/commit/7cd67bbd0069b5800b30a45999b5e3e32b08bbe8))

## [6.26.119](https://github.com/aquariuslt/blog/compare/v6.26.118...v6.26.119) (2020-08-21)

### Bug Fixes

- **deps:** update dependency vanilla-lazyload to v17.1.2 ([cfeda7f](https://github.com/aquariuslt/blog/commit/cfeda7f4cfd2d23f09816050b517dc6ddf9317b8))

## [6.26.118](https://github.com/aquariuslt/blog/compare/v6.26.117...v6.26.118) (2020-08-21)

### Bug Fixes

- **deps:** update dependency axios to v0.20.0 ([2a2aaa9](https://github.com/aquariuslt/blog/commit/2a2aaa9215a543b955c808ba63911eb9b2373655))

## [6.26.117](https://github.com/aquariuslt/blog/compare/v6.26.116...v6.26.117) (2020-08-11)

### Bug Fixes

- **deps:** update dependency vue-router to v3.4.3 ([e8799ab](https://github.com/aquariuslt/blog/commit/e8799ab1e61f1c22f8a4d95e4a001a6dd9793378))

## [6.26.116](https://github.com/aquariuslt/blog/compare/v6.26.115...v6.26.116) (2020-08-10)

### Bug Fixes

- **deps:** update dependency @mdi/font to v5.5.55 ([9f9c829](https://github.com/aquariuslt/blog/commit/9f9c829a86468bf5d20f2b1312dd830ea486d5e4))

## [6.26.115](https://github.com/aquariuslt/blog/compare/v6.26.114...v6.26.115) (2020-08-07)

### Bug Fixes

- **deps:** update dependency vue-router to v3.4.2 ([4bfd374](https://github.com/aquariuslt/blog/commit/4bfd37492954b8005d346bbbe636f73690ea8c79))

## [6.26.114](https://github.com/aquariuslt/blog/compare/v6.26.113...v6.26.114) (2020-08-05)

### Bug Fixes

- **deps:** update dependency vue-router to v3.4.0 ([c07579e](https://github.com/aquariuslt/blog/commit/c07579e0aea08f1a3f599b09db1922f4e4d1f2b5))

## [6.26.113](https://github.com/aquariuslt/blog/compare/v6.26.112...v6.26.113) (2020-08-02)

### Bug Fixes

- **deps:** update dependency cosmiconfig to v7 ([#554](https://github.com/aquariuslt/blog/issues/554)) ([4457033](https://github.com/aquariuslt/blog/commit/4457033561b2b5f62f8aca790a940128e05abfe2))

## [6.26.112](https://github.com/aquariuslt/blog/compare/v6.26.111...v6.26.112) (2020-07-31)

### Bug Fixes

- **deps:** update dependency rxjs to v6.6.2 ([e76cc81](https://github.com/aquariuslt/blog/commit/e76cc813fcf9f64c73c7022b7c01818ac94c2ecd))

## [6.26.111](https://github.com/aquariuslt/blog/compare/v6.26.110...v6.26.111) (2020-07-30)

### Bug Fixes

- **deps:** update nest monorepo to v7.4.2 ([1f37a01](https://github.com/aquariuslt/blog/commit/1f37a017316f87c6d90545b6d49614120ca964de))

## [6.26.110](https://github.com/aquariuslt/blog/compare/v6.26.109...v6.26.110) (2020-07-30)

### Bug Fixes

- **deps:** update dependency class-transformer to v0.3.1 ([45ca5e1](https://github.com/aquariuslt/blog/commit/45ca5e18d3595905fce54ff27ab508a97abbc7fa))

## [6.26.109](https://github.com/aquariuslt/blog/compare/v6.26.108...v6.26.109) (2020-07-29)

### Bug Fixes

- **deps:** update nest monorepo to v7.4.1 ([18479e9](https://github.com/aquariuslt/blog/commit/18479e9ac64e13d98c3a46a2e6ae09be9b5b6c5d))

## [6.26.108](https://github.com/aquariuslt/blog/compare/v6.26.107...v6.26.108) (2020-07-29)

### Bug Fixes

- **deps:** update nest monorepo to v7.4.0 ([08c9f3c](https://github.com/aquariuslt/blog/commit/08c9f3c01334355c3d7d6dad8507f52dee8ede5c))

## [6.26.107](https://github.com/aquariuslt/blog/compare/v6.26.106...v6.26.107) (2020-07-26)

### Bug Fixes

- **deps:** update dependency @mdi/font to v5.4.55 ([32cabfa](https://github.com/aquariuslt/blog/commit/32cabfaf740e723d384e060ecbabf95e484f588f))

## [6.26.106](https://github.com/aquariuslt/blog/compare/v6.26.105...v6.26.106) (2020-07-23)

### Bug Fixes

- **deps:** update dependency highlight.js to v10.1.2 ([6da683e](https://github.com/aquariuslt/blog/commit/6da683edffdcb985ebf7e31ad2ea30502484b5ca))

## [6.26.105](https://github.com/aquariuslt/blog/compare/v6.26.104...v6.26.105) (2020-07-23)

### Bug Fixes

- **deps:** update dependency vue-class-component to v7.2.5 ([7cf7e34](https://github.com/aquariuslt/blog/commit/7cf7e34d77f45f477ec2f34e3c37ece9d75dc8ec))

## [6.26.104](https://github.com/aquariuslt/blog/compare/v6.26.103...v6.26.104) (2020-07-21)

### Bug Fixes

- **deps:** update dependency puppeteer to v5.2.1 ([ec5f1da](https://github.com/aquariuslt/blog/commit/ec5f1da36bcaebb4d3e6ab929ff7fc7ae64ad11b))

## [6.26.103](https://github.com/aquariuslt/blog/compare/v6.26.102...v6.26.103) (2020-07-20)

### Bug Fixes

- **deps:** update dependency vue-class-component to v7.2.4 ([ce42d87](https://github.com/aquariuslt/blog/commit/ce42d8758e5990c32fdf10ba3c8009a83b43601b))

## [6.26.102](https://github.com/aquariuslt/blog/compare/v6.26.101...v6.26.102) (2020-07-17)

### Bug Fixes

- **deps:** update dependency date-fns to v2.15.0 ([402eff6](https://github.com/aquariuslt/blog/commit/402eff6bf365970ab82669a0fa660a723ac36348))

## [6.26.101](https://github.com/aquariuslt/blog/compare/v6.26.100...v6.26.101) (2020-07-17)

### Bug Fixes

- **deps:** update dependency puppeteer to v5.2.0 ([63d9413](https://github.com/aquariuslt/blog/commit/63d9413292111490c537d498d3d423e3835d4adb))

## [6.26.100](https://github.com/aquariuslt/blog/compare/v6.26.99...v6.26.100) (2020-07-13)

### Bug Fixes

- **deps:** update dependency puppeteer to v5.1.0 ([5d740c4](https://github.com/aquariuslt/blog/commit/5d740c4459d597b6a74beaa4d7846ec4b9759be7))

## [6.26.99](https://github.com/aquariuslt/blog/compare/v6.26.98...v6.26.99) (2020-07-10)

### Bug Fixes

- **deps:** update dependency puppeteer to v5 ([#473](https://github.com/aquariuslt/blog/issues/473)) ([cde4374](https://github.com/aquariuslt/blog/commit/cde4374cf4f5bd70b13de5ff1b9d034b87a2762b))

## [6.26.98](https://github.com/aquariuslt/blog/compare/v6.26.97...v6.26.98) (2020-07-08)

### Bug Fixes

- **deps:** update nest monorepo to v7.3.2 ([7c1ba9c](https://github.com/aquariuslt/blog/commit/7c1ba9cd7bd89ef0eca43e22329e27f8f0585f19))

## [6.26.97](https://github.com/aquariuslt/blog/compare/v6.26.96...v6.26.97) (2020-07-08)

### Bug Fixes

- **deps:** update dependency slate-history to v0.58.4 ([cad87b1](https://github.com/aquariuslt/blog/commit/cad87b13090be609e9ebf80c156a3b7a494b19e5))

## [6.26.96](https://github.com/aquariuslt/blog/compare/v6.26.95...v6.26.96) (2020-07-08)

### Bug Fixes

- **deps:** update dependency slate-react to v0.58.4 ([49b7fc8](https://github.com/aquariuslt/blog/commit/49b7fc89fb187a68dd291ff4366c15b4bc2f4086))

## [6.26.95](https://github.com/aquariuslt/blog/compare/v6.26.94...v6.26.95) (2020-07-08)

### Bug Fixes

- **deps:** update dependency slate to v0.58.4 ([e0d638e](https://github.com/aquariuslt/blog/commit/e0d638ea9c6bd82e2845ff392d00676f0b7799fb))

## [6.26.94](https://github.com/aquariuslt/blog/compare/v6.26.93...v6.26.94) (2020-07-02)

### Bug Fixes

- **deps:** update dependency vue-disqus to v4.0.1 ([f3d37ef](https://github.com/aquariuslt/blog/commit/f3d37ef17f9d5d7cea03661570a07db0ef9c66b8))

## [6.26.93](https://github.com/aquariuslt/blog/compare/v6.26.92...v6.26.93) (2020-07-02)

### Bug Fixes

- **deps:** update dependency @loadable/component to v5.13.1 ([6752423](https://github.com/aquariuslt/blog/commit/6752423abb10df214a162380d25340d1d1061f2d))

## [6.26.92](https://github.com/aquariuslt/blog/compare/v6.26.91...v6.26.92) (2020-07-02)

### Bug Fixes

- **deps:** update nest monorepo to v7.3.1 ([f5bcb0b](https://github.com/aquariuslt/blog/commit/f5bcb0b818d71c4f45715c2962b5101d9801746b))

## [6.26.91](https://github.com/aquariuslt/blog/compare/v6.26.90...v6.26.91) (2020-07-02)

### Bug Fixes

- **deps:** update dependency rxjs to v6.6.0 ([aea1a15](https://github.com/aquariuslt/blog/commit/aea1a1576f5b9388a979da5457b2dd123527f976))

## [6.26.90](https://github.com/aquariuslt/blog/compare/v6.26.89...v6.26.90) (2020-07-01)

### Bug Fixes

- **deps:** update dependency vanilla-lazyload to v17.1.0 ([452747f](https://github.com/aquariuslt/blog/commit/452747f6b315ea5574cb9ecb4e8e382cecc78e6b))

## [6.26.89](https://github.com/aquariuslt/blog/compare/v6.26.88...v6.26.89) (2020-07-01)

### Bug Fixes

- **deps:** update nest monorepo to v7.3.0 ([9e31039](https://github.com/aquariuslt/blog/commit/9e310392249c2acd1c2118f289714873b519363d))

## [6.26.88](https://github.com/aquariuslt/blog/compare/v6.26.87...v6.26.88) (2020-07-01)

### Bug Fixes

- **deps:** update dependency @material-ui/core to v4.11.0 ([f382559](https://github.com/aquariuslt/blog/commit/f382559a53f85051ee157453727c5650aa4edd60))

## [6.26.87](https://github.com/aquariuslt/blog/compare/v6.26.86...v6.26.87) (2020-06-29)

### Bug Fixes

- **deps:** update dependency @loadable/component to v5.13.0 ([e378b3b](https://github.com/aquariuslt/blog/commit/e378b3b87c6be684363363a0eed266b000aa3b8b))

## [6.26.86](https://github.com/aquariuslt/blog/compare/v6.26.85...v6.26.86) (2020-06-26)

### Bug Fixes

- **deps:** update dependency vanilla-lazyload to v17 ([#456](https://github.com/aquariuslt/blog/issues/456)) ([60ba0b7](https://github.com/aquariuslt/blog/commit/60ba0b73357cba9955848442b7ccdf8eb8317504))

## [6.26.85](https://github.com/aquariuslt/blog/compare/v6.26.84...v6.26.85) (2020-06-24)

### Bug Fixes

- **deps:** update dependency puppeteer to v4.0.1 ([387b06e](https://github.com/aquariuslt/blog/commit/387b06e4cd69efc654fb530222a9aaa0a5a6d054))

## [6.26.84](https://github.com/aquariuslt/blog/compare/v6.26.83...v6.26.84) (2020-06-22)

### Bug Fixes

- **deps:** update dependency @nestjs/serve-static to v2.1.3 ([6fbb83f](https://github.com/aquariuslt/blog/commit/6fbb83f58df1fe60d13a7cc96eb872b5e097ff16))

## [6.26.83](https://github.com/aquariuslt/blog/compare/v6.26.82...v6.26.83) (2020-06-22)

### Bug Fixes

- **deps:** update dependency puppeteer to v4 ([#417](https://github.com/aquariuslt/blog/issues/417)) ([1c69f49](https://github.com/aquariuslt/blog/commit/1c69f49fb6024a947bc53eb155a7a826f24bb06c))
- **deps:** update dependency vue-property-decorator to v9 ([#428](https://github.com/aquariuslt/blog/issues/428)) ([0667967](https://github.com/aquariuslt/blog/commit/0667967e7cac65a6b5d786119ad6bc3a302a3d22))

## [6.26.82](https://github.com/aquariuslt/blog/compare/v6.26.81...v6.26.82) (2020-06-18)

### Bug Fixes

- **deps:** update dependency vue-property-decorator to v8.5.1 ([70d24fd](https://github.com/aquariuslt/blog/commit/70d24fdd1864c40a3d1a92040ee6c6b981dab2a8))

## [6.26.81](https://github.com/aquariuslt/blog/compare/v6.26.80...v6.26.81) (2020-06-16)

### Bug Fixes

- **deps:** update dependency highlight.js to v10.1.1 ([97e1901](https://github.com/aquariuslt/blog/commit/97e190128b6f0de7857c5ed2d56d94dc64c640ab))

## [6.26.80](https://github.com/aquariuslt/blog/compare/v6.26.79...v6.26.80) (2020-06-13)

### Bug Fixes

- **deps:** update dependency vue-router to v3.3.4 ([6e7bb41](https://github.com/aquariuslt/blog/commit/6e7bb412387c8ecc3a7e5f3634ef8f7f08c3ed1f))

## [6.26.79](https://github.com/aquariuslt/blog/compare/v6.26.78...v6.26.79) (2020-06-12)

### Bug Fixes

- **deps:** update dependency vue-property-decorator to v8.5.0 ([57fd55a](https://github.com/aquariuslt/blog/commit/57fd55a2502cac3451754ce3e2ace7a2f85b29f7))

## [6.26.78](https://github.com/aquariuslt/blog/compare/v6.26.77...v6.26.78) (2020-06-12)

### Bug Fixes

- **deps:** update dependency sharp to v0.25.4 ([eb805ef](https://github.com/aquariuslt/blog/commit/eb805ef0f70792dfe8652c993382bd54e4491f90))

## [6.26.77](https://github.com/aquariuslt/blog/compare/v6.26.76...v6.26.77) (2020-06-12)

### Bug Fixes

- **deps:** update dependency vue-disqus to v4 ([#399](https://github.com/aquariuslt/blog/issues/399)) ([bd85c3c](https://github.com/aquariuslt/blog/commit/bd85c3c13617c6e2ce6f6abeaf9faf631dfcd688))

## [6.26.76](https://github.com/aquariuslt/blog/compare/v6.26.75...v6.26.76) (2020-06-11)

### Bug Fixes

- **deps:** update dependency @material-ui/core to v4.10.2 ([9f27ceb](https://github.com/aquariuslt/blog/commit/9f27ceb6bcdb23cdb0ecb1810cf130e7a39f266a))

## [6.26.75](https://github.com/aquariuslt/blog/compare/v6.26.74...v6.26.75) (2020-06-10)

### Bug Fixes

- **deps:** update dependency notistack to v0.9.17 ([17abce0](https://github.com/aquariuslt/blog/commit/17abce01ed18b61cfa56586004af4288402a204d))

## [6.26.74](https://github.com/aquariuslt/blog/compare/v6.26.73...v6.26.74) (2020-06-10)

### Bug Fixes

- **deps:** update dependency vue-meta to v2.4.0 ([57bdafd](https://github.com/aquariuslt/blog/commit/57bdafd4c914e99d25a495c78f7221dcbe859330))

## [6.26.73](https://github.com/aquariuslt/blog/compare/v6.26.72...v6.26.73) (2020-06-08)

### Bug Fixes

- **deps:** update dependency react-helmet to v6.1.0 ([a4a12dc](https://github.com/aquariuslt/blog/commit/a4a12dc568858761280e4b243e493f44043e5461))

## [6.26.72](https://github.com/aquariuslt/blog/compare/v6.26.71...v6.26.72) (2020-06-04)

### Bug Fixes

- **deps:** update dependency fs-extra to v9.0.1 ([347912d](https://github.com/aquariuslt/blog/commit/347912dcf58fbc4967246818f794dcae83d55b29))

## [6.26.71](https://github.com/aquariuslt/blog/compare/v6.26.70...v6.26.71) (2020-06-03)

### Bug Fixes

- **deps:** update nest monorepo to v7.1.3 ([646fce3](https://github.com/aquariuslt/blog/commit/646fce316ff8a216abdbc5ba7b906b6bf909267e))

## [6.26.70](https://github.com/aquariuslt/blog/compare/v6.26.69...v6.26.70) (2020-06-02)

### Bug Fixes

- **deps:** update dependency puppeteer to v3.3.0 ([149f7fc](https://github.com/aquariuslt/blog/commit/149f7fc2a61b9bb48b7606b74e9582619ee52050))

## [6.26.69](https://github.com/aquariuslt/blog/compare/v6.26.68...v6.26.69) (2020-06-01)

### Bug Fixes

- **deps:** update dependency @material-ui/core to v4.10.1 ([c4c6745](https://github.com/aquariuslt/blog/commit/c4c674552ff1537a586fc6c9ceec06d5f7d610fc))

## [6.26.68](https://github.com/aquariuslt/blog/compare/v6.26.67...v6.26.68) (2020-06-01)

### Bug Fixes

- **deps:** update nest monorepo to v7.1.2 ([2e5b85f](https://github.com/aquariuslt/blog/commit/2e5b85fbcbff96f6b4f4ceaf91393e4c98e51bce))

## [6.26.67](https://github.com/aquariuslt/blog/compare/v6.26.66...v6.26.67) (2020-05-30)

### Bug Fixes

- **deps:** update dependency clsx to v1.1.1 ([b94adb6](https://github.com/aquariuslt/blog/commit/b94adb6c0e43c2cb4dad8d5bb16a2db008a3f2aa))

## [6.26.66](https://github.com/aquariuslt/blog/compare/v6.26.65...v6.26.66) (2020-05-29)

### Bug Fixes

- **deps:** update dependency vue-router to v3.3.2 ([c487de0](https://github.com/aquariuslt/blog/commit/c487de04e160eaefd9d2176af78e4c3193dae744))

## [6.26.65](https://github.com/aquariuslt/blog/compare/v6.26.64...v6.26.65) (2020-05-29)

### Bug Fixes

- **deps:** update dependency puppeteer to v3.2.0 ([e11111b](https://github.com/aquariuslt/blog/commit/e11111bcb068714940d57ab85a834136f33fd8a9))

## [6.26.64](https://github.com/aquariuslt/blog/compare/v6.26.63...v6.26.64) (2020-05-28)

### Bug Fixes

- **deps:** update nest monorepo to v7.1.1 ([8872c73](https://github.com/aquariuslt/blog/commit/8872c73aa0e1f3d33a95807d16fc1090923d5304))

## [6.26.63](https://github.com/aquariuslt/blog/compare/v6.26.62...v6.26.63) (2020-05-27)

### Bug Fixes

- **deps:** update dependency vue-router to v3.3.1 ([1c1da9a](https://github.com/aquariuslt/blog/commit/1c1da9a3c64cff4339704c01118fea110f35957d))

## [6.26.62](https://github.com/aquariuslt/blog/compare/v6.26.61...v6.26.62) (2020-05-27)

### Bug Fixes

- **deps:** update dependency scroll-into-view-if-needed to v2.2.25 ([3daadcc](https://github.com/aquariuslt/blog/commit/3daadccf0ad2f90e32549069d09190ca4653061e))

## [6.26.61](https://github.com/aquariuslt/blog/compare/v6.26.60...v6.26.61) (2020-05-27)

### Bug Fixes

- **deps:** update dependency vue-router to v3.3.0 ([4af6657](https://github.com/aquariuslt/blog/commit/4af66574230634603f9b91b4d0ae0411702e1376))

## [6.26.60](https://github.com/aquariuslt/blog/compare/v6.26.59...v6.26.60) (2020-05-27)

### Bug Fixes

- **deps:** update dependency vue-meta to v2.3.4 ([ebc8175](https://github.com/aquariuslt/blog/commit/ebc8175a1d4c04f49a00b248d5c9e7eecfda786f))

## [6.26.59](https://github.com/aquariuslt/blog/compare/v6.26.58...v6.26.59) (2020-05-25)

### Bug Fixes

- **deps:** update dependency log4js to v6.3.0 ([f3db79f](https://github.com/aquariuslt/blog/commit/f3db79fcf163a4035d9a1f180c5e034be1f1281e))

## [6.26.58](https://github.com/aquariuslt/blog/compare/v6.26.57...v6.26.58) (2020-05-24)

### Bug Fixes

- **deps:** update nest monorepo to v7.1.0 ([64ecf5a](https://github.com/aquariuslt/blog/commit/64ecf5ad28c6655f23201b7bd89950e83cb1164c))

## [6.26.57](https://github.com/aquariuslt/blog/compare/v6.26.56...v6.26.57) (2020-05-24)

### Bug Fixes

- **deps:** update dependency @mdi/font to v5.3.45 ([332fd99](https://github.com/aquariuslt/blog/commit/332fd99cce97d518b9b7761ac15c3db9383bc7a1))

## [6.26.56](https://github.com/aquariuslt/blog/compare/v6.26.55...v6.26.56) (2020-05-23)

### Bug Fixes

- **deps:** update dependency @material-ui/core to v4.10.0 ([3747bd2](https://github.com/aquariuslt/blog/commit/3747bd2064ddffde143822886379a9ce7ae6e376))

## [6.26.55](https://github.com/aquariuslt/blog/compare/v6.26.54...v6.26.55) (2020-05-22)

### Bug Fixes

- **deps:** update dependency markdown-it to v11 ([#339](https://github.com/aquariuslt/blog/issues/339)) ([fa48ea9](https://github.com/aquariuslt/blog/commit/fa48ea9060a811881e3bd29523cc83cc97389143))
- **deps:** update dependency vanilla-lazyload to v16 ([#316](https://github.com/aquariuslt/blog/issues/316)) ([114d472](https://github.com/aquariuslt/blog/commit/114d4726339579bb443acb93a4dbc768f7735d76))

## [6.26.54](https://github.com/aquariuslt/blog/compare/v6.26.53...v6.26.54) (2020-05-19)

### Bug Fixes

- **deps:** update dependency vue-router to v3.2.0 ([9479f9e](https://github.com/aquariuslt/blog/commit/9479f9e120657ed33ccd0d6efe4455262d1d6bd9))

## [6.26.53](https://github.com/aquariuslt/blog/compare/v6.26.52...v6.26.53) (2020-05-19)

### Bug Fixes

- **deps:** update dependency schema-dts to v0.6.0 ([e0b0f5d](https://github.com/aquariuslt/blog/commit/e0b0f5d8f8de5aaa920765488858552e7895bbdb))

## [6.26.52](https://github.com/aquariuslt/blog/compare/v6.26.51...v6.26.52) (2020-05-18)

### Bug Fixes

- **deps:** update dependency date-fns to v2.14.0 ([5f4c6a6](https://github.com/aquariuslt/blog/commit/5f4c6a68341ca0c58c4ae6cd98170dfd203c54df))

## [6.26.51](https://github.com/aquariuslt/blog/compare/v6.26.50...v6.26.51) (2020-05-18)

### Bug Fixes

- **deps:** update dependency puppeteer to v3.1.0 ([881f1bd](https://github.com/aquariuslt/blog/commit/881f1bd58c544d792590539a4332e35f48e3df2a))

## [6.26.50](https://github.com/aquariuslt/blog/compare/v6.26.49...v6.26.50) (2020-05-17)

### Bug Fixes

- **deps:** update dependency notistack to v0.9.16 ([9425e52](https://github.com/aquariuslt/blog/commit/9425e52e481b05b8e688d54a2e03e91c6a0e20ee))

## [6.26.49](https://github.com/aquariuslt/blog/compare/v6.26.48...v6.26.49) (2020-05-17)

### Bug Fixes

- **deps:** update dependency notistack to v0.9.15 ([61f6ac2](https://github.com/aquariuslt/blog/commit/61f6ac2a103582c348b804f08f249c3f1eb3c1fc))

## [6.26.48](https://github.com/aquariuslt/blog/compare/v6.26.47...v6.26.48) (2020-05-17)

### Bug Fixes

- **deps:** update dependency sharp to v0.25.3 ([e737b57](https://github.com/aquariuslt/blog/commit/e737b57b18d08bb2a0f9acf92977ed68a99ff4e5))

## [6.26.47](https://github.com/aquariuslt/blog/compare/v6.26.46...v6.26.47) (2020-05-15)

### Bug Fixes

- **deps:** update nest monorepo to v7.0.13 ([12c400a](https://github.com/aquariuslt/blog/commit/12c400ac44f8b183d34b418641889a6ac9e042e0))

## [6.26.46](https://github.com/aquariuslt/blog/compare/v6.26.45...v6.26.46) (2020-05-15)

### Bug Fixes

- **deps:** update dependency notistack to v0.9.14 ([b439b1b](https://github.com/aquariuslt/blog/commit/b439b1ba58a69df8da279abef097f4901c7541a6))

## [6.26.45](https://github.com/aquariuslt/blog/compare/v6.26.44...v6.26.45) (2020-05-13)

### Bug Fixes

- **deps:** update dependency @mdi/font to v5.2.45 ([2b570ed](https://github.com/aquariuslt/blog/commit/2b570ed51bdb8fc77163ab635967376e72bddd69))

## [6.26.44](https://github.com/aquariuslt/blog/compare/v6.26.43...v6.26.44) (2020-05-13)

### Bug Fixes

- **deps:** update dependency notistack to v0.9.13 ([f86ee86](https://github.com/aquariuslt/blog/commit/f86ee86c9e082be0521dfe5b7cf9722926f155f4))

## [6.26.43](https://github.com/aquariuslt/blog/compare/v6.26.42...v6.26.43) (2020-05-12)

### Bug Fixes

- **deps:** update dependency markdown-it-anchor to v5.3.0 ([baf63b3](https://github.com/aquariuslt/blog/commit/baf63b38065b19b34e19f04d26bc1edc16903ea9))

## [6.26.42](https://github.com/aquariuslt/blog/compare/v6.26.41...v6.26.42) (2020-05-12)

### Bug Fixes

- **deps:** update nest monorepo to v7.0.11 ([d7704ca](https://github.com/aquariuslt/blog/commit/d7704ca9b06dca64cf7517233306e325cfb23c61))

## [6.26.41](https://github.com/aquariuslt/blog/compare/v6.26.40...v6.26.41) (2020-05-12)

### Bug Fixes

- **deps:** update nest monorepo to v7.0.10 ([af34c7b](https://github.com/aquariuslt/blog/commit/af34c7b7910cc982ea1bd44277fb9e871519edc0))

## [6.26.40](https://github.com/aquariuslt/blog/compare/v6.26.39...v6.26.40) (2020-05-12)

### Bug Fixes

- **deps:** update dependency @nestjs/serve-static to v2.1.1 ([87b3d65](https://github.com/aquariuslt/blog/commit/87b3d65ba10f29bb534c9570ec1a22246d46c448))

## [6.26.39](https://github.com/aquariuslt/blog/compare/v6.26.38...v6.26.39) (2020-05-12)

### Bug Fixes

- **deps:** update dependency highlight.js to v10.0.3 ([dee64bc](https://github.com/aquariuslt/blog/commit/dee64bc24e87995a9c12ca2b4d962297c79661c0))

## [6.26.38](https://github.com/aquariuslt/blog/compare/v6.26.37...v6.26.38) (2020-05-12)

### Bug Fixes

- **deps:** update dependency @material-ui/core to v4.9.14 ([7759119](https://github.com/aquariuslt/blog/commit/77591191ad06cc61d4ae2d60c76d8fd418b00f92))

## [6.26.37](https://github.com/aquariuslt/blog/compare/v6.26.36...v6.26.37) (2020-05-11)

### Bug Fixes

- **deps:** update dependency react-router-dom to v5.2.0 ([8f4ba8d](https://github.com/aquariuslt/blog/commit/8f4ba8d1d6f19081c8082cdf6f208c902111319b))

## [6.26.36](https://github.com/aquariuslt/blog/compare/v6.26.35...v6.26.36) (2020-05-08)

### Bug Fixes

- **deps:** update dependency vanilla-lazyload to v15.2.0 ([11c9cea](https://github.com/aquariuslt/blog/commit/11c9cea766a41572e461c84910a6a679c98d1515))

## [6.26.35](https://github.com/aquariuslt/blog/compare/v6.26.34...v6.26.35) (2020-05-07)

### Bug Fixes

- **deps:** update dependency puppeteer to v3.0.4 ([76e0ed4](https://github.com/aquariuslt/blog/commit/76e0ed4b133de782b32b1889e4a6682dfdfdd386))

## [6.26.34](https://github.com/aquariuslt/blog/compare/v6.26.33...v6.26.34) (2020-05-06)

### Bug Fixes

- **deps:** update dependency date-fns to v2.13.0 ([784d714](https://github.com/aquariuslt/blog/commit/784d714208ba7c6a2f07e362653138cb8dd12b46))

## [6.26.33](https://github.com/aquariuslt/blog/compare/v6.26.32...v6.26.33) (2020-05-06)

### Bug Fixes

- **deps:** update dependency puppeteer to v3.0.3 ([f4d6e15](https://github.com/aquariuslt/blog/commit/f4d6e15047c421aa6b984115e04308566d5e315a))

## [6.26.32](https://github.com/aquariuslt/blog/compare/v6.26.31...v6.26.32) (2020-05-05)

### Bug Fixes

- **deps:** update dependency schema-dts to v0.5.3 ([d95d9a8](https://github.com/aquariuslt/blog/commit/d95d9a815b9ac4074651eccfaf2e4877ffdadbb8))

## [6.26.31](https://github.com/aquariuslt/blog/compare/v6.26.30...v6.26.31) (2020-05-04)

### Bug Fixes

- **deps:** update dependency @material-ui/core to v4.9.13 ([51a1299](https://github.com/aquariuslt/blog/commit/51a1299299879c836a332f52d448cf2792592198))

## [6.26.30](https://github.com/aquariuslt/blog/compare/v6.26.29...v6.26.30) (2020-05-03)

### Bug Fixes

- **deps:** update dependency highlight.js to v10.0.2 ([9731882](https://github.com/aquariuslt/blog/commit/9731882404bdc1620c8d6fc27418350cfbd884c4))

## [6.26.29](https://github.com/aquariuslt/blog/compare/v6.26.28...v6.26.29) (2020-04-28)

### Bug Fixes

- **deps:** update dependency puppeteer to v3.0.2 ([075ffaf](https://github.com/aquariuslt/blog/commit/075ffafa7e8c20a67568dc7fa88978253a0e26b3))

## [6.26.28](https://github.com/aquariuslt/blog/compare/v6.26.27...v6.26.28) (2020-04-27)

### Bug Fixes

- **deps:** update dependency @material-ui/core to v4.9.12 ([a2aae8c](https://github.com/aquariuslt/blog/commit/a2aae8cc3388db24f1a814fc90a172d190129b91))

## [6.26.27](https://github.com/aquariuslt/blog/compare/v6.26.26...v6.26.27) (2020-04-26)

### Bug Fixes

- **deps:** update dependency highlight.js to v10.0.1 ([c15889d](https://github.com/aquariuslt/blog/commit/c15889d0684bb6cf83605af9016960681c151eae))

## [6.26.26](https://github.com/aquariuslt/blog/compare/v6.26.25...v6.26.26) (2020-04-25)

### Bug Fixes

- **deps:** update dependency class-validator to v0.12.2 ([#237](https://github.com/aquariuslt/blog/issues/237)) ([8d559bf](https://github.com/aquariuslt/blog/commit/8d559bf97e692a67fefec9cc800eda8920f0b551))
- **deps:** update dependency puppeteer to v3.0.1 ([#234](https://github.com/aquariuslt/blog/issues/234)) ([c28d3a5](https://github.com/aquariuslt/blog/commit/c28d3a5385e55e302980afde2743e12ffbc37995))
- **deps:** update dependency vue-property-decorator to v8.4.2 ([#243](https://github.com/aquariuslt/blog/issues/243)) ([765b4bd](https://github.com/aquariuslt/blog/commit/765b4bd1acfb62e7edbdb866de62de9c515eed2d))
- **deps:** update nest monorepo to v7.0.9 ([#239](https://github.com/aquariuslt/blog/issues/239)) ([4a5ed4a](https://github.com/aquariuslt/blog/commit/4a5ed4a59a2708b93c006bc396d90dc9c81a4cce))

## [6.26.25](https://github.com/aquariuslt/blog/compare/v6.26.24...v6.26.25) (2020-04-25)

### Bug Fixes

- **deps:** putback @types/express to v4.17.0 ([20c40bd](https://github.com/aquariuslt/blog/commit/20c40bdd4a7c6bbd94c572b544691abdfa48cf59))

## [6.26.24](https://github.com/aquariuslt/blog/compare/v6.26.23...v6.26.24) (2020-04-23)

### Bug Fixes

- **deps:** update dependency highlight.js to v10 ([#233](https://github.com/aquariuslt/blog/issues/233)) ([9e44b02](https://github.com/aquariuslt/blog/commit/9e44b021f7e1020d9fecf3a022106293daa52637))

## [6.26.23](https://github.com/aquariuslt/blog/compare/v6.26.22...v6.26.23) (2020-04-20)

### Bug Fixes

- **deps:** update dependency notistack to v0.9.11 ([9b6be4b](https://github.com/aquariuslt/blog/commit/9b6be4b015285bcb949b037c903da42489d364e7))

## [6.26.22](https://github.com/aquariuslt/blog/compare/v6.26.21...v6.26.22) (2020-04-19)

### Bug Fixes

- **deps:** update dependency log4js to v6.2.1 ([248e1bb](https://github.com/aquariuslt/blog/commit/248e1bb6fdca3e35fd85abf88c4f15b384f3d936))

## [6.26.21](https://github.com/aquariuslt/blog/compare/v6.26.20...v6.26.21) (2020-04-18)

### Bug Fixes

- **deps:** update dependency class-validator to v0.12.1 ([30da934](https://github.com/aquariuslt/blog/commit/30da934d2adc063ea64748b2d7322a8fbe09572e))

## [6.26.20](https://github.com/aquariuslt/blog/compare/v6.26.19...v6.26.20) (2020-04-18)

### Bug Fixes

- **deps:** update dependency @material-ui/core to v4.9.11 ([95b9caf](https://github.com/aquariuslt/blog/commit/95b9caf80ab6d19ae07d9c9a4ee8c6f3a085d641))

## [6.26.19](https://github.com/aquariuslt/blog/compare/v6.26.18...v6.26.19) (2020-04-18)

### Bug Fixes

- **deps:** update dependency class-validator to v0.12.0 ([3acfb9d](https://github.com/aquariuslt/blog/commit/3acfb9d22ea3bee996234754485001413582826e))

## [6.26.18](https://github.com/aquariuslt/blog/compare/v6.26.17...v6.26.18) (2020-04-18)

### Bug Fixes

- **deps:** update dependency puppeteer to v3 ([#211](https://github.com/aquariuslt/blog/issues/211)) ([18499c5](https://github.com/aquariuslt/blog/commit/18499c578bf7561206b542e08833cb4a97887cd3))

## [6.26.17](https://github.com/aquariuslt/blog/compare/v6.26.16...v6.26.17) (2020-04-18)

### Bug Fixes

- **deps:** update dependency notistack to v0.9.10 ([f988be1](https://github.com/aquariuslt/blog/commit/f988be1d38a41691da07ef74a3b755d5690e862d))

## [6.26.16](https://github.com/aquariuslt/blog/compare/v6.26.15...v6.26.16) (2020-04-16)

### Bug Fixes

- **deps:** update nest monorepo to v7.0.8 ([3313a19](https://github.com/aquariuslt/blog/commit/3313a194f76618fe1b292a1f390259f50fa606cd))

## [6.26.15](https://github.com/aquariuslt/blog/compare/v6.26.14...v6.26.15) (2020-04-16)

### Bug Fixes

- **deps:** update dependency @mdi/font to v5.1.45 ([e4ef711](https://github.com/aquariuslt/blog/commit/e4ef71189a7e8e359d104d183fde643dde25b0c4))

## [6.26.14](https://github.com/aquariuslt/blog/compare/v6.26.13...v6.26.14) (2020-04-14)

### Bug Fixes

- **deps:** update dependency log4js to v6.2.0 ([9773b18](https://github.com/aquariuslt/blog/commit/9773b1867e3b91e82dc281ebd5647d16430d8456))

## [6.26.13](https://github.com/aquariuslt/blog/compare/v6.26.12...v6.26.13) (2020-04-11)

### Bug Fixes

- **deps:** update dependency @material-ui/core to v4.9.10 ([07d8c01](https://github.com/aquariuslt/blog/commit/07d8c01ff7f6897ef1924de0589f66c6e00b7f2d))

## [6.26.12](https://github.com/aquariuslt/blog/compare/v6.26.11...v6.26.12) (2020-04-10)

### Bug Fixes

- **deps:** update dependency react-helmet to v6 ([#193](https://github.com/aquariuslt/blog/issues/193)) ([ac0b471](https://github.com/aquariuslt/blog/commit/ac0b4714d7a550b8617b7d8db37e7d413a5ff46e))

## [6.26.11](https://github.com/aquariuslt/blog/compare/v6.26.10...v6.26.11) (2020-04-09)

### Bug Fixes

- **deps:** update dependency date-fns to v2.12.0 ([ffd48ac](https://github.com/aquariuslt/blog/commit/ffd48ac6ab1f90840875d3235a9306f8ac58229d))

## [6.26.10](https://github.com/aquariuslt/blog/compare/v6.26.9...v6.26.10) (2020-04-04)

### Bug Fixes

- **deps:** update dependency @material-ui/core to v4.9.9 ([69658fb](https://github.com/aquariuslt/blog/commit/69658fb8779dacbcf4a3d3e8ababc7b980189ba7))

## [6.26.9](https://github.com/aquariuslt/blog/compare/v6.26.8...v6.26.9) (2020-04-03)

### Bug Fixes

- **deps:** update dependency patch-package to v6.2.2 ([b57a50b](https://github.com/aquariuslt/blog/commit/b57a50b7bb7a0b9a12d2eb24e3b846d5f1020d08))

## [6.26.8](https://github.com/aquariuslt/blog/compare/v6.26.7...v6.26.8) (2020-04-03)

### Bug Fixes

- **deps:** update dependency rxjs to v6.5.5 ([b98caaa](https://github.com/aquariuslt/blog/commit/b98caaaf888246d6bb7ca61ef541e8118f1d06ba))

## [6.26.7](https://github.com/aquariuslt/blog/compare/v6.26.6...v6.26.7) (2020-04-01)

### Bug Fixes

- **deps:** update dependency vanilla-lazyload to v15.1.1 ([205fbc7](https://github.com/aquariuslt/blog/commit/205fbc7854cc8fea47099ffc37e40b8e56c9b3ed))

## [6.26.6](https://github.com/aquariuslt/blog/compare/v6.26.5...v6.26.6) (2020-04-01)

### Bug Fixes

- **deps:** update dependency markdown-it-anchor to v5.2.7 ([40b3ec8](https://github.com/aquariuslt/blog/commit/40b3ec8eab5fc8488fd5eb05fc57cb502e8c0f85))

## [6.26.5](https://github.com/aquariuslt/blog/compare/v6.26.4...v6.26.5) (2020-04-01)

### Bug Fixes

- **deps:** update dependency vanilla-lazyload to v15 ([#156](https://github.com/aquariuslt/blog/issues/156)) ([803a158](https://github.com/aquariuslt/blog/commit/803a15826cbb997c58193d06f3db4a2e2176096f))

## [6.26.4](https://github.com/aquariuslt/blog/compare/v6.26.3...v6.26.4) (2020-03-29)

### Bug Fixes

- **deps:** update dependency vanilla-lazyload to v14.0.1 ([02f97da](https://github.com/aquariuslt/blog/commit/02f97daf544ec71897c0b449eb24461ca6689f00))

## [6.26.3](https://github.com/aquariuslt/blog/compare/v6.26.2...v6.26.3) (2020-03-29)

### Bug Fixes

- **deps:** update nest monorepo to v7.0.7 ([cd10c9f](https://github.com/aquariuslt/blog/commit/cd10c9f3faf0fccdf1165a75906f2d888ebb3410))

## [6.26.2](https://github.com/aquariuslt/blog/compare/v6.26.1...v6.26.2) (2020-03-29)

### Bug Fixes

- **theme-react:** do not show sw error with snackbar ([cfadc3c](https://github.com/aquariuslt/blog/commit/cfadc3cac46727716ee68f0e386767b5bff81b45))

## [6.26.1](https://github.com/aquariuslt/blog/compare/v6.26.0...v6.26.1) (2020-03-29)

### Bug Fixes

- **theme-react:** update noistack location ([c9d749a](https://github.com/aquariuslt/blog/commit/c9d749ad891fc75e70f559c1992eea8001fd15f7))

# [6.26.0](https://github.com/aquariuslt/blog/compare/v6.25.28...v6.26.0) (2020-03-29)

### Features

- **theme-react:** add service-worker notification ([ed1735a](https://github.com/aquariuslt/blog/commit/ed1735a05731494c9fc38a9a0140fa2cb27414b8))

## [6.25.28](https://github.com/aquariuslt/blog/compare/v6.25.27...v6.25.28) (2020-03-29)

### Performance Improvements

- resize gitignore cover image ([31eb9fa](https://github.com/aquariuslt/blog/commit/31eb9fa8f8b32d27a0c1133f2fb5e34f55154fa1))

## [6.25.27](https://github.com/aquariuslt/blog/compare/v6.25.26...v6.25.27) (2020-03-28)

### Bug Fixes

- **deps:** update dependency @material-ui/core to v4.9.8 ([#141](https://github.com/aquariuslt/blog/issues/141)) ([6f7ea14](https://github.com/aquariuslt/blog/commit/6f7ea14afb11bbf1c6a53db5f119b962e77e87b8))

## [6.25.26](https://github.com/aquariuslt/blog/compare/v6.25.25...v6.25.26) (2020-03-28)

### Bug Fixes

- **deps:** update dependency vanilla-lazyload to v14 ([#124](https://github.com/aquariuslt/blog/issues/124)) ([48e1ca5](https://github.com/aquariuslt/blog/commit/48e1ca52973279f59d82c34ba176dcf8b7778fdf))

## [6.25.25](https://github.com/aquariuslt/blog/compare/v6.25.24...v6.25.25) (2020-03-27)

### Bug Fixes

- **deps:** update dependency postinstall-postinstall to v2.1.0 ([c7dd680](https://github.com/aquariuslt/blog/commit/c7dd680e75c817b913dd2144a399312970ba85d4))

## [6.25.24](https://github.com/aquariuslt/blog/compare/v6.25.23...v6.25.24) (2020-03-26)

### Bug Fixes

- **deps:** update dependency date-fns to v2.11.1 ([62e6736](https://github.com/aquariuslt/blog/commit/62e67363baf301c82af5ff50f4eede8eb1aac983))

## [6.25.23](https://github.com/aquariuslt/blog/compare/v6.25.22...v6.25.23) (2020-03-26)

### Bug Fixes

- **deps:** update nest monorepo to v7.0.6 ([a85e315](https://github.com/aquariuslt/blog/commit/a85e315578354892f6a77797010905e94e3ce0bc))

## [6.25.22](https://github.com/aquariuslt/blog/compare/v6.25.21...v6.25.22) (2020-03-22)

### Bug Fixes

- **deps:** update nest monorepo to v7.0.5 ([9f3eb05](https://github.com/aquariuslt/blog/commit/9f3eb05e759cd14982ee16cdab6efee8d79f9758))

## [6.25.21](https://github.com/aquariuslt/blog/compare/v6.25.20...v6.25.21) (2020-03-21)

### Bug Fixes

- **deps:** update nest monorepo to v7.0.4 ([870ff1b](https://github.com/aquariuslt/blog/commit/870ff1b4bda0d402b047b619f2b390da08ef860e))

## [6.25.20](https://github.com/aquariuslt/blog/compare/v6.25.19...v6.25.20) (2020-03-21)

### Bug Fixes

- **deps:** update dependency sharp to v0.25.2 ([#108](https://github.com/aquariuslt/blog/issues/108)) ([3941a3d](https://github.com/aquariuslt/blog/commit/3941a3d743715f4d35b448e63619de545fa6f208))

## [6.25.19](https://github.com/aquariuslt/blog/compare/v6.25.18...v6.25.19) (2020-03-20)

### Bug Fixes

- **deps:** update dependency fs-extra to v9 ([#102](https://github.com/aquariuslt/blog/issues/102)) ([5d5c0c3](https://github.com/aquariuslt/blog/commit/5d5c0c3566d0d8d97eec8e611962db23654cb58b))

## [6.25.18](https://github.com/aquariuslt/blog/compare/v6.25.17...v6.25.18) (2020-03-19)

### Bug Fixes

- **deps:** update react monorepo to v16.13.1 ([6f92ab1](https://github.com/aquariuslt/blog/commit/6f92ab1be34c73b9b0a00f63db692ed07963b345))

## [6.25.17](https://github.com/aquariuslt/blog/compare/v6.25.16...v6.25.17) (2020-03-18)

### Performance Improvements

- **theme-react:** lazy load image in effects ([8148128](https://github.com/aquariuslt/blog/commit/8148128dbed73e18aa5e7d6cd49c626bee1eedac))

## [6.25.16](https://github.com/aquariuslt/blog/compare/v6.25.15...v6.25.16) (2020-03-18)

### Bug Fixes

- **deps:** update dependency @material-ui/core to v4.9.7 ([a4ae240](https://github.com/aquariuslt/blog/commit/a4ae240ca9f3922523990de6b478bf4ec3aa1e91))

## [6.25.15](https://github.com/aquariuslt/blog/compare/v6.25.14...v6.25.15) (2020-03-18)

### Bug Fixes

- **deps:** update dependency @material-ui/core to v4.9.6 ([ee23d7c](https://github.com/aquariuslt/blog/commit/ee23d7ce13276462b82445ed8eed3d7377bd5c09))

## [6.25.14](https://github.com/aquariuslt/blog/compare/v6.25.13...v6.25.14) (2020-03-18)

### Bug Fixes

- **deps:** update dependency class-validator to v0.11.1 ([4b81b69](https://github.com/aquariuslt/blog/commit/4b81b691db7354c441bce26fbe52204743a85744))

## [6.25.13](https://github.com/aquariuslt/blog/compare/v6.25.12...v6.25.13) (2020-03-17)

### Bug Fixes

- **deps:** update dependency schema-dts to v0.5.2 ([#94](https://github.com/aquariuslt/blog/issues/94)) ([4aac8a7](https://github.com/aquariuslt/blog/commit/4aac8a762a1894524d8b292cd2c142e7ad4e9b3a))

## [6.25.12](https://github.com/aquariuslt/blog/compare/v6.25.11...v6.25.12) (2020-03-17)

### Bug Fixes

- **deps:** update dependency vue-property-decorator to v8.4.1 ([#89](https://github.com/aquariuslt/blog/issues/89)) ([ab46212](https://github.com/aquariuslt/blog/commit/ab4621273e0e74f2739660aaa81b8ddbb8a6bba3))

## [6.25.11](https://github.com/aquariuslt/blog/compare/v6.25.10...v6.25.11) (2020-03-17)

### Bug Fixes

- **deps:** update nest monorepo to v7.0.3 ([#90](https://github.com/aquariuslt/blog/issues/90)) ([809c3d8](https://github.com/aquariuslt/blog/commit/809c3d823d13fbe5b832ce222f6fa89315b25308))

## [6.25.10](https://github.com/aquariuslt/blog/compare/v6.25.9...v6.25.10) (2020-03-16)

### Bug Fixes

- **deps:** update dependency react-disqus-components to v1.2.3 ([#88](https://github.com/aquariuslt/blog/issues/88)) ([02c0251](https://github.com/aquariuslt/blog/commit/02c02513c6589d0bb46ae90aa374e9aecbae6541))

## [6.25.9](https://github.com/aquariuslt/blog/compare/v6.25.8...v6.25.9) (2020-03-15)

### Bug Fixes

- **deps:** update nest monorepo to v7.0.2 ([#85](https://github.com/aquariuslt/blog/issues/85)) ([3ffe665](https://github.com/aquariuslt/blog/commit/3ffe66591a829753d9993505e35d96d471c97b34))

## [6.25.8](https://github.com/aquariuslt/blog/compare/v6.25.7...v6.25.8) (2020-03-15)

### Bug Fixes

- **theme-react:** avoid empty string for views.show key ([5895de1](https://github.com/aquariuslt/blog/commit/5895de1589b5a78738e1f27449b26e7533b16596))

## [6.25.7](https://github.com/aquariuslt/blog/compare/v6.25.6...v6.25.7) (2020-03-14)

### Bug Fixes

- **deps:** update dependency @nestjs/serve-static to v2.1.0 ([#84](https://github.com/aquariuslt/blog/issues/84)) ([f67708f](https://github.com/aquariuslt/blog/commit/f67708f5586a1c73a6436990724525f0084b7314))

## [6.25.6](https://github.com/aquariuslt/blog/compare/v6.25.5...v6.25.6) (2020-03-14)

### Bug Fixes

- **theme-react:** force lazy condition fixing ([1b4b713](https://github.com/aquariuslt/blog/commit/1b4b71360ba6b30a72ad9a2848167ddeb987512c))

## [6.25.5](https://github.com/aquariuslt/blog/compare/v6.25.4...v6.25.5) (2020-03-14)

### Bug Fixes

- **pwa:** resolve globPattern issue ([324032f](https://github.com/aquariuslt/blog/commit/324032f5b903855f96fbd150b771871ad398cbf6))

## [6.25.4](https://github.com/aquariuslt/blog/compare/v6.25.3...v6.25.4) (2020-03-14)

### Performance Improvements

- disable article detail cover lazyload ([d5bbb04](https://github.com/aquariuslt/blog/commit/d5bbb044a9b334ba769410b9946d65b42f6db206))

## [6.25.3](https://github.com/aquariuslt/blog/compare/v6.25.2...v6.25.3) (2020-03-14)

### Performance Improvements

- add image lazyload on all images ([8f4aac1](https://github.com/aquariuslt/blog/commit/8f4aac13867f7ee0271742798330efe3578fbd54))

## [6.25.2](https://github.com/aquariuslt/blog/compare/v6.25.1...v6.25.2) (2020-03-14)

### Performance Improvements

- use picture tag for webp optimize ([c26d1da](https://github.com/aquariuslt/blog/commit/c26d1dab911b629d7c101a5fa6980f668e312990))

## [6.25.1](https://github.com/aquariuslt/blog/compare/v6.25.0...v6.25.1) (2020-03-14)

### Bug Fixes

- **theme-react:** resolve wrong usage with views.show key ([de803ce](https://github.com/aquariuslt/blog/commit/de803ce8e8f81ad98101175fb34304d1e3deecc3))

# [6.25.0](https://github.com/aquariuslt/blog/compare/v6.24.10...v6.25.0) (2020-03-14)

### Features

- **theme-react:** integrate ([0dcb175](https://github.com/aquariuslt/blog/commit/0dcb1751c70ff0357d96edcf719e94e0dff2a36c))

## [6.24.10](https://github.com/aquariuslt/blog/compare/v6.24.9...v6.24.10) (2020-03-14)

### Bug Fixes

- **deps:** update dependency date-fns to v2.11.0 ([#83](https://github.com/aquariuslt/blog/issues/83)) ([f5a6f62](https://github.com/aquariuslt/blog/commit/f5a6f6259d517368b05af980eaf1b81fac8d376b))

## [6.24.9](https://github.com/aquariuslt/blog/compare/v6.24.8...v6.24.9) (2020-03-13)

### Performance Improvements

- **markdown:** add native lazy image loading support ([55b20cf](https://github.com/aquariuslt/blog/commit/55b20cf71c03fc8fd25ad3a200928247e41c25cb))

## [6.24.8](https://github.com/aquariuslt/blog/compare/v6.24.7...v6.24.8) (2020-03-12)

### Bug Fixes

- **deps:** pin dependencies ([#75](https://github.com/aquariuslt/blog/issues/75)) ([4c78ec5](https://github.com/aquariuslt/blog/commit/4c78ec55677823d26132832bfb2b128442f22e1c))

## [6.24.7](https://github.com/aquariuslt/blog/compare/v6.24.6...v6.24.7) (2020-03-12)

### Bug Fixes

- **pwa:** patch with correct syntax ([e000f31](https://github.com/aquariuslt/blog/commit/e000f31225dc2becb1bf02f74a9b0f5b1c5eecc6))

## [6.24.6](https://github.com/aquariuslt/blog/compare/v6.24.5...v6.24.6) (2020-03-12)

### Bug Fixes

- **pwa:** patch with correct syntax ([70a8a9c](https://github.com/aquariuslt/blog/commit/70a8a9c1c582a2b7e9134ba45d51b28ba43e2bdb))

## [6.24.5](https://github.com/aquariuslt/blog/compare/v6.24.4...v6.24.5) (2020-03-12)

### Performance Improvements

- **pwa:** use `priority-hints` low for precaching ([be94136](https://github.com/aquariuslt/blog/commit/be94136ed853ff5f190163d5579366ceb2209122))

## [6.24.4](https://github.com/aquariuslt/blog/compare/v6.24.3...v6.24.4) (2020-03-09)

### Bug Fixes

- **deps:** update dependency @mdi/font to v5 ([#70](https://github.com/aquariuslt/blog/issues/70)) ([247beb1](https://github.com/aquariuslt/blog/commit/247beb151d32abd1d886cd2f39352db7fdce70cc))

## [6.24.3](https://github.com/aquariuslt/blog/compare/v6.24.2...v6.24.3) (2020-03-07)

### Bug Fixes

- **deps:** update dependency sharp to v0.25.1 ([#69](https://github.com/aquariuslt/blog/issues/69)) ([e3109c3](https://github.com/aquariuslt/blog/commit/e3109c390b296007297b558d572f121e9b4c468b))

## [6.24.2](https://github.com/aquariuslt/blog/compare/v6.24.1...v6.24.2) (2020-03-07)

### Bug Fixes

- **deps:** update dependency sharp to v0.25.0 ([#68](https://github.com/aquariuslt/blog/issues/68)) ([c9de3c8](https://github.com/aquariuslt/blog/commit/c9de3c8e9c5d5bb274f999b4311e97c81bdfd0f1))

## [6.24.1](https://github.com/aquariuslt/blog/compare/v6.24.0...v6.24.1) (2020-03-07)

### Performance Improvements

- **api:** reduce home api response size by 10 ([b40bdc9](https://github.com/aquariuslt/blog/commit/b40bdc9ccb61f449e4b3fac671ab360f8fbf85e2))

# [6.24.0](https://github.com/aquariuslt/blog/compare/v6.23.0...v6.24.0) (2020-03-05)

### Features

- **now:** update now.json generation ([9c4814b](https://github.com/aquariuslt/blog/commit/9c4814b25aaf6ac4f5ee9054dcfad3159cb7c1aa))

# [6.23.0](https://github.com/aquariuslt/blog/compare/v6.22.1...v6.23.0) (2020-03-05)

### Features

- **now:** add `now.json` generation ([71ac079](https://github.com/aquariuslt/blog/commit/71ac079a5cbd5ee2c3f4c1d7cc94a0dc91c877b0))

## [6.22.1](https://github.com/aquariuslt/blog/compare/v6.22.0...v6.22.1) (2020-03-04)

### Bug Fixes

- **pwa:** revert workbox to v4.3.1 due to unclear document ([38a4e14](https://github.com/aquariuslt/blog/commit/38a4e14d56853ab1a127d82c0bd35714e52777dd))

# [6.22.0](https://github.com/aquariuslt/blog/compare/v6.21.9...v6.22.0) (2020-03-04)

### Features

- **og:** build full url for og:image meta ([4ac06ad](https://github.com/aquariuslt/blog/commit/4ac06ad79b0981aa132304d8ae9728a8a2f9fc1c))

## [6.21.9](https://github.com/aquariuslt/blog/compare/v6.21.8...v6.21.9) (2020-03-03)

### Bug Fixes

- **deps:** update nest monorepo to v6.11.11 ([#54](https://github.com/aquariuslt/blog/issues/54)) ([d915a14](https://github.com/aquariuslt/blog/commit/d915a1421db4111aa99353a845284e9700ab91f0))

## [6.21.8](https://github.com/aquariuslt/blog/compare/v6.21.7...v6.21.8) (2020-03-03)

### Bug Fixes

- **deps:** update dependency vanilla-lazyload to v13.0.1 ([#53](https://github.com/aquariuslt/blog/issues/53)) ([289142a](https://github.com/aquariuslt/blog/commit/289142a14186b6fb61c9800419c47682787b50d8))

## [6.21.7](https://github.com/aquariuslt/blog/compare/v6.21.6...v6.21.7) (2020-03-02)

### Bug Fixes

- **deps:** update nest monorepo to v6.11.9 ([#51](https://github.com/aquariuslt/blog/issues/51)) ([b355915](https://github.com/aquariuslt/blog/commit/b35591540af52e352c29514ffb12408406001db7))

## [6.21.6](https://github.com/aquariuslt/blog/compare/v6.21.5...v6.21.6) (2020-03-01)

### Bug Fixes

- **deps:** update dependency vanilla-lazyload to v13 ([#46](https://github.com/aquariuslt/blog/issues/46)) ([e62a722](https://github.com/aquariuslt/blog/commit/e62a722adde4e6d3c2796185d21ec08ad1ce0403))

## [6.21.5](https://github.com/aquariuslt/blog/compare/v6.21.4...v6.21.5) (2020-02-29)

### Bug Fixes

- **deps:** update dependency @material-ui/core to v4.9.5 ([#40](https://github.com/aquariuslt/blog/issues/40)) ([aac40b3](https://github.com/aquariuslt/blog/commit/aac40b36114a2018922a2ab219eba6d408d7b816))
- **posts:** update cover image links ([8c0b4b6](https://github.com/aquariuslt/blog/commit/8c0b4b68e55400eeac8ce8d1479a1ad513d15a55))

## [6.21.4](https://github.com/aquariuslt/blog/compare/v6.21.3...v6.21.4) (2020-02-28)

### Bug Fixes

- **deps:** update dependency vanilla-lazyload to v12.5.1 ([d331038](https://github.com/aquariuslt/blog/commit/d3310380bd4d9bfdcc0a40f2295574fefc6e29b7))

## [6.21.3](https://github.com/aquariuslt/blog/compare/v6.21.2...v6.21.3) (2020-02-27)

### Bug Fixes

- **deps:** update react monorepo to v16.13.0 ([#33](https://github.com/aquariuslt/blog/issues/33)) ([503db8f](https://github.com/aquariuslt/blog/commit/503db8fb745f959a77e2606dae9bcf1e24a891d6))

## [6.21.2](https://github.com/aquariuslt/blog/compare/v6.21.1...v6.21.2) (2020-02-26)

### Bug Fixes

- **deps:** update dependency vue-meta to v2.3.3 ([#32](https://github.com/aquariuslt/blog/issues/32)) ([cbd6c19](https://github.com/aquariuslt/blog/commit/cbd6c19ec300b61dbc8518e07ee6c79a078929b8))

## [6.21.1](https://github.com/aquariuslt/blog/compare/v6.21.0...v6.21.1) (2020-02-26)

### Bug Fixes

- **deps:** update dependency vue-router to v3.1.6 ([#31](https://github.com/aquariuslt/blog/issues/31)) ([7c3a5b4](https://github.com/aquariuslt/blog/commit/7c3a5b4bebee39a2c9a4203f0f41367844c7b026))

# [6.21.0](https://github.com/aquariuslt/blog/compare/v6.20.12...v6.21.0) (2020-02-25)

### Features

- **theme-react:** add pv event after url location changed ([4407ba2](https://github.com/aquariuslt/blog/commit/4407ba24cf0f8f393f82b97efbf33859591176bf))

## [6.20.12](https://github.com/aquariuslt/blog/compare/v6.20.11...v6.20.12) (2020-02-25)

### Bug Fixes

- **deps:** update dependency date-fns to v2.10.0 ([59de3bc](https://github.com/aquariuslt/blog/commit/59de3bc92566bd3a8a721aa29861a44cf2932938))

## [6.20.11](https://github.com/aquariuslt/blog/compare/v6.20.10...v6.20.11) (2020-02-24)

### Bug Fixes

- **deps:** update dependency vanilla-lazyload to v12.5.0 ([0614850](https://github.com/aquariuslt/blog/commit/061485021b673ca7f3b1e3978b115e3e1317b2f7))

## [6.20.10](https://github.com/aquariuslt/blog/compare/v6.20.9...v6.20.10) (2020-02-23)

### Bug Fixes

- **deps:** update dependency @nestjs/serve-static to v2 ([d683a12](https://github.com/aquariuslt/blog/commit/d683a12e8b99af5e5d4b3a81f2098e9116de170f))

## [6.20.9](https://github.com/aquariuslt/blog/compare/v6.20.8...v6.20.9) (2020-02-23)

### Bug Fixes

- **deps:** update dependency @material-ui/core to v4.9.4 ([a429783](https://github.com/aquariuslt/blog/commit/a4297839d07680a63a997c8a274f8f97af4a33ca))

## [6.20.8](https://github.com/aquariuslt/blog/compare/v6.20.7...v6.20.8) (2020-02-22)

### Bug Fixes

- **deps:** update dependency github-markdown-css to v4 ([395e081](https://github.com/aquariuslt/blog/commit/395e081a7a1ac32dfbabe1aef673c9e9fc03be2d))

## [6.20.7](https://github.com/aquariuslt/blog/compare/v6.20.6...v6.20.7) (2020-02-16)

### Performance Improvements

- optimize png in posts ([e52fff8](https://github.com/aquariuslt/blog/commit/e52fff8ca598cbbbccdb7fd27767d60754f7adab))

## [6.20.6](https://github.com/aquariuslt/blog/compare/v6.20.5...v6.20.6) (2020-02-15)

### Bug Fixes

- **pwa:** upgrade workbox-build to v5.0.0 ([acdde98](https://github.com/aquariuslt/blog/commit/acdde9828e15816d62a542f2ef1a17e4b0ea7958))
- webpack-favicons plugin version update issue ([d48fcbc](https://github.com/aquariuslt/blog/commit/d48fcbce77c35d474fb94d6d9b4db0389b481774))
- webpack-favicons plugin version update issue ([a1a6690](https://github.com/aquariuslt/blog/commit/a1a66903b9c14d6e806131f754a9257137b2d73e))

### Performance Improvements

- **post:** optimize image size ([da1e115](https://github.com/aquariuslt/blog/commit/da1e115ac87bbc360b0b59649fe954c21181a1af))

## [6.20.5](https://github.com/aquariuslt/blog/compare/v6.20.4...v6.20.5) (2020-02-15)

### Bug Fixes

- **theme-react:** use raw img tag instead of lazy load image ([ba89629](https://github.com/aquariuslt/blog/commit/ba8962987bb1ffb75a3af5af86e437a971526b82))

## [6.20.4](https://github.com/aquariuslt/blog/compare/v6.20.3...v6.20.4) (2020-02-13)

### Bug Fixes

- lazyload image component issue under pre-render ([5e9dc38](https://github.com/aquariuslt/blog/commit/5e9dc38f1d392b15b4b8e75e5e0e3ff6c5e78db6))

## [6.20.3](https://github.com/aquariuslt/blog/compare/v6.20.2...v6.20.3) (2019-12-08)

### Bug Fixes

- **theme-react:** update scroll callback trigger deps ([9a2679a](https://github.com/aquariuslt/blog/commit/9a2679acc26a5d2027305e2eab43b9144c10deee))

## [6.20.2](https://github.com/aquariuslt/blog/compare/v6.20.1...v6.20.2) (2019-12-08)

### Bug Fixes

- **theme-react:** clear `afterClick` timeout function first ([16f5c9a](https://github.com/aquariuslt/blog/commit/16f5c9a0634b4827ea399b08119fdd0236cef431))

## [6.20.1](https://github.com/aquariuslt/blog/compare/v6.20.0...v6.20.1) (2019-12-07)

### Bug Fixes

- resolve test case declaration issue ([7d94ce1](https://github.com/aquariuslt/blog/commit/7d94ce19e222063167e88c0d0936f1b167ac6f07))

# [6.20.0](https://github.com/aquariuslt/blog/compare/v6.19.0...v6.20.0) (2019-12-07)

### Features

- **theme-react:** set hash after click content-item ([be3fb3b](https://github.com/aquariuslt/blog/commit/be3fb3b1d491bc9a2a62e1f3f746fc2ec2dc1837))

# [6.19.0](https://github.com/aquariuslt/blog/compare/v6.18.0...v6.19.0) (2019-12-07)

### Features

- **migration:** remove migration package ([351c13e](https://github.com/aquariuslt/blog/commit/351c13eb6a22f682197b0e9ab0c7b931b413ba33))

# [6.18.0](https://github.com/aquariuslt/blog/compare/v6.17.10...v6.18.0) (2019-12-06)

### Features

- **router:** create sitemap item for pages ([88cbe8a](https://github.com/aquariuslt/blog/commit/88cbe8a5059bfdeafdb5ff5b169b0ecb5a83cbff))

## [6.17.10](https://github.com/aquariuslt/blog/compare/v6.17.9...v6.17.10) (2019-12-01)

### Performance Improvements

- **pwa:** precache manifest including webp ([6f849b8](https://github.com/aquariuslt/blog/commit/6f849b8a0143812dbab963549fe6726bfdcb266b))

## [6.17.9](https://github.com/aquariuslt/blog/compare/v6.17.8...v6.17.9) (2019-11-30)

### Bug Fixes

- **theme-react:** fix url-loader upgrade to v3 usage ([8e0e983](https://github.com/aquariuslt/blog/commit/8e0e9831204920b298caa357eb776e4c515f5311))

## [6.17.8](https://github.com/aquariuslt/blog/compare/v6.17.7...v6.17.8) (2019-11-30)

### Performance Improvements

- disable offline google-analytics ([42815cc](https://github.com/aquariuslt/blog/commit/42815ccedd0022477ad62b61702e69dae371e7f3))

## [6.17.7](https://github.com/aquariuslt/blog/compare/v6.17.6...v6.17.7) (2019-11-29)

### Performance Improvements

- **theme-react:** use scroll-into-view-if-needed ([5084e36](https://github.com/aquariuslt/blog/commit/5084e36fc063c75067b8764abba38a2df517d218))

## [6.17.6](https://github.com/aquariuslt/blog/compare/v6.17.5...v6.17.6) (2019-11-28)

### Performance Improvements

- **theme-react:** toggle scroll callback after click ([4bff76f](https://github.com/aquariuslt/blog/commit/4bff76f724ec51dc8e8e17687451e3d24829cf90))

## [6.17.5](https://github.com/aquariuslt/blog/compare/v6.17.4...v6.17.5) (2019-11-28)

### Performance Improvements

- **theme-react:** toggle scroll callback after click ([09fd803](https://github.com/aquariuslt/blog/commit/09fd80318d48c2bc6c6fb199a6dda59753854d35))

## [6.17.4](https://github.com/aquariuslt/blog/compare/v6.17.3...v6.17.4) (2019-11-26)

### Performance Improvements

- **theme-react:** enable React.hydrate() ([8200f3a](https://github.com/aquariuslt/blog/commit/8200f3a41184295351ca6fb7d1e8a98342b6865d))

## [6.17.3](https://github.com/aquariuslt/blog/compare/v6.17.2...v6.17.3) (2019-11-26)

### Performance Improvements

- **theme-react:** set active state for TOC after perform scroll animate ([ed36723](https://github.com/aquariuslt/blog/commit/ed36723b5f1db38708cc6c22dd6b26765e6b0e1c))

## [6.17.2](https://github.com/aquariuslt/blog/compare/v6.17.1...v6.17.2) (2019-11-26)

### Performance Improvements

- **theme-react:** using vanilla-lazyload instead lozad ([d88019f](https://github.com/aquariuslt/blog/commit/d88019f7be6e0ba58e43504fc894b5ac621b3d63))

### Reverts

- **theme-react:** revert lazy image picture tag perf ([396d6d6](https://github.com/aquariuslt/blog/commit/396d6d637b2d37af546d41bb2795fbaa8c5be778))

## [6.17.1](https://github.com/aquariuslt/blog/compare/v6.17.0...v6.17.1) (2019-11-26)

### Bug Fixes

- **theme-react:** add `alt` attribute at lazy image ([74eba53](https://github.com/aquariuslt/blog/commit/74eba5361f440379f8fcc94bfcccfbeab470ae9f))

# [6.17.0](https://github.com/aquariuslt/blog/compare/v6.16.0...v6.17.0) (2019-11-26)

### Features

- enable webp x <picture> for better performance ([a657c27](https://github.com/aquariuslt/blog/commit/a657c272764a3cb2c1bfdafc6e6c12bae5034754))

# [6.16.0](https://github.com/aquariuslt/blog/compare/v6.15.2...v6.16.0) (2019-11-26)

### Features

- enable pages ([5a047b6](https://github.com/aquariuslt/blog/commit/5a047b64ce811fa77aed10af8b96c2d68876d8b6))

## [6.15.2](https://github.com/aquariuslt/blog/compare/v6.15.1...v6.15.2) (2019-11-24)

### Performance Improvements

- **theme-react:** update active content-item scroll listener ([cfbd23f](https://github.com/aquariuslt/blog/commit/cfbd23f783730d160f0e240f605b09d713859fe6))

## [6.15.1](https://github.com/aquariuslt/blog/compare/v6.15.0...v6.15.1) (2019-11-24)

### Performance Improvements

- **theme-react:** update active content-item scroll listener ([bb1e3df](https://github.com/aquariuslt/blog/commit/bb1e3df923ac8141d4328b3d8898c66f5e59517f))

# [6.15.0](https://github.com/aquariuslt/blog/compare/v6.14.13...v6.15.0) (2019-11-24)

### Features

- **theme-react:** add active content-item scroll listener ([c6c70b4](https://github.com/aquariuslt/blog/commit/c6c70b471111a248a60b7f00cf534feb99b38e7b))

## [6.14.13](https://github.com/aquariuslt/blog/compare/v6.14.12...v6.14.13) (2019-11-17)

### Performance Improvements

- add `--add` at `gh-pages` deploy args ([53e9305](https://github.com/aquariuslt/blog/commit/53e93051a04ef288716fa517ca2f2eeeb3ade749))

## [6.14.12](https://github.com/aquariuslt/blog/compare/v6.14.11...v6.14.12) (2019-11-17)

### Bug Fixes

- downgrade and lock lerna version for workaround ([af148f6](https://github.com/aquariuslt/blog/commit/af148f6198433681f502ea49312d7062178c9bea))
- fix posts toc issue ([65f6a6d](https://github.com/aquariuslt/blog/commit/65f6a6d688a53704a182139ae06a21c5fbaf048a))

## [6.14.11](https://github.com/aquariuslt/blog/compare/v6.14.10...v6.14.11) (2019-11-12)

### Bug Fixes

- **route-tools:** add `id` as google-analytics tag ([f6dc172](https://github.com/aquariuslt/blog/commit/f6dc172b4bbe465978ae7e4301d63096550f393f))

## [6.14.10](https://github.com/aquariuslt/blog/compare/v6.14.9...v6.14.10) (2019-11-11)

### Performance Improvements

- **theme-react:** remove empty `ul` element in `ContentItems` ([8c548f6](https://github.com/aquariuslt/blog/commit/8c548f62ffcd6b3b22db5b45cb5010a277063533))

## [6.14.9](https://github.com/aquariuslt/blog/compare/v6.14.8...v6.14.9) (2019-11-11)

### Performance Improvements

- **theme-react:** bump `react-disqus-components` version ([13cbe18](https://github.com/aquariuslt/blog/commit/13cbe18f68dc194d9754fa66b8ff79fe0f885375))

## [6.14.8](https://github.com/aquariuslt/blog/compare/v6.14.7...v6.14.8) (2019-11-10)

### Performance Improvements

- **theme-react:** enable dynamic import and auto chunk spliting ([095e4d5](https://github.com/aquariuslt/blog/commit/095e4d5f2c320227cc37b64e63ec1c1ef8fa0097))

## [6.14.7](https://github.com/aquariuslt/blog/compare/v6.14.6...v6.14.7) (2019-11-10)

### Bug Fixes

- **theme-react:** bump `react-disqus-comments` version ([7534dfb](https://github.com/aquariuslt/blog/commit/7534dfb088948d07f30d62ebd705de4a73dcc3ba))

## [6.14.6](https://github.com/aquariuslt/blog/compare/v6.14.5...v6.14.6) (2019-11-10)

### Bug Fixes

- **theme-react:** bump `react-disqus-comments` version ([02efabb](https://github.com/aquariuslt/blog/commit/02efabb62bf5a461c110c0324d3bc0a287710bd4))

## [6.14.5](https://github.com/aquariuslt/blog/compare/v6.14.4...v6.14.5) (2019-11-10)

### Bug Fixes

- **theme-react:** bump `react-disqus-comments` version ([9cfaed9](https://github.com/aquariuslt/blog/commit/9cfaed9a897992bb0904c2eb1cd5712c88b3ce9d))

## [6.14.4](https://github.com/aquariuslt/blog/compare/v6.14.3...v6.14.4) (2019-11-10)

### Bug Fixes

- **theme-react:** bump `react-disqus-comments` version ([a3253f1](https://github.com/aquariuslt/blog/commit/a3253f155800c15fcbf3bb181381f3996cbf7756))

## [6.14.3](https://github.com/aquariuslt/blog/compare/v6.14.2...v6.14.3) (2019-11-10)

### Bug Fixes

- **theme-react:** remove basePath seetings ([59241d6](https://github.com/aquariuslt/blog/commit/59241d6eeeab2d0df6c5f73741d3cd5472030efe))

## [6.14.2](https://github.com/aquariuslt/blog/compare/v6.14.1...v6.14.2) (2019-11-09)

### Performance Improvements

- **theme-react:** bump react-disqus-components version ([c08676c](https://github.com/aquariuslt/blog/commit/c08676c689570ca1988e11aba15c951b122d8b8c))

## [6.14.1](https://github.com/aquariuslt/blog/compare/v6.14.0...v6.14.1) (2019-11-09)

### Bug Fixes

- **theme-react:** update Fab import from ([456d081](https://github.com/aquariuslt/blog/commit/456d0813ba47d6f9468d4403678376848637b649))

# [6.14.0](https://github.com/aquariuslt/blog/compare/v6.13.0...v6.14.0) (2019-11-09)

### Features

- **theme-react:** add back-to-top FAB button ([2945831](https://github.com/aquariuslt/blog/commit/294583108aa6d32a7fe75238406fe792d1a41630))

# [6.13.0](https://github.com/aquariuslt/blog/compare/v6.12.6...v6.13.0) (2019-11-09)

### Features

- **theme-react:** add robots.txt generation ([8fa8490](https://github.com/aquariuslt/blog/commit/8fa84909834591d97a58ca7ba4ca29d6794d9503))

## [6.12.6](https://github.com/aquariuslt/blog/compare/v6.12.5...v6.12.6) (2019-11-09)

### Performance Improvements

- reduce cover images size ([ba16df8](https://github.com/aquariuslt/blog/commit/ba16df839ec1723fea4722e3eabb1258acdfd1fb))

## [6.12.5](https://github.com/aquariuslt/blog/compare/v6.12.4...v6.12.5) (2019-11-09)

### Bug Fixes

- **theme-react:** fix invalid ref in useEffect() in ArticleDetail ([32140cc](https://github.com/aquariuslt/blog/commit/32140cc59522a5303c5b019bec5ce84485a58fa3))

## [6.12.4](https://github.com/aquariuslt/blog/compare/v6.12.3...v6.12.4) (2019-11-09)

### Performance Improvements

- **theme-react:** mark all chunks as preload ([c26889f](https://github.com/aquariuslt/blog/commit/c26889f1f605a3aaaeece920ad55917dd0338e45))

## [6.12.3](https://github.com/aquariuslt/blog/compare/v6.12.2...v6.12.3) (2019-11-08)

### Bug Fixes

- **theme-react:** add missing dependencies ([ae6d2cc](https://github.com/aquariuslt/blog/commit/ae6d2ccbf850c9bfdac75e3407ac85dc2223cfb0))

### Performance Improvements

- **theme-react:** add lozad for lazy load image ([501d034](https://github.com/aquariuslt/blog/commit/501d034cb69074bc3a2d19c705bf27403f86086d))

## [6.12.2](https://github.com/aquariuslt/blog/compare/v6.12.1...v6.12.2) (2019-11-07)

### Bug Fixes

- **theme-react:** add base href meta ([ee92718](https://github.com/aquariuslt/blog/commit/ee9271857ae8d0e8ee82111d2bce8e101d7c5a11))

## [6.12.1](https://github.com/aquariuslt/blog/compare/v6.12.0...v6.12.1) (2019-11-04)

### Bug Fixes

- **theme-react:** fix article-detail.tsx ([68bad92](https://github.com/aquariuslt/blog/commit/68bad92fc7529836759e3655e7646ec0f8b2678c))

# [6.12.0](https://github.com/aquariuslt/blog/compare/v6.11.0...v6.12.0) (2019-11-03)

### Bug Fixes

- **theme-react:** fix type conversion for keyword ([ee93ba9](https://github.com/aquariuslt/blog/commit/ee93ba9b894c859941fda3b31ee436de1605efa2))

### Features

- **theme-react:** add keyword in article detail ([27ba180](https://github.com/aquariuslt/blog/commit/27ba180f74e0ec77b16514c2a4ac47e9b57baec9))

# [6.11.0](https://github.com/aquariuslt/blog/compare/v6.10.1...v6.11.0) (2019-11-03)

### Features

- **theme-react:** add functional component with disqus api ([14b1c21](https://github.com/aquariuslt/blog/commit/14b1c21b71628f153b770b764785da9f9b79c839))

## [6.10.1](https://github.com/aquariuslt/blog/compare/v6.10.0...v6.10.1) (2019-11-03)

### Performance Improvements

- **theme-react:** update service-worker config ([be2d9ef](https://github.com/aquariuslt/blog/commit/be2d9ef7c002a132778edf4c873100c73990e6c0))

# [6.10.0](https://github.com/aquariuslt/blog/compare/v6.9.0...v6.10.0) (2019-11-03)

### Features

- **theme-react:** enable pwa manifest json injection ([4705060](https://github.com/aquariuslt/blog/commit/47050608eec1445c65d295567e20233bc0891491))

# [6.9.0](https://github.com/aquariuslt/blog/compare/v6.8.1...v6.9.0) (2019-11-03)

### Features

- **theme-react:** re-enable service-worker ([86a5fcd](https://github.com/aquariuslt/blog/commit/86a5fcd9e7ff1fa0dc33531a696f03646398ccec))

## [6.8.1](https://github.com/aquariuslt/blog/compare/v6.8.0...v6.8.1) (2019-11-03)

### Bug Fixes

- **theme-react:** remove react-disqus ([09f416c](https://github.com/aquariuslt/blog/commit/09f416cd61d64f507a4c346c1a1f7827f685b203))

# [6.8.0](https://github.com/aquariuslt/blog/compare/v6.7.0...v6.8.0) (2019-11-03)

### Bug Fixes

- **markdown:** add anchor plugin to generate heading ids ([5871078](https://github.com/aquariuslt/blog/commit/5871078c66143f99eb1bd2e5fc1484eef7ff2ced))

### Features

- **theme-react:** add component: navigation ([9648750](https://github.com/aquariuslt/blog/commit/9648750466f711f660180323c32b61f5ee61573c))
- **theme-react:** add components: ContentItems ([7882342](https://github.com/aquariuslt/blog/commit/7882342e77d76eef53224ff9a3283372742e2b73))
- **theme-react:** enable theme-react ([cd2a588](https://github.com/aquariuslt/blog/commit/cd2a588e5499f19643876a11cd2bf4c51bb590fa))

# [6.7.0](https://github.com/aquariuslt/blog/compare/v6.6.3...v6.7.0) (2019-11-02)

### Features

- **theme-react:** add route with apiPath as props ([d5f406f](https://github.com/aquariuslt/blog/commit/d5f406f9a86dee28454ebdcb6a3fb82a17b1fd59))

## [6.6.3](https://github.com/aquariuslt/blog/compare/v6.6.2...v6.6.3) (2019-10-30)

### Bug Fixes

- **theme-react:** fix webpack-dev-server hmr issue ([4d15a4c](https://github.com/aquariuslt/blog/commit/4d15a4cb23112300480d19729260ad771316dc58))

## [6.6.2](https://github.com/aquariuslt/blog/compare/v6.6.1...v6.6.2) (2019-10-30)

### Bug Fixes

- **sitemap:** fix sitemap generation issue ([3e61011](https://github.com/aquariuslt/blog/commit/3e610112d56a57a32134d3c1187d356aa2d883d6))
- **theme-react:** fix webpack configurations ([58afb8a](https://github.com/aquariuslt/blog/commit/58afb8af5c9b83f9dd623c49815580827d0fbe64))
- correct test issue ([d491722](https://github.com/aquariuslt/blog/commit/d491722882f84980b997e2f951dac902d352f18c))

## [6.6.1](https://github.com/aquariuslt/blog/compare/v6.6.0...v6.6.1) (2019-10-27)

### Bug Fixes

- **theme-react:** update jest config with `testMatch` ([8f782a2](https://github.com/aquariuslt/blog/commit/8f782a206b9db63f19b7a27c709687a1ea29f80d))

# [6.6.0](https://github.com/aquariuslt/blog/compare/v6.5.0...v6.6.0) (2019-10-27)

### Features

- **theme-react:** add package `@blog/theme-react` ([8e2082e](https://github.com/aquariuslt/blog/commit/8e2082e3e3a4e7a0b39071adda4b4380a94a1f11))

# [6.5.0](https://github.com/aquariuslt/blog/compare/v6.4.0...v6.5.0) (2019-10-26)

### Features

- **analytics:** inject google-analytics + workbox offline analytics ([523c6ad](https://github.com/aquariuslt/blog/commit/523c6adb34ccdf5ec6402c00a0d4eb44d797aba6))

# [6.4.0](https://github.com/aquariuslt/blog/compare/v6.3.2...v6.4.0) (2019-10-24)

### Bug Fixes

- **theme-vue:** add fallback route handling in router definition ([a7900f5](https://github.com/aquariuslt/blog/commit/a7900f58fe42b5a219444197d26d4a3bd43daefa))

### Features

- **theme-react:** create package `@blog/theme-react` ([7f69529](https://github.com/aquariuslt/blog/commit/7f69529502ae291de7db6b48062f3578cbb6ff78))

## [6.3.2](https://github.com/aquariuslt/blog/compare/v6.3.1...v6.3.2) (2019-10-22)

### Bug Fixes

- **render:** fix rendered html not contains lang attribute ([dd12e78](https://github.com/aquariuslt/blog/commit/dd12e780ad8b6e0303d3340bf5e1a1423a4192e6))

## [6.3.1](https://github.com/aquariuslt/blog/compare/v6.3.0...v6.3.1) (2019-10-22)

### Performance Improvements

- optimize images with `imagemin` ([5a0d5d6](https://github.com/aquariuslt/blog/commit/5a0d5d61cc672293927b374f698a47b01ab48e83))

# [6.3.0](https://github.com/aquariuslt/blog/compare/v6.2.0...v6.3.0) (2019-10-21)

### Bug Fixes

- **application:** fix typo for generateion `.nojekyll` file ([0914b8d](https://github.com/aquariuslt/blog/commit/0914b8ddba8e9bbe5d2513801e3dd11c9ed3595d))
- **theme-vue:** correct register-service-worker ([6d59d2a](https://github.com/aquariuslt/blog/commit/6d59d2a3969405481e7b2d30c593a1a4df0618c8))

### Features

- **application:** add build `.nojekyll` file in build flow ([7f72697](https://github.com/aquariuslt/blog/commit/7f7269724e79dabc2b1f5d6c50c7dfd0e00e3947))

# [6.2.0](https://github.com/aquariuslt/blog/compare/v6.1.0...v6.2.0) (2019-10-21)

### Features

- **release:** add root package.json and lerna.json update logic ([001f432](https://github.com/aquariuslt/blog/commit/001f4327679890bd2810334100010a36f9ec1e7c))

# [6.1.0](https://github.com/aquariuslt/blog/compare/v6.0.1...v6.1.0) (2019-10-21)

### Bug Fixes

- **renderer:** add DOCTYPE as html content header ([b30be82](https://github.com/aquariuslt/blog/commit/b30be823d1478ea16f6bb169651cd9ce9f99acca))
- **theme-vue:** add register-service-worker instead empty sw.js ([8845c39](https://github.com/aquariuslt/blog/commit/8845c39291d43e7b93deacda5019b4f211efb4eb))

### Features

- correct version ([f0bc0e7](https://github.com/aquariuslt/blog/commit/f0bc0e7644e7c8d8b2edaecdd76911e815a53712))

### Performance Improvements

- covert jpg to png ([5cb9649](https://github.com/aquariuslt/blog/commit/5cb964906134760ed62fc2bb8c343632dcea973f))

## [6.0.2](https://github.com/aquariuslt/blog/compare/v6.0.1...v6.0.2) (2019-10-21)

### Bug Fixes

- **renderer:** add DOCTYPE as html content header ([b30be82](https://github.com/aquariuslt/blog/commit/b30be823d1478ea16f6bb169651cd9ce9f99acca))
- **theme-vue:** add register-service-worker instead empty sw.js ([8845c39](https://github.com/aquariuslt/blog/commit/8845c39291d43e7b93deacda5019b4f211efb4eb))

### Performance Improvements

- covert jpg to png ([5cb9649](https://github.com/aquariuslt/blog/commit/5cb964906134760ed62fc2bb8c343632dcea973f))

### Performance Improvements

- covert jpg to png ([5cb9649](https://github.com/aquariuslt/blog/commit/5cb964906134760ed62fc2bb8c343632dcea973f))

# [5.3.0](https://github.com/aquariuslt/blog/compare/v5.2.0...v5.3.0) (2019-10-21)

### Bug Fixes

- should run build before running tests ([ad7ed90](https://github.com/aquariuslt/blog/commit/ad7ed901a5ba5895e3193c4fc40bce73c313dc1b))
- **detail:** replace images relative url to absolute url in article ([2be9942](https://github.com/aquariuslt/blog/commit/2be9942ed24dc712b3b53dafdadcdacaa4cc7074))
- **theme-vue:** fix article-detail layout issue ([dba37dc](https://github.com/aquariuslt/blog/commit/dba37dcca3c02729e77a2205748955a716341f67))

### Features

- **@theme/vue:** add navigation and profile loading logic ([57c7eac](https://github.com/aquariuslt/blog/commit/57c7eac12ca97c3e45bc759c543caaca076c8b99))
- **@theme/vue:** add sub package: @theme/vue ([ac79c8c](https://github.com/aquariuslt/blog/commit/ac79c8c93fd090ec2b4bb6b7ada0ab2f9d5dcaed))
- **api:** add api generate utils ([8258957](https://github.com/aquariuslt/blog/commit/82589571cc627f21842755f61c34ce36fddac8e9))
- **api:** add api response and persistent logic ([176a4df](https://github.com/aquariuslt/blog/commit/176a4df529b494be8bcead137250335a98a91ab0))
- **api:** add navigation and profile api ([1d2b8b0](https://github.com/aquariuslt/blog/commit/1d2b8b0efa8107ea3923b9b52a5ca144a998aa2e))
- **api:** create api module ([0464932](https://github.com/aquariuslt/blog/commit/046493206673565175bb1df4dabdd320edfe2844))
- **article:** add article module at application ([d2b4dc0](https://github.com/aquariuslt/blog/commit/d2b4dc0a6b73ff30c2461e0a99a9b1ffd8c7e535))
- **article-tools:** create subpackage `article-tools` ([a9e4381](https://github.com/aquariuslt/blog/commit/a9e438163ee816bcac480646c23958f5a1d27f68))
- **build-flow:** complete frontend build flow ([b369332](https://github.com/aquariuslt/blog/commit/b3693320d5d766a8856790999dade244915d1f5f))
- **detail:** add article-detail component ([80622bf](https://github.com/aquariuslt/blog/commit/80622bfe4d16415a0a739e6b35959f94f7c62de8))
- **logger:** override default nest logger, to use fancy-log ([c5b2c17](https://github.com/aquariuslt/blog/commit/c5b2c17b37773d658eeab4572a4faea5390db002))
- **markdown:** add images, content-items markdown-it plugin ([cb05e34](https://github.com/aquariuslt/blog/commit/cb05e34b2628654ffbdefa219209c7e260aa4ad4))
- **markdown:** migrate summary plugin ([a578dbc](https://github.com/aquariuslt/blog/commit/a578dbc229e7ab26038f2a99a6ace0eb9ba3dbef))
- **metas:** add common meta creation ([2aad8b8](https://github.com/aquariuslt/blog/commit/2aad8b8a40984f62095752fe3e37f608ba1d8cc4))
- **migration:** create sub package: `@blog/migration` ([10e87e4](https://github.com/aquariuslt/blog/commit/10e87e451457e6b3dd9e5f69c31a356e9eaab513))
- **pre-render:** add render service for prerendering ([da73468](https://github.com/aquariuslt/blog/commit/da73468bcd01ceaadf601275ddd8c78ecaf74c33))
- **profile:** add subpackage `@blog/profile` ([39013ff](https://github.com/aquariuslt/blog/commit/39013ffccf457b76eca56b1a13457b4a99d70e81))
- **routing:** add field `url` as fullUrl in route meta ([a77a95d](https://github.com/aquariuslt/blog/commit/a77a95de3f7719429321a031844028a9f62527e5))
- **routing:** add routing meta generation ([1ce4bc6](https://github.com/aquariuslt/blog/commit/1ce4bc6a14adfc00e2c5116e05f5de3ea7288c12))
- **routing:** add tags, categories routing info generation ([72654d7](https://github.com/aquariuslt/blog/commit/72654d7815763d94f02b8415e52c37c6fe58ec61))
- **routing:** create routing module ([95dc494](https://github.com/aquariuslt/blog/commit/95dc494845af5b13567c4c192524190ae44abf13))
- **theme:** add theme building flow ([3536102](https://github.com/aquariuslt/blog/commit/35361022b8ee0f109c02e6c8dd09da2d1043334c))

### Performance Improvements

- reformat jpg to png with optimized ([098a386](https://github.com/aquariuslt/blog/commit/098a38614325d48db2c37544c472e3b9c7083096))
- **pwa:** optimize from lighthouse audit suggestion ([d8a7626](https://github.com/aquariuslt/blog/commit/d8a76260815bc1b9974ea7dc09ec612335cb0aa4))
