import Vue from 'vue';
import VueMaterial from 'vue-material';
import '@mdi/font/css/materialdesignicons.css';
import 'vue-material/dist/vue-material.min.css';
import './theme.scss';

Vue.use(VueMaterial);
