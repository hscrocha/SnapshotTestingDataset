const badgeStatus = {
  COMING: 'green',
  PAST_DUE: 'red'
};

export default badgeStatus;
