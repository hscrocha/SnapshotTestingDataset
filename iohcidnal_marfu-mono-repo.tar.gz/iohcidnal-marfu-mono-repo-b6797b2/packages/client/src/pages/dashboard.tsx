import { MembersDashboard } from '../components';

export default function Dashboard() {
  return <MembersDashboard />;
}
