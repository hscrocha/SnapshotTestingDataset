import { MemberInfo } from '../../components';

export default function Member() {
  return <MemberInfo />;
}
