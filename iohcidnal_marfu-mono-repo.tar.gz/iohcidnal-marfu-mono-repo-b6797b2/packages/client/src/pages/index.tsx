import { SignIn } from '../components';

export default function Index() {
  return <SignIn />;
}
