import { UserRegistration } from '../../components';

export default function Index() {
  return <UserRegistration />;
}
