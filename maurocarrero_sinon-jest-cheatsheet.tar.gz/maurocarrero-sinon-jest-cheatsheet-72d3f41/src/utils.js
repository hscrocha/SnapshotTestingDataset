module.exports = {
  PI: Math.PI
};
