const operations = require('./operations');

module.exports = operations;

