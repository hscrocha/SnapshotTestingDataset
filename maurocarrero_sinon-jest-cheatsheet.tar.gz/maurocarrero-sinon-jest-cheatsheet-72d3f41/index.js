console.log('Please run `npm t`');
