/*
 eslint-disable no-unused-vars, import/no-cycle
*/

import React, { useContext } from 'react';
import PropTypes from 'prop-types';
import { HandleClickContext } from './Calculator';
import btnBgColor from '../logic/style';

const Button = props => {
  const { btnName } = props;
  const handleClick = useContext(HandleClickContext);
  const zeroBtnWidth = {
    width: '50%',
  };
  return (
    <button
      id={`btn-(${btnName})`}
      className={`btn ${btnBgColor(btnName)}`}
      style={btnName === '0' ? zeroBtnWidth : null}
      onClick={() => handleClick(btnName)}
    >
        {btnName}
    </button>
  );
};

Button.propTypes = {
  btnName: PropTypes.string.isRequired,
};

export default Button;