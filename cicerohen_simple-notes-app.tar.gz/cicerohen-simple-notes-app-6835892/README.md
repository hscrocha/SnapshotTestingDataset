### Simple Notes App

A simple notes app using the new React APIs

## Requirements

[Node.js](https://nodejs.org/en/)(^v8.x)

## Install

```bash
npm install
```

## Development mode

```bash
npm start
```
