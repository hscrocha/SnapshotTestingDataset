export { default } from './NoteCardHeader';
