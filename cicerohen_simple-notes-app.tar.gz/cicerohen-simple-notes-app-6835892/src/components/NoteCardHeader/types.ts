export interface NoteCardHeaderPropsInterface {
  title?: string;
}
