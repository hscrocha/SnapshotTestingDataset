export interface CardFooterPropsInterface {
  children?: string | JSX.Element | Array<JSX.Element>;
  className?: string;
}
