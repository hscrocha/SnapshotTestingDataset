export interface SearchBarPropsInterface {
  className?: string;
}
