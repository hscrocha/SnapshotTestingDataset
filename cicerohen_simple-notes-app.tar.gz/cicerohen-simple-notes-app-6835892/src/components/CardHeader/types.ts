export interface CardHeaderPropsInterface {
  children?: any;
  className?: string;
}
