export interface NoteCardFooterPropsInterface {
  children?: any;
}
