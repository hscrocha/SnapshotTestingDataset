export { default } from './NoteCardFooter';
