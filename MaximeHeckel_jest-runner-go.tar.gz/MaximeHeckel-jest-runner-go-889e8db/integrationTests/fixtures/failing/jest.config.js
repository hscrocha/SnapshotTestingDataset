module.exports = {
  runner: '../../../build',
  moduleFileExtensions: ['go'],
  testMatch: ['**/?(*_)test.go'],
};
