import { isValidPasswordType } from "../../types/utilsTypes";

export type PasswordStrengthLoggerProps = {
  passwordStrengthStatus: isValidPasswordType;
};
