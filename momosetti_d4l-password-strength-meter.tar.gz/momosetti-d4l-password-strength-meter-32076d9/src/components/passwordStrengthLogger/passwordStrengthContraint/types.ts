export type PasswordStrengthConstraintType = {
  status: boolean;
  innerContent: string;
};
