export type RegisterFormWrapperProps = {
  children: React.ReactNode;
};
