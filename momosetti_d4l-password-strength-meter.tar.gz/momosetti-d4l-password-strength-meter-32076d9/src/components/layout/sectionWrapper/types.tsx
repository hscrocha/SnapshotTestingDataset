export type SectionWrapperProps = {
  children: React.ReactNode;
};
