const createPurchase = {
  date: '',
  code: '',
  value: '',
  percentage: '',
  cashback: ''
}

export default createPurchase;