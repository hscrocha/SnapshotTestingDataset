export const userInfo = (providerData) => ({
  type: 'USER_INFO',
  providerData,
});
