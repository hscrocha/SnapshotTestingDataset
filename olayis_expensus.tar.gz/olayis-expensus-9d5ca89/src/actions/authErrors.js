// AUTHENTICATION NETWORK ERROR
export const authNetworkError = () => ({
  type: 'AUTH_NETWORK_ERROR',
});

// AUTHENTICATION OTHER ERRORS
export const authOtherErrors = () => ({
  type: 'AUTH_OTHER_ERRORS',
});

// CANCEL AUTHENTICATION NETWORK ERROR
export const cancelAuthNetworkError = () => ({
  type: 'CANCEL_AUTH_NETWORK_ERROR',
});

// CAMCEL AUTHENTICATION OTHER ERRORS
export const cancelAuthOtherErrors = () => ({
  type: 'CANCEL_AUTH_OTHER_ERRORS',
});
