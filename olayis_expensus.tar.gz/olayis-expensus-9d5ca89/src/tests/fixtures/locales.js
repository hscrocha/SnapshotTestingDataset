export default [
  { currency: 'Naira' },
  { currency: 'Pound Sterling' },
  { currency: 'Real' },
  { currency: 'Euro' },
  { currency: 'Hryvnia' },
];
