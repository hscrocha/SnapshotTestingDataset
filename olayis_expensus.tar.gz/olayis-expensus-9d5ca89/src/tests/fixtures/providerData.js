export default [
  {
    displayName: 'Test',
    email: 'test@example.com',
    photoURL: 'image url',
    providerId: 'expensus.com',
  },
];
