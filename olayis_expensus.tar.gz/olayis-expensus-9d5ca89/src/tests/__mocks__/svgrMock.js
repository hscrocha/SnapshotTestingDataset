import * as React from 'react';
export default 'SvgrURL';
export const ReactComponent = 'div';
