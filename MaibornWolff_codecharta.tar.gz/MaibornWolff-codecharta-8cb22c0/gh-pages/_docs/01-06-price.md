---
permalink: /docs/price/
title: "Price"
---

CodeCharta is free and licensed under MIT.

We initially created CodeCharta because we wanted a good tool for our [software audits](https://www.maibornwolff.de/software-audits). We were able to build it rather quickly because of all the great open source tools on the market so it made sense to also open source CodeCharta. Please use it as you see fit.
