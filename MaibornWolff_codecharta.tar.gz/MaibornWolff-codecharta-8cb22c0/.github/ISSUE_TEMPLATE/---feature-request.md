---
name: "\U0001F680 Feature request"
about: Suggest an idea for this project
title: ''
labels: ''
assignees: ''

---

# Feature request

<Please note by far the quickest way to get a new feature is to file a Pull Request.>
<We will consider your request but it may be closed,>
<if it's something we're not actively planning to work on>
<or it does not match our visison of this software.>

## Description

As a <type of user>, I want <some goal> so that <some reason>.

## Acceptance criteria
- 
- 
- 

## Assumptions & Exclusions


## Development notes (optional Task Breakdown)
- [ ] 
- [ ] 
- [ ] 

## Open questions
