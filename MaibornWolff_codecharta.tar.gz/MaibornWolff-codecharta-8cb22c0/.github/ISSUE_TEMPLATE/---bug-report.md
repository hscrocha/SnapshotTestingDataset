---
name: "\U0001F41E Bug report"
about: Create a report to help us improve
title: ''
labels: bug
assignees: ''

---

# Bug

## Expected Behavior

<GIVEN>

WHEN

THEN

## Actual Behavior


## Screenshots

## Steps to Reproduce the Problem
1.
1.
1.

## Specifications
- is released in [online-demo](https://maibornwolff.github.io/codecharta/visualization/app/index.html?file=codecharta.cc.json.gz&file=codecharta_analysis.cc.json.gz): yes | no
- CodeCharta Version:
- OS:
- Browser:
