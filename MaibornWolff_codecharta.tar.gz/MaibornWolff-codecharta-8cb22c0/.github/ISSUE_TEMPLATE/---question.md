---
name: "⁉️ Question"
about: Any Questions you would like to have answered?
title: ''
labels: question
assignees: ''

---

# Question

## Preparation

Please check these resources first before posting a question

* [ ] I searched for answers in [older issues](https://github.com/MaibornWolff/codecharta/issues?utf8=%E2%9C%93&q=)
* [ ] I looked into the [README.md](https://github.com/MaibornWolff/codecharta)
* [ ] I read the [website](https://maibornwolff.github.io/codecharta/)

## Question
