# ValidationTool

Checks if a given json file conforms to visualisation format.

## Usage

Has zero return code if valid or non-zero return code if not valid and errors printed to stderr.

> ccsh check \<json file>
