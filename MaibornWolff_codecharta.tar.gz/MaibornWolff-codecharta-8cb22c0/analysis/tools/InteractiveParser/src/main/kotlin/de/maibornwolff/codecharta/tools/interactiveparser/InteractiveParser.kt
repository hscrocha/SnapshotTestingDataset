package de.maibornwolff.codecharta.tools.interactiveparser

interface InteractiveParser {
    fun getDialog(): ParserDialogInterface
}
