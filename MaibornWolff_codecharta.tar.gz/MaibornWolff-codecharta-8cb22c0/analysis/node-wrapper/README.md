# CodeCharta

> CodeCharta by [MaibornWolff](https://www.maibornwolff.de)

Install via npm

This installs all binaries to run the analysis. Java 9 is required.

`npm install -g @maibornwolff/codecharta-analysis`

To run it you can call `ccsh`

# More

Please visit [our github page](https://github.com/MaibornWolff/codecharta/tree/master/analysis) to learn more about CodeCharta
