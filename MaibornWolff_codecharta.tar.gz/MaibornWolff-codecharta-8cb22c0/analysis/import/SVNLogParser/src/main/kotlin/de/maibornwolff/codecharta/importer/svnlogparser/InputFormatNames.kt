package de.maibornwolff.codecharta.importer.svnlogparser

enum class InputFormatNames {
    SVN_LOG
}
