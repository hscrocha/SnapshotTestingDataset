package de.maibornwolff.codecharta.importer.gitlogparser

enum class InputFormatNames {
    GIT_LOG_NUMSTAT_RAW_REVERSED
}
