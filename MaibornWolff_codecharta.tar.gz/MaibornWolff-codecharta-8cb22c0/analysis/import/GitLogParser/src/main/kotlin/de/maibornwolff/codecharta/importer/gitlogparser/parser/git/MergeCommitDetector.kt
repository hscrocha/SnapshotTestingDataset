package de.maibornwolff.codecharta.importer.gitlogparser.parser.git

internal object MergeCommitDetector {

    const val MERGE_COMMIT_INDICATOR = "Merge: "
}
