package de.maibornwolff.codecharta.importer.sonar.filter

import org.junit.jupiter.api.Test

class ErrorResponseFilterTest {
    @Test
    @Throws(Exception::class)
    fun filter() {
    }
}
