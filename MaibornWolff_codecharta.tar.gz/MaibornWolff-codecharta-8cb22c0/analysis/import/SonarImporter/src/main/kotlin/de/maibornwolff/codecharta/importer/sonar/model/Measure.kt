package de.maibornwolff.codecharta.importer.sonar.model

data class Measure(val metric: String, val value: String?)
