package de.maibornwolff.codecharta.importer.sonar.model

data class ErrorEntity(val msg: String)
