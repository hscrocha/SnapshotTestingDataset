package sampleproject;
import foo;

@Annotation
public class Foo {
    public void noop(){ }
}