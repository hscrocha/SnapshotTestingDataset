class CommentedOutCode {
    private void fooBar(int foo){
        /* int a = 3;
         int b = 2; */
        if(true){
            return;
        }

        //if(true){
        //    return;
        //}

        // System.out.println("Fizzbuzz");


        int a;
    }
}