package de.maibornwolff.codecharta.filter.mergefilter

class MergeException(s: String) : RuntimeException(s)
