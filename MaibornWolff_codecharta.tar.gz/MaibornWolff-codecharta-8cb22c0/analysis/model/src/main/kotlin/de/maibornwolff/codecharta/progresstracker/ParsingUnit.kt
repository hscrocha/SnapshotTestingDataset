package de.maibornwolff.codecharta.progresstracker

enum class ParsingUnit {
    Byte, Files
}
