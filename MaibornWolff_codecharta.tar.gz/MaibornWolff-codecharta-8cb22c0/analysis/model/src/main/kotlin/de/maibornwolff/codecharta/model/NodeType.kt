package de.maibornwolff.codecharta.model

enum class NodeType {
    File, Folder, Package, Class, Interface, Method, Unknown
}
