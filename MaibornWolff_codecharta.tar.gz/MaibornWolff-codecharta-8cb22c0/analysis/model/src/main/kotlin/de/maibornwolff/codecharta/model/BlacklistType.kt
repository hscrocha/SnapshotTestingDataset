package de.maibornwolff.codecharta.model

enum class BlacklistType {
    exclude, hide
}
