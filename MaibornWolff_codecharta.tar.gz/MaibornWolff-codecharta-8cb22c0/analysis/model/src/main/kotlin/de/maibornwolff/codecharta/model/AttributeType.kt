package de.maibornwolff.codecharta.model

enum class AttributeType {
    absolute, relative
}
