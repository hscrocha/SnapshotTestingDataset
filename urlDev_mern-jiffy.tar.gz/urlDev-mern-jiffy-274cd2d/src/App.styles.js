import styled from 'styled-components';

export const AppContainer = styled.div`
  max-width: 1070px;
  margin: 0 auto;
  padding: 0 5px;
`;
