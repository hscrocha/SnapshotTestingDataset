module.exports = {
  title: 'actions',
  data: [
    {
      gif: {
        images: {
          original: {
            url: 'https://media0.giphy.com/media/YqoQ9wgKBCNVe/giphy.gif',
            webp: 'https://media0.giphy.com/media/YqoQ9wgKBCNVe/giphy.webp',
          },
        },
        slug: 'selena-gomez-crying-break-up-YqoQ9wgKBCNVe',
      },
      name: 'breaking up',
    },
  ],
};
