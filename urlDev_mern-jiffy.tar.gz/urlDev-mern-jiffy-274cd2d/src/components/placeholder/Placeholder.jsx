import React from 'react';

import { PlaceholderContainer } from './Placeholder.styles';

const Placeholder = () => {
  return <PlaceholderContainer />;
};

export default Placeholder;
