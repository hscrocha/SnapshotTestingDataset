import React from 'react';
import './Home.css';

const Home = () => (
  <div className="Home">
    <h4>Welcome to our page!</h4>
    <p>
      It is a long established fact that a reader will be distracted by the readable
      content of a page when looking at its layout.
      The point of using Lorem Ipsum is that it has a more-or-less normal distribution of
      letters, as opposed to using &nbsp;
      <q>
        Content here, content here
      </q>
      &nbsp;
      making it look
      like readable English.
      Many desktop publishing packages and web page editors now use Lorem Ipsum
      as their default model text,
      and a search for
      <q>lorem ipsum</q>
      &nbsp;
      will uncover many web sites still in their infancy.
      Various versions have evolved over the years,
      sometimes by accident, sometimes on purpose (injected humour and the like).
    </p>
    <p>
      It is a long established fact that a reader will be distracted by the readable
      content of a page when looking at its layout.
      The point of using Lorem Ipsum is that it has a more-or-less normal distribution of
      letters, as opposed to using &nbsp;
      <q>
        Content here, content here
      </q>
      &nbsp;
      making it look like readable English.
      Many desktop publishing packages and web page editors now use Lorem Ipsum
      as their default model text, and a search for &nbsp;
      <q>lorem ipsum</q>
      &nbsp;
      will uncover many web sites still in their infancy.
      Various versions have evolved over the years,
      sometimes by accident, sometimes on purpose (injected humour and the like).
    </p>
  </div>
);

export default Home;
