/* eslint
import/prefer-default-export: 0
*/

export { default as logout } from './logout';
