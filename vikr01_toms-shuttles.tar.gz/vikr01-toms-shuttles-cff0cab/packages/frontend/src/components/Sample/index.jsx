import React from 'react';

const Sample = () => <div>Hello!</div>;

export default Sample;
