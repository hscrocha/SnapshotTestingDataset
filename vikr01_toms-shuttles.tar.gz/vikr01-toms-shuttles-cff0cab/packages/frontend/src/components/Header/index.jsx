// @flow
import React, { Fragment } from 'react';
import routes from '../../routes';

const HomePage = () => <Fragment>{null}</Fragment>;

export default HomePage;
