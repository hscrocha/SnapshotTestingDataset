import Waiting from "./Waiting"

export default Waiting 