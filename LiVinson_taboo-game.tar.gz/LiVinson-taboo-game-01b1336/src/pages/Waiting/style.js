import styled from "styled-components"

export const Instructions = styled.p`
  font-size: 2rem;
  margin-bottom: 2rem;
  padding: 0 1rem;
  text-align:center;
`

