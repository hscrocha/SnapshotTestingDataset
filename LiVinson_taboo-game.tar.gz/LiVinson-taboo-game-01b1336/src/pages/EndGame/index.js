import EndGame from "./EndGame"

export default EndGame