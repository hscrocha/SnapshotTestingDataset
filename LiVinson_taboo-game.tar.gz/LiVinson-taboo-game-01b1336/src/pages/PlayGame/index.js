import PlayGame from "./PlayGame"

export default PlayGame