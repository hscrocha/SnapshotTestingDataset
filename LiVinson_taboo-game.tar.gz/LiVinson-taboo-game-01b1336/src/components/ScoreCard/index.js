import ScoreCard from "./ScoreCard"

export default ScoreCard