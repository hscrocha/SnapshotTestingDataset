import LoadingCard from "./LoadingCard"

export default LoadingCard