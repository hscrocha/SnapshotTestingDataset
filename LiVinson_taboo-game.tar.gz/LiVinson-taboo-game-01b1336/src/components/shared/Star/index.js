import Star from "./Star"

export default Star