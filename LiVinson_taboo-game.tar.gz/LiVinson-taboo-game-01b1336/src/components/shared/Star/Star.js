import React from 'react'
import {StyledStar} from './style'

const Star = () => {
	return <StyledStar />
}

export default Star
