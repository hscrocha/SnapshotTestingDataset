import styled from "styled-components"

export const StyledKeyWord = styled.span`
    color: ${props => props.theme.color.accent2};

`