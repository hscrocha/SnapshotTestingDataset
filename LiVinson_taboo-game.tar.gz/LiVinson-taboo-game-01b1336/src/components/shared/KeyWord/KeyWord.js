import React from "react"
import { StyledKeyWord } from "./style"

export const KeyWord = ({ children }) => {
	return <StyledKeyWord>{children}</StyledKeyWord>
}
