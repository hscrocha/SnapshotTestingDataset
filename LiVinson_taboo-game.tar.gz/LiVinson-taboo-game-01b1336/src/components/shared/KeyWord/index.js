import { KeyWord } from "./KeyWord"

export default KeyWord