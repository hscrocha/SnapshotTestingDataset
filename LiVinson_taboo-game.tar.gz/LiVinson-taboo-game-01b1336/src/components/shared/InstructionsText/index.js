import { InstructionsText } from "./InstructionsText"

export default InstructionsText