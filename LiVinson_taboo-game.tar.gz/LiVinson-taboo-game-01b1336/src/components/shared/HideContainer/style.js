import styled from "styled-components"

export const StyleHideContainer = styled.span`
    display: none;
`