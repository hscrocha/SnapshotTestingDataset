import ButtonErrorCard, {ErrorCard} from "./ErrorCard"

export {ErrorCard, ButtonErrorCard}