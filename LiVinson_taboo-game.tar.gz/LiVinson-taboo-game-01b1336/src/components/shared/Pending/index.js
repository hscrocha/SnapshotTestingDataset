import {Pending} from "./Pending"

export default Pending