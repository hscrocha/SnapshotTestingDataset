import SubmitCardForm from "./SubmitCardForm"

export default SubmitCardForm