import CardsPlayed from "./CardsPlayed"

export default CardsPlayed