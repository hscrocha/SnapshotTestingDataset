import Rules from "./Rules"

export default Rules