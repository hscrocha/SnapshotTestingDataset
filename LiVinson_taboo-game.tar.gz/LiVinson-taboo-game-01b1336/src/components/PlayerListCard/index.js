import PlayerListCard from "./PlayerListCard"

export default PlayerListCard