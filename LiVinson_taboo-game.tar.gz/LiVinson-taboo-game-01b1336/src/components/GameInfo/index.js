import GameInfo from "./GameInfo"

export default GameInfo