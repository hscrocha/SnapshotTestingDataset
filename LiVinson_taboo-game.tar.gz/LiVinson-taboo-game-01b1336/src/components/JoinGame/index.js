import JoinGame  from "./JoinGame"

export default JoinGame