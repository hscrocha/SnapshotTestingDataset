import JoinGameForm  from "./JoinGameForm"

export default JoinGameForm