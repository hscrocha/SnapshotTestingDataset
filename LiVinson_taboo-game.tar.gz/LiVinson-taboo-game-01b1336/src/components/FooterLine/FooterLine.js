import React from 'react'
import { StyledFooterLine } from './style'

/*Not currently used*/
const FooterLine = () => {
	return (	
			<StyledFooterLine />
	)
}

export default FooterLine
