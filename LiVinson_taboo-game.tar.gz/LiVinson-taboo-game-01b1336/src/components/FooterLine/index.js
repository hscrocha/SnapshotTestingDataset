import FooterLine from "./FooterLine"

export default FooterLine