import CreateGame from "./CreateGame"

export default CreateGame