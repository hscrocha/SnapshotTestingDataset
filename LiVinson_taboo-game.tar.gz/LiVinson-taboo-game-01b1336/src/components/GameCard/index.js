import { GameCard } from "./GameCard"

export { GameCard }