import {Disclaimer} from "./Disclaimer"

export default Disclaimer