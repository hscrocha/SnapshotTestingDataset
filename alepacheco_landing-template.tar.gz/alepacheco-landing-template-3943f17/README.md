# Landing page template

Starting template with:
- React.js
- Next.js
- Typescript
- SCSS
- Google analytics
- SSL (via Zeit Now)
- CI
- CD
- Jest tests

## How to use

```javascript
npm i -g now
npm i
npm run dev
```