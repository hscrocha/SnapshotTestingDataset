import React from 'react';

export const HelloWorld = ({}) => <div>Hello World</div>;

export default HelloWorld;
