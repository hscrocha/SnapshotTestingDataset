module.exports = {
    tabWidth: 4,
    semi: true,
    singleQuote: true,
    trailingComma: "all",
    pluginSearchDirs: ["src"],
    plugins: ["prettier-plugin-svelte"],
};
