<script>
    import Layout from '@Components/Layout';
    import ImageExample from '@Components/ImageExample';
    import HelloWorld from '@Components/HelloWorld';
</script>

<style src="./style.scss">

</style>

<Layout>
    <div class="container">
        <div class="container__top">
            <ImageExample />
        </div>
        <div class="container__middle">
            <HelloWorld />
        </div>
    </div>
</Layout>
