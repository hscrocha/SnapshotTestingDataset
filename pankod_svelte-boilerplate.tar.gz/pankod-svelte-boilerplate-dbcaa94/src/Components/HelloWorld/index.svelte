<style src="./style.scss">

</style>

<div class="title">
    <span class="title__top">Hello</span>
    <span class="title__front">World</span>
    <span class="title__back">World</span>
</div>
