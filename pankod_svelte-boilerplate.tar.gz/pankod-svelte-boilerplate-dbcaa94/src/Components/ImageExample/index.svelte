<style src="./style.scss">

</style>

<div class="image-content">
    <div class="bg-image" />
</div>
