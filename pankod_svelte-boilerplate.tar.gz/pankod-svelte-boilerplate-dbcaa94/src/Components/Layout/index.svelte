<div class="layout">
    <slot />
</div>
