# Security Policy

## Supported Versions

​
| Version | Supported |
| ------- | ------------------ |
| 0.0.16 | :white_check_mark: |
| 0.0.15 | :x: |
| 0.0.14 | :x: |
| 0.0.13 | :x: |
| 0.0.12 | :x: |
| 0.0.11 | :x: |
| 0.0.10 | :x: |
| 0.0.9 | :x: |
| 0.0.8 | :x: |
| 0.0.7 | :x: |
| 0.0.6 | :x: |
| 0.0.5 | :x: |
| 0.0.4 | :x: |
| 0.0.3 | :x: |
| 0.0.2 | :x: |
| 0.0.1 | :x: |
​

## Reporting a Vulnerability

[Create Issue](https://github.com/gregoranders/ts-react-playground/issues/new?labels=bug&template=bug_report.md&title=Security+Issue)
