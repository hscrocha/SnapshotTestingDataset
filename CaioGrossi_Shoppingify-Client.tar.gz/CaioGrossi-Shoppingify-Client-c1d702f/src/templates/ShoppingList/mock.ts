const mockShoppingLits = {
  id: '1',
  name: 'lista 1',
  date: '2021-05-13T15:38:10.000Z',
  itemsSections: [
    {
      category: 'teste',
      items: [
        {
          id: '1',
          name: 'item',
          quantity: 1,
          checked: false
        }
      ]
    }
  ]
};

export { mockShoppingLits };
