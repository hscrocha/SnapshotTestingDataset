const itemsSections = [
  {
    date: 'today',
    lists: [
      {
        id: '1',
        name: 'list 1',
        createdAt: 'hoje',
        status: 'open' as 'open' | 'completed'
      },
      {
        id: '2',
        name: 'list 4',
        createdAt: 'hoje',
        status: 'open' as 'open' | 'completed'
      },
      {
        id: '3',
        name: 'list 1',
        createdAt: 'hoje',
        status: 'open' as 'open' | 'completed'
      }
    ]
  }
];

export { itemsSections };
