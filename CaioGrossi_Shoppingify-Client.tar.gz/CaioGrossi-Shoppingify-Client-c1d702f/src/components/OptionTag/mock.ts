const optionMock = {
  id: '1',
  name: 'fish'
};

export { optionMock };
