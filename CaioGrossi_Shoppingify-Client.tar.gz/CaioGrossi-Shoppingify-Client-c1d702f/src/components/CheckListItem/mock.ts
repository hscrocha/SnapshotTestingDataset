const mock = {
  id: '1',
  name: 'Avocado',
  quantity: 4,
  onCheck: () => null,
  checked: false,
  onRemove: () => null
};

export { mock };
