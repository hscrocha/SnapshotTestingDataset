const mock = {
  listId: '1',
  isOpen: true,
  onConfirm: () => null,
  onCancel: () => null
};

export { mock };
