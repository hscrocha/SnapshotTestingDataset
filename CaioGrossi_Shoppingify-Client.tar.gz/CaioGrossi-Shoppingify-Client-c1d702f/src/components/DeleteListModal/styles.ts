import styled from 'styled-components';

export const Content = styled.div``;

export const ButtonsWrapper = styled.div`
  display: flex;
  align-content: flex-end;
  justify-content: flex-end;
`;
