const dataListMock = {
  categories: [
    {
      id: '1',
      name: 'fish'
    },
    {
      id: '2',
      name: 'hot fish'
    },
    {
      id: '3',
      name: 'cold fish'
    },
    {
      id: '4',
      name: 'fruits'
    },
    {
      id: '5',
      name: 'crazy fruits'
    },
    {
      id: '6',
      name: 'breads'
    }
  ]
};

export { dataListMock };
