import { Story, Meta } from '@storybook/react/types-6-0';
import FormSignup from '.';

export default {
  title: 'FormSignup',
  component: FormSignup
} as Meta;

export const Default: Story = () => <FormSignup />;
