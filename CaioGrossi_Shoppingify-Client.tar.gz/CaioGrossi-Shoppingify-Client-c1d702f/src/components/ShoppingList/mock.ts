const itemsMock = [
  {
    id: '1',
    name: 'Cake',
    quantity: 2
  },

  {
    id: '2',
    name: 'Bread',
    quantity: 4
  },
  {
    id: '3',
    name: 'Cake',
    quantity: 2
  },

  {
    id: '4',
    name: 'Bread',
    quantity: 4
  },
  {
    id: '5',
    name: 'Cake',
    quantity: 2
  },

  {
    id: '6',
    name: 'Bread',
    quantity: 4
  },
  {
    id: '7',
    name: 'Cake',
    quantity: 2
  },

  {
    id: '8',
    name: 'Bread',
    quantity: 4
  },
  {
    id: '9',
    name: 'Cake',
    quantity: 2
  },

  {
    id: '10',
    name: 'Bread',
    quantity: 4
  },
  {
    id: '11',
    name: 'Cake',
    quantity: 2
  },

  {
    id: '12',
    name: 'Bread',
    quantity: 4
  },
  {
    id: '13',
    name: 'Cake',
    quantity: 2
  },

  {
    id: '14',
    name: 'Bread',
    quantity: 4
  }
];

export { itemsMock };
