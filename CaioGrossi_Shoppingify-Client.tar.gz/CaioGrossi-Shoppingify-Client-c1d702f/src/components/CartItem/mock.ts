const mockCartItem = {
  id: '1',
  name: 'Cheese'
};

export default mockCartItem;
