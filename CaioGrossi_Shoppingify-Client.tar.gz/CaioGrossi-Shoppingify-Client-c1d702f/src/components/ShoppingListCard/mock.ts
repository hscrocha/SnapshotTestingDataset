import { ShoppingListCardProps } from '.';

const shoppingListCardMock = {
  id: '1',
  name: 'Lista de compras',
  createdAt: 'Mon 24.8.2020',
  status: 'open'
} as ShoppingListCardProps;

export { shoppingListCardMock };
