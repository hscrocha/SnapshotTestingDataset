import Auth from 'templates/Auth';
import FormSigin from 'components/FormSignin';

export default function Sigin() {
  return (
    <Auth>
      <FormSigin />
    </Auth>
  );
}
