const HeaderNavigationList = [
  {
    title: 'Boards',
    path: '/',
    faIcon: 'columns',
  },
];

export default HeaderNavigationList
