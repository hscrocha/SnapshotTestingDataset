const SidebarNavigation = [
  {
    title: 'Change Background',
    component: 'BoardBackgroundEdit',
    icon: 'fill-drip',
  },
  {
    title: 'Delete Board',
    component: 'BoardDelete',
    icon: 'trash',
  },
];

export default SidebarNavigation
