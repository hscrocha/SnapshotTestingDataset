import React, { Component } from 'react';
import PropTypes from "prop-types";
import { Droppable } from 'react-beautiful-dnd';
import Card from '../Card/Card';
import styled from 'styled-components';

const CardLIst = styled.div`
  min-height: 2rem;
  position: relative;
  padding: .5rem;
  flex-grow: 1;
  overflow: auto;
`;

const InnerList = (props) => {
  const { cardsId, isDraggingOver } = props;
  return cardsId.map((cardId, index) =>
    <Card key={index} isDraggingOver={isDraggingOver} index={index} cardId={cardId} />
  )
};

class ListCards extends Component {
  componentDidUpdate = prevProps => {
    const { cardsId } = this.props;
    if (cardsId[cardsId.length - 2] === prevProps.cardsId[prevProps.cardsId.length - 1]) {
      this.scrollToBottom();
    }
  };

  scrollToBottom = () => {
    this.listEnd.scrollIntoView();
  };

  render() {
    const { listId, cardsId } = this.props;

    return (
      <Droppable type={'task'} droppableId={`${listId}`}>
        {(provided, { isDraggingOver }) => (
          <CardLIst
            {...provided.droppableProps}
            ref={provided.innerRef}
            isDraggingOver={isDraggingOver}
          >
            <InnerList isDraggingOver={isDraggingOver} cardsId={cardsId} />
            {provided.placeholder}
            <div ref={el => this.listEnd = el}/>
          </CardLIst>
        )}
      </Droppable>
    )
  }
}

ListCards.defaultProps = {
  cardsId: [],
};

ListCards.propTypes = {
  listId: PropTypes.string.isRequired,
  cardsId: PropTypes.arrayOf(PropTypes.string).isRequired,
};

export default ListCards;
