const ListActionsNavigationList = [
  {
    title: 'Move List',
    component: 'ListMove',
  },
  {
    title: 'Move All Cards',
    component: 'ListMoveAllCards',
  },
  {
    title: 'Delete List',
    component: 'ListDelete',
  },
  {
    title: 'Delete All Cards',
    component: 'ListDeleteAllCards',
  },
];

export default ListActionsNavigationList
