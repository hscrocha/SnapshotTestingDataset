import store from './store/index'

window.store = store;
