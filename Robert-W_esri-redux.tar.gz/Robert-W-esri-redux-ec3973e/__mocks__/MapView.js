module.exports = function MapView() {
  return new Promise(function () {});
};
