module.exports = function () {
  return {};
};
