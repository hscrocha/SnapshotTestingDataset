module.exports = function () {
  return new Promise(function () {});
};
