export const
  ENV_PROD = 'production';
