export interface Message {
  text: string;
  nickname: string;
  imgUrl: string;
  time: string;
}
