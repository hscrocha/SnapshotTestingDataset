export enum NodeEnv {
  DEVELOPMENT='development',
  PRODUCTION='production',
  TEST='test'
}
