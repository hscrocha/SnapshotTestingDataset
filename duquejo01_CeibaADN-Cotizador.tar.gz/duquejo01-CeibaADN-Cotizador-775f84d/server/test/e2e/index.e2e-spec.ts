import './calendariofestivos/controlador/controlador-calendariofestivos.e2e.ts';
import './categoriausuarios/controlador/controlador-categoriausuarios.e2e.ts';
import './centrovacacional/controlador/controlador-centrovacacional.e2e.ts';
import './cotizacion/controlador/controlador-cotizacion.e2e.ts';