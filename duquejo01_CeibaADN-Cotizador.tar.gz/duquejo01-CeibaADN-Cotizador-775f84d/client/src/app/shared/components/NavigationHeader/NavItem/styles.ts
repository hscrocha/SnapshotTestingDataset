import styled from 'styled-components';

export const NavItemDiv = styled.div`
  margin-left: 5px;
  margin-right: 10px;
  font-weight: bold;
`;
