export enum yupConditions {
    minStringLength=2,
    maxStringLength=50
}