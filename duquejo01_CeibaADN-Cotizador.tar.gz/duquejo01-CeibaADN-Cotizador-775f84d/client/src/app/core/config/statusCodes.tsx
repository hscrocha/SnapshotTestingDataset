export enum statusCodes {
    CREATED=201,
    SUCCESS=200,
    NOTFOUND=404
}