import { CategoriaUsuarios } from 'app/feature/Admin/models/CategoriaUsuarios';

export interface EstadoCategoriaUsuarios {
  categoriasUsuarios: CategoriaUsuarios[];
}
