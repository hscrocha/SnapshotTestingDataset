export interface Calendario {
  id?: number;
  nombre: string;
  descripcion: string;
  festivos: Array<string>;
}
