export interface CategoriaUsuarios {
  id?: number;
  nombre: string;
  descripcion: string;
  valorAlta: number;
  valorBaja: number;
}
