export interface ISelectionOptions {
    label: string;
    value: string;
}
