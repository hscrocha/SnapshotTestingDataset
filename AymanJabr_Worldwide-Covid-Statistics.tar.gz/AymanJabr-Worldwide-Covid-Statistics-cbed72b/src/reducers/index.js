import { combineReducers } from 'redux';
import statisticsReducer from './statistics';

export default combineReducers({
  statisticsReducer,
});
