# Simple Demo Application

###### Tiny App with auth and real-time data

### Tech:

##### 🌍 [create-react-app](https://create-react-app.dev/)

##### 📋 [ant design](https://ant.design/)

##### 🤞 [typescript](https://www.typescriptlang.org/)

##### 🃏 [jest](https://jestjs.io/)

##### 🐐[testing-library](https://testing-library.com/)
