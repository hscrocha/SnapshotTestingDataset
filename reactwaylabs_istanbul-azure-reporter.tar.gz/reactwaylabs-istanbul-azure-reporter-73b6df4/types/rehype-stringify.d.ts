export = index;
declare class index {
    constructor(config: any);
    Compiler: any;
}
