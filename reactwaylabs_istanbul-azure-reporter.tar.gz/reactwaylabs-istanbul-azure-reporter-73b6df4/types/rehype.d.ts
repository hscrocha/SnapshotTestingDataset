import { Processor } from "unified";

declare function rehype(): Processor;
export = rehype;
