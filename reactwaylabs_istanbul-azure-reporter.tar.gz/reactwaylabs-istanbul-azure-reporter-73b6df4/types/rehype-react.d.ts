export = index;
declare class index {
    constructor(options: any);
    Compiler: any;
}
