import { AzureReporter } from "./azure-reporter";
export = AzureReporter;
