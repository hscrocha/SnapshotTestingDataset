export interface Link {
    name: string;
    url: string | null;
}
