import omitBy from 'lodash/omitBy';
import isNil from 'lodash/isNil';
import {ForwardRef, Memo} from 'react-is';

import {typeName} from 'enzyme/build/Debug';
import {childrenOfNode, propsOfNode} from 'enzyme/build/RSTTraversal';

import {compact, applyMap} from './utils';

function getChildren(node, options) {
  if (options.mode === 'shallow' && typeof node.type === 'function') {
    return null;
  }

  const children = compact(
    childrenOfNode(node).map(n => internalNodeToJson(n, options)),
  );

  return children.length > 0 ? children : null;
}

function getProps(node, options) {
  const props = omitBy(
    {
      ...propsOfNode(node),
    },
    (val, key) => {
      return key === 'children' || val === undefined;
    },
  );

  if (!isNil(node.key) && options.noKey !== true) {
    props.key = node.key;
  }

  return props;
}

function internalNodeToJson(node, options) {
  if (typeof node === 'string' || typeof node === 'number') {
    return node;
  }

  if (isNil(node) || node === false) {
    return '';
  }

  if (Array.isArray(node)) {
    // enzyme does some funny stuff with memo function components turning the children
    // into an array resulting in undesirable snapshots
    if (node.length === 1) {
      return internalNodeToJson(node[0], options);
    }
    return node.map(child => internalNodeToJson(child, options));
  }

  if (
    options.mode === 'deep' &&
    (typeof node.type === 'function' ||
      node.type.$$typeof === ForwardRef ||
      node.type.$$typeof === Memo)
  ) {
    return internalNodeToJson(node.rendered, options);
  }

  return applyMap(
    {
      node,
      type: typeName(node),
      props: getProps(node, options),
      children: getChildren(node, options),
      $$typeof: Symbol.for('react.test.json'),
    },
    options,
  );
}

const mountToJson = (wrapper, options = {}) => {
  if (isNil(wrapper) || wrapper.length === 0) {
    return null;
  }

  if (wrapper.length > 1 && typeof wrapper.getNodesInternal === 'function') {
    const nodes = wrapper.getNodesInternal();
    return nodes.map(node => internalNodeToJson(node, options));
  }

  if (typeof wrapper.getNodeInternal === 'function') {
    const node = wrapper.getNodeInternal();
    return internalNodeToJson(node, options);
  }

  return null;
};

export default mountToJson;
