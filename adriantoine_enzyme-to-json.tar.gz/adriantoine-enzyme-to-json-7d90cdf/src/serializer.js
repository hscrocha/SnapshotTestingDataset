import createSerializer from './createSerializer';

module.exports = createSerializer();
