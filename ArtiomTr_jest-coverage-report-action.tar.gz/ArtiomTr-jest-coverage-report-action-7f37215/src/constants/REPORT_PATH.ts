export const REPORT_PATH = 'report.json';
