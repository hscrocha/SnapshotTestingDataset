import { run } from './run';

run();
