export const getCoverage = jest.fn();
