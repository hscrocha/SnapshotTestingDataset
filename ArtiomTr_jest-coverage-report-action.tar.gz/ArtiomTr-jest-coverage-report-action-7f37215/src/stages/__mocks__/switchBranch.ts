export const switchBranch = jest.fn();
