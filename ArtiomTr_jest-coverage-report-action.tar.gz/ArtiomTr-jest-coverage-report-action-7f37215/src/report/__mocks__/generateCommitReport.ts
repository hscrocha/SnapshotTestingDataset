export const generateCommitReport = jest.fn();
