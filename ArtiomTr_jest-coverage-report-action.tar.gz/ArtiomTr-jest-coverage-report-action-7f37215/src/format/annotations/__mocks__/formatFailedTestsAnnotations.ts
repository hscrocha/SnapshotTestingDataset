export const formatFailedTestsAnnotations = jest.fn();
