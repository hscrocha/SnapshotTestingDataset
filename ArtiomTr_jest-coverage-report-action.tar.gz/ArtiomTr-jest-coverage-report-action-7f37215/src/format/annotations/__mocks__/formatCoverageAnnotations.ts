export const formatCoverageAnnotations = jest.fn();
