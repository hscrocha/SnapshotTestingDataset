export const createCoverageAnnotations = jest.fn();
