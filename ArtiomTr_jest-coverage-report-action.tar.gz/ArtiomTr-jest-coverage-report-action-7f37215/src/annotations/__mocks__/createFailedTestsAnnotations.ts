export const createFailedTestsAnnotations = jest.fn();
