export const removeDirectory = jest.fn().mockName('removeDirectory');
