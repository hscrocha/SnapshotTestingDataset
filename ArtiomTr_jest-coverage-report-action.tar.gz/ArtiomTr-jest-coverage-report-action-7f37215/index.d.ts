declare module '*.md' {
    const text: string;

    export default text;
}
