export type LinkProps = {
    href: string;
    label: string;
};
