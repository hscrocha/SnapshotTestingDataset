export const readFile = jest.fn();

export const rmdir = jest.fn();

export const rm = jest.fn();
