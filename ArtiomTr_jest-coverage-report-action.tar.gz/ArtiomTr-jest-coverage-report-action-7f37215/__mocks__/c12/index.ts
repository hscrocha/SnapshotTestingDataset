export const loadConfig = jest.fn();
