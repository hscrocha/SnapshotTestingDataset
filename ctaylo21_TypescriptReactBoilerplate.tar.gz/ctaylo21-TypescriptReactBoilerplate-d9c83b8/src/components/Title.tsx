import React from 'react';

const Title = (): JSX.Element => <>Hello</>

export default Title;
