import React from 'react';

const SvgMock: React.FC<unknown> = (): JSX.Element => <></>;

export default SvgMock;
