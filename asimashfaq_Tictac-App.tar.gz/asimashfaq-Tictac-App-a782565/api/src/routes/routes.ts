// tslint:disable-next-line: import-name
import tictacRoutes from '../controllers/tictac/index';
export default [...tictacRoutes];
