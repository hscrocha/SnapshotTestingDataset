// tslint:disable-next-line: import-name
import tictacRoutes from './routes';

export default [...tictacRoutes];
