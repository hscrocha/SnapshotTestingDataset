export default interface IBoxModel {
  id: string;
  player: number;
  step: number;
  value: string;
}
