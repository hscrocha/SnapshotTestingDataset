declare module '*.json' {
  const value: any;
  export default value;
}
declare module '@hapi/joi';
