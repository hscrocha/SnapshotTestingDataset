export { default } from './gamehistory'
