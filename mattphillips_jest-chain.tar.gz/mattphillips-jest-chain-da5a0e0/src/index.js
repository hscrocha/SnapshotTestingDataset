import chain from './chain';

global.expect = chain(global.expect);
