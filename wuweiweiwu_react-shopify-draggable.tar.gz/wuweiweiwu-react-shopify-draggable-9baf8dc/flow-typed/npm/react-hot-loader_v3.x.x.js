// flow-typed signature: 9d0d7b4cee70d8ca16304fe8c1b4bbed
// flow-typed version: 23646d2d0e/react-hot-loader_v3.x.x/flow_>=v0.53.0

// @flow
declare module "react-hot-loader" {
  declare class AppContainer<S, A> extends React$Component<{
    errorReporter?: React$Element<any> | (() => React$Element<any>),
    children: React$Element<any>
  }> {}
}
