---
name: Feature - Component
about: 컴포넌트 단위의 issue
---

### Component

<!— 해당 컴포넌트의 이름을 적어주세요 —> ex) ModifyFormContainer (회원가입 추가입력 폼)

### Screenshot

<!- 해당 컴포넌트를 캡처해서 올려주세요 ->

### Page

<!- 해당 컴포넌트가 종속된 페이지를 적어주세요 -> ex) #1 로그인 페이지

### Explanation

<!- 컴포넌트에 대한 설명을 적어주세요 ->
