export default {
  SERVER_URL: 'http://localhost:13000',
};
