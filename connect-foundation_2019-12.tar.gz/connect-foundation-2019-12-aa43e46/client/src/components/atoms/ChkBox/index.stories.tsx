import React from 'react';

import ChkBox from '.';

export default {
  title: 'Atoms / ChkBox',
};

export const index: React.FC = () => {
  return <ChkBox checked={false} />;
};
