import React from 'react';
import InputOnlyNumber from '.';

export default {
  title: 'Atoms / InputOnlyNumber',
};

export const index: React.FC = () => {
  return <InputOnlyNumber inputName={'email'} />;
};
