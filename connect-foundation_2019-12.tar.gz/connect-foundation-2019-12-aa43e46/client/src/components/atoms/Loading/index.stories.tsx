import React from 'react';
import Loading from '.';

export default {
  title: 'Atoms / Loading',
};

export const defaultLabel: React.FC = () => <Loading />;
