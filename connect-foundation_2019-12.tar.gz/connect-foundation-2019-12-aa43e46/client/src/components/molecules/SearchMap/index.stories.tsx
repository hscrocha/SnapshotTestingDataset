import React from 'react';

import SearchMap from '.';

export default {
  title: 'Molecules / SearchMap',
};

export const index: React.FC = () => {
  return <SearchMap />;
};
