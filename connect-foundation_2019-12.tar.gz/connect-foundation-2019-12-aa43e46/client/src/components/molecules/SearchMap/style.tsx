import styled from 'styled-components';

export const Container = styled.div``;

export const SearchContainer = styled.div`
  position: relative;
`;
export const KakaoMapWrapper = styled.div`
  margin-top: 1rem;
`;
