import styled from 'styled-components';

export const CreateEventFormContainer = styled.div`
  & > div {
    margin-bottom: 4rem;
  }
`;
