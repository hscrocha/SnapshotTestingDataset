import React from 'react';

import Footer from '.';

export default {
  title: 'Organisms / Footer',
};

export const index: React.FC = () => <Footer />;
