import React from 'react';
import SignUpPage from '.';

export default {
  title: 'Pages / SignUpPage',
};

export const signUpPage: React.FC = () => {
  return <SignUpPage />;
};
