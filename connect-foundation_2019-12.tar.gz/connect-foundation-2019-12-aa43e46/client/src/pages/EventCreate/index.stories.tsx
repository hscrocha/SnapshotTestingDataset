import React from 'react';
import EventCreate from '.';

export default {
  title: 'Pages / EventCreate',
};

export const eventCreatePage: React.FC = () => {
  return <EventCreate />;
};
