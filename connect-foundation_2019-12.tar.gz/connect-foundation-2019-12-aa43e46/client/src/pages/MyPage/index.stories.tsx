import React from 'react';

import MyPage from '.';

export default {
  title: 'Pages / MyPage',
};

export const index: React.FC = () => {
  return <MyPage />;
};
