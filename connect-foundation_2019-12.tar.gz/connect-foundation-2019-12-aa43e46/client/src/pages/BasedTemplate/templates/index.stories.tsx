import React from 'react';

import BasedTemplate from 'pages/BasedTemplate/templates';

export default {
  title: 'Templates / BasedTemplate',
};

export const basedTemplate: React.FC = () => (
  <BasedTemplate>
    <div style={{ textAlign: 'center' }}>
      <h1>페이지 내용입니다</h1>
      <h1>페이지 내용입니다</h1>
      <h1>페이지 내용입니다</h1>
      <h1>페이지 내용입니다</h1>
      <h1>페이지 내용입니다</h1>
      <h1>페이지 내용입니다</h1>
      <h1>페이지 내용입니다</h1>
      <h1>페이지 내용입니다</h1>
    </div>
  </BasedTemplate>
);
