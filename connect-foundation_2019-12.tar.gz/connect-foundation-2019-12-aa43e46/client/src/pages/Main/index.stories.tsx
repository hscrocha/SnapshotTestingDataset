import React from 'react';
import Main from '.';

export default {
  title: 'Pages / Main',
};

export const main: React.FC = () => {
  return <Main />;
};
