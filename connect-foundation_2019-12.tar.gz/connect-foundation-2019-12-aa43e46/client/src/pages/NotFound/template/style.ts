import styled from 'styled-components';

export const ContentContainer = styled.div`
  height: 55rem;
  a {
    width: 100%;
    height: 100%;
    object-fit: contain;
  }
`;
