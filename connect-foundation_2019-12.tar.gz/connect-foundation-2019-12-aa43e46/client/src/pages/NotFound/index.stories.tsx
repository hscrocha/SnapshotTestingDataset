import React from 'react';
import NotFound from '.';

export default {
  title: 'Pages / NotFound',
};

export const notFound: React.FC = () => {
  return <NotFound />;
};
