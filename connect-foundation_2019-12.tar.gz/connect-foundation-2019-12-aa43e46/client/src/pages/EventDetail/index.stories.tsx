import React from 'react';
import EventDetail from '.';

export default {
  title: 'Pages / EventDetail',
};

export const eventDetailPage: React.FC = () => {
  return <EventDetail />;
};
