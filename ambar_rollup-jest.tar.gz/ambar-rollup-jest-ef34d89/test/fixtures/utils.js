export const foo = 42
