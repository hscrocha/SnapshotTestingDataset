import { fetchQuote, checkHeaders, createLink, DEFAULT_TIMEOUT } from './Api';

export { fetchQuote, checkHeaders, createLink, DEFAULT_TIMEOUT };
