//http://api.forismatic.com/api/1.0/?lang=en&key=111111&format=json&method=getQuote
const exampleResponse = {
  quoteText: 'When you see a man of worth, think of how you may emulate him. When you see one who is unworthy, examine yourself.  ',
  quoteAuthor: 'Confucius',
  senderName: '',
  senderLink: '',
  quoteLink: 'http://forismatic.com/en/ad042400a2/',
};

export { exampleResponse };
