import arithmetic from './Arithmetic';

export { arithmetic };
