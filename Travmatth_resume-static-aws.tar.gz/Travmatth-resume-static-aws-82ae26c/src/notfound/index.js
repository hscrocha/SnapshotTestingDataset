/* @flow */

if (typeof document !== 'undefined') {
  document.addEventListener('DOMContentLoaded', () => {});
}
