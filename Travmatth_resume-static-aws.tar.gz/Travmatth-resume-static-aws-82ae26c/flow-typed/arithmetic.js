declare module 'Arithmetic' {
  declare module.exports: {
    parse(str: string): string|Error;
  };
}
