// declare module './aws.json' {
//   declare var s3Opts: {
//    ACCESS_KEY_ID: string,
//    SECRET_ACCESS_KEY: string,
//    REGION: string,
//    BUCKET: string,
//   }
// }