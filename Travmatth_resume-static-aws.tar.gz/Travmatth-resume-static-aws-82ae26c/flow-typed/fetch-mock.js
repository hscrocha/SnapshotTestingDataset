declare module 'fetch-mock' {
  declare module.exports: any;
}