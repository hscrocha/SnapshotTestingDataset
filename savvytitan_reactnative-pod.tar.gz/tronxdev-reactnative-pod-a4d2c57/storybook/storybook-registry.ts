require('./stories/components/SearchBar.story')
