declare var tron
tron = null
