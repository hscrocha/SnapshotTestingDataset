module.exports = require('@scaleleap/utils/husky')(__dirname)
