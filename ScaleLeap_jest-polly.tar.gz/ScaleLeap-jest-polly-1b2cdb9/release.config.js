module.exports = require('@scaleleap/utils/semantic-release')
