module.exports = require('@scaleleap/utils/commitlint')
