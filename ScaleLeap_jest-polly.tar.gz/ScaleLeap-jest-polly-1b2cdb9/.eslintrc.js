module.exports = require('@scaleleap/utils/eslint')
