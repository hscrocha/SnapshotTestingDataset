module.exports = require('@scaleleap/utils/lint-staged')
