export const APPLICATION_JSON_MIME = 'application/json'
