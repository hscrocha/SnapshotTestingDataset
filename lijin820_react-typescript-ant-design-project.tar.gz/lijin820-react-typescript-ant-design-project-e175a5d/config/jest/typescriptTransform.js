/* eslint-disable */
const tsJestPreprocessor = require("ts-jest/preprocessor");

module.exports = tsJestPreprocessor;
