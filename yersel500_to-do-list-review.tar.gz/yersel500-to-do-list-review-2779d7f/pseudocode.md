# Pseudocode to-do List

Add module:

- Read the book from the input when user press key tab.
- Save the info on an array of objects: Description, complete:  false and index
- Save the in localstorage
- Show the info in the UL task list

Delete module:

- When user press on the task, on the right the icon change to trash and when click trash button the task is deleted
- The index number should be recalculated from the array
- Update local storage