// Tasks container
export const ulContainer = document.querySelector('.list');
// Input of tasks
export const taskInput = document.querySelector('.task-input');
// delete completed task
export const btndeleteTask = document.querySelector('.delete-task');
