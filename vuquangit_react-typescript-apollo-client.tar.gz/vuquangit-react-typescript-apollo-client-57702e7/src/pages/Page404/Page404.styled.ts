import styled from 'styled-components'

export const Page404Wrapper: React.FC = styled('div')`
  display: flex;
  align-items: center;
  justify-content: center;

  width: 100%;
  height: 100%;
`
