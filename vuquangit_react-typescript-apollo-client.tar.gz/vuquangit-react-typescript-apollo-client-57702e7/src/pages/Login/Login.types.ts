import { RouteComponentProps } from 'react-router'

// eslint-disable-next-line @typescript-eslint/ban-types
type TLoginProps = {}

export declare type BaseLoginProps = RouteComponentProps & TLoginProps
