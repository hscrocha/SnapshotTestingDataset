import styled from 'styled-components'

export const AttendancesWrapper = styled('div')``
