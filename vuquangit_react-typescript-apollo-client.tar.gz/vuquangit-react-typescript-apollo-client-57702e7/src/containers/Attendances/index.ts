import Attendances from './Attendances'

export default Attendances
