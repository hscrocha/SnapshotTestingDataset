// eslint-disable-next-line @typescript-eslint/ban-types
export type BaseAttendancesProps = {}
