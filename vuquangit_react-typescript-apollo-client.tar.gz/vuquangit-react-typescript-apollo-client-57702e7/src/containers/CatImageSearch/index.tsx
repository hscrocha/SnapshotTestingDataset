/**
 *
 * Index for CatImageSearch
 *
 */

import CatImageSearch from './CatImageSearch'

export default CatImageSearch
