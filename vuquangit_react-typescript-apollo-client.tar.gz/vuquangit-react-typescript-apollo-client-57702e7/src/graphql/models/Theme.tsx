export type ThemeState = 'light' | 'dark'
