export default {
  translation: {
    'Welcome to React': 'Welcome to react',
  },
}
