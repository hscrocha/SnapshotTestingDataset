export default {
  translation: {
    'Welcome to React': 'Chào mừng đến react',
  },
}
