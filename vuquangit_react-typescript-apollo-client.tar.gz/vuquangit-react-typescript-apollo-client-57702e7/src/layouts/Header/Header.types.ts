export interface INavList {
  id: number
  label: string
  link: string
  exact?: boolean
}

// eslint-disable-next-line @typescript-eslint/ban-types
export declare type BaseHeaderProps = {}
