import styled from 'styled-components'

export const FooterWrapper = styled('footer')`
  order: 3;
  padding: 20px 0;
  border-top: 1px solid #e2e2e2;
  text-align: center;
`
