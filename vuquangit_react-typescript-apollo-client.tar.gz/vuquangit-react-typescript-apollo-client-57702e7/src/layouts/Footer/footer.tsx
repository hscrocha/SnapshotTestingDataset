import React, { FC } from 'react'
import { FooterWrapper } from './Footer.styled'

const Footer: FC = () => {
  return <FooterWrapper>Footer</FooterWrapper>
}

export default Footer
