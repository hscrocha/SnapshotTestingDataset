import styled from 'styled-components'

export const MainWrapper = styled('main')`
  flex-grow: 1;
  order: 1;
`
