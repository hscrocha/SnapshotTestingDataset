import React, { FC } from 'react'

const NoopLayout: FC = ({ children }) => {
  return <>{children}</>
}

export default NoopLayout
