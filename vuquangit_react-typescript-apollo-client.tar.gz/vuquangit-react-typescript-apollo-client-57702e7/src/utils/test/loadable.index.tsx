import React from 'react'

const LazyloadComponent = () => <div>My lazy-loaded component</div>

export default LazyloadComponent
