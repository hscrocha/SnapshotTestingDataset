const dateData = {
  date: 6,
  dayName: 'Fri',
  iso: '2020-11-06',
  maxWidth: 14.285714285714286,
  type: 'current',
}

export { dateData }
