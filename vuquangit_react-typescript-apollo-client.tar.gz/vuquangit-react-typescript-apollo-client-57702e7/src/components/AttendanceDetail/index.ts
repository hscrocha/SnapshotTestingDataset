import AttendanceDetail from './AttendanceDetail'

export default AttendanceDetail
