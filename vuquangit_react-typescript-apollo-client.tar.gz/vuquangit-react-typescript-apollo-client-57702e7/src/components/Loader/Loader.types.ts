export interface ILoaderProps {
  size?: number
}

export declare type BaseLoaderProps = ILoaderProps
