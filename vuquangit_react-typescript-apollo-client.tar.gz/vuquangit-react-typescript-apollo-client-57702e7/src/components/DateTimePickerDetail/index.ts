import DateTimePickerDetail from './DateTimePickerDetail'

export default DateTimePickerDetail
