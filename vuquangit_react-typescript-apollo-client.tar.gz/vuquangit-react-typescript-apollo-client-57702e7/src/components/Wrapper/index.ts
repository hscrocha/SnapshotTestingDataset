/**
 *
 * Index for Wrapper
 *
 */

import Wrapper from './Wrapper'

export default Wrapper
