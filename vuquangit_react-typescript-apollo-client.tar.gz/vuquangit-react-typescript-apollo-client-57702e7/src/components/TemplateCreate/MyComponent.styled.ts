import styled from 'styled-components'
import { space } from 'styled-system'

export const ComponentWrapper = styled('div')`
  ${space}
`
