import { SpaceProps } from 'styled-system'

// eslint-disable-next-line @typescript-eslint/no-empty-interface
export interface IMyComponentProps {}
export declare type BaseComponentProps = IMyComponentProps & SpaceProps
