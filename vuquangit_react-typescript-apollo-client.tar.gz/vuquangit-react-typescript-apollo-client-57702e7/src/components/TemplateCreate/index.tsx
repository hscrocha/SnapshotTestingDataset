import MyComponent from './MyComponent'

export default MyComponent
