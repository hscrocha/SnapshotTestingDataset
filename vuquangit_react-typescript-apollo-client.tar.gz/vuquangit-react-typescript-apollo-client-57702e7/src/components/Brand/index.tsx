/**
 *
 * Index for Brand
 *
 */

import Brand from './Brand'

export default Brand
