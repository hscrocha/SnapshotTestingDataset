import { SpaceProps } from 'styled-system'

export declare type BaseBrandProps = SpaceProps
