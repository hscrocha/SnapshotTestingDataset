import SwitchTheme from './SwitchTheme'

export default SwitchTheme
