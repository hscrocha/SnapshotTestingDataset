import { SpaceProps } from 'styled-system'

// eslint-disable-next-line @typescript-eslint/no-empty-interface
export interface ICircleTimeProps {}
export declare type BaseCircleTimeProps = ICircleTimeProps & SpaceProps
