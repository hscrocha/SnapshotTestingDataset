/**
 *
 * Tests for DateTimePicker
 *
 */

import React from 'react'
import { render /* fireEvent */ } from '@testing-library/react'

import DateTimePicker from '..'
import AppWrapper from '@/test/supports/AppWrapper'

describe('App DateTimePicker', () => {
  it('Test DateTimePicker with date type', async () => {
    // const { container, getByTestId } = render(
    //   <AppWrapper>
    //     <DateTimePicker typePicker="date" />
    //   </AppWrapper>
    // )
    // expect(container).toMatchSnapshot()
  })
})
