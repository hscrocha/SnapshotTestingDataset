import Emoji from './Emoji'

export default Emoji
