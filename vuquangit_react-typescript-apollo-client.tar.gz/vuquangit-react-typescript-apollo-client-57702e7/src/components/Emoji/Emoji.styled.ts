import styled from 'styled-components'
import { space } from 'styled-system'

export const EmojiWrapper = styled('span')`
  ${space};
`
