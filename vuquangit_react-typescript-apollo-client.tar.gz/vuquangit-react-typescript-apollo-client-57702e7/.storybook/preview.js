export const parameters = {
  layout: 'padded',
  actions: { 
    argTypesRegex: '^on[A-Z].*', 
    docs: { page: null } 
  },
}
