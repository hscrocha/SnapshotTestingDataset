import { NativeTestInstance } from './query-helpers';

export declare function getNodeText(node: NativeTestInstance): string;
