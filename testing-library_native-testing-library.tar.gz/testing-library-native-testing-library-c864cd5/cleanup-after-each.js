afterEach(() => {
  return require('./dist/cleanup-async')();
});
