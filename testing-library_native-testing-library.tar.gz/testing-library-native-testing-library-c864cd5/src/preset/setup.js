// Configure NTL
import './configure';

// Un-mock the things that we'll be mocking
import './mock-modules';
