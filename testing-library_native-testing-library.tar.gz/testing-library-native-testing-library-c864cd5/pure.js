// makes it so people can import from '@testing-library/react-native/pure'
module.exports = require('./dist/pure');
