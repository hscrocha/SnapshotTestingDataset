export default function Page(): JSX.Element {
  return <div></div>;
}
