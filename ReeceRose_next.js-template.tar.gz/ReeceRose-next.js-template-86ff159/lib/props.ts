export type SEOProps = {
  title: string;
  description: string;
};
