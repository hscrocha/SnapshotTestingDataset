export { default } from './LightBrightInteractiveArea';
