export { default } from './Board';
