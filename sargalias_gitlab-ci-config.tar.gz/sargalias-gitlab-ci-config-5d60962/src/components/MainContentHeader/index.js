export { default } from './MainContentHeader';
