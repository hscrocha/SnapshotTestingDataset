export { default } from './LightBrightPage';
