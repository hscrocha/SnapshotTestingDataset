# Roadmap

- [x] fix page_action button to be active when tab is `https://www.youtube.com/feed/subscriptions/*`
- [] add scroll to pickup point button
- [] recent history of pickup points, popup to click to go back to previous pickup point
- [] find video even through pagination using [sample/browse_ajax.json](sample/browse_ajax.json)
