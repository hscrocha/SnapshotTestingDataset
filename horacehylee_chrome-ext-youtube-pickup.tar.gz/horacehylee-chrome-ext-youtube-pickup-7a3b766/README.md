[![Build Status](https://img.shields.io/travis/horacehylee/chrome-ext-youtube-pickup.svg?branch=master)](https://travis-ci.org/horacehylee/chrome-ext-youtube-pickup)
[![Coverage Status](https://img.shields.io/coveralls/github/horacehylee/chrome-ext-youtube-pickup.svg)](https://coveralls.io/github/horacehylee/chrome-ext-youtube-pickup?branch=master)
[![MIT license](http://img.shields.io/badge/license-MIT-brightgreen.svg)](http://opensource.org/licenses/MIT)

# ![][logo] Youtube Pickup Chrome Extension

> Chrome extension that track the last youtube video that you scroll to and let you pick up where you left off

![][screencast]

## License

MIT © [Horace Lee](https://github.com/horacehylee)

[logo]: resources/images/logo32.png
[screencast]: assets/screencast.gif