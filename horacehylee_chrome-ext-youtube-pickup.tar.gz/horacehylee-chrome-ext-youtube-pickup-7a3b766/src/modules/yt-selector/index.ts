import { queryVideos } from "./queryVideos";

export const ytSelector = {
  queryVideos
};
