# My Professional Profile

<img src="https://github.com/annabranco/my-profile/raw/master/src/assets/images/annabranco.png" width="10%">

Hi, I'm **Anna Branco**, Frontend developer. This is a digital version of my web
professional profile.

Thank you very much for your interest on visiting me.

[annabranco.github.io/my-profile/](https://annabranco.github.io/my-profile/)

*For an enhanced user experience, I recommended visiting it on a full-screen desktop.*

<a href="https://www.linkedin.com/in/annabranco/">
<img src="https://upload.wikimedia.org/wikipedia/commons/thumb/c/ca/LinkedIn_logo_initials.png/240px-LinkedIn_logo_initials.png" width="50px">
</a>

[/annabranco/](https://www.linkedin.com/in/annabranco/)
