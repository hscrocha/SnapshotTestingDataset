export default {
  active: false,
  read: false,
  visible: false
};
