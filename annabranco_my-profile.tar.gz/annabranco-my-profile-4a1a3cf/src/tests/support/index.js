import '@cypress/code-coverage/support';
