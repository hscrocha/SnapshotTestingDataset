export default {
  DEFAULT_PAGE_LANGUAGE: 'English'
};
