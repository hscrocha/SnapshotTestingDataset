export const isDevelopment: boolean =
  process.env.REACT_APP_DEV_SERVER === 'true';
