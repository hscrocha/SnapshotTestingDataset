export const ACTIVE_SECTION = 'activeSection';
export const INFO_PAGE_SECTION = 'main';
export const SKILLS_SECTION = 'technical';
export const PROJECTS_SECTION = 'projects';
export const EXPERIENCES_SECTION = 'experience';
export const FORMATION_SECTION = 'formation';
export const OTHER_INFO_SECTION = 'other';
export const SEABED_SECTION = 'seabed';
