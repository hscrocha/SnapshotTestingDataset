export const CENTER = 'center';
export const LEFT = 'left';
export const ON_THE_LEFT = 'on_the_left';
export const ON_THE_RIGHT = 'on_the_right';
export const RIGHT = 'right';
