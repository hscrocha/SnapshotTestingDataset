export const APP_LANGUAGES = {
  es: 'Español',
  pt: 'Português',
  fr: 'Français',
  en: 'English'
};
