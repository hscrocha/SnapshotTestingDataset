import { createSerializer } from './create-serializer';

export = createSerializer();
