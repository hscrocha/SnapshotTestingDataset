// prettier.config.js or .prettierrc.js
module.exports = {
  trailingComma: 'all',
  arrowParens: 'always',
  singleQuote: true,
  jsxSingleQuote: false,
  bracketSpacing: false,
};
