// export same wrapper as Gatsby Browser
export { wrapRootElement } from "./gatsby-browser"
