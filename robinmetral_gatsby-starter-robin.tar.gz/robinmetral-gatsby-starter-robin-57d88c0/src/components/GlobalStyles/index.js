import GlobalStyles from "./GlobalStyles"

export default GlobalStyles
