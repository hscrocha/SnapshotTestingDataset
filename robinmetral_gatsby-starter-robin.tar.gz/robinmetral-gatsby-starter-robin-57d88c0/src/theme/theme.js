export default {
  colors: {
    primary: "rebeccapurple",
    white: "white",
  },
  sizes: ["1.0875rem", "1.45rem"],
  space: ["960px"],
}
