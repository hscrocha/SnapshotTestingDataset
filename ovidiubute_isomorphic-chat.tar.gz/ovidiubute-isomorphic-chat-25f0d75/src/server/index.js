require("regenerator-runtime/runtime");
require("babel-register");

// Start backend
require("./app");
