import React from 'react'
import { Input } from 'monki-ui'
import 'monki-ui/dist/index.css'

export default () => (
  <div>
    <Input placeholder="disabled" disabled />
  </div>
)
