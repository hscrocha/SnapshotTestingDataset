import Tag from './tag'

export default Tag
