import React from 'react'
import { Button } from 'monki-ui'
import 'monki-ui/dist/index.css'

export default () => (
  <div>
    <Button type="primary" block>
      主按钮
    </Button>
  </div>
)
