## category

words

## titles

Open Graph Protocol
OGP

## description

SNS でそのウェブページをシェアした際に表示される HTML 要素  
OGP で表示するタイトル、説明文、画像などは事前に設定しておくことができる  
これを設定しておかないと SNS 側で自動的に画像や文が設定されるので、意図しないものになる可能性がある
