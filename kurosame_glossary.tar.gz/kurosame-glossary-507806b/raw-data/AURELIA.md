## category

language

## titles

Aurelia

## description

Angular の元開発者の Rob Eisenberg 氏によって作成された  
ES2015+および TypeScript  
Web Components を使う
