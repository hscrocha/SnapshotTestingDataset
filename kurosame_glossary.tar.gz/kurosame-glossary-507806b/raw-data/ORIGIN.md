## category

words

## titles

Origin
オリジン

## description

スキーム、ホスト、ドメイン、ポートをまとめてオリジンと呼ぶ

`https://www.example.co.jp:8080`

|          |               |
| -------- | ------------- |
| スキーム | https         |
| ホスト   | www           |
| ドメイン | example.co.jp |
| ポート   | 8080          |

`https://example.co.jp:8080`

|          |               |
| -------- | ------------- |
| スキーム | https         |
| ホスト   | 無し          |
| ドメイン | example.co.jp |
| ポート   | 8080          |
