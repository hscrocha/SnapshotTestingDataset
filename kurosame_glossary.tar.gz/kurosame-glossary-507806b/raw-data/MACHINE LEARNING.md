## category

ml

## titles

Machine Learning
機械学習

## description

<a href="https://gist.github.com/kurosame/b74ea51c7c4516ad57c062fa611d97ea" target="_blank">scikit-learn と TensorFlow による実践機械学習 - scikit-learn 編</a>
