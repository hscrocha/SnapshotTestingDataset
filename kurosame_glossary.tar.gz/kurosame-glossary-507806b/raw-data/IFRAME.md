## category

html

## titles

iframe
インラインフレーム

## description

`src`属性で別ページの URL を指定し、インラインでそのコンテンツを埋め込むことができる
