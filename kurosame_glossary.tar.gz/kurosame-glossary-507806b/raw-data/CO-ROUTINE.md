## category

programming

## titles

Co-routine
コルーチン

## description

C# や Kotlin などのいくつかのプログラミング言語に備わっている機能  
処理を中断した後、任意のタイミングで処理を再開できる
