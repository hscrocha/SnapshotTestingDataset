## category

server

## titles

Apache HTTP Server

## description

マルチスレッドモデル、マルチスレッドモデルが多い  
Event MPM でイベント駆動化できるが、クライアントとのネットワーク I/O のみ  
画面入力などのパラメーターで画面上のコンテンツを動的に変える動的コンテンツが得意  
Web サービスに特化した機能が豊富
