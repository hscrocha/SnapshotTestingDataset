## category

words

## titles

Request for Comments
RFC

## description

IETF によるインターネットで利用される技術の標準化や運用に関する事項などの保存・公開形式  
インターネットの利用者・開発者向けに広く公開すべきであろう情報を公開するためのシステム  
全ての RFC はインターネット上に公開されており、誰でも閲覧可能
