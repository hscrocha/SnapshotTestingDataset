## category

words

## titles

Extract Transform Load
ETL

## description

業務システムの膨大な雑多なデータソースを`Extract（抽出） -> Transform（変換） -> Load（書き出す）`処理を行い、時系列やカテゴリ別などに整理されたデータベース（データウェアハウス）にまとめる
