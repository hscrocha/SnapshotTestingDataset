## category

go

## titles

Go
Golang

## description

<a href="https://kurosame-th.hatenadiary.com/entry/2019/05/21/174811" target="_blank">Go と VS Code の快適な開発環境を考える</a>

## シングルバイナリ

Go でコンパイルするとシングルバイナリ（バイナリ単体で実行できるファイル）が生成される

## クロスコンパイル

macOS、Windows、Linux 向けのバイナリファイルを生成したい場合、コマンドベースで生成できるようにサポートしている
