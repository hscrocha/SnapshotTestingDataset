## category

browser

## titles

Web Worker

## description

画面のレンダリングを大幅にブロックするような処理をマルチスレッドでバックグラウンドのスレッドで実行することができる  
DOM にはアクセス不可能

<a href="https://qiita.com/kurosame/items/7a03b2a45e9cbe6ac9c6" target="_blank">Vuex のアクションの処理を Web Worker にやらせる</a>

### WorkerDOM

Web Worker から DOM を利用できるようになる  
現在（2018/12/26）は α 版
