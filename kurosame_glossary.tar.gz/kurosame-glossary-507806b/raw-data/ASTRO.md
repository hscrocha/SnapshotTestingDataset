## category

js

## titles

Astro

## description

静的サイトビルダー（静的サイトジェネレーター）

- React、Svelte、Vue.js、Preact などをサポート
- TypeScript や Markdown などをサポート
- ビルドツールは Vite を使っている
