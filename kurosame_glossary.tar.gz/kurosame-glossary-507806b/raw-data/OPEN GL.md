## category

hardware

## titles

OpenGL
WebGL

## description

### OpenGL

3D グラフィックを高速に描画できる API

### WebGL

OpenGL を JavaScript に移植したもの
