## category

react

## titles

Expo

## description

ReactNative でのアプリ開発を支援するサービス  
Expo の create-react-native-app 等の CLI でインストールする

ビルドするとターミナル上に QR コードが出る  
デバイスで QR コードを読み取ればケーブルに繋がなくても実機確認ができる
