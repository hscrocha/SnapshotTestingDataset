## category

vue

## titles

vue-component-compiler
@vue/component-compiler

## description

バンドラーに依存しない SFC 専用のコンパイラ
