## category

js

## titles

Storybook

## description

コンポーネント指向言語の開発環境  
storiesOf 上でコンポーネントを呼び出せばコンポーネント単体で動かすことが可能  
アドオンを使った便利機能の追加なども可能  
現在、React, React Native, Vue.js, Angular, Ember が対応されている
