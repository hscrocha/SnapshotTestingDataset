## category

html

## titles

Canvas

## description

HTML5 から追加された canvas タグ  
図形を描くために使われる  
JS で Canvas のコンテキスト（現状 2D のみ）を取得し、用意された関数を使って描画する
