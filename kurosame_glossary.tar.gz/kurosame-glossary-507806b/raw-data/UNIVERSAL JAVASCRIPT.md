## category

js

## titles

Universal JavaScript
Isomorphic JavaScript
アイソモーフィック

## description

### Isomorphic JavaScript

SSR(+SPA)構成でクライアントとサーバで同じコードを共有すること  
SSR -> 初期表示速い / ページ遷移遅い  
SPA -> 初期表示遅い / ページ遷移速い

### Universal JavaScript

クライアントとサーバで同じコードを共有し、さらにアプリなどでも実行できること
