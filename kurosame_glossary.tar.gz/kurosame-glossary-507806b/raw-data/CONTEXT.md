## category

words

## titles

Context
コンテキスト

## description

システム全体で使う制御情報
