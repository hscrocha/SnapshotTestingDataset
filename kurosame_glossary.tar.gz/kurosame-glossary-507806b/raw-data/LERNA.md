## category

package-manager

## titles

Lerna

## description

Monorepo を簡単にできるようにしたツール  
babel 開発者の Sebastian McKenzie が作成した

- Monorepo の依存パッケージの一括インストール
- 重複パッケージを親ディレクトリに一括インストールして共有できる（hoisting）
- Monorepo で管理しているパッケージの npm-scripts を一括実行できる（同じコマンド名なら）
