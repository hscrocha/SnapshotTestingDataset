## category

words

## titles

Web Accessibility
Web アクセシビリティ

## description

特定の環境に依存せず、多くの環境から Web を利用できる  
1 人でも多くのユーザが利用できるようにサポートする
