## category

words

## titles

JSON Web Token
JWT

## description

認証トークンなどで利用される  
ヘッダー・ペイロード・署名の 3 つから構成されており、それぞれ`.`（ドット）区切りで連結され、Base64 でエンコードされている
