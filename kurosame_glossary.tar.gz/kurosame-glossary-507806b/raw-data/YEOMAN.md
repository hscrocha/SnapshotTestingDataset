## category

package-manager

## titles

Yeoman
ヨーマン

## description

Google が開発

以下の 3 つの機能を統合したワークフローを提供する

1.  スキャフォールディングツール（yo）
1.  ビルドツール（Gulp, Grunt）
1.  パッケージ管理ツール（npm, Bower）

以下の流れで使う

1.  yo でプロジェクトを作成
1.  npm, Bower でパッケージ管理
1.  Gulp, Grunt でビルド&テスト
