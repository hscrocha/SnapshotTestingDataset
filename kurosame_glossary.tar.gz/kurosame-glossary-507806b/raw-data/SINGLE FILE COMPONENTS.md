## category

programming

## titles

Single File Components
SFC

## description

HTML, CSS, JS を 1 つのファイルに纏めて記述する  
Vue.js の場合、そのファイルの拡張子は`.vue`
