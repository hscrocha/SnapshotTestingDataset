## category

aws

## titles

AWS AppSync

## description

GraphQL を使った完全マネージド型サービス

<a href="https://zenn.dev/kurosame/scraps/747df781b69b54" target="_blank">AppSync の使用感を確認</a>
