## category

monitoring

## titles

Datadog

## description

<a href="https://zenn.dev/kurosame/articles/482601fa0f422df9390d" target="_blank">Datadog を利用したブラウザのエラー収集</a>

<a href="https://kurosame-th.hatenadiary.com/entry/2020/11/10/102431" target="_blank">レガシーな CoffeeScript で書かれた hubot に Datadog 監視を導入する</a>
