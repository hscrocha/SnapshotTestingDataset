## category

words

## titles

High(Low)-level Programming Language
高（低）水準言語

## description

### 高水準言語

人間の言葉に近い言語  
普段書いてる言語はほとんどこっち

### 低水準言語

コンピュータの言葉に近い言語  
機械語やアセンブリ言語
