## category

words

## titles

Hosting
ホスティング

## description

日本で言うレンタルサーバ  
Web ページを Firebase などへホスティングして運用する
