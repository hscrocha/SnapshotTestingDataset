## category

package-manager

## titles

Yarn Workspaces

## description

yarn が Monorepo をサポートして使えるようになった  
Lerna みたいなやつ
