## category

firebase

## titles

Firebase Realtime Database

## description

NoSQL データベース  
データを 1 つの JSON ツリーとして保存する

そのうち上位互換の Cloud Firestore に取って代わられるだろう

### 特徴

- 性能は Cloud Firestore が上
- iOS, Android のみのオフラインサポート
- スケールしたい場合は、複数のインスタンスにデータをシャーディングする必要がある
