## category

compiler

## titles

BuckleScript
バックル

## description

OCaml のコードを JavaScript のコードに変換するコンパイラ  
TypeScript と比べて 10 倍高速にコードをコンパイルできるらしい

### OCaml オーキャムル

かつては Objective Caml という名称であり、その省略呼びが OCaml だった  
現在は OCaml という名称で正式に改名された

OCaml は関数型言語 ML をプログラミング言語に発展させたもので型推論のある強い静的型付けされた言語である
