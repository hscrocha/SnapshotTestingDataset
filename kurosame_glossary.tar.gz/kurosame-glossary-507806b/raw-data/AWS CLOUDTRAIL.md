## category

aws

## titles

AWS CloudTrail

## description

AWS 全体のアクティビティログを参照できる  
イベント履歴からフィルタリングしてログを追える
