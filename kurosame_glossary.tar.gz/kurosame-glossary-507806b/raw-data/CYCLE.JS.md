## category

language

## titles

Cycle.js

## description

2014 年 11 月に誕生  
RxJS のコミッターの André Staltz 氏が作成

アプリケーションの状態を管理するアプリケーション層（main 関数）と副作用を扱うドライバー層（driver 関数）に分けている  
main 関数は引数を Observable で受け取り、加工して driver 関数に渡す  
driver 関数では DOM の描画や HTTP 通信など副作用のある処理をカプセル化している

VirtualDOM と RxJS を使っている
