## category

programming

## titles

receiver
レシーバ

## description

オブジェクト A で定義されている関数を呼び出そうとした時、オブジェクト A のことをレシーバと呼ぶ

```js
A.func()
```
