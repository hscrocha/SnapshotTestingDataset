## category

words

## titles

ストリーム処理

## description

永続的に発生するデータ（無限）を処理する技術  
それに対してバッチ処理は、保存済みデータ（有限）を処理対象とする
