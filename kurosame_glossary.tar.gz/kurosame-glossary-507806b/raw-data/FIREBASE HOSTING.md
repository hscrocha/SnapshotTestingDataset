## category

firebase

## titles

Firebase Hosting

## description

SSL と HTTP/2 に対応している  
カスタムドメインも無料で設定可能

Firebase CLI の`firebase deploy`コマンドで Firebase のホスティングサーバーにデプロイできる
