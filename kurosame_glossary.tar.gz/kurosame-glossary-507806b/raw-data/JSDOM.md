## category

js

## titles

jsdom

## description

Node.js 環境で仮想的な DOM を構築できる  
単体テストでよく使われる
