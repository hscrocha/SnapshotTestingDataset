## category

words

## titles

User Agent
ユーザーエージェント

## description

ユーザーが使用している OS やブラウザが設定されている  
サイト側は User Agent を取得でき、アクセス分析などに利用することができる  
ただし、ユーザーエージェントは利用者が偽装することもできるので、信頼性は低い
