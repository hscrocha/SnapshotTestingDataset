## category

server

## titles

Heroku
ヘロク

## description

PaaS  
2010 年に Salesforce に買収された  
でも今は Firebase 使えばいいかなって思った
