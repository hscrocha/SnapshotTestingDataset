## category

programming

## titles

Metaprogramming
メタプログラミング

## description

他のプログラムを入力とするプログラムのこと  
例えば、プログラムを入力として、Doc の作成やコードフォーマットやエラーチェックなどを行うプログラムを書くなど
