## category

package-manager

## titles

Monorepo

## description

複数の npm パッケージを単一の git リポジトリで管理すること

たとえば babel だと以下のように複数パッケージが 1 つのリポジトリで管理されている  
<a href="https://github.com/babel/babel/tree/master/packages" target="_blank">babel/packages</a>
