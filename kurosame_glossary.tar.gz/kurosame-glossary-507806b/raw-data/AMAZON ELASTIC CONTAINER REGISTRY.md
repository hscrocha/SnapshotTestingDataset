## category

aws

## titles

Amazon Elastic Container Registry
Elastic Container Registry
ECR

## description

Docker のコンテナイメージを保存できるレジストリ  
Docker Hub 的なサービス  
AWS を使っている場合は、他の AWS サービスとの統合が簡単になるので、Docker Hub より ECR を使った方が良い
