## category

architecture

## titles

Pub/Sub メッセージングモデル

## description

- Pub(Publish)  
  メッセージを作成して送信する側  
  トピックに向けてメッセージを送信する

- Sub(Subscribe)  
  メッセージを受信する側  
  トピックを購読しておく
