## category

ci

## titles

Dagger

## description

すべてのアクションを Docker 上で実行する  
Docker が動く環境（CircleCI や GitHub Actions など）であれば同じように動かせる

メリットは以下

- CircleCI や GitHub Actions など、特定の CI/CD ベンダーに依存しない
- 動作確認で CI に push する必要がないので、ローカルでの確認が可能になる
