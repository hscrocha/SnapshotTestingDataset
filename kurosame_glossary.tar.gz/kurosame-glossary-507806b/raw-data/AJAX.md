## category

js

## titles

Ajax
Asynchronous JavaScript XML

## description

XMLHttpRequest を使って非同期通信をする技術  
Vue.js の場合、Ajax を直接扱う方法はサポートしておらず、axios などの Ajax リクエストを Promise ベースで扱えるライブラリを用いて使用することが多い
