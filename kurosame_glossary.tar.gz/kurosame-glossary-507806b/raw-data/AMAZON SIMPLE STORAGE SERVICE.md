## category

aws

## titles

Amazon Simple Storage Service
Amazon S3
S3

## description

クラウドストレージ上にデータを保管できる  
容量無制限で安価  
指定期間過ぎたオブジェクトを削除するなどのライフサイクルのルールを設定可能
