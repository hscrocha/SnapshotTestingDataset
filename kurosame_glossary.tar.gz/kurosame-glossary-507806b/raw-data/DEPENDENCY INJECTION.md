## category

programming

## titles

Dependency Injection
DI
依存性注入

## description

### 依存性

クラスや関数が状態をもっていること  
その状態にクラスや関数が依存している

### DI

その状態を外から渡すこと

### メリット

- テストがしやすい
- 柔軟性が高い
