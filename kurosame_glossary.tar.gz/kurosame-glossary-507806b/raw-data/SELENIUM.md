## category

browser

## titles

Selenium

## description

クロスブラウザでブラウザの操作を自動化するためのツール  
当初は UI テストを自動化する目的で開発された  
主に UI テスト、E2E テスト、Web スクレイピングなどで利用される
