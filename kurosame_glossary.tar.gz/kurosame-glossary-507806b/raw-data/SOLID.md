## category

language

## titles

Solid
SolidJS

## description

- JSX 記法をサポート
- 仮想 DOM を持たない
- コンポーネントは再レンダリングされない
  - コンポーネント全体は 1 回だけレンダリングされ、hooks や effect のみが再実行されることでコンポーネントの更新を実現する
- ビルダーは Vite
