## category

browser

## titles

Web Real-Time Communication
WebRTC

## description

ブラウザでリアルタイムコミュニケーションを実現するための仕組み  
ビデオや音声、データをブラウザ間でやり取り可能にする規格（ビデオ音声チャット的な）  
WebSocket と違いサーバレス

ブラウザ間の通信で P2P 方式を採用している  
通信は暗号化されている
