## category

language

## titles

Flutter

## description

ReactNative の Dart 版みたいな  
ただし、UI 周りは独自 API を提供しているため、その API で要件を満たせない場合は他を検討した方が良い  
（ちなみに ReactNative の場合は、ネイティブ依存）

<a href="https://kurosame-th.hatenadiary.com/entry/2020/03/18/203259" target="_blank">Flutter の環境構築</a>

<a href="https://gist.github.com/kurosame/857f01201ef6934348000bde926a4692" target="_blank">Flutter/Dart コードメモ</a>
