## category

language

## titles

Clojure

## description

動的型付けの関数型プログラミング言語  
Scala や Kotlin などと同様に JVM で動作する  
Lisp 系の言語

### ClojureScript

Clojure を JavaScript にコンパイルする
