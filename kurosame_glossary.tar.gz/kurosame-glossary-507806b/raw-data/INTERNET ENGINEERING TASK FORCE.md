## category

words

## titles

Internet Engineering Task Force
IETF

## description

インターネットで利用される技術の標準化を策定する組織
