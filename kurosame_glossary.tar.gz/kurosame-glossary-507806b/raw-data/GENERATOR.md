## category

programming

## titles

Generator

## description

任意の時点で処理を中断/再開することができる関数
