## category

package-manager

## titles

Bower

## description

フロントエンド専用のパッケージ管理ツール

現在は非推奨となった  
<a href="https://github.com/bower/bower/pull/2458" target="_blank">Add yarn and webpack recommendation from bower.io to readme Fixes</a>
