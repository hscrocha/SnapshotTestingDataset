## category

language

## titles

Elm

## description

Haskell ライクの関数型リアクティブプログラミング（FRP）言語  
1 つのソースからコンパイル時に HTML/CSS/Javascript を生成する
