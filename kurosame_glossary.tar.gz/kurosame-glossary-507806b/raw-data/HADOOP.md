## category

apache

## titles

Hadoop

## description

Apache Hadoop  
テキスト、画像、ログなどの構造化されていないデータを高速に処理できる  
複数のマシンを使って、分散処理を行っている  
複数マシン間のプロセスの通信や監視などは Hadoop へ任せることができる
