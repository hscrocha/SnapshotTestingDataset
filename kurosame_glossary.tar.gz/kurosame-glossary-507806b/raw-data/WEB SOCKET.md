## category

browser

## titles

WebSocket

## description

クライアントとサーバ間に単一で永続的で双方向な通信を可能にする  
DOM にアクセス可能
