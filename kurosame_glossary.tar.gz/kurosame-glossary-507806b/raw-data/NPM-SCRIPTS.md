## category

package-manager

## titles

npm
npm-scripts

## description

### `npm run コマンド名`のエイリアスで`npm コマンド名`として使えるもの

start, stop, restart, test

### publish

npm レジストリに公開

### pack

指定したパッケージを tgz に圧縮  
使う時は install で tgz ファイルを指定すれば良い

### version [patch, minor, major]

指定したパッケージのバージョンを上げる

### pre, post

各コマンドの Prefix に付けると、コマンド前後にフックできる
