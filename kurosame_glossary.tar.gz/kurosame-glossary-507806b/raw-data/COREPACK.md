## category

package-manager

## titles

Corepack

## description

npm や Yarn などのパッケージマネージャーを管理するツール  
Node.js v16.9.0 で Corepack が標準バンドルされた

npm は Node.js に標準バンドルされているが、npm 以外のパッケージマネージャーである Yarn などは別途インストールが必要だった  
Corepack により、利用者が事前にパッケージマネージャーをインストールしておくという手間が省ける  
npm だけ特別扱いだったが、他のパッケージマネージャーも npm と同等に扱えるようにしたいという意図があるらしい

現状（2021 年 9 月）はまだ Experimental な機能
