## category

programming

## titles

Polymorphism
ポリモーフィズム

## description

### オーバーロード

同じ関数名で引数の異なる関数を複数定義すること

### オーバーライド

親クラスから継承した関数を同じ関数名で再定義すること
