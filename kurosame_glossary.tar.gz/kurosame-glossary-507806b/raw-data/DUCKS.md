## category

react

## titles

Ducks
Redux

## description

Redux のデザインパターン  
Action や Reducer を modules にパッケージする

vuejs-boilerplate でも使ってる気がする  
1 ファイルにはしてないけど、actions, getters, mutations, state を import して modules でパッケージして export してる  
そして Store 作るときに modules をセットしている
