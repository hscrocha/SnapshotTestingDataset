## category

words

## titles

Semantics
セマンティクス

## description

シンタックス（構文）と対になる言葉  
そのプログラムの意図や目的
