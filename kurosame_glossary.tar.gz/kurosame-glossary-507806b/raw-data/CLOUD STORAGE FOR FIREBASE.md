## category

firebase

## titles

Cloud Storage for Firebase
Cloud Storage

## description

クラウドストレージ上にデータを保管できる  
格納先は Google Cloud Storage  
GUI 上でファイルアップロードやフォルダー作成ができる  
同一ファイル名のファイルをアップロードした場合は上書き保存する

料金は保存しているデータ量、ダウンロードデータ量、アップロード回数、ダウンロード回数によって決まる
