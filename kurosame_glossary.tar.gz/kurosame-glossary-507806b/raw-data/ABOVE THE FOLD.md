## category

words

## titles

Above the fold
ATF
First View
ファーストビュー

## description

スクロールしないで最初に見えるページの範囲  
Google はこの範囲のコンテンツを 1 秒以下で表示するように提案している  
ATF 領域を優先的にレンダリングして、スクロールしないと見えない領域は Lazy Load するのが良い
