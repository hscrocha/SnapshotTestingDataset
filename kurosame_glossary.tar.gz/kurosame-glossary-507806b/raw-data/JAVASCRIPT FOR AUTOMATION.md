## category

js

## titles

JavaScript for Automation
JXA

## description

Mac を Script で操作するのに AppleScript が用いられていたが、Yosemite から JavaScript が使えるようになった  
Mac を制御・操作する JavaScript を JXA という
