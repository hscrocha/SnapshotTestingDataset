## category

programming

## titles

Higher-Order Components
HOC

## description

コンポーネントを引数にして、機能追加などの加工をしたコンポーネントを返す関数  
つまりコンポーネントをラップしたコンポーネント

高階関数（Higher-Order Function）（関数を引数、戻り値として扱う関数）のコンポーネント版
