## category

db

## titles

Supabase

## description

BaaS  
Firebase の代替を謳っているが、Firebase の機能はあまり網羅していない  
（Database、Authentication、Storage、Edge Functions のみ（2022/09））

- Database は Postgres ベースの RDB
  - Firebase は NoSQL ベース
- 料金は無料枠があり、従量課金はない
  - Firebase は Functions を使う場合、ほぼ強制的に従量課金プランになる
  - 枠を超えた利用を行いたい場合は追加料金になる
