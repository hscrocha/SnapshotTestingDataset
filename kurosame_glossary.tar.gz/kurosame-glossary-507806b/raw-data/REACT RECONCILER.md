## category

react

## titles

React Reconciler
react-reconciler

## description

VDOM と呼ばれている部分

1. ReactElement のツリーを構築
1. Component をマウント、アンマウント、更新
1. ライフサイクル関数を呼出す
1. 現在の DOM との差分を計算する
1. renderer に差分を伝える
