## category

react

## titles

Blitz

## description

React ベースのフルスタックフレームワーク  
Next.js 上に構築されている  
React 向けの Ruby on Rails を目指す構想で開発されている
