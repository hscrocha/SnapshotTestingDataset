## category

js

## titles

Incremental Static Regeneration
ISR

## description

一定期間ごとにサーバーサイドレンダリングを行う  
サーバーサイドレンダリングの結果はキャッシュする  
リクエストしたユーザーには常にキャッシュしていた HTML を返す

リクエスト時に最新の情報でない可能性がある  
SSG したいが、更新頻度が高いページなどは ISR が使える可能性はある
