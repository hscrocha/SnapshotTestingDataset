## category

build

## titles

Poi

## description

egoist さん作の開発環境構築不要のビルドツール  
React, Preact, Vue に対応している  
エントリーポイントとなる index.js などを用意して、以下コマンドで実行すると動く

```sh
npx poi index.js
```
