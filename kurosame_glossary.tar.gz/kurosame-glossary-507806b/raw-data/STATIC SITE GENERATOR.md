## category

js

## titles

Static Site Generator
SSG

## description

ビルド時に HTML を生成する  
外部 API からのデータ取得も可能  
キャッシュが作りやすい

更新頻度が高いページには向かない
