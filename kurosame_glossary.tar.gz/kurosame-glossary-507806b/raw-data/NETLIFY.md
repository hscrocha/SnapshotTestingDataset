## category

server

## titles

Netlify

## description

ホスティングサービス  
静的なサイトを高速で提供する  
GitHub Pages や Firebase Hosting と同じレイヤー

カスタムドメインを設定可能  
リポジトリから webhook を受けると、自動でリポジトリの pull、ビルド、デプロイを行う  
HTTPS, HTTP/2 をサポート

<a href="https://qiita.com/kurosame/items/7b5fd3cbf1f688b47e88" target="_blank">Netlify Functions を使って CORS エラーを回避する</a>
