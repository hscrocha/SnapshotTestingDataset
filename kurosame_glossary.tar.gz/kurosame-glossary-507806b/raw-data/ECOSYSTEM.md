## category

words

## titles

Ecosystem
エコシステム

## description

特定の言語やツールやライブラリをサポートする環境  
Vue.js であれば、webpack や ESLint などの周辺技術が Vue.js 用のサポートをしていることや  
テストやルーティング周りで良いライブラリが作られていることがエコシステムが充実していると言える
