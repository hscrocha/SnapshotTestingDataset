## category

mobile

## titles

Hybrid Application
ハイブリッドアプリケーション

## description

アプリを Web 技術を使って作成する技術  
動作はネイティブより遅いし、ネイティブアプリの UI 周りは独自実装は必要そう

### Ionic アイオニック

Apache Cordova を拡張して作られている（Cordova もハイブリッドアプリ開発フレームワーク）  
Angular を使って開発する

### Onsen UI

Angular に加えて、React や Vue.js にも対応している
