## category

scala

## titles

doobie

## description

### SQL インジェクション

doobie は基本的に SQL に渡されたパラメーターをすべてエスケープしてくれるが、`Fragment.const`に関してはエスケープ処理を行わない
