## category

language

## titles

Dart

## description

Google によって開発された Web 向けプログラミング言語  
JavaScript に替わるプログラミング言語として開発されていたが、現在はトランスパイル言語の 1 つという立ち位置になっている  
当初はすべてのブラウザに DartVM を載せて、JavaScript の代わりに Dart を動かそうとしていた

<a href="https://gist.github.com/kurosame/857f01201ef6934348000bde926a4692" target="_blank">Flutter/Dart コードメモ</a>
