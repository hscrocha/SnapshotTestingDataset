
const VictoryChart = "VictoryChart";
const VictoryAxis = "VictoryAxis";
const VictoryLine = "VictoryLine";
const VictoryScatter = "VictoryScatter";
const VictoryArea = "VictoryArea";

export {
  VictoryChart,
  VictoryAxis,
  VictoryLine,
  VictoryScatter,
  VictoryArea,
};
