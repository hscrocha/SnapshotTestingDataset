import { StyleSheet } from "aphrodite";

export default StyleSheet.create({
  right: {
    ":hover": {
      opacity: 0.8,
    },
  },
});
