
import SmallButton from "./SmallButton";

export { SmallButton };

export default { SmallButton };
