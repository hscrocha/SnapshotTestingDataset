
export default "Label";
