
import Spinner from "./Spinner";

const Loading = () => (
  <Spinner />
);

export default Loading;
