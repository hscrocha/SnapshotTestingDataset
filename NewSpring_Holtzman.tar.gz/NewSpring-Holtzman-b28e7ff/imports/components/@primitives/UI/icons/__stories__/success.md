## Success Icon

### Usage

```js
import Error from "../../components/icons/Success";

<Success />
```

### Purpose

This is currently being used to communicate to the user when a successful action has occurred. This is typically used within giving or account creation.
