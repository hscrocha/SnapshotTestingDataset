## Accounts Icons

### Purpose

This is currently designed to be used to show users which type of card issuer or payment type they are using during giving.
