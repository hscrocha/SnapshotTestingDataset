## Error Icon

### Usage

```js
import Error from "../../components/icons/Error";

<Error />
```

### Purpose

This is currently being used to communicate to the user when an error has occurred. This is typically used within giving or account creation.
