
import Progress from "./Progress";
import ProgressStep from "./ProgressStep";

export { Progress, ProgressStep };

export default { Progress, ProgressStep };
