
// import Audio from "./audio"
import Video from "./video/index";

export default Video;
