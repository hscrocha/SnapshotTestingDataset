import { StyleSheet } from "aphrodite";

export default StyleSheet.create({
  offset: {
    "@media screen and (min-width: 481px)": {
      marginLeft: "80px",
    },
  },
});
