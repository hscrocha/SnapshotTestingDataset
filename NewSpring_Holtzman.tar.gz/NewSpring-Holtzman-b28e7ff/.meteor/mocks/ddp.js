
export const DDP = {
  _CurrentInvocation: {
    get: jest.fn(() => {}),
  },
}
