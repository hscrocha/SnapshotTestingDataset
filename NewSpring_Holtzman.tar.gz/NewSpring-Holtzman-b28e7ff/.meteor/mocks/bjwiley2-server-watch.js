const serverWatch = {
  isAlive: jest.fn(),
}

export { serverWatch };
