

const Accounts = {
  _storedLoginToken: jest.fn(),
  forgotPassword: jest.fn(),
}

export { Accounts };
