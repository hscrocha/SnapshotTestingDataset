---

# QA Platform Checklist

- [ ] iOS
- [ ] Android
- [ ] Kindle
- [ ] Web
