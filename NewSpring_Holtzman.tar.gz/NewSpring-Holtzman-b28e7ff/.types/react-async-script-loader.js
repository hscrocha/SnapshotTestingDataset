declare module "react-async-script-loader" {
  declare var exports: any;
}
