declare module cordova {
  declare var platformId: string;
}

declare var cordova: $Exports<'cordova'>;
