declare module "meteor/bjwiley2:server-watch" {
  declare var exports: any;
}
