declare module "react-router" {
  declare function Link(to: Object, className: string): Function;
  declare function withRouter(component: Object): Function;
  declare function withRouter(): Function;
}
