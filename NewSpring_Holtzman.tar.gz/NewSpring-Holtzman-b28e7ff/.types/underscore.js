declare module underscore {
  declare function sortBy(arr: Object[], filter: string): Object[];
}
