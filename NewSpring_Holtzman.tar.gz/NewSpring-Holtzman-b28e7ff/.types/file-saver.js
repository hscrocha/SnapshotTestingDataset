declare module "file-saver" {
  declare var exports: any;
}
