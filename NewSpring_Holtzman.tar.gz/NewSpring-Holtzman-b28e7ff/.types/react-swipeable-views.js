declare module "react-swipeable-views" {
  declare var exports: any;
}
