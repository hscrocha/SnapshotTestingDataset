declare module "striptags" {
  declare var exports: any;
}