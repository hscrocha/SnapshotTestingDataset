// XXX Custom type def to enable flow for HtmlElements
declare class FormElement extends HTMLElement {
  reset(): void;
}
