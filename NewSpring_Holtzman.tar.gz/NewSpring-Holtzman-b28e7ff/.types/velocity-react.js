declare module "velocity-react" {
  declare var exports: any;
}