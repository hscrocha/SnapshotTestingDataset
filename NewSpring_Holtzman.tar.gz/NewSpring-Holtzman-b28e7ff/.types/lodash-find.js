declare module "lodash.find" {
  declare function find(): Object;
  declare var exports : typeof find;
}
