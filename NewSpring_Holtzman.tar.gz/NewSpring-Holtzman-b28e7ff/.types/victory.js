declare module "victory" {
  declare var exports: any;
}