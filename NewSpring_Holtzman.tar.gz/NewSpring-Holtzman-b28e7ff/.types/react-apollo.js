declare module "react-apollo" {
  declare function graphql(query: Object, options: Object): Function;
}
