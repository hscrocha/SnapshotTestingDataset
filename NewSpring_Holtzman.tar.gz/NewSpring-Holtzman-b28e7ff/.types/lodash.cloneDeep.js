declare module "lodash.clonedeep" {
  declare function cloneDeep<T>(value: T): T;
  declare var exports : typeof cloneDeep;
}
