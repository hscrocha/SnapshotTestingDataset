declare module "styled-components" {
  declare var exports: any;
}