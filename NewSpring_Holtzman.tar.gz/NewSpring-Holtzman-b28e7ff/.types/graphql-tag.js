declare module "graphql-tag" {
  declare var exports: any;
}
