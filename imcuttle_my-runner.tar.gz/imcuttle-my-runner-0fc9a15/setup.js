/**
 * @file setup
 * @author imcuttle <moyuyc95@gmail.com>
 * @date 2019/6/30
 *
 */

// process.env.DEBUG = 'my-runner'
