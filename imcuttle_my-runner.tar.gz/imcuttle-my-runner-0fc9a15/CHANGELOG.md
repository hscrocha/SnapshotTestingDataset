<a name="3.0.0"></a>

# [3.0.0](https://github.com/imcuttle/my-runner/compare/v2.0.0...v3.0.0) (2020-09-27)

<a name="2.0.0"></a>

# [2.0.0](https://github.com/imcuttle/my-runner/compare/v1.0.11...v2.0.0) (2020-03-13)

### Bug Fixes

- mutable-global ([cd1022c](https://github.com/imcuttle/my-runner/commit/cd1022c))

<a name="1.0.11"></a>

## [1.0.11](https://github.com/imcuttle/my-runner/compare/v1.0.10...v1.0.11) (2019-07-09)

<a name="1.0.10"></a>

## [1.0.10](https://github.com/imcuttle/my-runner/compare/v1.0.9...v1.0.10) (2019-07-04)

<a name="1.0.9"></a>

## [1.0.9](https://github.com/imcuttle/my-runner/compare/v1.0.8...v1.0.9) (2019-07-03)

### Features

- exports moduleMain & moduleCache ([4471d83](https://github.com/imcuttle/my-runner/commit/4471d83))

<a name="1.0.8"></a>

## [1.0.8](https://github.com/imcuttle/my-runner/compare/v1.0.7...v1.0.8) (2019-07-03)

<a name="1.0.7"></a>

## [1.0.7](https://github.com/imcuttle/my-runner/compare/v1.0.6...v1.0.7) (2019-07-03)

<a name="1.0.6"></a>

## [1.0.6](https://github.com/imcuttle/my-runner/compare/v1.0.5...v1.0.6) (2019-07-03)

### Features

- support NODE_PATH ([d9ef8fc](https://github.com/imcuttle/my-runner/commit/d9ef8fc))

<a name="1.0.5"></a>

## [1.0.5](https://github.com/imcuttle/my-runner/compare/v1.0.4...v1.0.5) (2019-07-03)

<a name="1.0.4"></a>

## [1.0.4](https://github.com/imcuttle/my-runner/compare/v1.0.3...v1.0.4) (2019-07-02)

<a name="1.0.3"></a>

## [1.0.3](https://github.com/imcuttle/my-runner/compare/v1.0.2...v1.0.3) (2019-07-02)

<a name="1.0.2"></a>

## [1.0.2](https://github.com/imcuttle/my-runner/compare/v1.0.1...v1.0.2) (2019-07-02)

<a name="1.0.1"></a>

## 1.0.1 (2019-07-02)
