/**
 * @file main
 * @author imcuttle
 * @date 2018/4/4
 */
const myRunner = require('../')

describe('myRunner', function() {
  it('should', function(done) {
    done()
  })
})
