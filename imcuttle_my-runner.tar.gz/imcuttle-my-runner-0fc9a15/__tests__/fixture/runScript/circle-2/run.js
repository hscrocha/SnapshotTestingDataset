/**
 * @file run
 * @author imcuttle <moyuyc95@gmail.com>
 * @date 2019/7/1
 *
 */
const { runFile } = require('../../../../index')

runFile(__dirname + '/1.js')
