/**
 * @file index
 * @author imcuttle <moyuyc95@gmail.com>
 * @date 2019/7/2
 *
 */

setTimeout(() => {
  module.exports = 'async'
})
