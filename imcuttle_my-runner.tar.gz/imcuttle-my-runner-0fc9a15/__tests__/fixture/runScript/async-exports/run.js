/**
 * @file run
 * @author imcuttle <moyuyc95@gmail.com>
 * @date 2019/7/2
 *
 */
const fn = require('./index')

setTimeout(() => {
  console.log(fn())
}, 100)
