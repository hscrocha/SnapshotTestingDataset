/**
 * @file index
 * @author imcuttle <moyuyc95@gmail.com>
 * @date 2019/6/25
 *
 */

module.exports = 'b'
