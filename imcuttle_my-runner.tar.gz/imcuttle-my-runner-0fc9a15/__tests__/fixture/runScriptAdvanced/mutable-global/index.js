/**
 * @file index
 * @author imcuttle <moyuyc95@gmail.com>
 * @date 2019/6/25
 *
 */

global._i = () => {}

module.exports = require('./a')
