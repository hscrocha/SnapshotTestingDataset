import { ButtonProps } from '.'

export const ButtonMock: ButtonProps = {
  children: <span>Salvar</span>,
  disabled: false,
  typeStyle: 'enter'
}
