import styled from 'styled-components'
import Card from '@/components/Card'

export const CardComponent = styled(Card)``
