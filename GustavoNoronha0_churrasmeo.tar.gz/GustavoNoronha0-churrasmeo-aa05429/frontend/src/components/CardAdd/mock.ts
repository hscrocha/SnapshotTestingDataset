import { CardAddProps } from '.'

export const CardAddMock: CardAddProps = {
  onClick: () => undefined
}
