export interface RemoveBarbecue {
  remove: (id: string) => Promise<number>
}
