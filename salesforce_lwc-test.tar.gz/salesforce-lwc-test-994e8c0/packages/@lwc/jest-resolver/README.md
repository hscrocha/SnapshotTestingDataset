# @lwc/jest-resolver

Resolves all supported `lwc-*` imports.
