## @lwc/jest-shared

Shared internal code for LWC Jest packages.

Note that you should probably not be using this package directly! Likely, you should use `@lwc/jest-preset` instead.
