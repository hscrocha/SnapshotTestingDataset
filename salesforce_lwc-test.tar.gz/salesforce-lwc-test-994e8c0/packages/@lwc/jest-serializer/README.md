## @lwc/jest-serializer

Standarize snapshots for Shadow DOM.
