import { LightningElement, api } from 'lwc';

export default class extends LightningElement {
    @api foo = "fooTS"
}
