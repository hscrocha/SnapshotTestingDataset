/**
 * Cypress support file
 *
 * This file is loaded automatically before your test files.
 *
 * @link shttps://on.cypress.io/configuration
 */
import './commands';
import './screenshots';

export default {};
