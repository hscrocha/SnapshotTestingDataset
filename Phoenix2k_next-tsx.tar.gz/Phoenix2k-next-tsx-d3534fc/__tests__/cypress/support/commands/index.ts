/// <reference types="../" />
/**
 * Custom commands
 *
 * This example commands.js shows you how to create various custom commands and overwrite
 * existing commands.
 *
 * @link https://on.cypress.io/custom-commands
 */
import './itemprop';
