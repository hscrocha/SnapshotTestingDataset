import sitemap from '../../data/sitemap.json';
import { Pages } from './types';

const pages: Pages = sitemap;

export default pages;
