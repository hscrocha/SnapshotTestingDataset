# Index page

This is the main page of the application.

Local address: <http://localhost:3000>
