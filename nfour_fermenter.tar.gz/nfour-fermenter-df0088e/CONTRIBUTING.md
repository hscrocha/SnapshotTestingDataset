# Contributing

## Tests

`yarn test`

## Build

`yarn build`
