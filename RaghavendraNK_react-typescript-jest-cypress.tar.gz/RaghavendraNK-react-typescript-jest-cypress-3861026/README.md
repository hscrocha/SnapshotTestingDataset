# react-typescript-jest-cypress

1.React<br/> 2. Jest<br/> 3. Enzyme, Sinon and Chai<br/> 4. Cypress<br/> 5. Istanbul code coverage<br/> 6. Typescript<br/> 7. Sass<br/> 8. Storybook<br/> 9. Docker<br/> 10. Jenkins<br/> 11. Lintings (Eslint, SassLint) and Prettier<br/> 12. Pre-commit hooks using husky<br/> 13. React-router-dom<br/> 14. Figma<br/> 15. Redux<br/> 16. i18n<br/> 17. nodeJS with express<br/> 18.mongoDB<br/>

https://raghavendrank.medium.com/reactapp-typescript-with-tdd-and-bdd-jest-enzyme-sinon-and-cypress-linting-and-pre-commit-2ae549ca815 <br/>
https://raghavendrank.medium.com/mern-with-docker-container-setup-part-2-93cf34912445 <br/>
https://www.npmjs.com/package/slick-react-ui-components
