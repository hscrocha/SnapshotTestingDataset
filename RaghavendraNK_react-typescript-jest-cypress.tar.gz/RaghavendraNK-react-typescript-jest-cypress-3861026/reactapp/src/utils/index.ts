export const language = ['en'];
export const setlanguage = 'en';
