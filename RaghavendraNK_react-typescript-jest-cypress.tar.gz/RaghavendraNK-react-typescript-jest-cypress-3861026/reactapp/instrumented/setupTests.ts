function cov_1nrbe6xq6y() {
    var path =
        '/home/raghavendra/Documents/Github/react-typescript-jest-cypress/src/setupTests.ts';
    var hash = '61624976bc4c0f3268a508313704a486eff5dc1d';
    var global = new Function('return this')();
    var gcv = '__coverage__';
    var coverageData = {
        path:
            '/home/raghavendra/Documents/Github/react-typescript-jest-cypress/src/setupTests.ts',
        statementMap: {},
        fnMap: {},
        branchMap: {},
        s: {},
        f: {},
        b: {},
        _coverageSchema: '1a1c01bbd47fc00a2c39e90264f33305004495a9',
        hash: '61624976bc4c0f3268a508313704a486eff5dc1d',
    };
    var coverage = global[gcv] || (global[gcv] = {});

    if (!coverage[path] || coverage[path].hash !== hash) {
        coverage[path] = coverageData;
    }

    var actualCoverage = coverage[path];
    {
        // @ts-ignore
        cov_1nrbe6xq6y = function () {
            return actualCoverage;
        };
    }
    return actualCoverage;
}

cov_1nrbe6xq6y();
// jest-dom adds custom jest matchers for asserting on DOM nodes.
// allows you to do things like:
// expect(element).toHaveTextContent(/react/i)
// learn more: https://github.com/testing-library/jest-dom
import '@testing-library/jest-dom';
//# sourceMappingURL=data:application/json;charset=utf-8;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbInNldHVwVGVzdHMudHMiXSwibmFtZXMiOltdLCJtYXBwaW5ncyI6Ijs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7O0FBZVk7Ozs7Ozs7OztBQWZaO0FBQ0E7QUFDQTtBQUNBO0FBQ0EsT0FBTywyQkFBUCIsInNvdXJjZXNDb250ZW50IjpbIi8vIGplc3QtZG9tIGFkZHMgY3VzdG9tIGplc3QgbWF0Y2hlcnMgZm9yIGFzc2VydGluZyBvbiBET00gbm9kZXMuXG4vLyBhbGxvd3MgeW91IHRvIGRvIHRoaW5ncyBsaWtlOlxuLy8gZXhwZWN0KGVsZW1lbnQpLnRvSGF2ZVRleHRDb250ZW50KC9yZWFjdC9pKVxuLy8gbGVhcm4gbW9yZTogaHR0cHM6Ly9naXRodWIuY29tL3Rlc3RpbmctbGlicmFyeS9qZXN0LWRvbVxuaW1wb3J0ICdAdGVzdGluZy1saWJyYXJ5L2plc3QtZG9tJztcbiJdfQ==
