import React from 'react';
import './App.scss';

function App() {
    return <div className="App">Welcome!</div>;
}

export default App;
