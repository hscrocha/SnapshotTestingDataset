React Jest, Enzyme, Sinon, and Chai Cypress Typescript & node-sass Storybook Docker Jenkins Lintings along with pre-commit hooks using husky Istanbul code coverage React-router-dom
