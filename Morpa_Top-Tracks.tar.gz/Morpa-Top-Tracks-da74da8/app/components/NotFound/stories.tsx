import { Story, Meta } from '@storybook/react/types-6-0'
import { NotFound } from '.'

export default {
  title: 'NotFound',
  component: NotFound
} as Meta

export const Default: Story = () => <NotFound />
