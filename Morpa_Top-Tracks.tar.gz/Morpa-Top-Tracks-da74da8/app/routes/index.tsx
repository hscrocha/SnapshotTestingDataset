import { Base } from '~/templates/Base'
import { Home } from '~/templates/Home'

export default function () {
  return (
    <Base>
      <Home />
    </Base>
  )
}
