import '@testing-library/jest-dom'
import 'jest-styled-components'
import react from 'react'

global.React = react
