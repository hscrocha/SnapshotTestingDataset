<h1 align="center">Top Tracks</h1>

<p align="center">
  <img alt="Made by" src="https://img.shields.io/badge/made%20by-Morpa%20-%2356BEB8">

  <img alt="GitHub last commit" src="https://img.shields.io/github/last-commit/morpa/Top-Tracks.svg?color=56BEB8">

  <img alt="Code size" src="https://img.shields.io/github/languages/code-size/morpa/Top-Tracks.svg?color=56BEB8">

  <img alt="Github top language" src="https://img.shields.io/github/languages/top/Morpa/Top-Tracks?color=56BEB8">

  <img alt="Github language count" src="https://img.shields.io/github/languages/count/Morpa/Top-Tracks?color=56BEB8">

  <img alt="Repository size" src="https://img.shields.io/github/repo-size/Morpa/Top-Tracks?color=56BEB8">

</p>

## What is inside?

This project uses lot of stuff as:

- [TypeScript](https://www.typescriptlang.org/)
- [Remix](https://remix.run/)
- [Styled Components](https://styled-components.com/)
- [Jest](https://jestjs.io/)
- [React Testing Library](https://testing-library.com/docs/react-testing-library/intro)
- [Storybook](https://storybook.js.org/)
- [Eslint](https://eslint.org/)
- [Prettier](https://prettier.io/)
- [Husky](https://github.com/typicode/husky)
