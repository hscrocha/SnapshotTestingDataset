const Custom404 = () => <div>404 Page not Found</div>;

export default Custom404;
