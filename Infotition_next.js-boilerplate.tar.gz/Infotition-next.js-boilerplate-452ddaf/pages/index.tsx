import Default from '@layout/Default/Default';
import HomePage from '@template/HomePage/HomePage';

const App = () => (
  <Default>
    <HomePage />
  </Default>
);

export default App;
