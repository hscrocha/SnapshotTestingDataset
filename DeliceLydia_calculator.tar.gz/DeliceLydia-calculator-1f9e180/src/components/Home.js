const Home = () => (
  <div className="homepage">
    <h1>Welcome to our calculator app</h1>
    <p>
      This is a calculator app where users will be able to perform mathematic
      operations by using 4 mathematical operations: Addition, Subtraction,
      Multiplication, Division .
    </p>
  </div>
);

export default Home;
