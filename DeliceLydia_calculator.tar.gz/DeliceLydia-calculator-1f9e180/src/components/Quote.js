const Quote = () => (
  <p className="quote">
    Math may not teach us how to add love, or substract hate,
    but it gives us hope that every problem has a solution.
  </p>
);

export default Quote;
