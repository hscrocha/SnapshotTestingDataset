<template lang="pug">
	app-page
		.container.dsp__flex.pad__sml.w_max__reg
			h1 Page not found
</template>

<script>
import AppPage from '../molecules/AppPage.vue';

export default {
	components: { AppPage },
};
</script>
