declare const glamorSerializer: jest.SnapshotSerializerPlugin

export default glamorSerializer
