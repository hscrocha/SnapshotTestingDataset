export type ApplicationState = {
  readonly text: string
}

export const initialAppState: ApplicationState = {
  text: '# initial headline 2',
}
