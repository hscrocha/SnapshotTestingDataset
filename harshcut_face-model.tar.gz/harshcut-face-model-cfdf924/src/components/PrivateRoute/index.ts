import PrivateRoute from "./PrivateRoute";

export default PrivateRoute;
