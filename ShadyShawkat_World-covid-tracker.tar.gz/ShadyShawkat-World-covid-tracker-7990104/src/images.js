import africa from './Assets/Images/Africa.png';
import australia from './Assets/Images/Australia-Oceania.png';
import northAmerica from './Assets/Images/North America.png';
import southAmerica from './Assets/Images/South America.png';
import asia from './Assets/Images/Asia.png';
import europe from './Assets/Images/Europe.png';

export default {
  Africa: africa,
  'Australia-Oceania': australia,
  'North America': northAmerica,
  'South America': southAmerica,
  Asia: asia,
  Europe: europe,
};
