module.exports = {
  content: ['./src/**/*.{js,jsx,ts,tsx}'],
  theme: {
    extend: {
      colors: {
        'blue-dark': '#35548B',
      },
    },
  },
  plugins: [],
};
