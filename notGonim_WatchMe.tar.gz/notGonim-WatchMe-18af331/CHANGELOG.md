# Changelog

All notable changes to this project will be documented in this file. See [standard-version](https://github.com/conventional-changelog/standard-version) for commit guidelines.

### [0.1.25](https://github.com/notGonim/WatchMe/compare/v0.1.24...v0.1.25) (2021-07-01)

### [0.1.24](https://github.com/notGonim/WatchMe/compare/v0.1.23...v0.1.24) (2021-07-01)

### [0.1.23](https://github.com/notGonim/WatchMe/compare/v0.1.22...v0.1.23) (2021-07-01)

### [0.1.22](https://github.com/notGonim/WatchMe/compare/v0.1.21...v0.1.22) (2021-06-30)

### [0.1.21](https://github.com/notGonim/WatchMe/compare/v0.1.20...v0.1.21) (2021-06-29)

### [0.1.20](https://github.com/notGonim/WatchMe/compare/v0.1.19...v0.1.20) (2021-06-28)

### [0.1.19](https://github.com/notGonim/WatchMe/compare/v0.1.18...v0.1.19) (2021-06-28)

### [0.1.18](https://github.com/notGonim/WatchMe/compare/v0.1.17...v0.1.18) (2021-06-28)

### [0.1.17](https://github.com/notGonim/WatchMe/compare/v0.1.16...v0.1.17) (2021-06-26)

### [0.1.16](https://github.com/notGonim/WatchMe/compare/v0.1.15...v0.1.16) (2021-06-26)

### [0.1.15](https://github.com/notGonim/WatchMe/compare/v0.1.14...v0.1.15) (2021-06-21)

### [0.1.14](https://github.com/notGonim/WatchMe/compare/v0.1.13...v0.1.14) (2021-06-20)

### [0.1.13](https://github.com/notGonim/WatchMe/compare/v0.1.12...v0.1.13) (2021-06-19)

### [0.1.12](https://github.com/notGonim/WatchMe/compare/v0.1.11...v0.1.12) (2021-06-19)

### [0.1.11](https://github.com/notGonim/WatchMe/compare/v0.1.10...v0.1.11) (2021-06-19)

### [0.1.10](https://github.com/notGonim/WatchMe/compare/v0.1.9...v0.1.10) (2021-06-18)

### [0.1.9](https://github.com/notGonim/WatchMe/compare/v0.1.8...v0.1.9) (2021-06-18)

### [0.1.8](https://github.com/notGonim/WatchMe/compare/v0.1.7...v0.1.8) (2021-06-18)


### Features

* form ([727757e](https://github.com/notGonim/WatchMe/commit/727757eea84842bac6fe4c64fb5ded3f83c5b412))

### [0.1.7](https://github.com/notGonim/WatchMe/compare/v0.1.6...v0.1.7) (2021-06-17)

### [0.1.6](https://github.com/notGonim/WatchMe/compare/v0.1.5...v0.1.6) (2021-06-17)


### Features

* FAQs ([2abfb3d](https://github.com/notGonim/WatchMe/commit/2abfb3de8ec5a550471f1a9cfe6370dfaf8b9244))

### [0.1.5](https://github.com/notGonim/WatchMe/compare/v0.1.4...v0.1.5) (2021-06-17)


### Features

* Jumbotron ([6e79c97](https://github.com/notGonim/WatchMe/commit/6e79c970f3a503e15cbb516a58dfa524ac42aa60))

### [0.1.4](https://github.com/notGonim/WatchMe/compare/v0.1.3...v0.1.4) (2021-06-16)

### [0.1.3](https://github.com/notGonim/WatchMe/compare/v0.1.2...v0.1.3) (2021-06-16)

### [0.1.2](https://github.com/notGonim/WatchMe/compare/v0.1.1...v0.1.2) (2021-06-16)

### 0.1.1 (2021-06-16)
