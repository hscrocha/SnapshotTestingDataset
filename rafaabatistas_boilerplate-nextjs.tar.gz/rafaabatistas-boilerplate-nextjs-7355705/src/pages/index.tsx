import HomeSection from '~templates/HomeSection/HomeSection';

export default function Home() {
  return <HomeSection />;
}
