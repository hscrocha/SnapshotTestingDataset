# flofun-app
React native app using `expo`, `react-navigation`, `jest`, `redux`, `react-native-elements`

### Flower Selection
<img src="/assets/selectFlowers.gif?raw=true">

### SMS code login
![sms](https://d26dzxoao6i3hh.cloudfront.net/items/1o462P0d1b3k16243v1M/sms.gif)

### Address Lookup using Google Maps reverse geocoding
![googlemap](https://d26dzxoao6i3hh.cloudfront.net/items/2V1S2C0p040M3F270k2G/directions.gif)
