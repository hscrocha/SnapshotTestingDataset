export default {
  blackColor: 'black',
  whiteColor: '#fff',
  grayBackground: '#DDDDDD',
  grayColor: '#4B586E',
  purpleColor: '#574E6D',
  purpleDarkColor: '#43405D',
  greenColor: '#428B46',
  quantityColor: '#f4efff',
}
