export const fetchFlowers = () => [
  { title: 'flower 1', image: 'img1', price: 30 },
  { title: 'flower 2', image: 'img2', price: 40 },
  { title: 'flower 3', image: 'img3', price: 50 },
]
