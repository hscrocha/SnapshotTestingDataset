export default {
  API_URL: '',
  facebookAppId: '',
  googleTokenAndroid: '',
  googleTokenIos: '',
}
