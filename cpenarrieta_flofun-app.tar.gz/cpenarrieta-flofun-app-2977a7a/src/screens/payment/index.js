import PaymentScreen from './PaymentScreen'

export { PaymentScreen }
