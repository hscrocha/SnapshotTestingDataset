import ContactDetailsScreen from './ContactDetailsScreen'
import ContactDetailsReducer from './reducer'

export { ContactDetailsScreen, ContactDetailsReducer }
