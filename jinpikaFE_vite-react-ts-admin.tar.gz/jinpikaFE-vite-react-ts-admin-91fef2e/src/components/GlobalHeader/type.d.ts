export type AvatarDropdownPropsType = {
  onMenuClick?: () => void;
  menu?: any
}