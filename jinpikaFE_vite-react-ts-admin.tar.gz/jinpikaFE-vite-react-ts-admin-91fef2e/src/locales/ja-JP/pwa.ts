export default {
  'app.pwa.offline': 'あなたは今オフラインです',
  'app.pwa.serviceworker.updated': '新しいコンテンツが利用可能です',
  'app.pwa.serviceworker.updated.hint':
    '現在のページをリロードするには、「更新」ボタンを押してください',
  'app.pwa.serviceworker.updated.ok': 'リフレッシュ',
};
