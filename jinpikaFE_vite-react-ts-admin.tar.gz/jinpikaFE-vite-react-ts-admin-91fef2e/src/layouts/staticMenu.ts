export const staticMenu = [
  {
    _id: '61639a54ec93bb0b6a96f500',
    name: 'welcome',
    path: '/home',
    icon: 'icon-home',
    status: 1,
    isLink: 0,
    registerTime: '2021-10-11T01:58:44.807Z',
    color: '#181717',
  },
];
