export type FormRoleType = {
  _id: string;
  name: string;
  authority: string[]
}