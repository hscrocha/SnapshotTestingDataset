export type FormUserType = {
  _id: string;
  userName: string;
  email: string;
  phone: string;
  password: string;
  role: string;
  captcha: string;
  avatar?: any
}