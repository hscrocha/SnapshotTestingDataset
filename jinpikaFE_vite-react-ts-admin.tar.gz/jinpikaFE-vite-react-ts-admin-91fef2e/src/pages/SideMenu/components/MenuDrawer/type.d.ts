export type MenuDrawerProps = {
  onCloseDrawer: () => void;
  visibleDrawer: boolean;
};
