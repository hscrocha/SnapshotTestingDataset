export const CUSTOMOPTIONS = {
  diet: '饮食',
  shop: '购物',
  transport: '交通',
};
