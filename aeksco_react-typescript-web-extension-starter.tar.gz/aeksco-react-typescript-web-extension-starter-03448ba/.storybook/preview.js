// Import global app.css file
import "../src/css/app.css";
