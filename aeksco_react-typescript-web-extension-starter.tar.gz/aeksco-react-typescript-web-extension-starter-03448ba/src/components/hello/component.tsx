import React from "react";

// // // //

export function Hello() {
    return (
        <div className="row">
            <div className="col-lg-12 text-center">
                <p className="lead mb-0">Example Extension</p>
            </div>
        </div>
    );
}
