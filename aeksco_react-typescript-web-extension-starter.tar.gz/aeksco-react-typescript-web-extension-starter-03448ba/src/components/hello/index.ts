export { Hello } from "./component";
