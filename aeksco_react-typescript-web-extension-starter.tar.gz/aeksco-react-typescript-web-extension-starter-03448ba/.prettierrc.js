module.exports = {
    semi: true,
    trailingComma: "all",
    singleQuote: false,
    tabWidth: 4,
};
