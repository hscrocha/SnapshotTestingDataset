import React from 'react';

const Loading = () => (
  <div className="loader-container">
    <div className="loader" />
  </div>
);

export default Loading;
