module.exports = {
  files: "**/*.{mdx}",
  native: true,
  typescript: true
};
