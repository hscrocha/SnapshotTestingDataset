/* tslint:disable */
/* eslint-disable */
// @generated
// This file was automatically generated and should not be edited.

// ====================================================
// GraphQL query operation: CurrentConferenceWeek
// ====================================================

export interface CurrentConferenceWeek_currentConferenceWeek {
  __typename: "ConferenceWeek";
  start: any;
  end: any;
  calendarWeek: number;
}

export interface CurrentConferenceWeek {
  currentConferenceWeek: CurrentConferenceWeek_currentConferenceWeek;
}
