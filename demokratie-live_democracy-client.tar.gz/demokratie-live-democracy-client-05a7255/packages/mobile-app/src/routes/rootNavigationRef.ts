import React from 'react';
import { NavigationContainerRef } from '@react-navigation/core';

export const rootNavigationRef = React.createRef<NavigationContainerRef>();
