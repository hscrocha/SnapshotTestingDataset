module.exports = {
  root: true,
  rules: {}
};
