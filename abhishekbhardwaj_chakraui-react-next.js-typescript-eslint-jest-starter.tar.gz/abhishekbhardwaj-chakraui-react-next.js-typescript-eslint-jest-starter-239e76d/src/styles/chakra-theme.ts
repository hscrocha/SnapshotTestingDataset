import { extendTheme } from '@chakra-ui/react'

export default extendTheme({
  // add appropriate properties here
})
