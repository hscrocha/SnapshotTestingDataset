console.log('utilities');

const functionOne = () => "hello world";
const functionTwo = () => "hello world";

export { functionOne as default, functionTwo }