import functionOne, { functionTwo } from './utilities';


console.log(functionOne());