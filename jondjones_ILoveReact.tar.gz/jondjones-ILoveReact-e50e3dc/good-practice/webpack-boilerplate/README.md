# Boilerplate WEbpack Project

Clone this to get started with a vanilla webpack based project

## Quick Start

```bash
npm dev-server
npm live-server
```