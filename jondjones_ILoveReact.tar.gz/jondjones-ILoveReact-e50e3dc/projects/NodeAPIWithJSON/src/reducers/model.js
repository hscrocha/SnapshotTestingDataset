const data = {};

export const model = (state = data, action) => {
    return state;
};
