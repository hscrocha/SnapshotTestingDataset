
# Test

Only did limiting tests on the API to ensure it returned the correct data
No integration tests, would have used cypress

# CSS

Rushed the css a bit.  It uses css grid and has the basics, with more time I would make it look nicer.  Would have maybe used postcss to make sure it was ie compatible.  Assuming CSS Grid is OK

There was no url returned in the supplied .json so the links do not point anywhere

# Code

Would have added eslint file to automat the code

Lay loaded the results would be nice

Dealing with missing server images

# API

CORS not locked down very securely.  Better approach would be to add a token and pass it back from the app


