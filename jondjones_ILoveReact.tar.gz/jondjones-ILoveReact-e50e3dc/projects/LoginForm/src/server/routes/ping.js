export default function ping(req, res) {
    res.sendStatus(200);
}
