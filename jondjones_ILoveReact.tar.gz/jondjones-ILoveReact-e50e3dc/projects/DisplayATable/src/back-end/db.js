import { variant } from './db/variant';
import { columns } from './db/columns'

export { variant, columns };
