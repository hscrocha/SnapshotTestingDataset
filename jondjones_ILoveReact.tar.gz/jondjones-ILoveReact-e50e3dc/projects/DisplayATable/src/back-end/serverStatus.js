export const serverStatus = {
  OK: 200,
  INTERNAL_SERVER_ERROR: 500,
  UNAUTHORIZED: 401
};

export default serverStatus;
