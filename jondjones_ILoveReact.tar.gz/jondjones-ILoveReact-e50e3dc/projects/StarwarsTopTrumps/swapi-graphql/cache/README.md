SWAPI Cache
=============

This module contains a cache of SWAPI obtained using `npm run download`.
