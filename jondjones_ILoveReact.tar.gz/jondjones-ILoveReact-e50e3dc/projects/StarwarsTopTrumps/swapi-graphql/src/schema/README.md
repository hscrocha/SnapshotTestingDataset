SWAPI GraphQL Schema
====================

This module exposes a `GraphQLSchema` that provides access to SWAPI.
