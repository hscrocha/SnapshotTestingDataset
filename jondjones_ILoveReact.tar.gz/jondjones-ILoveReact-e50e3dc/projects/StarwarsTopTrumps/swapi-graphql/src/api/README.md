SWAPI Wrapper
=============

The module exposes `getFromLocalUrl`, a method that takes a SWAPI URL and returns our local copy of the result.
