import React from 'react';

export const LoadingComponent = () => <div>LOADING</div>;

export const ErrorComponent = () => <div>ERROR</div>;