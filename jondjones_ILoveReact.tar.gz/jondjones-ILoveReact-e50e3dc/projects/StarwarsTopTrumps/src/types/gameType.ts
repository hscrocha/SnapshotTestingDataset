enum GameType {
    Character,
    Spaceship
}

export default GameType