enum GameStatus {
    Fighting,
    PlayerWin,
    MonsterWin,
}

export default GameStatus