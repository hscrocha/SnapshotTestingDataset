import React from 'react'
import ReactDOM from 'react-dom'

const ContactPage = () => (
    <div>
      Contact Page
    </div>
)

export default ContactPage;