import React from 'react'
import ReactDOM from 'react-dom'

const NotFoundPage = () => (
    <div>
        404 Page
    </div>
)

export default NotFoundPage;