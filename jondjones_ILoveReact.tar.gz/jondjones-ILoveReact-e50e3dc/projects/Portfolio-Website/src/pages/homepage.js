import React from 'react'
import ReactDOM from 'react-dom'

const Homepage = () => (
    <div>Homepage</div>
);

export default Homepage;