// SPDX-License-Identifier: MPL-2.0

import assert from 'node:assert/strict';
import test from 'asia';
import mod from '../src/index.js';

test('todo tests for @hela/cli package', async () => {
  assert.equal(typeof mod, 'function');
});
