// SPDX-License-Identifier: MPL-2.0

export * from '@hela/core';

// eslint-disable-next-line no-restricted-exports
export { default } from '@hela/core';
