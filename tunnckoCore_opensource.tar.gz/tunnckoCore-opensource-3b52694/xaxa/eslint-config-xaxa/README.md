# eslint-config-xaxa

Zero-config linting, Instant Fast. Powered by few amazing unicorns, AirBnB &
Prettier.

```
yarn add -D eslint-config-xaxa
```

eslint config

```json
{
  "eslintConfig": {
    "extends": ["xaxa"]
  }
}
```
