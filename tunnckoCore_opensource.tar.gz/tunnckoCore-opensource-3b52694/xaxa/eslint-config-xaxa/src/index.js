// SPDX-License-Identifier: Apache-2.0

/* eslint-disable unicorn/prefer-module */

const { getESLintConfig } = require('./main.js');

module.exports = getESLintConfig();
