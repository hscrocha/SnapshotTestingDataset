# xaxa

Zero-config linting, Instant Fast. Powered by few amazing unicorns, AirBnB &
Prettier.

```
xaxa --help
```

package.json

```json
{
  "scripts": {
    "lint": "xaxa"
  }
}
```
