export default async () => ({
  // disabling file caching, with just regular Map
  // tests: new Map(),
  foo: 1,
});
