const mod = require('../src');

test('todo tests for jest-runner-node package', async () => {
  expect(typeof mod).toStrictEqual('function');
});
