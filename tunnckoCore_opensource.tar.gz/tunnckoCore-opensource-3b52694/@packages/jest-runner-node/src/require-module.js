'use strict';

/* eslint-disable global-require, import/no-dynamic-require */
module.exports.require = (modPath) => require(modPath);
