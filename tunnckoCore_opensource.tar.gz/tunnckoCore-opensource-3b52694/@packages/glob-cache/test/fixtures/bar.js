export default () => 123;
