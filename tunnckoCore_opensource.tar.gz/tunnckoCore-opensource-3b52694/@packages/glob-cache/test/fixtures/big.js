import bar from './bar';

export const foo = bar();

export default foo;
