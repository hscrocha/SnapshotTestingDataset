module.exports = {
  runner: require.resolve('../../support/runner'),
  testMatch: ['**/__src__/**/*.js'],
};
