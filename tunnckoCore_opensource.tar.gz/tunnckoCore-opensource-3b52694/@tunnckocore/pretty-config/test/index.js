import mod from '../src/index.js';

test('todo tests for @tunnckocore/pretty-config package', async () => {
  expect(typeof mod).toStrictEqual('function');
});
