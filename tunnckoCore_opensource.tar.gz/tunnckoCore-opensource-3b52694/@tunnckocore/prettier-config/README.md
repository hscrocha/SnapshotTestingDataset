# @tunnckocore/prettier-config

> Shareable Prettier config for all @tunnckoCore projects

```
yarn add -D @tunnckocore/prettier-config
```

on your config:

```json
{
  "prettier": "@tunnckocore/prettier-config"
}
```
