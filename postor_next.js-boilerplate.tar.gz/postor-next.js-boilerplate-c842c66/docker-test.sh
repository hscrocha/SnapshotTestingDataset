npm run lint && npm run test
