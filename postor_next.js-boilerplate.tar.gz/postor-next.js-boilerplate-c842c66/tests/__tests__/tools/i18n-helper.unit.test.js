import helper from '../../../tools/i18n-helper'

describe('jwt-unit', () => {
  it('sign-verify', async () => {
    expect(helper.defaultLang).toBe('en')
  })
})