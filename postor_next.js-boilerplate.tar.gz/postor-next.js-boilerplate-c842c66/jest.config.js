module.exports = {
  setupFiles: ['<rootDir>/tests/jest.setup.js'],
  testPathIgnorePatterns: ['<rootDir>/.next/', '<rootDir>/node_modules/']
}