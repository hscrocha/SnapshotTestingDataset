import Layout from '../components/Layout.js'

const About = () => (
    <div>
        <p>This is the about page</p>
    </div>
)

export default Layout(About)