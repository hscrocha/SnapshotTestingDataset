const loginSubmit = {
  preventDefault: () => { },
  target: {
    elements: {
      userName: {
        value: ''
      }
    }
  }
};

export default loginSubmit;