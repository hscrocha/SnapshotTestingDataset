const rooms = [
  {
    name: 'Home Chat',
    password: null,
    users: ['John'],
    messages: []
  }
];

export default rooms;