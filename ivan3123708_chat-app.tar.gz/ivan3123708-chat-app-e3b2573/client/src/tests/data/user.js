const user = {
  id: '123',
  name: 'John',
  avatar: '/img/avatars/1.png',
  rooms: ['Home Chat']
};

export default user;