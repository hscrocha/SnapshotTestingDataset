const messageConsecutive = {
  text: 'How are you?',
  time: '20:31',
  consecutive: true
};

export default messageConsecutive;