const createRoomSubmit = {
  preventDefault: () => { },
  target: {
    elements: {
      roomName: {
        value: ''
      },
      password: {
        value: ''
      }
    }
  }
}

export default createRoomSubmit;