const messageConsecutive = {
  sender: {
    name: 'John',
    avatar: '/img/avatars/1.png'
  },
  text: 'Hello world!',
  time: '20:30',
  consecutive: false
};

export default messageConsecutive;