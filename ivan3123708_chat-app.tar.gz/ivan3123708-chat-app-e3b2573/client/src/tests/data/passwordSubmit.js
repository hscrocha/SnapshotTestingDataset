const passwordSubmit = {
  preventDefault: () => { },
  target: {
    elements: {
      password: {
        value: ''
      }
    }
  }
}

export default passwordSubmit;