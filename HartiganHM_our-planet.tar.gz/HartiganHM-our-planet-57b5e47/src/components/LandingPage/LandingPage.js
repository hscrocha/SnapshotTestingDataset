import React from 'react';

import './LandingPage.scss';

const LandingPage = () => (
  <div className="LandingPage">
    <div className="inner">
      <div className="content" />
    </div>
  </div>
);

export default LandingPage;
