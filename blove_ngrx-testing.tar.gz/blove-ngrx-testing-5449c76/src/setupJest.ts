import 'jest-preset-angular';
import './jestGlobalMocks';
