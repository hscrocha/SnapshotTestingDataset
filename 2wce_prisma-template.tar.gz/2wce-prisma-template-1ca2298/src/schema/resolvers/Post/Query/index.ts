import post from './post';
import posts from './posts';

export default {
  posts,
  post,
};
