import Mutation from './Mutation';

export default {
  Mutation,
};
