import me from './me';

export default {
  me,
};
