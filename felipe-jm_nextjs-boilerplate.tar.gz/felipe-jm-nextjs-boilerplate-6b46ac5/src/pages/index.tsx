import Main from 'components/Main';

const Home = () => <Main />;

export default Home;
