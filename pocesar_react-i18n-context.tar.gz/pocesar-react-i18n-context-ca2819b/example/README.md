# Example

* Run `npm i`
* After install, run `npm run start`
* Visit `http://localhost:1234` in your browser