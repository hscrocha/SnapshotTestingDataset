module.exports = {
  images: {
    domains: ['res.cloudinary.com'],
  },
  experimental: {
    outputStandalone: true,
  },
}