const ua = require('universal-analytics');

const analytics = ua('UA-145385834-1');

module.exports = analytics;
