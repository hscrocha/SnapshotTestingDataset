// @flow weak
import en from './en/translations.json';
import fr from './fr/translations.json';

const translations = {
  en,
  fr,
};

module.exports = translations;
