import { AppRegistry } from 'react-native';
import App from '<%= appName %>/src/App';

AppRegistry.registerComponent('<%= appName %>', () => App);
