import React from 'react';
import Scenes from './Scenes';

const App = () => <Scenes />;

export default App;
