# Adding linting

*Eslint ensures a consistent coding style. For React Native newcomers it will also help you in your path to learn it.*

*Prettier autoformats your code as you save. No more wasting time indenting, adding a missing comma or splitting lines*

Use `yo rn-toolbox:lint` to setup eslint-config-universe with prettier enabled.
