# Visual Studio Code Setup

*Sets up VSCode for ultimate productivity with React Native*

Use `yo rn-toolbox:vscode` to set it up
