module.exports = {
  ENV: '<%= environmentName %>',
};
