module.exports = {
  ENV: 'local',
};
