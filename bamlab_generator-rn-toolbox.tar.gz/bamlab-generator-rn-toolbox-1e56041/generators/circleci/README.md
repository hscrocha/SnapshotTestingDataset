# CircleCI setup for continuous integration

CircleCI is a widely used CI service for both web and mobile projects. After running this generator, pushing your code to CircleCI should result in a succesful build configured with dependency caching and good practices.
