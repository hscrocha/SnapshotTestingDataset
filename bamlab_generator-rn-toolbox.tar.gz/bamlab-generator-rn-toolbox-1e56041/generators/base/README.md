# Base Project setup

*Tired of the same empty initial app? Start with a real React Native Project*

Use `yo rn-toolbox:base` to replace the base project

**Features**
- Centralized App.js
- [react-navigation](https://github.com/react-community/react-navigation) 2 pages setup
- Custom header
- Custom button
- Centralized app style
- Page container
