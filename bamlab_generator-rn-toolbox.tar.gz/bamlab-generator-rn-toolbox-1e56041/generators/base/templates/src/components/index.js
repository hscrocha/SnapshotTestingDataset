// @flow

export { default as Page } from './Page';
