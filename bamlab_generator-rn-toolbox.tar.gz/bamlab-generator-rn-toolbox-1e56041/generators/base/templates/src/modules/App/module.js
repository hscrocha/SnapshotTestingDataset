// @flow

const initialState = {};

// ACTION TYPES
export const actionTypes = {};

// REDUCER
export function appReducer(state = initialState, action) {
  switch (action.type) {
    default:
      return state;
  }
}

// ACTION CREATORS
