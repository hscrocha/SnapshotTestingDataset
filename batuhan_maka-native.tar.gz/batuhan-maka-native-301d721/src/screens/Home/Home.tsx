import React from "react";
import { View, Text } from "react-native";

interface Props {}

export default function Home({  }: Props) {
  return (
    <View>
      <Text>Home</Text>
    </View>
  );
}
