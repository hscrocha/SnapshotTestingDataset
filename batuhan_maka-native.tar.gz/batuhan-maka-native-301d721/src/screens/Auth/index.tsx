import Login from "./Login";
import Register from "./Register";

export { Login, Register };
