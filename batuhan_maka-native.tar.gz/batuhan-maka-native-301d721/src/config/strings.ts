const strings = {
  LOGIN: "Log In",
  WELCOME_TO_LOGIN: "Welcome to the login screen!",
  EMAIL_PLACEHOLDER: "Email",
  PASSWORD_PLACEHOLDER: "Password",
  MOBILE_NUMBER_PLACEHOLDER: "Mobile Number",
  NAME_PLACEHOLDER: "Name",
  REGISTER: "Register",
  JOIN_HERE: "Join Here"
};

export default strings;
