const inAppConfig = {
  REGISTER_NUMBER_IS_REQUIRED: false,
  REGISTER_FULLNAME_IS_REQUIRED: true,
  MIN_PASSWORD_LENGTH: 8,
  MIN_FULLNAME_LENGTH: 8,
  COUNTRY_CODE: "tr",
  AUTH_STORAGE_NAME: "my-awesome-token"
};

export default inAppConfig;
