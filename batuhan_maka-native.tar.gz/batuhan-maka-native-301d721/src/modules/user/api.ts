const baseUrl = "blabla";

const getUser = () => {
  //call api
  const profile = {
    email: "xyz@gmail.com"
  };
  const idToken = "token";
  return {
    profile
  };
};

export { getUser };
