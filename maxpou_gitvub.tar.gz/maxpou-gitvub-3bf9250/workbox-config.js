module.exports = {
  'globDirectory': 'dist/',
  'swDest': 'dist/sw.js',
  'swSrc': 'src/sw.js'
}
