'use strict'
module.exports = {
  NODE_ENV: '"production"',
  GITHUB_URL: '"https://api.github.com"',
  GITHUB_CLIENTID: '"2c1a8680d4e497d52a52"',
  GITHUB_CLIENTSECRET: '"9c64d4b112a250806911ed8ba9c3a76e1afbfab2"'
}
