<template>
  <div class="mdl-grid">
    <div class="mdl-cell mdl-cell--2-col mdl-cell--hide-tablet mdl-cell--hide-phone" />
    <div
      id="overview"
      class="mdl-shadow--4dp content mdl-color-text--grey-800 mdl-cell mdl-cell--8-col">

      <h2>About</h2>

      <blockquote>GitVub = Git + Vue.js</blockquote>
      <ul>
        <li>
          <a href="https://vuejs.org/" rel="nofollow">Vue.js</a>: an awesome JS Framework</li>
        <li>
          <a href="https://vuex.vuejs.org/en/" rel="nofollow">Vuex</a>: A state management library for VueJs</li>
        <li>
          <a href="https://router.vuejs.org/en/" rel="nofollow">vue-router</a>: a routing library</li>
        <li>
          <a href="https://github.com/mzabriskie/axios">Axios</a>: a well known library for XMLHttpRequests</li>
        <li>
          <a href="https://facebook.github.io/jest/" rel="nofollow">Facebook/Jest</a>: a test library</li>
        <li>
          <a href="https://getmdl.io/" rel="nofollow">Material Design Lite</a>: CSS Framework</li>
        <li>
          <a href="https://material.io/icons/" rel="nofollow">Material Icons</a>: a set of icons</li>
        <li>
          <a href="https://developers.google.com/web/tools/workbox/next/" rel="nofollow">Workbox (v3)</a>: JavaScript libraries for Progressive Web Apps (PWA)</li>
      </ul>
      <p>... using the
        <a href="https://api.github.com/">GitHub Api</a> (
        <a href="https://developer.github.com/v3">doc</a>).</p>
      <p>Based on
        <a href="https://github.com/vuejs/vue-cli/blob/dev/docs/README.md#conventions">vue-cli 3</a> and follow his file structure/conventions.
      </p>
    </div>
  </div>
</template>

<style>
.content {
  border-radius: 2px;
  padding: 80px 56px;
  margin-bottom: 80px;
}
</style>
