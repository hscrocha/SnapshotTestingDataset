import * as Components from "./components";

export default Components;