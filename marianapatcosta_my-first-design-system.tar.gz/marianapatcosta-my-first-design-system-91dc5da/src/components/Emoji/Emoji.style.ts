import styled from 'styled-components';
import { baseStyles } from '../../styles';

export const StyledEmoji = styled.div`
  ${baseStyles}
  font-size: 90%;
`;
