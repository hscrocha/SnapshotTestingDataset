import Alert from './alert.svg';
import Chevron from './chevron.svg';
import Close from './close.svg';
import CloseWhite from './close-white.svg';
import DoubleChevron from './double-chevron.svg';
import Info from './info.svg';
import MagnifyingGlass from './magnifying-glass.svg';
import Success from './success.svg';
import Tick from './tick.svg';
import Warning from './warning.svg';

export {
  Alert,
  Chevron,
  Close,
  CloseWhite,
  DoubleChevron,
  Info,
  MagnifyingGlass,
  Success,
  Tick,
  Warning,
};
