# Expensify App

Is an app to keep your expenses in control, like a budget app but with different
kinds of filters. 
Amount, date and so on.

  
![screenshot](./app-screenshot.png) 

## Built With
- JavaScript
- React.Js
- Sass, CSS
- jsx

## Live Demo

[Live Demo Link](https://expensify-ceci-app.herokuapp.com/)

## Author
### Cecilia Benitez
- 👤 [GitHub](https://github.com/Ceci007)

## Show your support
Give a ⭐️ if you like this project

## Acknowledgments
- Inspiration
Appreciate Andrew Meat course on Udemy.
