/**
 * @author arman
 * @since 4/13/17
 *
 */

export const TOGGLE_SCANNING = 'toggle_scanning';
export const TOGGLE_TABLE_VIEW = 'toggle_table_view';
export const ADD_NEW_TRACK = 'Add_new_track';
export const UPDATE_PATH_LIST = 'add_path_list';
export const CLEAR_PATH_LIST = 'clear_path_list';
export const HANDLE_DIALOG_OPEN = 'handle_dialog_open';
export const HANDLE_DRAWER_OPEN = 'handle_drawer_open';
export const UPDATE_METADATA = 'update_metadata';
export const UPDATE_VIEW = 'update_view';
export const UPDATE_SEARCH_PATH = 'update_path_list';
export const CHANGE_CATEGORY = 'change_category';