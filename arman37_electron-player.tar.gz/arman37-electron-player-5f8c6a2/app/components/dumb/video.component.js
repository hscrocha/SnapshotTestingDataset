/**
 * @author arman
 * @since 12/31/2016
 *
 */

import React from 'react';

const Video = ({}) => {
  return (
    <div id="video" className="w3-container w3-animate-bottom table-view">
      <h2>Video List</h2>
    </div>
  )
};

export default Video;