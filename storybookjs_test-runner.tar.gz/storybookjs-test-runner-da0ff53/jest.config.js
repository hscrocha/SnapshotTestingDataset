module.exports = {
  testMatch: ['**/*.test.ts'],
};
