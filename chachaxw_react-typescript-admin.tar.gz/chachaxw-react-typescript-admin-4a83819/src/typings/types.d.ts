declare module 'dva-loading';
