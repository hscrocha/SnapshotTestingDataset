import { ApiUrl } from './ApiConfig';
import AxiosInstance from './AxiosInstance';

export class DashboardService {

}
