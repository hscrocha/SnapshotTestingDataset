// API url config
export const ApiUrl = {
  auth: '/auth',
  dashboard: '/dashboard',
};
