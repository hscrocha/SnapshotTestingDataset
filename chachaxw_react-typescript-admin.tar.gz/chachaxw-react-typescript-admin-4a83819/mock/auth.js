const faker = require('faker');
const Random = faker.random;

module.exports = function () {
  return {
    isAuthenticated: true,
  };
}
