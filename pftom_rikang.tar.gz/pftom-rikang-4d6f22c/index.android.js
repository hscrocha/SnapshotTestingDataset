global.__APP__ = true;
global.__ANDROID__ = true;
global.__IOS__ = false;
import './Root';