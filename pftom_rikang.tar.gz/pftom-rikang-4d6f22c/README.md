If you want to view the latest process of this project.You can clone this hub to your computer.
And then run the following script.

```
  git clone git@github.com:powerformer/rikang.git
  cd rikang
  npm install && react-native run-ios
  or yarn react-native run-ios
```

If you meet some errors.May be the following reasons.

* You don't have `npm` or `yarn` package manager

   so go [https://www.npmjs.com/](https://www.npmjs.com/) download `npm`

   or go [https://yarnpkg.com/zh-Hans/](https://yarnpkg.com/zh-Hans/) download `yarn`


* You don't have a `react-native-cli`.

   so go [https://facebook.github.io/react-native/](https://facebook.github.io/react-native/) and download this `cli`.

If you have any problems, please make a `Issue`.
