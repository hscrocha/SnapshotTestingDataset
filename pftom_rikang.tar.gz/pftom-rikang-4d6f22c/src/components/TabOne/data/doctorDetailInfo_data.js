export const titleMap = {
        specialty: '擅长及诊所介绍',
        background: '医学教育背景介绍',
        achievements: '学术研究成果、获奖介绍',
        motto: '医生寄语',
};