//descriminate jump
export const jumpScreen = {
  '寻找医生': 'DoctorList',
  '寻找医院': 'HospitalList',
  '我要提问': 'PutQuestion',
};