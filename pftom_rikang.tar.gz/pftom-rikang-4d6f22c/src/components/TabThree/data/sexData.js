const SEX = {
  U: '未选择',
  F: '女',
  M: '男',
};

const SEXMAP = {
  '未选择': 'U',
  '女': 'F',
  '男': 'M',
};

export {
  SEX,
  SEXMAP,
}