export const getToken = (state) => state.getIn(['auth', 'token']);
