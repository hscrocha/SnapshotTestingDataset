var moment = require('moment');

var now = new Date('Sun Aug 06 2017 09:37:25 GMT+0800 (CST)');

console.log(now.getFullYear());