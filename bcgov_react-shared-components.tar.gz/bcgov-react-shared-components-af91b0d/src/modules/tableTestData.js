const elements = [
  { name: "BCeID", value: "bobross42" },
  {
    name: "Last Name",
    value: "Ross",
  },
  { name: "First Name", value: "Bob" },
  { name: "Email Address", value: "bob.ross@example.com" },
];

export function getTableElementsTestData() {
  return elements;
}
