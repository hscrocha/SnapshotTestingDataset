module.exports = {
  preset: '@stencil/core/testing',
  globals: {
    jasmine: { getEnv: () => null },
  },
};
