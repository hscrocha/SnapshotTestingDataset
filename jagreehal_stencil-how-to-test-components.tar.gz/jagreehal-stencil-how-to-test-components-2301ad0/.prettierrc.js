module.exports = {
  semi: true,
  singleQuote: true
};
