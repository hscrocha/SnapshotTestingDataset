'use strict';



module.exports = {
    "require": ["./launchPuppeteerHook", "@testim/root-cause-mocha/rootHooks"],
    "reporter": "@testim/root-cause-mocha/reporter"
}
