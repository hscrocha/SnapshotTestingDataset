export const MOCHA_INTERMEDIATE_DIR = 'mocha_intermediate';
