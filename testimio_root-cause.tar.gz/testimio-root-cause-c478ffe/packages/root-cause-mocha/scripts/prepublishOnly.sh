set -ex

cp package.json ./dist/
cp README.md ./dist/
