'use strict';

module.exports = {
  preset: 'ts-jest',
  testMatch: ['**/integration.test.ts'],
};
