import initStoryshots from '@storybook/addon-storyshots';

describe.skip('snapshots not stable :(', () => {
  initStoryshots({
    /* configuration options */
  });
});
