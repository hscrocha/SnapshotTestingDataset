set -ex

cp package.json ./packageToPublish/
