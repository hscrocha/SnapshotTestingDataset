import reporter = require('@testim/root-cause-jest/lib/reporter/default');

module.exports = reporter;
