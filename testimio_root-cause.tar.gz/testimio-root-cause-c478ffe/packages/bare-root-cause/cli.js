#! /usr/bin/env node

require('@testim/root-cause/src/cli');
