See https://www.npmjs.com/package/@testim/root-cause
