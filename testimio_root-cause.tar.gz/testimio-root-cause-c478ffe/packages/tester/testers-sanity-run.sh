yarn ts-node index.ts
yarn ts-node subObjects.ts
yarn ts-node tester-cnn.ts
yarn ts-node launchFunctionTester.ts
