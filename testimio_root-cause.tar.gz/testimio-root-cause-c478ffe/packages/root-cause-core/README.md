# Core component of Testim Root Cause

For more information visit https://www.npmjs.com/package/@testim/root-cause
