export function malformedConfigFile() {
  return `Root Cause error: malformed config file
Falling back to default config`;
}
