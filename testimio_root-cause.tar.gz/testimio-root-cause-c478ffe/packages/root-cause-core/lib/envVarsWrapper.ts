export const TEST_API_PORT = 9876;
export const INJECTED_TEST_NAME = process.env.INJECTED_TEST_NAME || 'server-basic';
export const INJECTED_TEST_DIR = process.env.INJECTED_TEST_DIR;
