set -ex

cp package.json ./dist/
cp README.md ./dist/
cp .npmignore ./dist/
