'use strict';

module.exports = {
  projects: ['<rootDir>/for-integration-test/jest.config.js'],
};
