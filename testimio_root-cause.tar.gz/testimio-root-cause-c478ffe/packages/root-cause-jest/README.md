# Testim Root Cause jest integration

For more information visit https://www.npmjs.com/package/@testim/root-cause
