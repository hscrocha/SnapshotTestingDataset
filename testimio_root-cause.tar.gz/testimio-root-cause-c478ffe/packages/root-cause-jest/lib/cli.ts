#! /usr/bin/env node

import '@testim/root-cause-core/lib/cli';
