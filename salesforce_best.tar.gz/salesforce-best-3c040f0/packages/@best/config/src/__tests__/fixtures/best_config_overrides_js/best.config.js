module.exports = {
    projectName: 'test',
    mainBranch: 'test-branch'
};
