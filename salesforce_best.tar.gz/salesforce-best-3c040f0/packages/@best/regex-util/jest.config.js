const COMMON = require('../../../scripts/jest/common.config');

module.exports = {
    displayName: 'regex-util',
    ...COMMON,
};
