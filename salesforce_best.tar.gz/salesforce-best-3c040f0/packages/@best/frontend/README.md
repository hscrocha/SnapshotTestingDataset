# Best Frontend2

This is the frontend for Best. It will display the performance benchmarks for your projects.

## Getting started

To get setup you must first install all of the dependencies:

```
yarn install
```

### Development

If you want to run a development server you can run:

```
yarn watch
```

### `lwc-create-app` Commands

This project was build using [`lwc-create-app`](https://github.com/muenzpraeger/lwc-create-app) which has more documentation on the different commands available through `lwc-services`.
