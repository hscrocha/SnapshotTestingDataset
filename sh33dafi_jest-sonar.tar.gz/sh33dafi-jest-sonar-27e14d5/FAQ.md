#FAQ

## Sonar fails to import results

https://github.com/sh33dafi/jest-sonar/issues/30