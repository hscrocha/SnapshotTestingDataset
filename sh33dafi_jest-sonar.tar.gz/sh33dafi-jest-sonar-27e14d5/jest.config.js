module.exports = {
    coverageReporters: ['lcov', 'clover']
};
