'use strict';

const reporter = require('./src/jest-sonar');
module.exports = reporter;
