#!/bin/bash
echo "Skipping helm stage"
