## TODOS / MISSING FEATURES

#### LOGIN STUFF

#### HOME PAGE
* relay container(s)

#### PROJECTS LIST
* graphs above table

#### REPOSITORY (cases + files)
* custom facets
* summary section

#### ENTITY PAGES
* relay container(s)

#### CART PAGE
* cart state (redux + localstorage)
* cart buttons on various pages

#### SMART SEARCH

#### QUICK SEARCH
