export interface IBucket {
  doc_count: number;
  key: string;
};
