/* @flow */

import { makeIDLink } from './utils';

export default makeIDLink({ pathname: '/projects' });
