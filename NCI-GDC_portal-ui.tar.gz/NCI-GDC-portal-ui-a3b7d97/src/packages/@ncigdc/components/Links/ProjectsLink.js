/* @flow */

import { makeListLink } from './utils';

export default makeListLink({ pathname: '/projects', children: 'projects' });
