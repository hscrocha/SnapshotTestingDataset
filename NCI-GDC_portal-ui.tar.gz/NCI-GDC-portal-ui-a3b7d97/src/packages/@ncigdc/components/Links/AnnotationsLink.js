/* @flow */

import { makeListLink } from './utils';

export default makeListLink({
  pathname: '/annotations',
  children: 'annotations',
});
