/* @flow */

import { makeListLink } from './utils';

export default makeListLink({ pathname: '/files', children: 'files' });
