import ImpactTdContents from './ImpactTdContents';
import ImpactThContents from './ImpactThContents';

export { ImpactThContents, ImpactTdContents };
