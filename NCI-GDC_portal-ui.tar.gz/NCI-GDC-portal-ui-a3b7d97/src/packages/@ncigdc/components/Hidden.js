// @flow
import styled from '@ncigdc/theme/styled';

export default styled.div({
  width: 0,
  height: 0,
  overflow: 'hidden',
});
