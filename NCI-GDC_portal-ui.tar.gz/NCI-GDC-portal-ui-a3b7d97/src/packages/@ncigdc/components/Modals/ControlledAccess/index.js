import ControlledAccessModal from './ControlledAccessModal';

export default ControlledAccessModal;
