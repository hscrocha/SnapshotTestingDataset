import DevSettings from './DevSettings';

export default DevSettings;
