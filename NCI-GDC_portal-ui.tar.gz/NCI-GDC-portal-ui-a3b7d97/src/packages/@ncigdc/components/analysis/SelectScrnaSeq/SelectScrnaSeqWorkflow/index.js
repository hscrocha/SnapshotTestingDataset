import Component from './SelectScrnaSeqWorkflow';
import withQuery from './SelectScrnaSeqWorkflow.relay';

export default withQuery(Component);
