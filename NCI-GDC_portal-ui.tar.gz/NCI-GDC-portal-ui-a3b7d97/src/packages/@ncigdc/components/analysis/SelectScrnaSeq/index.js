import Component from './SelectScrnaSeq';
import withQuery from './SelectScrnaSeq.relay';
export default withQuery(Component);
