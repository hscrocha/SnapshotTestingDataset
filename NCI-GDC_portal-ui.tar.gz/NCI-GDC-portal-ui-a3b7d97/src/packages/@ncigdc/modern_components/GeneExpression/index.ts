export { default } from './GeneExpression';
