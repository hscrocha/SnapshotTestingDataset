import Component from './FileAggregations';
import createRenderer from './FileAggregations.relay';
export default createRenderer(Component);
