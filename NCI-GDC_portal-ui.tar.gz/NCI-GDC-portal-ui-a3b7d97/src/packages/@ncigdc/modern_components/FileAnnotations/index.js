import Component from './FileAnnotations';
import createRenderer from './FileAnnotations.relay';
export default createRenderer(Component);
