import Component from './CohortComparison';
import createRenderer from './CohortComparison.relay';
export default createRenderer(Component);
