import Component from './DownloadBiospecimenDropdown';
import createRenderer from './DownloadBiospecimenDropdown.relay';
export default createRenderer(Component);
