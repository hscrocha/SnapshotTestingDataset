// @flow
import React from 'react';

export default ({ children }: { children: any }) => <div>{children}</div>;
