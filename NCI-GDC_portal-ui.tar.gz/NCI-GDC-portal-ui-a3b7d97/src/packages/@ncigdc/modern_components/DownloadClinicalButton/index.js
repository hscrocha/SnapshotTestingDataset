import Component from './DownloadClinicalButton';
import createRenderer from '@ncigdc/modern_components/Counts/repositoryCase.relay';
export default createRenderer(Component);
