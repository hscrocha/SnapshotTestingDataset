import Component from './CaseAggregations';
import createRenderer from './CaseAggregations.relay';
export default createRenderer(Component);
