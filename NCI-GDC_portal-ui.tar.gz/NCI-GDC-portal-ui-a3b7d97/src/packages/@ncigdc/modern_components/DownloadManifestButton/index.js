import Component from './DownloadManifestButton';
import createRenderer from './DownloadManifestButton.relay';
export default createRenderer(Component);
