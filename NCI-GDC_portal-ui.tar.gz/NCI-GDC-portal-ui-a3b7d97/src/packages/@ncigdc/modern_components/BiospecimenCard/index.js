import BiospecimenCard from './BiospecimenCard';
import createRenderer from './BiospecimenCard.relay';

export default createRenderer(BiospecimenCard);
