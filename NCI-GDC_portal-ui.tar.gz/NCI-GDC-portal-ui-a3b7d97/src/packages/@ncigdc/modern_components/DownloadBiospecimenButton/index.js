import Component from './DownloadBiospecimenButton';
import createRenderer from './DownloadBiospecimenButton.relay';
export default createRenderer(Component);
