import Component from './ExploreCasesAggregations';
import createRenderer from './ExploreCasesAggregations.relay';

export default createRenderer(Component);
