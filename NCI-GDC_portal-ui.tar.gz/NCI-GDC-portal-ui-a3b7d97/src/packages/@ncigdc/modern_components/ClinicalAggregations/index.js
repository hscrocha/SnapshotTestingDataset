import ClinicalAggregations from './ClinicalAggregations';
import createRenderer from './ClinicalAggregations.relay';

export default createRenderer(ClinicalAggregations);
