import AffectedCasesTable from './AffectedCasesTable';
export default AffectedCasesTable;
