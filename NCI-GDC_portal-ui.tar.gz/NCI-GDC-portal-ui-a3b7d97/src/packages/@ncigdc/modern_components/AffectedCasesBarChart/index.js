import AffectedCasesBarChart from './AffectedCasesBarChart';
export default AffectedCasesBarChart;
