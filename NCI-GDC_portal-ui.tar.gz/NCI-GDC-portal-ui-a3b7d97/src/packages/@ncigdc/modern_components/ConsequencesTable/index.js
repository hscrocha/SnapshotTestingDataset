import Component from './ConsequencesTable';
import createRenderer from './ConsequencesTable.relay';
export default createRenderer(Component);
