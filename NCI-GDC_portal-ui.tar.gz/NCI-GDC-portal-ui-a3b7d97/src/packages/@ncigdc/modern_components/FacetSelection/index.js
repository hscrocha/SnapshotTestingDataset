import Component from './FacetSelection';
import createRenderer from './FacetSelection.relay';

export default createRenderer(Component);
