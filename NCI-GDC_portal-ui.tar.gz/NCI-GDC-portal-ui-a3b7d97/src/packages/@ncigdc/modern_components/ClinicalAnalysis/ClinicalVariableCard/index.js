import CategoricalVariableCard from './CategoricalVariableCard';
import ContinuousVariableCard from './ContinuousVariableCard';

export { CategoricalVariableCard, ContinuousVariableCard };