import CategoricalCustomBinsModal from './CategoricalCustomBinsModal';

export default CategoricalCustomBinsModal;
