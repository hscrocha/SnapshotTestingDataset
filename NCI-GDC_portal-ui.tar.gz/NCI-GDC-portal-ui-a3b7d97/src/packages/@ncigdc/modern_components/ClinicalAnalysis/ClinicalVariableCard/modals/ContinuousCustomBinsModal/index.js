import ContinuousCustomBinsModal from './ContinuousCustomBinsModal';

export default ContinuousCustomBinsModal;
