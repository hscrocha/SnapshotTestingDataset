import ClinicalAnalysisResult from './ClinicalAnalysisResult';
import createRenderer from './ClinicalAnalysisResult.relay';

export default createRenderer(ClinicalAnalysisResult);
