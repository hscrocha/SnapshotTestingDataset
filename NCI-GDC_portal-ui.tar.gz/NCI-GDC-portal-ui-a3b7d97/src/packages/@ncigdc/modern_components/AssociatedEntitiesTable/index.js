import Component from './AssociatedEntitiesTable';
import createRenderer from './AssociatedEntitiesTable.relay';
export default createRenderer(Component);
