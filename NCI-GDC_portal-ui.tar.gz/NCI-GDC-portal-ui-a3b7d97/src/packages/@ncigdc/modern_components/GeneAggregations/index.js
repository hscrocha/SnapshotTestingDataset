import GeneAggregations from './GeneAggregations';
import createRenderer from './GeneAggregations.relay';

export default createRenderer(GeneAggregations);
