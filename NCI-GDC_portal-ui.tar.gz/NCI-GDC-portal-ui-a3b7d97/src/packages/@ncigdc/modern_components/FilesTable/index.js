import Component from './FilesTable';
import withQuery from './FilesTable.relay';
export default withQuery(Component);
