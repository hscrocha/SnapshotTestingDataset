import Component from './DownloadClinicalDropdown';
import createRenderer from './DownloadClinicalDropdown.relay';
export default createRenderer(Component);
