import React from 'react';

const mockComponent = () => <div>Mock Uploader</div>;

export default mockComponent;
