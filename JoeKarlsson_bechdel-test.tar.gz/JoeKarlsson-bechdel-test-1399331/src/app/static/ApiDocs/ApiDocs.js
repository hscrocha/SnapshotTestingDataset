import React from 'react';

const ApiDocs = () => (
	<div className="container">
		<h1>api documentation</h1>
	</div>
);

export default ApiDocs;
