import React from 'react';

const NoMatch = () => <div className="container">No Page Found</div>;

export default NoMatch;
