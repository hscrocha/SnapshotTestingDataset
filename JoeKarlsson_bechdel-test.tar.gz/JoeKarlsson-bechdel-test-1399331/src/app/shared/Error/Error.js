import React from 'react';

const Error = () => <div>Im sorry! Please try again.</div>;

export default Error;
