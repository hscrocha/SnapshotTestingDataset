const DEFAULT_ERROR_MESSAGE = 'Sorry, something went wrong. Please try again.';

export default DEFAULT_ERROR_MESSAGE;
