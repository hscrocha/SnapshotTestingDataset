export function readCodeFile(name: string): Promise<string>;
