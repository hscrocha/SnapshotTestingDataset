module.exports = {
  /* test style stub */
};
