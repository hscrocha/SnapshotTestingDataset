
// Auto-generated file created by react-native-storybook-loader
// Do not edit.
//
// https://github.com/elderfo/react-native-storybook-loader.git

function loadStories() {
  require('./stories/Button/index');
  require('./stories/Icon/index');
  
}

const stories = [
  './stories/Button/index',
  './stories/Icon/index',
  
];

module.exports = {
  loadStories,
  stories,
};
