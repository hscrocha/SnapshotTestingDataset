export const colors = {
  white: 'white',
  black: 'black',
  secondary: 'tomato',
  primary: 'darkslateblue',
  grey: 'darkgrey'
};
