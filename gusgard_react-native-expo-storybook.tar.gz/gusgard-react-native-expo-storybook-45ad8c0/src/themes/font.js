export const fontSize = {
  large: 60,
  medium: 40,
  small: 30
};
