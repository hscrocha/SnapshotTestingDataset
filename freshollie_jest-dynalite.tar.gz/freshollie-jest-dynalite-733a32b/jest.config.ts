export default {
  projects: ["./tests/jest-*.config.ts", "./jest.unit.config.ts"],
};
