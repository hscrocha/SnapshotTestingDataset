import tables from "./configs/tables";

// This is the simple jest-dynalite config used by most tests
// More advanced test configs can be found in .jest/configs
export default {
  tables,
  basePort: 10500,
};
