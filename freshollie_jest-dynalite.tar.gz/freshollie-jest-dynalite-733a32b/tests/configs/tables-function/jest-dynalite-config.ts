import tables from "../tables";

export default {
  tables: () => tables,
  basePort: 10500,
};
