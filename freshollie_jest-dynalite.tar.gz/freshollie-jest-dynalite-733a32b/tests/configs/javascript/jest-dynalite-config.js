const tables = require("./tables");

module.exports = {
  tables: () => tables,
  basePort: 10500,
};
