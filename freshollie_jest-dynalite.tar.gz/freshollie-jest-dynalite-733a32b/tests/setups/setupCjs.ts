import { join } from "path";
import { setup } from "../../src";

// Setup with the config dir
setup(join(__dirname, "../configs/cjs"));
