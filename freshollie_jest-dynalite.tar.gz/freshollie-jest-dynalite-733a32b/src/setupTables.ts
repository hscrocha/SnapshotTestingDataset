import { createTables } from "./db";

beforeAll(createTables);
