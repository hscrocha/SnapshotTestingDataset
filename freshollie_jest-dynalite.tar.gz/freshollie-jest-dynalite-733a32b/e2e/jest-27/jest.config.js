module.exports = {
  preset: "jest-dynalite",
  displayName: {
    name: "preset",
    color: "yellow",
  },
};
