module.exports = {
  preset: "jest-dynalite",
  displayName: {
    name: "monorepo",
    color: "red",
  },
};
