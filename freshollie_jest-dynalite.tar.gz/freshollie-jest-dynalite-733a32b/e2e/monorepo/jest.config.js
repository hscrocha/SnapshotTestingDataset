module.exports = {
  projects: ["<rootDir>/packages/*/jest.config.js"],
};
