module.exports = {
  globalSetup: `./globalSetup.js`,
  globalTeardown: `./globalTeardown.js`,
  displayName: {
    name: "global-setup",
    color: "blue",
  },
};
