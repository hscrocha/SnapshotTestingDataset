import { createContext } from 'react';

const patientContext = createContext();

export default patientContext;
