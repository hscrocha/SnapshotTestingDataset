export { default } from './BasicInfo';
