 
var MedChain = artifacts.require("MedChain");

module.exports = function(deployer) {
  deployer.deploy(MedChain);
};