export * from './affiliate-link';
