import * as React from 'react';

import { Styled } from './divider.styles';

export const Divider = () => <Styled.Divider noMargin />;
