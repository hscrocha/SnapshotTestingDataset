import styled from 'styled-components';

const Awards = styled.section``;

export const Styled = {
  Awards,
};
