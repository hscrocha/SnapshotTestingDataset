import styled from 'styled-components';

const Languages = styled.section``;

export const Styled = {
  Languages,
};
