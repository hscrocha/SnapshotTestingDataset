import * as React from 'react';

import { Styled } from './title.styles';

export const Title = () => (
  <Styled.Title>This page can’t be found.</Styled.Title>
);
