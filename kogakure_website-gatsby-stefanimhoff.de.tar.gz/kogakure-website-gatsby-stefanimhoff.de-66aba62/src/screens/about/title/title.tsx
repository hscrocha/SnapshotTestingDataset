import * as React from 'react';

import { Styled } from './title.styles';

export const Title = () => <Styled.Title>About</Styled.Title>;
