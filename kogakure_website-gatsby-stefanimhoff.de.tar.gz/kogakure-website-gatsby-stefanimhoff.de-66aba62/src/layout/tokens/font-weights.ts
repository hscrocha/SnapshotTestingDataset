export const fontWeight = {
  normal: 400,
  bold: 600,
  black: 900,
};
