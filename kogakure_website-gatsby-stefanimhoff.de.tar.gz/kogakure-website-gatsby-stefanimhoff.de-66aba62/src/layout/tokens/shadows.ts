export const shadow = {
  subtleShade: '0 0 50px rgba(0, 0, 0, 0.2)',
  beveledKeyboard: '0 1px 0 rgba(0, 0, 0, 0.2), inset 0 0 0 2px #ffffff',
  whiteOutline: '0 1px 0 #ffffff',
  darkInset: 'inset 0 0 10px rgba(0, 0, 0, 0.2)',
};
