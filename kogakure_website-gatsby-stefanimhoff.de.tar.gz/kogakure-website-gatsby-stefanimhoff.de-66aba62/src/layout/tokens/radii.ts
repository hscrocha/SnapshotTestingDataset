export const radius = {
  1: '2px',
  2: '5px',
  4: '8px',
  25: '25%',
  50: '50%',
};
