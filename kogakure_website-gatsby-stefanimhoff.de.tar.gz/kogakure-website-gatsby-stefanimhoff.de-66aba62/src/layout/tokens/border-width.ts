export const borderWidth = {
  1: '1px',
  10: '0.1em',
  15: '0.15em',
};
