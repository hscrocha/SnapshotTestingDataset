export const borderStyle = {
  solid: 'solid',
};
