export const transitionDuration = {
  1: '100ms',
  2: '200ms',
  5: '500ms',
};
