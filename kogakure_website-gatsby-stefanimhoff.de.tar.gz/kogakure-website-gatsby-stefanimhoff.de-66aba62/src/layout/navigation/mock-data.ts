export const navigation = [
  { text: 'About', url: '/about/' },
  { text: 'Projects', url: '/projects/' },
];
