export * from './legal-information';
