import React from 'react';

import { Footer } from '.';

export default {
  component: Footer,
  title: 'Layout/Footer',
};

export const Default = () => <Footer />;
