---
published: true
title: Best of 2020
date: 2020-12-22T18:00:00+02:00
author: Stefan Imhoff
description: A distilled collection of my favorite topics, articles, videos, podcasts, people, or other things in 2020.
categories:
  - tip
---

This article is a distilled collection of my favorite topics, articles, videos, podcasts, people, or other things in 2020. I tried to get the recommendations in some order, so expect similar topics to follow each other.

---

## What I’ve Learned

[What I’ve Learned](https://www.youtube.com/c/WhatIveLearned/) by _Joseph Everett_ is one of my favorite channels regarding health, productivity, and psychology. He puts a lot of effort into summarizing dozens of scientific studies or meta-studies in an easily digestible way. One of his goals is to fight modern dogma.

This year he created four fantastic videos on health: [Meat: Grows the Brain or Rusts the Body?](https://youtu.be/1MH2ZKt35K4), [What made the Ancient Egyptians Fat and Sick?](https://youtu.be/YGq_EbYEaSY), [Does Coffee make you Fat and Anxious?](https://youtu.be/pVXHD1gl6c4), and [Does Instagram Lower your Testosterone?](https://youtu.be/xpVnXJl3GK8).

And three videos on Psychology and Neuroscience: [Willpower is for Losers](https://youtu.be/k2Wcu6aGyz8), [Why are you Uncertain, Unfocused and Anxious? What should we do about it?](https://youtu.be/GaJmw54BMcw), and [Why do we find Satisfying things so Satisfying? (Neuroscience and Pleasure)](https://youtu.be/qr0JMv2uYxQ).

## Why We Sleep

I discovered _Matthew Walker_, the author of [Why We Sleep](https://www.goodreads.com/book/show/34466963-why-we-sleep), first on [The Joe Rogan Experience 1109](https://open.spotify.com/episode/1WtITGcwwZYQZHVJGciMJp). His book summarizes years of studies of sleep and the severe effects of too little sleep.

Since I read his book and listened to his [TED talk](https://youtu.be/5MuIMqhT8DM) I increased my median sleep duration from 6 hours to 8 hours a night.

## What is Happiness?

I found the YouTube channel of [Will Schroder](https://twitter.com/willschoder) through his fantastic video [How To Remember Everything You Learn](https://youtu.be/V-UvSKe8jW4) in 2018.

This year he created a three-part series about Happiness:
[What is Happiness?](https://youtu.be/5f0ilA4tjJ0), [The Foundations of Happiness](https://youtu.be/p4X7uXfZ2cY), and [The Secret to Happier](https://youtu.be/Yg5Q9XBHYYk). The amount of work he put into this long documentary is impressive!

## Aydin Paladin

A new channel about politics, news, social psychology, media psychology, human communication, and memes I discovered in 2020 was [Aydin Paladin](https://www.youtube.com/c/AydinPaladin/). Her essays are impressive! In one-hour long videos, she entertainingly summarizes studies. I found her through her destruction of [Critical Race Theory](https://youtu.be/Kl3p3M67MkQ) studies. That was interesting. In [How Russians Hacked My Memes: Dissertation Destruction](https://youtu.be/ABo_72Ov9dI) she destroyed a recent doctoral dissertation.

## Jordan B Peterson

_Jordan Peterson_ was finally back at the end of 2020. He needed a long recovery, because of the severe side-effects of a medication he took to deal with anxiety resulting from the cancer diagnosis of his wife.

He announced his new book [Beyond Order](https://www.goodreads.com/book/show/56019043-beyond-order) and released three of the six parts of his _12 Rules for Life Tour_ in Australia: [Brisbane](https://youtu.be/R-z92l0kPls), [Melbourne](https://youtu.be/dPv1RYsi7sA), and [Sydney](https://youtu.be/Q_zjdmkou0Q).

I finished his lecture [2017 Personality and Its Transformations (University of Toronto)](https://www.youtube.com/playlist?list=PL22J3VaeABQApSdW8X71Ihe34eKN6XhCi), highly recommended for everybody interested in psychology and personality.

_Andrew Doyle_ wrote a fantastic article about _Peterson_ on _Spiked_: [Jordan Peterson: how the left manufactured a folk devil](https://www.spiked-online.com/2020/11/27/jordan-peterson-how-the-left-manufactured-a-folk-devil/).

## The Art of Manliness

I love the work _Brett_ and _Kate McKay_ are doing on their website [The Art of Manliness](https://www.artofmanliness.com/). In times of declining male values and the rise of weak, whiney, pathetic men ([Soy Boys](https://www.urbandictionary.com/define.php?term=Soy%20Boy)) their work is so relevant. They promote Stoic values, adventure, responsibility, leadership, courage, learning, strength, and virtue – for women _and_ for men.

Their blog is a vast collection of well-written articles, precise tips, lists, and recommendations. If I could only read one blog, it would be this.

In 2020 they wrote articles about [Pocket Knives](https://www.artofmanliness.com/articles/complete-guide-pocket-knives/), [Lessons from Homer’s Odyssey](https://www.artofmanliness.com/articles/3-lessons-from-homers-odyssey/), [Kaizen](https://www.artofmanliness.com/articles/get-1-better-every-day-the-kaizen-way-to-self-improvement/), [Cooking Steak](https://www.artofmanliness.com/articles/reverse-sear-best-cooking-method-steak/), [100 Skills Every Man Should Know](https://www.artofmanliness.com/articles/100-skills-every-man-should-know/), [Being Uncomfortable](https://www.artofmanliness.com/articles/how-i-learned-to-be-comfortable-with-being-uncomfortable/), [James Bond Stoicism](https://www.artofmanliness.com/articles/james-bond-stoicism/), [Hygge](https://www.artofmanliness.com/articles/8-things-that-can-help-you-get-more-hygge-this-winter/), or [100 Must-See Movies](https://www.artofmanliness.com/articles/100-must-see-movies/), to named a few.

[The Art of Manliness Podcast](https://www.artofmanliness.com/podcast/) has over 600 episodes, and 2.5 million monthly downloads. They interview interesting people and talk about important topics as for example [breathing correctly](https://www.artofmanliness.com/articles/importance-of-proper-breathing/), [physical autonomy](https://www.artofmanliness.com/articles/podcast-663-how-to-achieve-physical-autonomy/), [the code of the warrior](https://www.artofmanliness.com/articles/code-of-the-warrior/), [how to deal with bullies](https://www.artofmanliness.com/articles/podcast-627-how-to-deal-with-jerks-bullies-tyrants-and-trolls/), [how to thinking for yourself](https://www.artofmanliness.com/articles/podcast-649-thinking-for-yourself-in-an-age-of-outsourced-expertise/), [why people build bunkers](https://www.artofmanliness.com/articles/podcast-650-why-people-are-building-apocalypse-bunkers/), [organizing your life like a chef](https://www.artofmanliness.com/articles/mise-en-place-how-chefs-organize/), [getting in shape](https://www.artofmanliness.com/articles/podcast-655-simple-excuse-busting-advice-for-getting-in-shape/), [learning for its own sake](https://www.artofmanliness.com/articles/podcast-656-the-hidden-pleasures-of-learning-for-its-own-sake/), [Greek tragedies for theraphy](https://www.artofmanliness.com/articles/podcast-660-how-ancient-greek-tragedies-can-heal-the-soul/), [male loneliness](https://www.artofmanliness.com/articles/male-loneliness/), or [turning fear into fuel](https://www.artofmanliness.com/articles/how-to-overcome-fear/).

## exurb1a

I can’t even categorize this YouTube channel properly. Stories, comedy, science, and philosophy? 🤔 But you need to watch the videos [Sleep is Just Death Being Shy](https://youtu.be/-mu780uB7mI), [Let’s Build a Time Machine With Pickles and Sadness](https://youtu.be/uBinqZfhIBg), [The Moon is a Door to Forever](https://youtu.be/K3X2Fv-c3Fc), [How to Be Correct About Everything All the Time](https://youtu.be/DJiGuFCzaFo), and [There's No Such Thing As Orange](https://youtu.be/WX0xWJpr0FY). Just do it, you won’t regret it.

## Psychedelics & Religion

I listened maybe too much to Joe Rogan, but even though I never took any drugs in my life, I now think that psychedelics need to be legal.

A lot has changed since the criminalization in the 70s put an end to the studies of psychedelics. Scientists started studying the topic again with incredible results. Jordan B Peterson gives an introduction to the recent studies in [Heroic and Shamanic Initiations](https://youtu.be/wLc_MC7NQek?t=2h30m) from his lecture [2017 Personality and Its Transformations (University of Toronto)](https://www.youtube.com/playlist?list=PL22J3VaeABQApSdW8X71Ihe34eKN6XhCi). It’s incredible how one dose of Psilocybin can change the personality permanently by one standard deviation in _Openness_. Psychedelics reduce anxiety, lift the fear of death, and make people friendlier.

I watched the funny, artful [Tales from the Trip](https://www.youtube.com/playlist?list=PLChmxKYOuWILcPzhzea-dVvXN-ii0hh95) by _Comedy Central_ that animated the stories of people taking psychedelics in short 5-minute episodes.

_Roland Griffiths_ presented [the science of psilocybin and its use to relieve suffering](https://youtu.be/81-v8ePXPd4) at TED.

The visit of _Brian Muraresku_ & _Graham Hancock_ on [The Joe Rogan Experience 1543](https://open.spotify.com/episode/0FwCgmkG2Cfb36etijDIho) was fascinating. [Brian Muraresku](https://www.brianmuraresku.com/) wrote nearly 12 years on his book [The Immortality Key](https://www.goodreads.com/book/show/51174256-the-immortality-key). It is an intriguing dive into the history of psychedelics. It connects the old ruins of [Göbekli Tepe](https://en.wikipedia.org/wiki/G%C3%B6bekli_Tepe), _spiked_ beer and wine to the Stone Age, the _Mysteries of Eleusis_, Demeter, Dionysos, and the Eucharist. Who would have thought that the early Christians were high? 😅

But the thing that fascinated me most was [Eleusis](https://youtu.be/iaprpVwW-QU). I was always interested in Greek history but never heard of this mystical religion that spanned over 2000 years. Even Marcus Aurelius took part in the _Mysteries_.

Religion institutions are in the process of breaking down, people losing their faith, and replace it with personalized gods (health, food, politics, technology, or money). But most people are not able to find meaning without religion.

I think it is the right time to bring back psychedelics. Restoring our ancient connection to psychedelics after 2000 years of a ban by the Catholic Church could change life on Earth for everybody for the better.

## Aliens & Flying Saucers

I never took too much notice of Alien stories besides Science Fiction. But the recent releases of [videos](https://youtu.be/9a0xIzp-fbs) by the Pentagon and credible people coming forward got me interested in the topic.

_Bob Lazar_ claims to have been hired by a government organization to work in a secret research facility S-4 several kilometers south of Area 51 to reverse engineer the engines of vehicles of unknown origin. He does not give many interviews and dislikes being the center of attention, but I enjoyed his visit on [The Joe Rogan Experience 1315](https://open.spotify.com/episode/7Gg4Qi578G5SXoEtaLVVpx). I watched the documentary [Bob Lazar: Area 51 and Flying Saucers](https://www.themoviedb.org/movie/522320-bob-lazar) <NetflixFlag id="81083891" /> about his story.

Other fascinating interviews about Aliens and UFOs were the ones with [George Knapp](https://open.spotify.com/episode/3RIsqi1Axn6zPGd0IpCRgf) and [Jacques Vallée](https://open.spotify.com/episode/3cuW6TuyRnZxBNaQJeH2Ce).

But most impressive is _David Favor_, a decorated fighter pilot commander with an incredible career. He and his wingman and another fighter saw a _Tic Tac_ shaped 40 feet long object for more than 5 minutes that hovered over the water off the coast of Southern California. It behaved against all physical laws, blocked the radar, and flew off with speed no human invention can reach. The incident was recorded in 2004 and leaked to the public before the Pentagon confirmed its authenticity. _David Fravor_ was interviewed on [The Joe Rogan Experience 1361](https://open.spotify.com/episode/16If5PVe6ouxeDwNbtu0iC) and [Lex Friedman Podcast 122](https://podcasts.apple.com/de/podcast/lex-fridman-podcast/id1434243584).

## Like Stories of Old

[Like Stories of Old](https://www.youtube.com/c/LikeStoriesofOld/) by _Tom van der Linden_ is one of my favorite channels of all time. He takes movies (and sometimes games) and tells stories that cross the boundary between film analysis and life lessons, mixed with cross-references to literature and quotes. Each of his films is a piece of art.

He analyzed the works of directors and filmmakers as [Andrei Tarkovsky](https://youtu.be/gNezdOlS-aw), [Terrence Malick](https://youtu.be/Oohg3LZd898), and [Werner Herzog](https://youtu.be/ogFN6ncIaD8).

And he made a video about [The Real Implications Of Ex Machina’s Turing Test](https://youtu.be/nmjgM8fPSLU), the [Anatomy of a Global Pandemic](https://youtu.be/ELq4iRFLiLM), [Lies of Heroism – Redefining the Anti-War Film](https://youtu.be/yf0G2MPBEYM), and [Who We Really Are… When Everything Goes Wrong](https://youtu.be/vT_sKGbP1yY).

I especially liked his three-part series _Stories vs. Reality_, with [The Fundamental Difference Between Stories And Reality](https://youtu.be/wuI-hEDhfCw), [Your Life is Not a Hero’s Journey](https://youtu.be/j5bEQC6TTeM), and [Stories as Identities: Who Are We Without Them?](https://youtu.be/1sWdBo-k2iA).

## Out of Frame

I found the YouTube channel of the [Foundation for Economic Education](https://www.youtube.com/c/FEEonline/) through the video [This Movie Offends You? Good.](https://youtu.be/vSGZrpN7ahQ)

It is a delightful channel with video essays on the intersection of art, culture, and ideas. They ask questions about economics, ethics, and legal principles of a free society by analyzing movies and TV shows.

[The Tiger King Is Right (About One Thing)](https://youtu.be/DmBQgLbzsSg) analyses the economy of bad actors in markets. [The Holocaust The New York Times Ignored](https://youtu.be/BqnfmCu6fUk) tells the story of the Holocaust in Ukraine. [Is Disney Praising Chinese Genocide!?](https://youtu.be/3xcw-7t5L2Y) is criticizing Disney for their indirect support of the genocide of the Uighur Muslim population in Xinjiang province. [The Horrible Economics of 80s Horror](https://youtu.be/wUSZLxWHRUc) shines a light on Hollywood's dislike of free-market capitalism. [Woke Outrage: Great Marketing for Terrible Movies](https://youtu.be/PfDZ6x9KxYE) is about how outrage sells awful movies.

The two-part series _The Social Dilemma Is Dangerously Wrong…_ ([Part I](https://youtu.be/Z8Nh5U5cyk4), [Part II](https://youtu.be/pOYxN_a7zL4)) analyses why the documentary [The Social Dilemma](https://www.themoviedb.org/movie/656690-the-social-dilemma) is an awful documentary that has massive flaws.

[You Really DON'T Want to Live in The Last Kingdom](https://youtu.be/cna_28sakpQ) highlights the progress our societies made through respect for individual rights and limitations on governments.

[Cops, Karens, and the Coming Dystopia](https://youtu.be/GFbfDcELLxw) is a social commentary on Coronavirus lockdowns, economic and emotional damage, riots using _V for Vendetta_ and the idea of Dystopias. The warning label put on the video by YouTube is a sign of who precise the analysis is. [Wonder Woman Got It Wrong. Did You?](https://youtu.be/otSip1l20I0) shows that tribalism is wrong and that the reality is more complicated than we think.

[Superman Is the Hero We Need Right Now](https://youtu.be/daQ7mdRohY0) let me re-think my stance on Superman. I never liked the character, but Out of Frame convinced me I was wrong.

## The Critical Drinker

The Critical Drinker is the YouTube channel of _Will Jordan_, author and film critic. I love his sarcastic reviews of awful movies and TV shows like [Mulan](https://youtu.be/kIH-eFqBLP4) or [Star Trek Discovery](https://youtu.be/vyMHkkB5gXg), and his recommendations as for example [Cobra Kai](https://youtu.be/XEDwYbnqSiA), [Fight Club](https://youtu.be/-IyJGImfcvs), [Dredd](https://youtu.be/GXEFg2zs6g4), or [The Lighthouse](https://youtu.be/b1s-7EuKvn4).

Additionally, he does entertaining documentaries of movie productions that destroyed careers and drove people insane in [Apocalyse Now](https://youtu.be/TXC-b4O_H_M), [The Abyss](https://youtu.be/0RyLikHFh78), or [The Island of Dr. Moreau](https://youtu.be/X9Cg-upCQD8).

## Parasite

The Korean movie [Parasite](https://www.themoviedb.org/movie/496243) <PrimeVideoFlag id="B07ZKN6JHB" /> by _Bong Joon-ho_ was one of my favorite motion picture of the year.

Its class critique was reviewed by [Wisecrack](https://youtu.be/oDz2dbXivDU) and [Just Write](https://youtu.be/BhEgGxaeCqM). _The Nerdwriter_ did an incredible analysis of the rhythm of the movie in [Parasite’s Perfect Montage](https://youtu.be/ma1rD2OP85c).

## The Handmaiden

Another Korean movie I enjoyed was [The Handmaiden](https://www.themoviedb.org/movie/290098) <PrimeVideoFlag id="B08GLH82GZ" />. In Korea, in the 1930s a young woman is hired as a handmaiden to a rich Japanese heiress. She is part of a team of swindlers that plan to rob her of her fortune. The story is brilliant, thrilling, and has a lot of surprises.

I had listened to the beautiful [soundtrack](https://music.apple.com/album/%EC%95%84%EA%B0%80%EC%94%A8-original-motion-picture-soundtrack/1147511388) two years before I had the chance to see the movie and enjoyed the [The Beauty Of The Handmaiden (Ah-ga-ssi)](https://youtu.be/qeK8KoAA31Y).

## The Expanse

At the beginning of 2020, I finished the 8th book of the series: [Tiamat’s Wrath](https://www.goodreads.com/book/show/28335698-tiamat-s-wrath). I liked it a lot and can‘t wait for the last book of the series (I hope next year).

Meanwhile, the TV show is back with Season 5: [The Expanse](https://www.themoviedb.org/tv/63639-the-expanse) <PrimeVideoFlag id="B08MMQGFXV" />. The [trailer](https://youtu.be/caLji74IIp4) appeared in October, but it was hard to wait for December because book 5 was my favorite book of the series.

## Cobra Kai

Some podcasts recommended this show that I had never watched without the recommendation: [Cobra Kai](https://www.themoviedb.org/tv/77169-cobra-kai) <NetflixFlag id="81002370" />. But it was one of the most fun to watch TV shows in 2020. The story follows up 36 years after the end of the movie [The Karate Kid](https://www.themoviedb.org/movie/1885-the-karate-kid) and gives it a nice turn and twist the story. It’s fun and takes a few hits and kicks at the weak new generation. 😅

Nearly all actors of the original movie are part of the new TV show. The third season will arrive in January 2021. There are [25 Things You Missed in Cobra Kai](https://youtu.be/WtjskFP7Ce0), most of which I didn’t know.

The soundtrack of [Season 1](https://music.apple.com/de/album/cobra-kai-season-1-soundtrack-from-the-original-series/1377948784) and [Season 2](https://music.apple.com/de/album/cobra-kai-season-2-soundtrack-from-the-original-series/1460317956) combines the 80s and today's music.

## Tales from the Loop

[Tales from the Loop](https://www.themoviedb.org/tv/93784-tales-from-the-loop) <PrimeVideoFlag id="B086BPMKBB" /> is refreshing Science Fiction and hard-warming stories around the people in a city above a secret research facility.

The idea for the TV show comes from the artwork of the Swedish illustrator [Simon Stålenhag](https://www.simonstalenhag.se/). His artwork blends nostalgia and futurism.

## Dark

[Dark](https://www.themoviedb.org/tv/70523-dark) <NetflixFlag id="80100172" /> was one of the few German TV shows that got international acclaim. It’s a fantastic Science Fiction story. The third and final season finished the incredible story arch and solved a lot of the riddles.

But the story of _Dark_ is so complicated that Netflix made a [website](https://dark.netflix.io/) to browse the different seasons and episodes, read up on characters and the plot (spoiler-free).

## Barbarians

Another German TV show that got attention outside of Germany was [Barbarians](https://www.themoviedb.org/tv/93785-the-barbarians) <NetflixFlag id="81024039" />. It shows (quite accurately) the devastating battle at the _Teutoburger Forest_ between the Roman Army and united Germanic tribes. The fight resulted in the loss of 3 legions (⅛ of the 25 Roman legions) and was devastating for the Empire. It resulted in the construction of the Limes, a 550 km long fortified wall to protect the Roman Empire from the Germanic tribes and stopped the Roman expansion.

There were many documentaries at the same time with the release of the TV show as [Origin of the Germanic Tribes](https://youtu.be/_KFzDlhT6bs), [Arminius: Hero of Germania, Traitor to Rome](https://youtu.be/logbxY7_FCw), and channels discussing the [accuracy of the TV show](https://youtu.be/YMC-gzAC1FI) or the [languages they spoke](https://youtu.be/EjfeGqfZFi8).

## Rick and Morty

[Rick and Morty](https://www.themoviedb.org/tv/60625-rick-and-morty) <NetflixFlag id="80014749" /> is a TV show of its own category. It’s so unusual, creative, and funny. I always binge a full season in one day.

Adult Swim released two funny short films. [Samurai & Shogun (Rick and Morty)](https://youtu.be/BSF5yoD-vC4) is a homage to the 70s TV show [Lone Wolf and Cub](https://www.themoviedb.org/tv/36749-kozure-kami).

[Rick and Morty vs. Genocider](https://youtu.be/-kdltv_CSHE) is another Manga styled short film that has secret answers to the TV show.

## DUST

[DUST](https://watchdust.com/) started as a platform for free Science Fiction short films.

In 2019 they started the [DUST Podcast](https://podcasts.apple.com/de/podcast/dust/id1482669176). [Season 1](https://podcasts.apple.com/de/podcast/dust/id1482669176?i=1000452670310) features multiple interesting short stories.

In 2020 they released [Season 2: FLIGHT 008](https://podcasts.apple.com/de/podcast/dust/id1482669176?i=1000468772220), multiple short stories all connected. The season told stories of passengers of Flight 008 from Tokyo to San Fransisco that passes a wrinkle in space-time and lands in the year 2040. The stories were fantastic because each author thought of possible implications of missing 20 years and progress differently.

[Season 3: CHRYSALIS](https://podcasts.apple.com/de/podcast/dust/id1482669176?i=1000489807363) was my favorite season of DUST. It’s one long story of an Artificial Intelligence that awakes on Earth to find out that humanity was wiped out by a malevolent alien race. The AI starts building itself a body to revenge its builders.

## Zettelkasten & Obsidian

I started this year to work intensively with the _Zettelkasten_ method. It’s a note-taking method that allows creating basic ideas to remember concepts or facts, developing new ideas, and making connections. Zettelkasten simulates how our brain works.

I read the fantastic book [How to Take Smart Notes](https://www.goodreads.com/book/show/34507927-how-to-take-smart-notes) by [Sönke Ahrens](https://takesmartnotes.com/) to learn more about the method.

In 2020 I wrote two articles about the topic: [Zettelkasten Note-Taking Method With DEVONthink](/zettelkasten-note-taking-devonthink/) and [Tools I Use For Note-Taking](/tools-i-use-for-note-taking/). My note count exceeded **800** in mid-December.

I started writing my notes in [DEVONthink](https://devontechnologies.com/apps/devonthink), where I still store all my notes, references, documents, and inspirations, but the release of [Obsidian](https://obsidian.md/) changed how I write them. Obsidian is the best tool I know to write and connect ideas, and it’s free.

Obsidian is incredible powerful with it’s features as backlinks, auto-complete, note [graph](https://youtu.be/058Tvff2Fso), [block references](https://youtu.be/oqx2O0aXZjQ), and a huge amount of [plugins](https://youtu.be/2Hrja0SRgO0).

I started following the YouTube channels [Linking Your Thinking](https://www.youtube.com/channel/UC85D7ERwhke7wVqskV_DZUA) that has well made [6-part introduction](https://youtu.be/QgbLb6QCK88) for Obsidian beginners. [Effective Remote Work](https://www.youtube.com/channel/UCkzyo69rqBoBJUyQ9jo53Bw) has a lot of tutorials.

## Konmari Folding Method

[Marie Kondō](https://www.youtube.com/channel/UCNaPKFA1niUFRgzkVqqhJVg), the best-selling Japanese author and organizing specialist released three videos showing how to fold [Basics](https://youtu.be/IjkmqbJTLBM), [Intimates](https://youtu.be/SVwrwJPIHPU), and [Menswear](https://youtu.be/auknz13Jp4M). I use her method for two years and love it! Much more space in the closets. Everything is quick and easy to fold and easy to find later.

## The Andrew Schulz

The Corona crisis took a massive hit into the careers of a lot of comedians. But not for _Andrew Schulz_. He had built up his online presence over the last years, but this year his career took off.

His YouTube show [SCHULZ](https://www.youtube.com/playlist?list=PLGFd0dP0EJslfzNb9J2MoY-8mRf2zFul1) has 3-5 minute long comedy sets about a specific topic and are hilarious. They were so successful that Netflix gave him a comedy special [Schulz Saves America: Pandemics, Predators, Protests & Presidents](https://www.themoviedb.org/tv/114604-schulz-saves-america-pandemics-predators-protests-presidents) <NetflixFlag id="81383020" />.

But the archive of his comedy is gigantic. There are hundreds of videos on his YouTube channel. Clips from Standups like [Views from a Cis](https://www.youtube.com/playlist?list=PLGFd0dP0EJslHN5dz6B1FzaIS-YB56J0y) or [Inside Jokes](https://www.youtube.com/playlist?list=PLGFd0dP0EJsn6-EeyCJcWgG26EZk1vZMu) where he meets other comedians to work on their most offensive jokes and try to squeeze out some fun. He even did a TED talk: [Can Comedy Be Funny Anymore?](https://www.ted.com/talks/andrew_schulz_can_comedy_be_funny_anymore_jan_2019).

## Awaken with JP

Another comedian I enjoyed this year was JP Sears and his YouTube channel [Awaken with JP](https://www.youtube.com/channel/UCwUizOU8pPWXdXNniXypQEQ). I love his work for a few years. He made fun of the new age movement, influencers, vegans, and other gurus.

But in 2020 he became much more political due to the ever-increasing cancel culture and threads against free speech. He got [threatened by Facebook](https://youtu.be/PTPreIUN2g0). YouTube deleted some of his videos, a clear violation of his Free Speech, guaranteed by the First Amendment to the United States Constitution.

He made videos joking about [Zoom Calls with Old People](https://youtu.be/JY4vFj_fGWg), insane and overreaching regulations during the Corona crisis, for example [Emotional Distancing Guidelines](https://youtu.be/ohRQ1ZbqcwE), [The Pandemic Hotline](https://youtu.be/uese-6Xln7o), or [How To Be More Obedient](https://youtu.be/RG2j8P_4EKE).

He criticized the new media outlets in [How News Anchors Are Trained](https://youtu.be/xxGeu9edNLY), political division in [How the Left and Right Fight](https://youtu.be/TN7s0-FuIEM) and even educated about the election in [Biden Won! Here’s What You Need To Know](https://youtu.be/lBZ-KiYoU68) and [How a Civil War Could Start!](https://youtu.be/6luFJvZt-og).

He made fun of [Political Correctness](https://youtu.be/bXrnqcNgL00) and [Wokeness](https://youtu.be/gHSVjmO4iJY) and mocked social media companies for censorship in [What It’s Like Getting Censored on YouTube](https://youtu.be/RGxbaxviRVw), [Spotify Employees Censoring Joe Rogan](https://youtu.be/SB50heKBxgw), [Why Twitter Censored the NY Post Article on Biden](https://youtu.be/jrjI2X9TIZA), and [The Fact Checkers](https://youtu.be/AmKPbYbAnKE).

## Ryan Long

In a similar kind the standup comedian [Ryan Long](https://www.youtube.com/c/RyanLongcomedy) made a lot of funny and critical videos about media bias in [How to Sell Protest Footage to FOX AND CNN](https://youtu.be/xiYZ__Ww02c) or [New Website Curates News You Agree With (Newsyourway.net)](https://youtu.be/rFRewkdDT2g). He criticized Antifa in [Meet The People Who Decide Who You Can Punch](https://youtu.be/LXcHL2K-RSg). His video library is full of funny videos mocking social justice and the woke ideology movement.

## K-Von Comedy

I discovered [K-Von](https://www.youtube.com/channel/UCh5pgse6OhrBT0IywOqtg8Q) who describes himself as _½ Persian Comedian_ because of his funny and educational videos where he compared Trump and Biden on specific topics: [Who is more racist?](https://youtu.be/DZfzJATDmXs), [Who is against the Disabled?](https://youtu.be/OIfRUIm3Kuc), [Who is better with Gays?](https://youtu.be/7y3Bffyio-A), [Who Handled Covid Best?](https://youtu.be/tdqvJITqkuc), [Who Disrespects the Military Most?](https://youtu.be/rI2RtQ1IohM), and [Who’s the Celebrity Choice for President?](https://youtu.be/0MHdrZcd7F0). The videos are well-researched and will surprise one or the other person.

## Freedom Toons

[FreedomToons](https://www.youtube.com/c/FreedomToons/) is a YouTube channel creating cartoons about politics. The clips are very short, seldom longer than 2 minutes. And as for the other comedians 2020 gave a lot of material: They made fun of censorship on Twitter in [Twitter CENSORS "Fake News"](https://youtu.be/BP6w3QrlpMY) and [ⓘ Official sources say this cartoon is false](https://youtu.be/tez4CF4yUy4).

The election was a topic to make fun of in [The Very Presidential Debate](https://youtu.be/VnlYaH8y_HU) and [Reasons To Vote For Joe Biden!](https://youtu.be/FE5Gmp5LQTE).

But my favorite clips are [A Brief History of Socialism](https://youtu.be/zZz2HF5KtrY) and [Joe Rogan interviews Tim Pool & Jack Dorsey](https://youtu.be/NEArAlNMuE4).

## James Lindsay

[James Lindsay](https://twitter.com/ConceptualJames) is my favorite fighter against _Critical Race Theory_ and _Woke_ ideology of 2020. He is an American mathematician, author, and cultural critic. He wrote together with _Helen Pluckrose_ the book [Cynical Theories: How Activist Scholarship Made Everything about Race, Gender, and Identity—and Why This Harms Everybody](https://www.goodreads.com/book/show/53052177-cynical-theories) which I’ll read next.

I heard first of him for his involvement in the [grievance studies affair](https://youtu.be/kVk9a5Jcd1k) with _Peter Boghossian_ and _Helen Pluckrose_. They exposed in 2018 the corruption in the humanities of American universities by submitting 20 fake papers. At the time of their reveal 4 studies had been accepted and published, 3 accepted but not yet published, 6 were rejected and 7 were still under review.

He knows the language of Social Justice activists and ideologues as nobody else and regularly comes up with new ideas to mock, trigger, and ridicule those on Twitter. I love how he regularly renames his Twitter handle. For example in December 2020 his handle is _James Lindsay, Bd.E., respect my degree_.

He is the founder of [New Discourses](https://newdiscourses.com/) one of my favorite magazines writing about the pursuit of objective truth and calling out “Critical Social Justice” and other ideological dogmas. I read many of his articles, for example [The Cult Dynamics of Wokeness](https://newdiscourses.com/2020/06/cult-dynamics-wokeness/), [The Woke Breaking Point](https://newdiscourses.com/2020/06/woke-breaking-point/), [Iconoclasm as a Prelude to Woke Horrors?](https://newdiscourses.com/2020/06/iconoclasm-prelude-woke-horrors/), or [The Great Silencing of America and the Hallmarks of Woke Totalitarianism](https://newdiscourses.com/2020/09/great-silencing-america-hallmarks-woke-totalitarianism/).

He is an excellent speaker and regular guest in podcasts and on conferences to talk about Woke ideology. I loved his talk [Diversity, Inclusion, Equity](https://youtu.be/3jLNgLABuTw) at _Sovereign Nations_.

His new podcast [New Discourses](https://podcasts.apple.com/podcast/new-discourses/id1499880546) started in mid-2020 and is fantastic! He can talk an hour calmly and with reason about important topics. I recommend [Understanding Diversity, Equity, and Inclusion](https://podcasts.apple.com/podcast/understanding-diversity-equity-and-inclusion/id1499880546?i=1000492540461), [Biden Is Not The Room](https://podcasts.apple.com/podcast/new-discourses/id1499880546?i=1000495583484), or [The Next Chapter of the American Story](https://podcasts.apple.com/podcast/the-next-chapter-of-the-american-story/id1499880546?i=1000500853629).

## Douglas Murray

[Douglas Murray](https://twitter.com/douglaskmurray) is a bestselling author of six books, including [The Madness of Crowds](https://www.goodreads.com/book/show/44667183-the-madness-of-crowds) and [The Strange Death of Europe](https://www.goodreads.com/book/show/33584231-the-strange-death-of-europe). He is Associate Editor at [The Spectator](https://www.spectator.co.uk/writer/douglas-murray).

He was a guest on [The Joe Rogan Experience 1538](https://open.spotify.com/episode/3z58RgmzyxqqNjrUdA0pA9) in September 2020 and was on Eric Weinsteins Podcast [The Portal 41 – Heroism 2020: Defence of Our Own Civilization](https://podcasts.apple.com/podcast/the-portal/id1469999563?i=1000495880717). This was a nearly _5 hours long_ conversation and the **best** podcast episode I listened to in 2020!

## Thomas Sowell

Instead of believing the narrative pushed by _Black Lives Matter_ I started listening to _Thomas Sowell_ after I learned about him in [Show Me the Evidence](https://youtu.be/nxygmc_SMAU). He is a conservative economist and fellow of _Hoover Institution_. And even though he is already 90 years old, he doesn’t stop fighting bad ideas. His [YouTube channel](youtube.com/channel/UCNdA_qZp4eQP5orJ1BsRBWA/) has numerous interesting talks for example [The Myths of Economic Inequality](https://youtu.be/mS5WYp5xmvI).

## John McWhorter

[John McWhorter](https://twitter.com/JohnHMcWhorter) is an American linguist associate professor of English and comparative literature at Columbia University. He is one of the reasonable voices fighting the woke movement. Some interesting talks with him are [America Has Never Been Less Racist](https://youtu.be/O3POpubeoIc), or [How Anti Racism Hurts Black People](https://youtu.be/mT2rlJe9cuU). With _Bret Weinstein_ he discussed [George Floyd Protests and Race in America](https://youtu.be/Y-FOCZVLTaw) and with _Coleman Hughes_ Has [Anti-Racism Become A New Religion?](https://youtu.be/UPiNiTwf5bM). He is a regular guest on _Glenn Loury’s_ podcast [Blogginheads.tv](https://bloggingheads.tv/) where they recently [called out Ibram X. Kendi](https://youtu.be/3qanSigtOO4), the author of _Anti Racism_ as the fraud he is.

## Glenn Loury

[Glenn Loury](https://twitter.com/GlennLoury) is an American economist, academic, and author. He became the first black tenured professor of economics in the history of Havard University at the age of 33.

He hosts The [Glenn Show](https://bloggingheads.tv/programs/current/glenn-show) on [Bloggingheads.tv](https://bloggingheads.tv/). _ReasonTV_ talked with him about racism in America in [‘We’re Being Swept Along by Hysteria’ About Racism in America](https://youtu.be/gp4fg9PWuhM).

## Coleman Hughes

[Coleman Hughes](https://colemanhughes.org/) is a fellow at the _Manhattan Institute_ for Policy Research, opinion columnist on issues related to race and racism at the online magazine [Quillette](https://quillette.com/author/coleman-cruz-hughes/), a fellow and contributing editor at _City Journal_, and host of the podcast [Conversations with Coleman](https://www.youtube.com/c/ColemanHughesOfficial/).

## Gad Saad

[Gad Saad](https://twitter.com/GadSaad) is Professor, Evolutionary Behavioral Scientist, and author of [The Parasitic Mind: How Infectious Ideas Are Killing Common Sense](https://www.goodreads.com/book/show/49680197-the-parasitic-mind).

He was a guest on many podcasts this year, for example [The Joe Rogan Experience 1557](https://open.spotify.com/episode/5zpR3pB69LX1AzGJTGjzER) or [Science Salon 136](https://podcasts.apple.com/de/podcast/science-salon/id1352860989?i=1000493742268) with _Michael Shemer_.

His podcast [The Saad Truth with Dr. Saad](https://podcasts.apple.com/de/podcast/the-saad-truth-with-dr-saad/id1516343565) had interesting guests for example [Noor Bin Ladin](https://podcasts.apple.com/de/podcast/the-saad-truth-with-dr-saad/id1516343565?i=1000496712005), the niece of _Osama bin Laden_ or [Robert O’Neill](https://podcasts.apple.com/de/podcast/the-saad-truth-with-dr-saad/id1516343565?i=1000498064323), the Navy SEAL that killed _Osama bin Laden_.

## Colin Wright

[Colin Wright](https://twitter.com/SwipeWright) is evolutionary biologist and [Managing Editor at Quillette](https://quillette.com/author/colin-wright/). He fights against [The New Evolution Deniers](https://quillette.com/2018/11/30/the-new-evolution-deniers/) and people that don’t believe in biology. His other articles [“Sex is NOT a Spectrum” – Colin Wright](https://audioboom.com/posts/7700095-sex-is-not-a-spectrum-colin-wright) and [Think Cancel Culture Doesn’t Exist? My Own ‘Lived Experience’ Says Otherwise](https://quillette.com/2020/07/30/think-cancel-culture-doesnt-exist-my-own-lived-experience-says-otherwise/) are a very good read.

He was a guest on [TRIGGERnometry](https://podcasts.apple.com/de/podcast/triggernometry/id1375568988?i=1000493942045) and multiple other podcasts.

## Glenn Greenwald

[Glenn Greenwald](https://twitter.com/ggreenwald) is a Journalist, Co-Founder of [The Intercept](https://theintercept.com/), a newspaper that forced him to resign in 2020, because they refused to publish his article critical of _Hunter Biden_. He was also the Journalist who met _Edward Snowden_ in Hong Kong in 2013 when he revealed the systemic overreach by the NSA.

Glenn Greenwald's resignation letter can be read on [My Resignation From The Intercept](https://greenwald.substack.com/p/my-resignation-from-the-intercept) and his forced resignation is a worrying case for free speech.

The censored article was published nevertheless on his new home on Substack: [Article on Joe and Hunter Biden Censored By The Intercept](https://greenwald.substack.com/p/article-on-joe-and-hunter-biden-censored).

He was a guest on [The Joe Rogan Experience 1556](https://open.spotify.com/episode/6ryXHBRMkkIlAK2vCtAE2v) and talked about [Nothing Trump Did Compares to the ‘Moral Evil’ of Bush’s and Obama’s Wars](https://youtu.be/3KMyoKa946s) on _ReasonTV_.

## Bari Weiss

Another center opinion column writer who was bullied into leaving her employer _The New York Times_ was [Bari Weiss](https://twitter.com/bariweiss). She writes about her experiences of harassment at the newspaper that forced her to leave the paper in her [Resignation Letter](https://www.bariweiss.com/resignation-letter). She was a guest on [The Joe Rogan Experience 1415](https://open.spotify.com/episode/1S6ZvgxOQWj8nIPsLdxjtD) in January 2020.

## Joseph Paul Watson

[Joseph Paul Watson](https://www.youtube.com/channel/UCittVh8imKanO_5KohzDbpg) is regularly smeared as a right-wing YouTuber and conspiracy theorist by people who dislike his political criticism and comments on social issues. But his well-researched commentary is on-point, uses often no words but lets the videos speak for themselves. His videos are a creative mix of facts, articles, memes, movie clips, and music. He is one of my favorite social commentators and an excellent observer of trends in society.

He criticized the similarities to communism in the BLM movement in [Cultural Revolution ✊](https://youtu.be/aEWjQOnrZRg) and [Ritual Public Shaming](https://youtu.be/olXipfCKUoo), exposed Biden’s new cabinet members of the military-industrial complex in [MEET THE NEW BOSS](https://youtu.be/o8-OtyUb9ok).

He exposed the hypocrisy of stars like _Lewis Hamilton_ in [Lewis Hamilton is an Idiot](https://youtu.be/kq2E7LBClnY) and technocrats in [They think you’re stupid](https://youtu.be/oQxaGm7eK4U) who would like to reorganize the society with a _Great Reset_.

I liked his take on corporate virtue signaling and Anti-Racism in [Things That Didn’t End Racism](https://youtu.be/pvFmju2Qhyw). He commented on the Islamic terrorist attacks in France in [Submission](https://youtu.be/XI1IpFKFSmk).

He criticized the insanity of overreaching Corona regulations, the rise of authoritarian and totalitarian tendencies by governments around the globe during the pandemic, and everyday insanity in [Attack of the Corona Karens](https://youtu.be/AA6_GuZOyAI), [i s o l a t i o n 👉👈](https://youtu.be/ilNBxQTCEWQ), [q u a r a n t i n e 🥱](https://youtu.be/-yFCdrqoK90), [COVID-1984](https://youtu.be/aCc2JsAUkwU), and [Send in the Clowns 🤡](https://youtu.be/cFCrs6uR-d8).

But his series **m o d e r n i t y** ([part 1](https://youtu.be/O_ftyZ0eb9A), [part 2](https://youtu.be/nvesu6oK4rU), [part 3](https://youtu.be/LF6yyuJGspM), and [part 4](https://youtu.be/w_ewUvSNT3w)) is my favorite and a dark mirror of society. Of course, the excesses he shines a light on are not the majority of people, but mostly the fringe sides of the political spectrum. But normal people need to be able to identify these bad ideas if they sneak into normality and call them out.

## Bridget Phetasy

[Bridget Phetasy](https://twitter.com/BridgetPhetasy) is an American writer, comedian, and broadcaster. She feels politically homeless and took on the fight against Woke ideology. She hosts the podcast [Dumpster Fire](https://www.youtube.com/user/phetasy) on YouTube.

She was interviewed by the satire magazine [The Babylon Bee](https://youtu.be/nziErnmPjwY) and on [TRIGGERnometry](https://youtu.be/gXOkekmSFZg) podcast in December 2020.

I loved how she mocked in [Naked Ballot Audition](https://youtu.be/uW5opNsGdD4) woke celebrities asking people to vote.

## Blue Collar Logic

[Blue Collar Logic](https://www.youtube.com/channel/UCd13O3aKVIhsFpbHt0vmFFA) are _Jason Siler_ and _Dave Morrison_ who use logic and reason to make political commentary. If you are a Liberal (as I am) and think your media consumption is balanced — which it isn’t — and want to listen to reasonable conservative arguments, this channel is the right one. No yelling, no partisan lies, but facts and logic.

## Buddy Brown

[Buddy Brown](https://www.youtube.com/channel/UCUGgU3vf-y8gHbzumbzSeMg) is a traditional country music artist and his songs are funny. But I started following his channel because he is authentic and honest. His political commentary is on the point and delivered with humor. And I love the Southern accent. 😂

His commentary _Just Sayin_ has topics like [How to not get shot by the police](https://youtu.be/iNQuDsHkBdQ), explains [privilege](https://youtu.be/_OOXuYhwktY), has some nice ideas for [what to do with looters](https://youtu.be/ZpN2xrHrskE) or [how to solve the parenting problem](https://youtu.be/hWqWmptFc-w).

And his song [I am 911](https://youtu.be/7Z2yCBnlvBA) is really funny. Other funny songs are [The Coronavirus Song](https://youtu.be/YDFkQ8FTTgw), [Kids That Never Got Spanked](https://youtu.be/DflVFjYaZQA), [Driving Through the Ghetto](https://youtu.be/xm-F9wKiH7E), or [Looters](https://youtu.be/EyiEgdiip9o).

## Journey

Even though the fantastic game [Journey](https://thatgamecompany.com/journey/) by _thatgamecompany_ was released in 2012 I had never heard of it before I saw [this homage](https://youtu.be/WxAQjEC-mXc) on YouTube. I bought it for 15 € for [PlayStation 4](https://store.playstation.com/product/EP9000-CUSA00470_00-JOURNEYPS4061115) and later again for [iOS](https://apps.apple.com/app/journey/id1445593893). I played it at least 15 times in 2020 and it’s my favorite game of all time.

The story of the game is told without text or speech, but with music and images. You play sometimes with other people, but it’s random if you meet people. It might be one person you follow along with the whole game, multiple, or none. The game has a system of rank visualized by the embroidery on the robe. The highest level is the white robe that you earn after finding all secrets in the game.

The music of the game was composed by _Austin Wintory_ and it is incredibly beautiful. My favorite song is _Apotheosis_. It was performed in concert at the [FMF 2018 Video Games Music Gala](https://youtu.be/XpT-92HS11I) in Poland.

After finishing the game I can recommend watching these short videos about [the story explanation](https://youtu.be/8DsK3eTrMGM), [artistry of game design](https://youtu.be/RJyGpVmkewU), and [the hidden story in the soundtrack](https://youtu.be/KeKnkaB0MBE).

## Ghost of Tsushima

Playing [Ghost of Tsushima](https://www.playstation.com/games/ghost-of-tsushima-ps4/) was a lot of fun. The story was interesting, the huge open-world huge had many different vegetations and seasons: Vast grasslands, yellow maple trees, foggy swamps, long beaches, cloudy mountain ranges with Shinto temples, burned battlefields, and destroyed villages. The game is pure [mono no aware](https://en.wikipedia.org/wiki/Mono_no_aware) (物の哀れ) and it’s hard to not constantly snap photos of the [stunning scenes](https://youtu.be/my62R7QUf00) while playing.

And the [soundtrack](https://music.apple.com/album/ghost-of-tsushima-music-from-the-video-game/1521542376) by _Ilan Eshkeri_ and _Shigeru Umebayashi_ supports the stunning landscapes for the right mood.

## Tina Guo

I discovered [Tina Guo](https://tinaguo.com/) after I watched her incredible Cello solo at the [FMF 2018 Video Games Music Gala](https://youtu.be/XpT-92HS11I) in Poland. She trained to play the Cello for more than 8 hours every day of her childhood.

She regularly streams training sessions on her [YouTube channel](https://www.youtube.com/user/demix500/) and likes playing movie music, game music, and Heavy Metal.

## Samara Ginsberg

Another Cellist I started following is [Samara Ginsberg](https://www.youtube.com/channel/UCSF5mJTarQx3ER3MhiR5QoQ). She plays a famous movie and TV show songs and arranges them together. I loved [Knight Rider for 8 cellos](https://youtu.be/eYf595EJAc4) and [Imperial March (Darth Vader’s Theme) for 8 cellos](https://youtu.be/W6ZaZWAy6D0), but she did over 20 videos in 2020.

---

**One last thing:** If 2020 has shown me _one_ thing it’s that you can’t and _never_ should trust institutions, media companies, or politicians to do the right thing.

People fought and died for the privileges we have: Personal autonomy, life, liberty, freedom, and the rule of law against overreaching government, authoritarian and totalitarian tendencies in politicians and media oligarchs.

Start thinking for yourself. The media censorship and blunt manipulation I witnessed this year are mind-boggling for anybody born before the internet was invented. We slowly give away our freedoms and rights for convenience or the feeling of security and control.

One way you can do this is by supporting a decentralized internet and open source. Fight back and speak up against censorship and authoritarian tendencies, reject any legislation against cryptography or for more surveillance, dismiss the usage of fear-driven politics, privacy violations, expose hypocrisy in politicians, celebrities, and influencers. Vote with your money and attention.

Start using tools that support privacy, security, and encryption. Use [Signal](https://www.signal.org/) or [Element](https://element.io/) instead of WhatsApp or Facebook Messenger. [Brave](https://brave.com/) or [Firefox](https://www.mozilla.org/firefox/browsers/) instead of Google Chrome and Microsoft Edge. [DuckDuckGo](https://duckduckgo.com/), [Startpage](https://startpage.com/), or [Ecosia](https://www.ecosia.org/) instead of Google. [ProtonMail](https://protonmail.com/) or [Tutanota](https://tutanota.com/) instead of Google Mail. [Mastodon](https://joinmastodon.org/) or [Parler](https://parler.com/) instead of Twitter. [Invidious](https://invidious.site/), [Odysee](https://odysee.com/), [BitChute](https://www.bitchute.com/), or [Rumble](https://rumble.com/) instead of YouTube.

[The Hated One](https://www.youtube.com/channel/UCjr2bPAyPV7t35MvcgT3W8Q) or [Rob Braxman](https://www.youtube.com/channel/UCYVU6rModlGxvJbszCclGGw) make videos with tips and tricks on how to protect your privacy online. [Restore Privacy](https://restoreprivacy.com/) is another good resource to learn about privacy and security. You don’t need to stop using the other services, but using alternatives will move power and money away from the big social media companies.

RSS readers are my favorite way to escape curated, biased, ad-driven streams of content by companies that have not my interest as a priority. I use [Feedly](https://feedly.com/) but there are [many other ways](https://zapier.com/blog/best-rss-feed-reader-apps/) to read the content you want. Brave released recently a [news feed](https://brave.com/brave-today/) for their browser that will soon support custom feed URLs.
