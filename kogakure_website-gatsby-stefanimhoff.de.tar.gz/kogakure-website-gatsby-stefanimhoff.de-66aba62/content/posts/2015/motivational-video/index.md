---
published: true
title: Motivational Video
author: Stefan Imhoff
date: 2015-08-14T18:15:00+00:00
description: Last week I found a really inspirational film on YouTube, focusing on Motivation. But because it was poorly quoted, I tried to find the quotes and fix the issue.
categories:
  - film
  - quote
---

## Why Do We Fall?

Last week I found an inspirational film on YouTube, focusing on motivation. It’s a good example of creating something good out of the work of others. The film uses clips and quotes from a broad variety of people and uses music from movies.

![Why Do We Fall? – Motivational Video](./motivational-video.jpg)

The film _[Why Do We Fall? – Motivational Video](https://youtu.be/mgmVOuLgFB0)_ by _Mateusz M_ is quite successful and was watched until now over **30 million** times.

The one thing though, which I didn’t like was how the sources where quoted. Just a plain comma-separated list of people and music out of context, missing where the quote was from or who said it foremost. This post has the aim to fix this.

Sometimes it was hard to find out in which interview exactly a quote was said. If you have more information, please contact me and I’ll update the sources.

## Music

Music is easy, as it was quoted quite good below the film on YouTube:

1. (00:00) Corynorhinus – Hans Zimmer, James Newton Howard (Batman Begins)
2. (01:07) Time – Hans Zimmer (Inception)
3. (03:17) Barbastella – Hans Zimmer, James Newton Howard (Batman Begins)
4. (04:02) Why Do We Fall? – Hans Zimmer (The Dark Knight Rises)
5. (05:23) Mark Petrie: Polar Shift

## Quotes

I wrote down the quotes from different movies, interviews, or speeches with as much context as possible. For interviews, it was hard to find out, where exactly it was quoted because most YouTube videos are missing the information.

Additionally I <mark>highlight</mark> the parts used in the film.

---

<Blockquote
  author="Rocky Balboa (Sylvester Stallone)"
  source="Rocky Balboa (2006)"
>
  <p>
    I’d hold you up to say to your mother,{" "}
    <q>
      this kid’s gonna be the best kid in the world. This kid’s gonna be
      somebody better than anybody I ever knew.
    </q>{" "}
    And you grew up good and wonderful. It was great just watching you, every
    day was like a privilege. Then the time comes for you to be your own man and
    take on the world, and you did. But somewhere along the line, you changed.
    You stopped being you. You let people stick a finger in your face and tell
    you you’re no good. And when things got hard, you started looking for
    something to blame, like a big shadow.{" "}
    <mark>
      Let me tell you something you already know. The world ain’t all sunshine
      and rainbows. It’s a very mean and nasty place and I don’t care how tough
      you are it will beat you to your knees and keep you there permanently if
      you let it. You, me, or nobody is gonna hit as hard as life. But it ain’t
      about how hard you hit. It’s about how hard you can get hit and keep
      moving forward. How much you can take and keep moving forward. That’s how
      winning is done!
    </mark>{" "}
    Now if you know what you’re worth then go out and get what you’re worth. But
    ya gotta be willing to take the hits, and not pointing fingers saying you
    ain’t where you wanna be because of him, or her, or anybody! Cowards do that
    and that ain’t you! You’re better than that! I’m always gonna love you no
    matter what. No matter what happens. You’re my son and you’re my blood.
    You’re the best thing in my life. But until you start believing in yourself,
    ya ain’t gonna have a life. Don’t forget to visit your mother.
  </p>
</Blockquote>

---

<Blockquote
  author="Lance Armstrong"
  source="It’s Not About the Bike: My Journey Back to Life. New York: Berkley Books (2001); Quoted by Eric Thomas"
>
  <p>
    <mark>
      Pain is temporary. It may last a minute, or an hour, or a day, or a year,
      but eventually it will subside and something else will take its place. If
      I quit, however, it lasts forever.
    </mark>
  </p>
</Blockquote>

---

<Blockquote author="Tony D’Amato (Al Pacino)" source="Any Given Sunday (1999)">
  <p>
    I don’t know what to say, really. Three minutes to the biggest battle of our
    professional lives. All comes down to today, and either, we heal as a team,
    or we’re gonna crumble. Inch by inch, play by play. Until we’re finished.
    We’re in hell right now, gentlemen. Believe me. And, we can stay here, get
    the shit kicked out of us, or we can fight our way back into the light. We
    can climb outta hell… one inch at a time. Now I can’t do it for ya, I’m too
    old. I look around, I see these young faces and I think, I mean, I’ve made
    every wrong choice a middle-aged man can make. I, uh, I’ve pissed away all
    my money, believe it or not. I chased off anyone who’s ever loved me. And
    lately, I can’t even stand the face I see in the mirror. You know, when you
    get old, in life, things get taken from you. I mean, that’s… that’s… that’s
    a part of life. But, you only learn that when you start losin’ stuff. You
    find out life’s this game of inches, so is football. Because in either game
    - life or football -{" "}
    <mark>
      the margin for error is so small. I mean, one half a step too late or too
      early and you don’t quite make it. One-half second too slow, too fast and
      you don’t quite catch it. The inches we need are everywhere around us.
      They’re in every break of the game, every minute, every second.
    </mark>{" "}
    On this team, we fight for that inch. On this team, we tear ourselves and
    everyone else around us to pieces for that inch. We claw with our
    fingernails for that inch. Because we know when add up all those inches,
    that’s gonna make the fucking difference between winning and losing! Between
    living and dying! I’ll tell you this, in any fight, it’s the guy who's
    willing to die whose gonna win that inch. And I know, if I’m gonna have any
    life anymore it’s because I’m still willing to fight and die for that inch,
    because that’s what living is, the six inches in front of your face. Now I
    can’t make you do it. You’ve got to look at the guy next to you, look into
    his eyes. Now I think ya going to see a guy who will go that inch with you.
    Your gonna see a guy who will sacrifice himself for this team because he
    knows when it comes down to it your gonna do the same for him. That’s a
    team, gentlemen, and either, we heal, now, as a team, or we will die as
    individuals. That’s football guys, that’s all it is. Now, what are you gonna
    do?
  </p>
</Blockquote>

---

<Blockquote
  author="Christopher Gardner (Will Smith)"
  source="The Pursuit of Happyness (2006)"
>
  <p>
    <mark>
      You got a dream… You gotta protect it. People can’t do somethin’
      themselves, they wanna tell you you can’t do it. If you want somethin’, go
      get it. Period.
    </mark>
  </p>
</Blockquote>

---

<Blockquote author="Arnold Schwarzenegger" source="6 Secrets to Success">
  <p>
    <mark>Don’t be afraid to fail.</mark> Anything that I’ve ever attempted I
    was always willing to fail.{" "}
    <mark>You can’t always win, but don’t be afraid of making decisions.</mark>{" "}
    You can’t be paralyzed by fear of failure or you will never push yourself.
    You keep pushing because you believe in yourself and in your vision and you
    know that it is the right thing to do, success will come.
  </p>
</Blockquote>

---

<Blockquote author="Will Smith" source="Interview">
  <p>
    […] The first step, before anybody else in the world believes it is you have
    to believe it. There’s no reason to have a plan B because it distracts from
    plan A. I think that there’s a certain delusional quality that all
    successful people have to have. You have to believe that something different
    than what has happened for the past 50 million years of history,{" "}
    <mark>you have to believe that something different can happen.</mark>
  </p>
  <p>
    Confucius said that{" "}
    <mark>
      he who said he can and he who says he can’t are both usually right.
    </mark>{" "}
    […]
  </p>
</Blockquote>

---

<Blockquote
  author="Eric Thomas"
  source="How Bad Do You Want It Part 1, Secrets to Success Part 1, Heart of Detroit Mixtape, No Sleep (Produced by Mikestro Music)"
>
  <p>
    When I went to college, guys were way smarter than me. 4.0’s, 3.0’s, they
    went to the Ivy League schools, came to oakwood from these great schools.
    Most of them are not doing what I’m doing, why? Because it’s not about where
    you come from. It’s about heart.
  </p>
  <p>
    You come to a place where you know being smart ain’t enough. You got to have
    heart.
  </p>
  <p>
    That’s why I wake up every morning at two o clock, two-thirty, coz I got my
    momma counting on me, I got my sister counting on me. I got my son and my
    daughter counting on me. I got a world that gets up every morning and
    watches me.
  </p>
  <p>
    Stop being this high school drop out. Stop giving up, stop sleeping on the
    street, stop walking up and down Finkle avenue like you ain’t got none and
    get your GED. Stop being afraid to take a test. Stop being afraid to go to
    college coz your daddy didn’t go and your mommy didn’t go.
  </p>
  <p>
    I don’t do well in math, your right. you ain’t never studied. I’m not good
    at writing, coz you have never written before! You can get to a writing
    class and you got tutor after tutor, resource after resource. The problem
    is, you ain’t never felt no pain before! You’re soft! It’s a soft
    generation. you quit on everything.
  </p>
  <p>
    You have to give it everything you’ve got! No more TV, no more parties, no
    more playing. If you have a 4.0 what you need to be doing is studying!
  </p>
  <p>
    And when you get to the point where all you want to do is be successful as
    bad as you want to breathe, then you will be successful! And I’m here to
    tell you number one{" "}
    <mark>
      that most of you say you want to be successful but you don’t want it bad,
      you just kinda want it. You don’t want it badder than you want to party,
      you don’t want it as much as you want to be cool. Most of you don’t want
      success as much as you want to sleep!
    </mark>{" "}
    Some of you love sleep more than you love success!
  </p>
  <p>
    And I’m here to tell you today if you’re going to be successful, you’ve got
    to be willing to give up sleep!
  </p>
  <p>
    So you say you want it as bad as you want to breathe, then it’s showtime!
    It’s examination time! It’s time to get tested! To test your will, your
    endurance, it’s time to test your heart, to test your limits!
  </p>
  <p>
    But I’m exactly where I want to be because I realize, I’ve got to commit my
    very being to this thing. I got to breathe it, I got to eat it, I’ve got to
    sleep it. And until you get there you will never be successful in life.
  </p>
  <p>But once you get there I guarantee you the world is yours.</p>
  <p>So work hard and you can have whatever it is you want!</p>
</Blockquote>

---

<Blockquote
  author="Marianne Williamson"
  source="A Return to Love: Reflections on the Principles of A Course in Miracles; Ch. 7; Section 3 (1992); p. 190. Quoted by Timo Cruz (Rick Gonzalez); Coach Carter (2005)"
>
  <p>
    <mark>
      Our deepest fear is not that we are inadequate. Our deepest fear is that
      we are powerful beyond measure. It is our light, not our darkness that
      most frightens us.
    </mark>{" "}
    We ask ourselves, Who am I to be brilliant, gorgeous, talented, and
    fabulous? Actually, who are you not to be? You are a child of God. Your
    playing small does not serve the world. There is nothing enlightened about
    shrinking so that other people will not feel insecure around you. We are all
    meant to shine, as children do. We were born to make manifest the glory of
    God that is within us. It is not just in some of us; it is in everyone and
    as we let our own light shine, we unconsciously give others permission to do
    the same. As we are liberated from our own fear, our presence automatically
    liberates others.
  </p>
</Blockquote>

---

<Blockquote author="Arnold Schwarzenegger" source="6 Secrets to Success">
  <p>
    Many young people are getting so much advice from their parents and from
    their teachers and from everyone. But what is most important is that you{" "}
    <mark>
      have to dig deep down, dig deep down and ask yourselves, who do you want
      to be?
    </mark>{" "}
    Not what, but who.{" "}
    <mark>
      Figuring out for yourselves what makes you happy, no matter how crazy it
      may sound to the people.
    </mark>
  </p>
</Blockquote>

---

<Blockquote author="Will Smith" source="Interview">
  <p>
    There’s a redemptive power that making a choice has rather than feeling like
    you’re an effect to all the things that are happening.{" "}
    <mark>
      Make a choice. Just decide what it’s gonna be, who you’re gonna be, how
      you are going to do it. Just decide.
    </mark>{" "}
    And from that point, the universe will get out of your way.
  </p>
</Blockquote>

---

<Blockquote author="Derrick Rose" source="Interview">
  <p>
    The way I look at it within myself,{" "}
    <mark>
      why not? Why can’t I be the MVP of the League? Why can’t I be the best
      player in the League? I don’t see why-why-why can’t I do that?
    </mark>{" "}
    I think I work hard, I think I dedicate myself to the game and sacrifice a
    lot of things at a young age and I know if I continue to do good, what I can
    get out of it and if that’s me going out or doing whatever, I’m willing to
    do it because I know in the long run, it’s going to help me.
  </p>
</Blockquote>

---

<Blockquote
  author="Rocky Balboa (Sylvester Stallone)"
  source="Rocky Balboa (2006)"
>
  <p>
    <mark>
      What is it you said to the kid? It ain’t about how hard you can hit; it’s
      about how hard you can get hit and keep moving forward… How much you can
      take and keep moving forward. Now get up, get up and don’t ever give up.
    </mark>
  </p>
</Blockquote>

---

<Blockquote author="Tony D’Amato (Al Pacino)" source="Any Given Sunday (1999)">
  <p>
    I don’t know what to say, really. Three minutes to the biggest battle of our
    professional lives. All comes down to today, and either, we heal as a team,
    or we’re gonna crumble. Inch by inch, play by play. Until we’re finished.
    We’re in hell right now, gentlemen. Believe me. And,{" "}
    <mark>
      we can stay here, get the shit kicked out of us, or we can fight our way
      back into the light. We can climb outta hell… one inch at a time.
    </mark>{" "}
    Now I can’t do it for ya, I’m too old. I look around, I see these young
    faces and I think, I mean, I’ve made every wrong choice a middle-aged man
    can make. I, uh, I’ve pissed away all my money, believe it or not. I chased
    off anyone who’s ever loved me. And lately, I can’t even stand the face I
    see in the mirror. You know, when you get old, in life, things get taken
    from you. I mean, that’s… that’s… that’s a part of life. But, you only learn
    that when you start losin’ stuff. You find out life’s this game of inches,
    so is football. Because in either game - life or football - the margin for
    error is so small. I mean, one half a step too late or too early and you
    don’t quite make it. One-half second too slow, too fast and you don’t quite
    catch it. The inches we need are everywhere around us. They’re in every
    break of the game, every minute, every second. On this team, we fight for
    that inch. On this team, we tear ourselves and everyone else around us to
    pieces for that inch. We claw with our fingernails for that inch. Because we
    know when add up all those inches, that’s gonna make the fucking difference
    between winning and losing! Between living and dying! I’ll tell you this, in
    any fight, it’s the guy who's willing to die whose gonna win that inch. And
    I know, if I’m gonna have any life anymore it’s because I’m still willing to
    fight and die for that inch, because that’s what living is, the six inches
    in front of your face. Now I can’t make you do it. You’ve got to look at the
    guy next to you, look into his eyes. Now I think ya going to see a guy who
    will go that inch with you. Your gonna see a guy who will sacrifice himself
    for this team because he knows when it comes down to it your gonna do the
    same for him. That’s a team, gentlemen, and either, we heal, now, as a team,
    or we will die as individuals. That’s football guys, that’s all it is. Now,
    what are you gonna do?
  </p>
</Blockquote>

---

<Blockquote
  author="Eric Thomas"
  source="How Bad Do You Want It Part 1, Secrets to Success Part 1, Heart of Detroit Mixtape, No Sleep (Produced by Mikestro Music)"
>
  <p>
    The most important thing is this:{" "}
    <mark>
      to be able at any moment - to sacrifice what you are, for what you will
      become!
    </mark>
  </p>
</Blockquote>

---

<Blockquote
  author="Eric Thomas"
  source="How Bad Do You Want It Part 1, Secrets to Success Part 1, Heart of Detroit Mixtape, No Sleep (Produced by Mikestro Music)"
>
  <p>
    <mark>
      Most of you won’t be successful because when you’re studying and you get
      tired, you quit.
    </mark>
  </p>
</Blockquote>

---

<Blockquote
  author="Eric Thomas"
  source="How Bad Do You Want It Part 1, Secrets to Success Part 1, Heart of Detroit Mixtape, No Sleep (Produced by Mikestro Music)"
>
  <p>
    When I went to college, guys were way smarter than me. 4.0’s, 3.0’s, they
    went to the Ivy League schools, came to oakwood from these great schools.
    Most of them are not doing what I’m doing, why? Because it’s not about where
    you come from. It’s about heart.
  </p>
  <p>
    You come to a place where you know being smart ain’t enough. You got to have
    heart.
  </p>
  <p>
    That’s why I wake up every morning at two o clock, two-thirty, coz I got my
    momma counting on me, I got my sister counting on me. I got my son and my
    daughter counting on me. I got a world that gets up every morning and
    watches me.
  </p>
  <p>
    Stop being this high school drop out. Stop giving up, stop sleeping on the
    street, stop walking up and down Finkle avenue like you ain’t got none and
    get your GED. Stop being afraid to take a test. Stop being afraid to go to
    college coz your daddy didn’t go and your mommy didn’t go.
  </p>
  <p>
    <mark>
      I don’t do well in math, your right. you ain’t never studied. I’m not good
      at writing, coz you have never written before!
    </mark>{" "}
    You can get to a writing class and you got tutor after tutor, resource after
    resource. The problem is, you ain’t never felt no pain before! You’re soft!
    It’s a soft generation. you quit on everything.
  </p>
  <p>
    You have to give it everything you’ve got! No more TV, no more parties, no
    more playing. If you have a 4.0 what you need to be doing is studying!
  </p>
  <p>
    And when you get to the point where all you want to do is be successful as
    bad as you want to breathe, then you will be successful! And I’m here to
    tell you number one that most of you say you want to be successful but you
    don’t want it bad, you just kinda want it. You don’t want it badder than you
    want to party, you don’t want it as much as you want to be cool. Most of you
    don’t want success as much as you want to sleep! Some of you love sleep more
    than you love success!
  </p>
  <p>
    And I’m here to tell you today if you’re going to be successful, you’ve got
    to be willing to give up sleep!
  </p>
  <p>
    So you say you want it as bad as you want to breathe, then it’s showtime!
    It’s examination time! It’s time to get tested! To test your will, your
    endurance, it’s time to test your heart, to test your limits!
  </p>
  <p>
    But I’m exactly where I want to be because I realize, I’ve got to commit my
    very being to this thing. I got to breathe it, I got to eat it, I’ve got to
    sleep it. And until you get there you will never be successful in life.
  </p>
  <p>But once you get there I guarantee you the world is yours.</p>
  <p>So work hard and you can have whatever it is you want!</p>
</Blockquote>

---

<Blockquote author="Will Smith" source="Interview">
  <p>
    The separation of talent and skill is one of the greatest misunderstood
    concepts for people who are trying to excel, who have dreams, who want to do
    things.{" "}
    <mark>
      Talent you have naturally. Skill is only developed by hours and hours and
      hours of beating on your craft.
    </mark>
  </p>
</Blockquote>

---

<Blockquote author="Will Smith" source="Interview">
  <p>
    <mark>
      If you’re not making someone else’s life better, then you’re wasting your
      time.
    </mark>{" "}
    Your life will become better by making other lives better.
  </p>
</Blockquote>

---

<Blockquote
  author="Eric Thomas"
  source="How Bad Do You Want It Part 1, Secrets to Success Part 1, Heart of Detroit Mixtape, No Sleep (Produced by Mikestro Music)"
>
  <p>
    <mark>
      Don’t cry to give up! Cry to keep going! Don’t cry to quit! You already in
      pain, you already hurt! Get a reward from it!
    </mark>
  </p>
</Blockquote>

---

<Blockquote
  author="Rocky Balboa (Sylvester Stallone)"
  source="Rocky Balboa (2006)"
>
  <p>
    I’d hold you up to say to your mother,{" "}
    <q>
      this kid’s gonna be the best kid in the world. This kid’s gonna be
      somebody better than anybody I ever knew.
    </q>{" "}
    And you grew up good and wonderful. It was great just watching you, every
    day was like a privilege. Then the time comes for you to be your own man and
    take on the world, and you did. But somewhere along the line, you changed.
    You stopped being you. You let people stick a finger in your face and tell
    you you’re no good. And when things got hard, you started looking for
    something to blame, like a big shadow. Let me tell you something you already
    know. The world ain’t all sunshine and rainbows. It’s a very mean and nasty
    place and I don’t care how tough you are it will beat you to your knees and
    keep you there permanently if you let it. You, me, or nobody is gonna hit as
    hard as life. But it ain’t about how hard you hit. It’s about how hard you
    can get hit and keep moving forward. How much you can take and keep moving
    forward. That’s how winning is done!{" "}
    <mark>
      Now if you know what you’re worth then go out and get what you’re worth.
      But ya gotta be willing to take the hits, and not pointing fingers saying
      you ain’t where you wanna be because of him, or her, or anybody! Cowards
      do that and that ain’t you! You’re better than that!
    </mark>{" "}
    I’m always gonna love you no matter what. No matter what happens. You’re my
    son and you’re my blood. You’re the best thing in my life. But until you
    start believing in yourself, ya ain’t gonna have a life. Don’t forget to
    visit your mother.
  </p>
</Blockquote>

---

<Blockquote author="Ray Lewis" source="Interview">
  <p>
    I can’t thank you guys for the opportunity. I’m gonna tell you something if
    tomorrow wasn’t promised… what would you give for today? Forget everything
    else. Forget that there was any sunlight left what would you spend today.
    Thinking about? Yourself? Or the man that’s beside you or the man that you
    know you’d give everything in your heart for? We get one opportunity in
    life. One chance in life. To do whatever you gonna do to lay our foundation,
    to make whatever mark you gonna make whatever legacy you’re going to leave
    your legacy! And it’s found through effort wins and losses come a dime a
    dozen. But effort? Nobody can judge effort! Because effort is between you,
    and you! Effort ain’t got nothing to do with nobody else. So that team that
    thinks they’re ready to see you? They think what they’ve seen on film? They
    ain’t saw what film shows!{" "}
    <mark>
      Because every day is a new day! Every moment is a new moment! So now
      you’ve gotta go out and show them that I’m a different creature NOW
    </mark>{" "}
    than I was five minutes ago. Because I’m pissed off. For Greatness! Because
    if you ain’t pissed off for greatness, that means you okay with being
    mediocre. And ain’t no man in here that okay with being just basic. So let’s
    do what we do! Tonight!
  </p>
</Blockquote>

---

<Blockquote
  author="Muhammed Ali"
  source="Speech before his match against George Foreman (1974)"
>
  <p>
    Imma show you, how great I am. Last night, I cut the light off in my bedroom
    and was in bed before the room was dark. Imma show you, how great I am. Only
    last week, I murdered a rock, injured a stone, hospitalized a brick. I’m so
    mean, I make medicine sick. Imma show you, how great I am. This kid’s gonna
    be the best kid in the world. This kid’s gonna be somebody better than
    anybody I ever knew. Imma show you, how great I am. I have wrestled with an
    alligator, I done tussled with a whale, I done handcuffed lightnin’, thrown
    thunder in jail. Imma show you, how great I am. All you chumps are gonna bow
    when I whoop him, all of you. I know you got him, I know you’ve got him
    picked, but the man’s in trouble. <mark>Imma show you how great I am.</mark>
  </p>
</Blockquote>

---

<Blockquote
  author="Hynkel - Dictator of Tomania (Charlie Chaplin)"
  source="The Great Dictator (1940)"
>
  <p>
    I’m sorry, but I don’t want to be an emperor. That’s not my business. I
    don’t want to rule or conquer anyone. I should like to help everyone - if
    possible: Jew, Gentile, black man, white. We all want to help one another.
    Human beings are like that. We want to live by each other’s happiness - not
    by each other’s misery. We don’t want to hate and despise one another. In
    this world, there is room for everyone. And the good earth is rich and can
    provide for everyone. The way of life can be free and beautiful, but we have
    lost the way.
  </p>
  <p>
    Greed has poisoned men’s souls, has barricaded the world with hate, has
    goose-stepped us into misery and bloodshed. We have developed speed, but we
    have shut ourselves in. Machinery that gives abundance has left us in want.
    Our knowledge has made us cynical. Our cleverness, hard, and unkind. We
    think too much and feel too little. More than machinery we need humanity.
    More than cleverness we need kindness and gentleness. Without these
    qualities, life will be violent and all will be lost.
  </p>
  <p>
    The aeroplane and the radio have brought us closer together. The very nature
    of these inventions cries out for the goodness in men, cries out for
    universal brotherhood, for the unity of us all. Even now my voice is
    reaching millions throughout the world, millions of despairing men, women,
    and little children, victims of a system that makes men torture and imprison
    innocent people.
  </p>
  <p>
    To those who can hear me, I say - do not despair. The misery that is now
    upon us is but the passing of greed, the bitterness of men who fear the way
    of human progress. The hate of men will pass, and dictators die, and the
    power they took from the people will return to the people. And so long as
    men die, liberty will never perish.
  </p>
  <p>
    Soldiers! don’t give yourselves to brutes, men who despise you, enslave you,
    who regiment your lives, tell you what to do, what to think, and what to
    feel! Who drill you, diet you, treat you like cattle, use you as cannon
    fodder. Don’t give yourselves to these unnatural men, machine men with
    machine minds and machine hearts! You are not machines! You are not cattle!
    You are men! You have the love of humanity in your hearts! You don’t hate!
    Only the unloved hate, the unloved and the unnatural! Soldiers! Don’t fight
    for slavery! Fight for liberty!
  </p>
  <p>
    <mark>
      In the 17th Chapter of St Luke it is written: “the Kingdom of God is
      within man” Not one man nor a group of men but in all men! In you! You,
      the people have the power, the power to create machines. The power to
      create happiness! You, the people, have the power to make this life free
      and beautiful, to make this life a wonderful adventure.
    </mark>
  </p>
  <p>
    Then, in the name of democracy, let us use that power, let us all unite. Let
    us fight for a new world, a decent world that will give men a chance to
    work, that will give youth a future and old age a security. By the promise
    of these things, brutes have risen to power. But they lie! They do not
    fulfill that promise. They never will!
  </p>
  <p>
    Dictators free themselves but they enslave the people! Now let us fight to
    fulfill that promise! Let us fight to free the world, to do away with
    national barriers, to do away with greed, with hate and intolerance. Let us
    fight for a world of reason, a world where science and progress will lead to
    all men’s happiness. Soldiers! in the name of democracy, let us all unite!
  </p>
</Blockquote>

---

<Blockquote author="Tony D’Amato (Al Pacino)" source="Any Given Sunday (1999)">
  <p>
    I don’t know what to say, really. Three minutes to the biggest battle of our
    professional lives. All comes down to today, and either, we heal as a team,
    or we’re gonna crumble. Inch by inch, play by play. Until we’re finished.
    We’re in hell right now, gentlemen. Believe me. And, we can stay here, get
    the shit kicked out of us, or we can fight our way back into the light. We
    can climb outta hell… one inch at a time. Now I can’t do it for ya, I’m too
    old. I look around, I see these young faces and I think, I mean, I’ve made
    every wrong choice a middle-aged man can make. I, uh, I’ve pissed away all
    my money, believe it or not. I chased off anyone who’s ever loved me. And
    lately, I can’t even stand the face I see in the mirror. You know, when you
    get old, in life, things get taken from you. I mean, that’s… that’s… that’s
    a part of life. But, you only learn that when you start losin’ stuff. You
    find out life’s this game of inches, so is football. Because in either game
    - life or football - the margin for error is so small. I mean, one half a
    step too late or too early and you don’t quite make it. One-half second too
    slow, too fast and you don’t quite catch it. The inches we need are
    everywhere around us. They’re in every break of the game, every minute,
    every second. On this team, we fight for that inch. On this team, we tear
    ourselves and everyone else around us to pieces for that inch. We claw with
    our fingernails for that inch. Because we know when add up all those inches,
    that’s gonna make the fucking difference between winning and losing! Between
    living and dying! I’ll tell you this, in any fight, it’s the guy who's
    willing to die whose gonna win that inch. And I know, if I’m gonna have any
    life anymore it’s because I’m still willing to fight and die for that inch,
    because that’s what living is, the six inches in front of your face. Now I
    can’t make you do it. You’ve got to look at the guy next to you, look into
    his eyes. Now I think ya going to see a guy who will go that inch with you.
    Your gonna see a guy who will sacrifice himself for this team because he
    knows when it comes down to it your gonna do the same for him. That’s a
    team, gentlemen, and either, we heal, now, as a team, or we will die as
    individuals. That’s football guys, that’s all it is.{" "}
    <mark>Now, what are you gonna do?</mark>
  </p>
</Blockquote>

---

<Blockquote author="Michael Jordan" source="Interview">
  <p>
    Never say never,{" "}
    <mark>because limits, like fears, are often just an illusion.</mark>
  </p>
</Blockquote>
