---
published: true
title: Wokeness is just Facism
date: 2021-04-06T18:00:00+02:00
author: Stefan Imhoff
description: James Lindsay on why Wokeness is just Nazi ideology, with Neo-Marxist approach to Communism, and Classis Corporate Fascism.
categories:
  - quote
---

_James Lindsay_ talks on his podcast [New Discourses](https://newdiscourses.com/) in [There Is No Good Part of Hitler’s Mein Kampf](https://podcasts.apple.com/podcast/new-discourses/id1499880546?i=1000514538341) about the [Grievance studies affair](https://en.wikipedia.org/wiki/Grievance_studies_affair) where he, _Helen Pluckrose_, and _Peter Boghossian_ released a bunch of fake papers to academic journals in cultural, queer, race, gender, fat, and sexuality studies to show the ideological corruption in academia. Several of these papers were accepted, including the most quoted paper where they rewrote a chapter of Adolf Hitler’s _Mein Kampf_ in feminist language which was accepted with praise.

He made this fascinating comparison about Wokeness:

<Blockquote author="James Lindsay" source="There Is No Good Part of Hitler’s Mein Kampf, 57:05" sourceUrl="https://podcasts.apple.com/podcast/new-discourses/id1499880546?i=1000514538341">

Hitlers Anti-Semitism, or Anti-Semitism in general, is a conspiracy theory that says: <q>Hey, look, there is this race, they are part of a culture and they have erected themselves as the privileged members who hoard resources and they have these nefarious plots to keep other people down and who maintain their own dominance and control and they help each other but they don’t help others.</q> It’s his whole idea, right? And he has got this grievance against it since that’s causing Germany to be terrible.

Guess what? We come over to Wokeness: <q>There is this racial group called white people […] and they have all the power and privilege and they keep it for themselves and they hoard resources and they try to keep other races down and keep them out and so they can maintain their own power and dominance.</q>

It’s the same wormed-over BS. It’s not even just the politics of grievance. Wokeism is actually just wormed-over Nazi ideology that's been tied in somehow into this weird mishmash with Neo-Marxists approach to Communism and outright Classic Corporate Fascism. It’s like all the worst ideas of the 20s century mashed together and then unleashed on the world.

</Blockquote>
