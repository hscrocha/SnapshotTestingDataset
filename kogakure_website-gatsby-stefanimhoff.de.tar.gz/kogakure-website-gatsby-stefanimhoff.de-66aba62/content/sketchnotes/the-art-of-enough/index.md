---
title: The Art of Enough
date: "2017-05-25T13:06:00"
published: true
---

<div>

Sketchnote for the article [The Art of Enough](https://experiencelife.com/article/the-art-of-enough/), about consumption, spending mindful, and buying quality.

</div>

![The Art of Enough](1.jpg)
