---
title: Weight Idea
date: "2017-06-11T15:00:00"
published: true
---

<div>

Some ideas I had about how to visualize weights for my training diary.

</div>

![Weight Idea](1.jpg)
