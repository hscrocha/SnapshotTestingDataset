---
title: Being a Good Listener
date: "2017-07-22T11:58:00"
published: true
---

<div>

Sketchnote of the video [Being A Good Listener](https://youtu.be/-BdbiZcNBXg) by **The School of Life**. Notes in German, but the video is in English.

</div>

![Being a Good Listener](1.jpg)
