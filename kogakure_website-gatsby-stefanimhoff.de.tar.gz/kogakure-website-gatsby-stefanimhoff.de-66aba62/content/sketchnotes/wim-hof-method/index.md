---
title: The Wim Hof Method
date: "2017-05-28T12:43:00"
published: true
---

<div>

Sketchnote of the **Wim Hof Method**. A breathing technique, which allowed him to hold 26 world records of the extreme kind: Walking on Mount Everest in shorts, being dug in ice for hours.

</div>

![The Wim Hof Method](1.jpg)
