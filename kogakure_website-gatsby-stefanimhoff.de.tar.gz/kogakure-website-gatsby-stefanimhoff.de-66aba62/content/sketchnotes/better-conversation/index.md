---
title: Better Conversation
date: "2017-06-11T14:57:00"
published: true
---

<div>

A Sketchnote I did of the TED Talk **Celeste Headlee**: [10 ways to have a better conversation](https://www.ted.com/talks/celeste_headlee_10_ways_to_have_a_better_conversation).

</div>

![Better Conversation](1.jpg)
