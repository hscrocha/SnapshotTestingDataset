---
title: How to Speak So That People Want to Listen
date: "2017-06-01T21:01:00"
published: true
---

<div>

Sketchnote of the TED-Talk [How to speak so that people want to listen](https://www.ted.com/talks/julian_treasure_how_to_speak_so_that_people_want_to_listen#t-185141) by **Julian Treasure**.

</div>

![How to Speak So That People Want to Listen](1.jpg)
