---
title: Bikablo Practice
date: "2017-05-06T11:36:00"
published: true
---

<div>

Practicing containers and lettering in my practice sketchbook. Vocabulary from the [bikablo® books](https://bikablo.com/). Highlighting and shadows are done with the fantastic [fineOne brush pen](https://de.neuland.com/marker-stifte/neuland-marker/neuland-fineone-art-pinselspitze-0-5-5-mm-einzelfarben.html?c=725).

</div>

![Bikablo Practice 1](1.jpg)
![Bikablo Practice 2](2.jpg)
![Bikablo Practice 3](3.jpg)
![Bikablo Practice 4](4.jpg)
![Bikablo Practice 5](5.jpg)
