import React, { useState } from 'react';
import ButtonsContainer from './Buttons';
import calculate from '../logic/calculate';
import './styles/CalculatorPage.css';

const Calculator = () => {
  const [state, setState] = useState(0);

  const handleClick = (event) => {
    setState((state) => calculate(state, event.target.textContent));
  };

  return (
    <div className="calculatorPageContainer">
      <h2 className="calculatorTitle">Let&apos;s do some math!</h2>
      <div className="container">
        <div className="display">{state.next || state.total || 0}</div>
        <ButtonsContainer handleClick={handleClick} />
      </div>
    </div>
  );
};

export default Calculator;
