const NotMatch = () => (
  <h2>No page match for this url</h2>
);

export default NotMatch;
