## Copyright 2021, [Houssam Hichami & Francis Ugorji]

###### Please delete this line and the next one
###### APP TYPE can be a webpage/website, a web app, a software and so on

Permission is hereby granted, free of charge, to any person obtaining a copy of this [https://github.com/redwing555/SpaceX-Project] and associated documentation files, to deal in the [https://github.com/redwing555/SpaceX-Project] without restriction, including without limitation the rights to use, copy, modify, merge, publish, distribute, sublicense, and/or sell copies of the [https://github.com/redwing555/SpaceX-Project], and to permit persons to whom the [https://github.com/redwing555/SpaceX-Project] is furnished to do so, subject to the following conditions:

The above copyright notice and this permission notice shall be included in all copies or substantial portions of the [https://github.com/redwing555/SpaceX-Project].

THE [https://github.com/redwing555/SpaceX-Project] IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY, FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM, OUT OF OR IN CONNECTION WITH THE [https://github.com/redwing555/SpaceX-Project] OR THE USE OR OTHER DEALINGS IN THE [https://github.com/redwing555/SpaceX-Project].
