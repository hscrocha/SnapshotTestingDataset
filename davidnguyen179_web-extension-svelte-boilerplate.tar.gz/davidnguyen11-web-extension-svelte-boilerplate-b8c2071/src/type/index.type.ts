export type DayPeriod = 'morning' | 'afternoon' | 'night';
