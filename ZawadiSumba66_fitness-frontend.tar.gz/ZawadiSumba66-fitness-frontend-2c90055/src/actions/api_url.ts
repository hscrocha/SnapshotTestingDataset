const API_BASE = 'https://fitness-api-app.herokuapp.com/api/v1';
export default API_BASE;
