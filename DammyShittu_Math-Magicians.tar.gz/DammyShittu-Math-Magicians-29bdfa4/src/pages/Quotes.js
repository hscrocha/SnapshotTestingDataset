import React from 'react';

const Quotes = () => (
  <blockquote style={{ marginTop: '10%' }}>
    The definition of a good mathematical problem is the mathematics it generates, rather
    than the problem itself. ~Andrew Wiles
  </blockquote>
);

export default Quotes;
