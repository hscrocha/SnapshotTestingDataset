import React from 'react';

const Home = () => (
  <div className="home-div">
    <h2>Welcome To Our Page!</h2>
    <p>
      Lorem ipsum dolor sit amet consectetur adipisicing elit. Eum totam molestiae quas quae
      explicabo odit quisquam nemo, dolore voluptatum rerum! Illo ad vel, quidem voluptates
      provident facere eius perspiciatis necessitatibus, saepe rem odio optio voluptatum animi
      veniam dolorem temporibus itaque excepturi inventore minima ipsum, voluptatem enim
      soluta. Saepe doloribus ex enim, recusandae alias, distinctio non laudantium autem magnam
      inventore eveniet!
    </p>
    <p>
      Lorem ipsum dolor, sit amet consectetur adipisicing elit. Ut temporibus iusto incidunt
      ullam soluta repellat cupiditate qui, voluptatibus debitis iure, perferendis totam.
      Placeat cum consequatur corrupti cumque saepe, blanditiis modi obcaecati nisi minus
      nostrum quibusdam vel dolore quaerat? Corrupti, eos.
    </p>
  </div>
);

export default Home;
