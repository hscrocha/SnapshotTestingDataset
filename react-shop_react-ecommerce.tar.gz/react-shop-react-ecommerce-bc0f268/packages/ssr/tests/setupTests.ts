import '@testing-library/jest-dom';
import 'jest-styled-components';
import '@tests/mocks/image';
