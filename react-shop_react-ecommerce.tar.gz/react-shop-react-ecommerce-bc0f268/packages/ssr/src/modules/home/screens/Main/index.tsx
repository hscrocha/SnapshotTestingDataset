import React from 'react';

const Home = () => {
  return <div>Home screen</div>
}

export default Home;
