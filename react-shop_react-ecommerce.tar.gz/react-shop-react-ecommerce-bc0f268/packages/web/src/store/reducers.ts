import { combineReducers } from 'redux';

export default () => combineReducers({});
