import React from 'react';
import { render } from 'react-dom';
import Root from './root';

// import 'slick-carousel/slick/slick.css';
// import 'slick-carousel/slick/slick-theme.css';

// eslint-disable-next-line no-undef
render(<Root />, document.getElementById('root'));
