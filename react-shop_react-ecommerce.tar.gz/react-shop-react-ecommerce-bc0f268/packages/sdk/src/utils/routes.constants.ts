export const api = {
  BASE_URL: 'https://api.github.com/users/viniarruda',
};

const ROOT_PRODUCTS = '/repos';

export const ENDPOINTS = {
  PRODUCTS: `${ROOT_PRODUCTS}`,
};
