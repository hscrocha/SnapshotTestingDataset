export declare const api: {
    BASE_URL: string;
};
export declare const ENDPOINTS: {
    PRODUCTS: string;
};
