export declare const http: import("axios").AxiosInstance;
export interface IAccessUser {
    token: string;
}
