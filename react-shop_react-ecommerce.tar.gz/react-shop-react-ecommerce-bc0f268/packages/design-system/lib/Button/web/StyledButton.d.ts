declare const StyledButton: import("styled-components").StyledComponent<"button", any, import("./DefaultButton").IButtonProps, never>;
export default StyledButton;
