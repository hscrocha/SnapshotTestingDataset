declare const OutlinedButton: import("styled-components").StyledComponent<"button", any, import("./DefaultButton").IButtonProps, never>;
export default OutlinedButton;
