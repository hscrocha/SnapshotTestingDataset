export interface IButtonProps {
    full?: boolean;
    secondary?: boolean;
}
declare const DefaultButton: import("styled-components").StyledComponent<"button", any, IButtonProps, never>;
export default DefaultButton;
