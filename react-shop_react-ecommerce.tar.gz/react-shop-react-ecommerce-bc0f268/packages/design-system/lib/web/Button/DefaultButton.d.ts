export interface IButtonProps {
    full?: boolean;
    secondary?: boolean;
}
declare const DefaultButton: import("styled-components").StyledComponent<"button", import("styled-components").DefaultTheme, IButtonProps, never>;
export default DefaultButton;
