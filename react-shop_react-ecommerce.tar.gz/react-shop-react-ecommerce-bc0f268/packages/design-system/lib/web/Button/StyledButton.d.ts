declare const StyledButton: import("styled-components").StyledComponent<"button", import("styled-components").DefaultTheme, import("./DefaultButton").IButtonProps, never>;
export default StyledButton;
