import { FunctionComponent } from 'react';
import { TGridProps } from './interface';
declare const Grid: FunctionComponent<TGridProps>;
export default Grid;
