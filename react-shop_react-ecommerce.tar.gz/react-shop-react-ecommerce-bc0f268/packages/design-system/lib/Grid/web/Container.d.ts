export declare const Container: import("styled-components").StyledComponent<"div", any, {}, never>;
