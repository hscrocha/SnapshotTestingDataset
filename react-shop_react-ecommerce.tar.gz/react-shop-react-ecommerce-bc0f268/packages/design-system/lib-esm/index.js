export * from './web';
export { default as GlobalStyles } from './theme/globalStyle';
