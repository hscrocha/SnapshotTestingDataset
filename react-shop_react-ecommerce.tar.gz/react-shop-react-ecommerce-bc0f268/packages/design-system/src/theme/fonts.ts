const weights = {
  light: 300,
  regular: 500,
  bold: 700,
  black: 900,
};

export default {
  weights,
};
