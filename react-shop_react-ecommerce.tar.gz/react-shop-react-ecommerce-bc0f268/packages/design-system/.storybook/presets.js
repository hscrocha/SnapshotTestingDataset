module.exports = ['@storybook/addon-docs/react/preset'];
