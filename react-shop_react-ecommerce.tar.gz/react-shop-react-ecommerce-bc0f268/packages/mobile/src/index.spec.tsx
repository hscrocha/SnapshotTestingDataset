describe('When sum 2 numbers', () => {
  it('should be 5', () => {
    expect(4 + 1).toBe(5);
  });
});
