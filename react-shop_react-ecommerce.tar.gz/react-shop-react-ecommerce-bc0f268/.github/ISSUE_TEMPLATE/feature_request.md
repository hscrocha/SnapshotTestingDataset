---
name: ✨ Feature request
about: Suggest an idea.
labels: "enhancement"
---

## Describe the Feature

<!-- Describe the requested Feature -->

## Possible Implementations

<!-- Describe how to implement the feature -->

## Related Issues

<!-- Link related issues here -->
