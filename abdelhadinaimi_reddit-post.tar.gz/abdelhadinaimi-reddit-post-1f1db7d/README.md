![Tests](https://github.com/abdelhadinaimi/reddit-post/workflows/Tests/badge.svg)
## Reddit Post

Just add the name of the subreddit into the text box and press the + button

Preview : https://abdelhadinaimi.github.io/sample/reddit-post
