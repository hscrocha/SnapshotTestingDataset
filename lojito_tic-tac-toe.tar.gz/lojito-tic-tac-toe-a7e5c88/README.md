The Tic-tac-toe game based on images from different categories where your opponent is always the computer.




https://user-images.githubusercontent.com/46691447/205774094-f1fd82dc-d9c9-44fb-b16a-3de3b5eba3b7.mp4

