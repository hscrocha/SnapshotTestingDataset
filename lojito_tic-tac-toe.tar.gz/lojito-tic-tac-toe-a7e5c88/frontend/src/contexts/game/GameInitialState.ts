import {
  PlayingLevel,
  GameResult,
  Player,
  IImage,
  ICategory,
} from "../../types";
import categories from "../../assets/json/categories.json";
import { IState } from "../../types";

const NUMBER_OF_CATEGORIES = 10;
const category = categories[
  Math.floor(Math.random() * NUMBER_OF_CATEGORIES)
] as ICategory;

const IMAGES_PER_CATEGORY = 20;
const userImage = Math.floor(Math.random() * IMAGES_PER_CATEGORY) as IImage;
let computerImage = Math.floor(Math.random() * IMAGES_PER_CATEGORY) as IImage;

const initialState: IState = {
  category,
  images: {
    user: userImage,
    computer: computerImage,
  },
  first: Player.User,
  level: PlayingLevel.Easy,
  disabled: false,
  over: false,
  result: GameResult.Started,
  winners: [],
};

export default initialState;
