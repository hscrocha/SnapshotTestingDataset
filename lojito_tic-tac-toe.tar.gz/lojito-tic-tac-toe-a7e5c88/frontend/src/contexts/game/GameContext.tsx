import React, { createContext } from "react";
import { Action, IState } from "../../types";

export const GameContext = createContext<{
  game: IState;
  dispatch: React.Dispatch<Action>;
}>({ game: {} as IState, dispatch: {} as React.Dispatch<Action> });
