import React, { FC, useContext } from "react";
import { LanguageContext } from "../language/LanguageContext";
import data from "../../assets/json/dictionary.json";
import { IDictionaryEntry } from "../../types";
import { DictionaryContext } from "./DictionaryContext";

const DictionaryContextProvider: FC = ({ children }) => {
  const { language } = useContext(LanguageContext);
  const dictionary: IDictionaryEntry = data[language] as IDictionaryEntry;

  return (
    <DictionaryContext.Provider value={{ dictionary }}>
      {children}
    </DictionaryContext.Provider>
  );
};

export default DictionaryContextProvider;
