import { createContext } from "react";
import data from "../../assets/json/dictionary.json";
import { Language, IDictionaryEntry } from "../../types";

export const DictionaryContext = createContext<{
  dictionary: IDictionaryEntry;
}>({
  dictionary: data[Language.English],
});
