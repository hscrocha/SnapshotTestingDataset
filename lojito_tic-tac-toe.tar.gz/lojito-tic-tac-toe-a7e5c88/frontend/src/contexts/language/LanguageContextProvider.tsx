import React, { FC } from "react";
import { LanguageContext } from "./LanguageContext";
import useLanguage from "../../hooks/useLanguage";
import { Language } from "../../types";

const LanguageContextProvider: FC = ({ children }) => {
  const { language, handleChangeLanguage } = useLanguage(Language.English);

  return (
    <LanguageContext.Provider value={{ language, handleChangeLanguage }}>
      {children}
    </LanguageContext.Provider>
  );
};

export default LanguageContextProvider;
