export type CategoryId = 0 | 1 | 2 | 3 | 4 | 5 | 6 | 7 | 8 | 9;

export type CategoryFolder =
  | "habana"
  | "montreal"
  | "vancouver"
  | "spain"
  | "germany"
  | "soccer"
  | "fruits"
  | "animals"
  | "puppies"
  | "seinfeld";

export interface CATEGORY_HAVANA_LANDMARKS {
  id: 0;
  name: "CATEGORY_HAVANA_LANDMARKS";
  folder: "habana";
}

export interface CATEGORY_MONTREAL_LANDMARKS {
  id: 1;
  name: "CATEGORY_MONTREAL_LANDMARKS";
  folder: "montreal";
}

export interface CATEGORY_VANCOUVER_LANDMARKS {
  id: 2;
  name: "CATEGORY_VANCOUVER_LANDMARKS";
  folder: "vancouver";
}

export interface CATEGORY_SPAIN_LANDMARKS {
  id: 3;
  name: "CATEGORY_SPAIN_LANDMARKS";
  folder: "spain";
}

export interface CATEGORY_GERMANY_LANDMARKS {
  id: 4;
  name: "CATEGORY_GERMANY_LANDMARKS";
  folder: "germany";
}

export interface CATEGORY_SOCCER_PLAYERS {
  id: 5;
  name: "CATEGORY_SOCCER_PLAYERS";
  folder: "soccer";
}

export interface CATEGORY_FRUITS_AND_VEGETABLES {
  id: 6;
  name: "CATEGORY_FRUITS_AND_VEGETABLES";
  folder: "fruits";
}

export interface CATEGORY_ANIMALS {
  id: 7;
  name: "CATEGORY_ANIMALS";
  folder: "animals";
}

export interface CATEGORY_PUPPIES {
  id: 8;
  name: "CATEGORY_PUPPIES";
  folder: "puppies";
}

export interface CATEGORY_SEINFELD {
  id: 9;
  name: "CATEGORY_SEINFELD";
  folder: "seinfeld";
}

export type ICategory =
  | CATEGORY_ANIMALS
  | CATEGORY_FRUITS_AND_VEGETABLES
  | CATEGORY_GERMANY_LANDMARKS
  | CATEGORY_HAVANA_LANDMARKS
  | CATEGORY_MONTREAL_LANDMARKS
  | CATEGORY_PUPPIES
  | CATEGORY_SEINFELD
  | CATEGORY_SOCCER_PLAYERS
  | CATEGORY_SPAIN_LANDMARKS
  | CATEGORY_VANCOUVER_LANDMARKS;

export interface ICategories {
  categories: ICategory[];
}

export type IImage =
  | 0
  | 1
  | 2
  | 3
  | 4
  | 5
  | 6
  | 7
  | 8
  | 9
  | 10
  | 11
  | 12
  | 13
  | 14
  | 15
  | 16
  | 17
  | 18
  | 19;

export interface IImages {
  user: IImage;
  computer: IImage;
}

export type FirstPlayer = Player.User | Player.Computer;

export enum PlayingLevel {
  Easy,
  Smart,
}

export enum Player {
  User,
  Computer,
  Nobody,
}

export type GameBoard = [
  Player,
  Player,
  Player,
  Player,
  Player,
  Player,
  Player,
  Player,
  Player
];

export interface ISquare {
  disabled: boolean;
  id: string;
  imagePath: string;
  className: "win" | "";
}

export enum Square {
  TopLeft,
  TopCenter,
  TopRight,
  MiddleLeft,
  MiddleCenter,
  MiddleRight,
  BottomLeft,
  BottomCenter,
  BottomRight,
}

export enum GameResult {
  Draw,
  Lost,
  Started,
  Won,
}

export enum Language {
  English,
  Spanish,
  French,
}

export interface IDictionaryEntry {
  readonly ABOUT: string;
  readonly ABOUT_GAME_DEVELOPED_WITH: string;
  readonly ABOUT_OTHER_HOME_PROJECTS: string;
  readonly ABOUT_SOURCE_CODE: string;
  readonly AUTH_FORM_EMAIL_LABEL: string;
  readonly AUTH_FORM_EMAIL_PLACEHOLDER: string;
  readonly AUTH_FORM_NAME_LABEL: string;
  readonly AUTH_FORM_NAME_PLACEHOLDER: string;
  readonly AUTH_FORM_PASSWORD_LABEL: string;
  readonly AUTH_FORM_PASSWORD_PLACEHOLDER: string;
  readonly BUTTON_BACK: string;
  readonly BUTTON_DELETE_GAME: string;
  readonly BUTTON_LOGOUT: string;
  readonly BUTTON_PLAY: string;
  readonly BUTTON_PLAY_AGAIN: string;
  readonly BUTTON_SEE_GAME: string;
  readonly BUTTON_SIGNIN: string;
  readonly BUTTON_SIGNUP: string;
  readonly CATEGORY: string;
  readonly CATEGORY_ANIMALS: string;
  readonly CATEGORY_FRUITS_AND_VEGETABLES: string;
  readonly CATEGORY_GERMANY_LANDMARKS: string;
  readonly CATEGORY_HAVANA_LANDMARKS: string;
  readonly CATEGORY_MONTREAL_LANDMARKS: string;
  readonly CATEGORY_PUPPIES: string;
  readonly CATEGORY_SEINFELD: string;
  readonly CATEGORY_SOCCER_PLAYERS: string;
  readonly CATEGORY_SPAIN_LANDMARKS: string;
  readonly CATEGORY_VANCOUVER_LANDMARKS: string;
  readonly CONTACT: string;
  readonly CONTACT_AUTHOR: string;
  readonly CONTACT_EMAIL: string;
  readonly CONTACT_GITHUB: string;
  readonly CONTACT_LINKEDIN: string;
  readonly FLAG_ENGLISH_HINT: string;
  readonly FLAG_FRENCH_HINT: string;
  readonly FLAG_SPANISH_HINT: string;
  readonly GAME: string;
  readonly GAME_OVER: string;
  readonly GAME_STARTED_BY: string;
  readonly GAME_STARTED_BY_COMPUTER: string;
  readonly GAME_STARTED_BY_YOU: string;
  readonly HISTORICAL: string;
  readonly HISTORICAL_NO_DATA_YET: string;
  readonly IMAGE_COMPUTER_LABEL: string;
  readonly IMAGE_COMPUTER_TOOLTIP: string;
  readonly IMAGE_REFRESH_TOOLTIP: string;
  readonly IMAGE_USER_LABEL: string;
  readonly IMAGE_USER_TOOLTIP: string;
  readonly LOGIN: string;
  readonly MESSAGE_DRAW: string;
  readonly MESSAGE_LOST: string;
  readonly MESSAGE_WON: string;
  readonly PLAYING_LEVEL_EASY: string;
  readonly PLAYING_LEVEL_LABEL: string;
  readonly PLAYING_LEVEL_SMART: string;
  readonly PLAYING_LEVEL_TOOLTIP: string;
  readonly REPOSITORY: string;
  readonly SIGNUP: string;
  readonly WELCOME_BACK: string;
  readonly YOU_START_LABEL: string;
  readonly YOU_START_NO: string;
  readonly YOU_START_TOOLTIP: string;
  readonly YOU_START_YES: string;
}

export interface ActionCategory {
  type: "CHANGE_CATEGORY";
  category: ICategory;
}

export interface ActionDisabled {
  type: "CHANGE_DISABLED";
  disabled: boolean;
}

export interface ActionFirst {
  type: "CHANGE_FIRST";
  first: FirstPlayer;
}

export interface ActionImages {
  type: "CHANGE_IMAGES";
  images: IImages;
}

export interface ActionPlayingLevel {
  type: "CHANGE_PLAYING_LEVEL";
  level: PlayingLevel;
}

export interface ActionOver {
  type: "CHANGE_OVER";
  over: boolean;
}

export interface ActionResult {
  type: "CHANGE_GAME_RESULT";
  result: GameResult;
}

export interface ActionWinners {
  type: "CHANGE_WINNERS_SQUARES";
  winners: Square[];
}

export interface ActionUnknow {
  type: "UNKNOWN";
}

export type Action =
  | ActionCategory
  | ActionDisabled
  | ActionFirst
  | ActionImages
  | ActionPlayingLevel
  | ActionOver
  | ActionResult
  | ActionWinners
  | ActionUnknow;

export const CHANGE_CATEGORY = "CHANGE_CATEGORY";
export const CHANGE_DISABLED = "CHANGE_DISABLED";
export const CHANGE_FIRST = "CHANGE_FIRST";
export const CHANGE_IMAGES = "CHANGE_IMAGES";
export const CHANGE_PLAYING_LEVEL = "CHANGE_PLAYING_LEVEL";
export const CHANGE_OVER = "CHANGE_OVER";
export const CHANGE_GAME_RESULT = "CHANGE_GAME_RESULT";
export const CHANGE_WINNERS_SQUARES = "CHANGE_WINNERS_SQUARES";

export interface IAccount {
  email: string;
  name?: string;
  password: string;
}

export interface IState {
  category: ICategory;
  images: IImages;
  first: FirstPlayer;
  level: PlayingLevel;
  disabled: boolean;
  over: boolean;
  result: GameResult;
  winners: Square[];
}

export interface IDBGame {
  _id?: string;
  board: GameBoard;
  categoryId: CategoryId;
  first: FirstPlayer;
  imageUser: IImage;
  imageComputer: IImage;
  level: PlayingLevel;
  result: GameResult;
  winners: Square[];
  user?: string;
  createdAt?: string;
  updatedAt?: string;
  __v?: number;
}
