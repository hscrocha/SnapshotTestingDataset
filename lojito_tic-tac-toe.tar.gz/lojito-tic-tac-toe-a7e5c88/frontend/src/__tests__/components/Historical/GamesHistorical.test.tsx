import React from "react";
import { render, screen } from "@testing-library/react";
import userEvent from "@testing-library/user-event";
import "@testing-library/jest-dom/extend-expect";
import { DictionaryContext } from "../../../contexts/dictionary/DictionaryContext";
import GamesHistorical from "../../../components/Historical/GamesHistorical";
import useFetchGames from "../../../hooks/game/useFetchGames";
import useDeleteGame from "../../../hooks/game/useDeleteGame";

import { IDBGame, IDictionaryEntry } from "../../../types";

interface Props {
  game: IDBGame;
  displayBoard: boolean;
  onDeleteGame: () => void;
}

jest.mock(
  "../../../components/Game/Historical",
  () =>
    ({ game, onDeleteGame }: Props) => {
      return (
        <>
          <div>category id: {game.categoryId}</div>
          <div>image user: {game.imageUser}</div>
          <div>image computer: {game.imageComputer}</div>
          <div>first: {game.first}</div>
          <div>level: {game.level}</div>
          <button onClick={() => onDeleteGame()}>Delete Game</button>
        </>
      );
    }
);

jest.mock("../../../hooks/game/useFetchGames");
jest.mock("../../../hooks/game/useDeleteGame");

describe("GamesHistorical", () => {
  const gameId = "637c268c2079f86953546d9a";

  const mockGamesFetchedFromDB = [
    {
      _id: gameId,
      board: [0, 2, 2, 1, 0, 2, 1, 2, 0],
      categoryId: 5,
      first: 0,
      imageComputer: 12,
      imageUser: 15,
      level: 0,
      result: 3,
      winners: [0, 4, 8],
      user: "636048af80d558d24d56265e",
      createdAt: "2022-11-22T01:31:56.533Z",
      updatedAt: "2022-11-22T01:31:56.533Z",
      __v: 0,
    },
  ] as IDBGame[];

  const mockDictionary = {
    HISTORICAL_NO_DATA_YET:
      "There is no historical data yet. Play some games and comeback.",
  } as IDictionaryEntry;

  const mockHandleFetchGames = jest.fn();
  const mockHandleDeleteGame = jest.fn();
  const mockHandleRemoveGame = jest.fn();

  interface GamesHistoricalWithProviderProps {
    games?: IDBGame[] | null;
    errorFetchingGames?: string;
    gameId?: string;
    errorDeletingGame?: string;
  }

  const GamesHistoricalWithProvider = (
    {
      games = null,
      errorFetchingGames = "",
      gameId = "",
      errorDeletingGame = "",
    }: GamesHistoricalWithProviderProps = {
      games: null,
      errorFetchingGames: "",
      gameId: "",
      errorDeletingGame: "",
    }
  ) => {
    (useFetchGames as jest.Mock).mockReturnValue({
      games,
      error: errorFetchingGames,
      handleFetchGames: mockHandleFetchGames,
      handleRemoveGame: mockHandleRemoveGame,
    });

    (useDeleteGame as jest.Mock).mockReturnValue({
      gameId,
      error: errorDeletingGame,
      handleDeleteGame: mockHandleDeleteGame,
    });

    return (
      <DictionaryContext.Provider value={{ dictionary: mockDictionary }}>
        <GamesHistorical token="token" />
      </DictionaryContext.Provider>
    );
  };

  it("should render correctly", () => {
    const { asFragment } = render(<GamesHistoricalWithProvider />);

    expect(asFragment()).toMatchSnapshot();
  });

  it("should show the historical of a game once the it has been fetched", () => {
    const { rerender } = render(<GamesHistoricalWithProvider />);

    let deleteGameButton = screen.queryByRole("button", {
      name: "Delete Game",
    });
    expect(deleteGameButton).not.toBeInTheDocument();

    rerender(<GamesHistoricalWithProvider games={mockGamesFetchedFromDB} />);

    const { categoryId, imageUser, imageComputer, first, level } =
      mockGamesFetchedFromDB[0];
    expect(screen.getByText(`category id: ${categoryId}`)).toBeInTheDocument();
    expect(screen.getByText(`image user: ${imageUser}`)).toBeInTheDocument();
    expect(
      screen.getByText(`image computer: ${imageComputer}`)
    ).toBeInTheDocument();
    expect(screen.getByText(`first: ${first}`)).toBeInTheDocument();
    expect(screen.getByText(`level: ${level}`)).toBeInTheDocument();
    deleteGameButton = screen.getByRole("button", {
      name: "Delete Game",
    });
    expect(deleteGameButton).toBeInTheDocument();
  });

  it("should display an error because fetching the games failed", () => {
    const { rerender } = render(<GamesHistoricalWithProvider />);

    const errorFetchingGames =
      "Error while fetching the games historical from the database.";

    rerender(
      <GamesHistoricalWithProvider errorFetchingGames={errorFetchingGames} />
    );

    expect(screen.getByText(errorFetchingGames)).toBeInTheDocument();
  });

  it("should display the no historical games message", () => {
    render(<GamesHistoricalWithProvider />);

    expect(
      screen.getByText(mockDictionary.HISTORICAL_NO_DATA_YET)
    ).toBeInTheDocument();
  });

  it("should call the delete game handler", () => {
    const { rerender } = render(<GamesHistoricalWithProvider />);

    rerender(<GamesHistoricalWithProvider games={mockGamesFetchedFromDB} />);

    const deleteGameButton = screen.getByRole("button", {
      name: "Delete Game",
    });
    userEvent.click(deleteGameButton!);

    expect(mockHandleDeleteGame).toBeCalled();
  });

  it("should call the remove game handler", () => {
    const { rerender } = render(<GamesHistoricalWithProvider />);

    rerender(<GamesHistoricalWithProvider games={mockGamesFetchedFromDB} />);

    const deleteGameButton = screen.getByRole("button", {
      name: "Delete Game",
    });
    userEvent.click(deleteGameButton!);

    rerender(<GamesHistoricalWithProvider gameId={gameId} />);

    expect(mockHandleRemoveGame).toBeCalled();
  });

  it("should display the game deleting error", () => {
    const { rerender } = render(<GamesHistoricalWithProvider />);

    rerender(<GamesHistoricalWithProvider games={mockGamesFetchedFromDB} />);

    const deleteGameButton = screen.getByRole("button", {
      name: "Delete Game",
    });
    userEvent.click(deleteGameButton!);

    const errorDeletingGame = "Error while deleting the game from the database";
    rerender(
      <GamesHistoricalWithProvider
        gameId={gameId}
        games={mockGamesFetchedFromDB}
        errorDeletingGame={errorDeletingGame}
      />
    );

    expect(screen.getByText(errorDeletingGame)).toBeInTheDocument();
  });
});
