import React from "react";
import { render, screen } from "@testing-library/react";
import userEvent from "@testing-library/user-event";
import "@testing-library/jest-dom/extend-expect";
import { DictionaryContext } from "../../../contexts/dictionary/DictionaryContext";
import { Router } from "react-router-dom";
import { createMemoryHistory } from "history";
import Navigation from "../../../components/Navigation/Navigation";
import { IDictionaryEntry } from "../../../types";

describe("Navigation", () => {
  const renderNavigation = (isLoggedIn: boolean = true) => {
    const mockDictionary = {
      GAME: "Game",
      HISTORICAL: "Historical",
      REPOSITORY: "Repository",
      ABOUT: "About",
      CONTACT: "Contact",
      LOGIN: "SignIn",
      SIGNUP: "SignUp",
    } as IDictionaryEntry;
    const onLogout = jest.fn;
    const history = createMemoryHistory();
    history.push = jest.fn();

    const utils = render(
      <DictionaryContext.Provider value={{ dictionary: mockDictionary }}>
        <Router history={history}>
          <Navigation isLoggedIn={isLoggedIn} onLogout={onLogout} />
        </Router>
      </DictionaryContext.Provider>
    );

    const game = screen.queryByRole("link", {
      name: mockDictionary["GAME"],
    });
    const historyNav = screen.queryByRole("link", {
      name: mockDictionary["HISTORICAL"],
    });
    const repository = screen.queryByRole("link", {
      name: mockDictionary["REPOSITORY"],
    });
    const about = screen.queryByRole("link", {
      name: mockDictionary["ABOUT"],
    });
    const contact = screen.queryByRole("link", {
      name: mockDictionary["CONTACT"],
    });
    const login = screen.queryByRole("link", {
      name: mockDictionary["LOGIN"],
    });
    const signup = screen.queryByRole("link", {
      name: mockDictionary["SIGNUP"],
    });

    return {
      ...utils,
      game,
      historyNav,
      repository,
      about,
      contact,
      login,
      signup,
      history,
    };
  };

  it("renders the Navigation component correctly", () => {
    const { asFragment } = renderNavigation();

    expect(asFragment()).toMatchSnapshot();
  });

  it("should display the navigation bar", () => {
    renderNavigation();

    expect(screen.getByTestId("nav")).toHaveClass("nav");
  });

  it("should display the navigation menu items but Singin and Singup", () => {
    const { game, historyNav, repository, about, contact, login, signup } =
      renderNavigation();

    expect(game).toBeInTheDocument();
    expect(historyNav).toBeInTheDocument();
    expect(repository).toBeInTheDocument();
    expect(about).toBeInTheDocument();
    expect(contact).toBeInTheDocument();
    expect(login).not.toBeInTheDocument();
    expect(signup).not.toBeInTheDocument();
  });

  it("should display the Signin and Singup navigation menu items only", () => {
    const isLoggedIn = false;

    const { game, historyNav, repository, about, contact, login, signup } =
      renderNavigation(isLoggedIn);

    expect(game).not.toBeInTheDocument();
    expect(historyNav).not.toBeInTheDocument();
    expect(repository).not.toBeInTheDocument();
    expect(about).not.toBeInTheDocument();
    expect(contact).not.toBeInTheDocument();
    expect(login).toBeInTheDocument();
    expect(signup).toBeInTheDocument();
  });

  it("should route to the Game component", () => {
    const { game, history } = renderNavigation();

    userEvent.click(game!);

    expect(history.push).not.toHaveBeenCalled();
  });

  it("should set the href attribute of the 'Game' menu item", () => {
    const { game } = renderNavigation();

    expect(game).toHaveAttribute("href", "/");
  });

  it("should route to the Historical component", () => {
    const { historyNav, history } = renderNavigation();
    userEvent.click(historyNav!);

    expect(history.push).toHaveBeenCalledWith({
      hash: "",
      pathname: "/historical",
      search: "",
      state: null,
    });
  });

  it("should set the href attribute of the 'Historical' menu item", () => {
    const { historyNav } = renderNavigation();

    expect(historyNav).toHaveAttribute("href", "/historical");
  });

  it("should route to the Repository component", () => {
    const { repository, history } = renderNavigation();
    userEvent.click(repository!);

    expect(history.push).toHaveBeenCalledWith({
      hash: "",
      pathname: "/repository",
      search: "",
      state: null,
    });
  });

  it("should set the href attribute of the 'Repository' menu item", () => {
    const { repository } = renderNavigation();

    expect(repository).toHaveAttribute("href", "/repository");
  });

  it("should route to the About component", () => {
    const { about, history } = renderNavigation();
    userEvent.click(about!);

    expect(history.push).toHaveBeenCalledWith({
      hash: "",
      pathname: "/about",
      search: "",
      state: null,
    });
  });

  it("should set the href attribute of the 'About' menu item", () => {
    const { about } = renderNavigation();

    expect(about).toHaveAttribute("href", "/about");
  });

  it("should route to the Contact component", () => {
    const { contact, history } = renderNavigation();
    userEvent.click(contact!);

    expect(history.push).toHaveBeenCalledWith({
      hash: "",
      pathname: "/contact",
      search: "",
      state: null,
    });
  });

  it("should set the href attribute of the 'Contact' menu item", () => {
    const { contact } = renderNavigation();

    expect(contact).toHaveAttribute("href", "/contact");
  });
});
