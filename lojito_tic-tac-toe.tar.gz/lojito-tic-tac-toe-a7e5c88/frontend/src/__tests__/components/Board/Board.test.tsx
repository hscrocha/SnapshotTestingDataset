import React from "react";
import { render, screen } from "@testing-library/react";
import userEvent from "@testing-library/user-event";
import "@testing-library/jest-dom/extend-expect";
import Board from "../../../components/Board/Board";
import useBoard from "../../../hooks/useBoard";
import { GameContext } from "../../../contexts/game/GameContext";
import {
  IState,
  Player,
  PlayingLevel,
  GameResult,
  GameBoard,
} from "../../../types";

jest.mock(
  "../../../components/Square/Square",
  () =>
    ({
      disabled,
      id,
      imagePath,
      className,
    }: {
      disabled: boolean;
      id: string;
      imagePath: string;
      className: string;
    }) => {
      const path = `url(${process.env.PUBLIC_URL}/images`;
      const url =
        imagePath === "default"
          ? `${path}/default.jpg)`
          : `${path}/${imagePath}.jpg)`;

      return (
        <button
          id={id}
          data-testid={`square-${id}`}
          className={className}
          disabled={disabled}
          style={{ backgroundImage: url }}
        >
          {id}
        </button>
      );
    }
);

jest.mock("../../../hooks/useBoard");

describe("Board", () => {
  const mockPlayGame = jest.fn();

  const emptyBoard: GameBoard = [
    Player.Nobody,
    Player.Nobody,
    Player.Nobody,
    Player.Nobody,
    Player.Nobody,
    Player.Nobody,
    Player.Nobody,
    Player.Nobody,
    Player.Nobody,
  ];

  interface Props {
    disabled?: boolean;
    over?: boolean;
    board?: GameBoard;
    winners?: number[];
  }

  const renderBoard = (
    {
      disabled = false,
      over = false,
      board = emptyBoard,
      winners = [],
    }: Props = {
      disabled: false,
      over: false,
      board: emptyBoard,
      winners: [],
    }
  ) => {
    const game = {
      category: {
        id: 5,
        folder: "soccer",
        name: "CATEGORY_SOCCER_PLAYERS",
      },
      images: {
        user: 5,
        computer: 6,
      },
      first: Player.User,
      level: PlayingLevel.Easy,
      disabled,
      over,
      result: GameResult.Started,
      winners,
    } as IState;

    (useBoard as jest.Mock).mockReturnValue({
      gameBoard: board,
      playGame: mockPlayGame,
    });

    const dispatch = jest.fn();
    const handleGameOver = jest.fn();

    const utils = render(
      <GameContext.Provider value={{ game, dispatch }}>
        <Board onGameOver={handleGameOver} />
      </GameContext.Provider>
    );

    return { ...utils, mockPlayGame };
  };

  it("should render the Board component correctly", () => {
    const { asFragment } = renderBoard();

    expect(asFragment()).toMatchSnapshot();
  });

  it("should render the wrapper div with class board", () => {
    renderBoard();

    expect(screen.queryByTestId("board")).toHaveClass("board");
  });

  it("should render the board when disabled is true", () => {
    renderBoard({ disabled: true });

    const firstSquare = screen.queryByTestId("square-0");

    userEvent.click(firstSquare!);
    expect(mockPlayGame).toHaveBeenCalled();
  });

  it("should render the board when over is true", () => {
    const over = true;
    const board: GameBoard = [
      Player.Computer,
      Player.Computer,
      Player.Computer,
      Player.User,
      Player.User,
      Player.Computer,
      Player.User,
      Player.User,
      Player.Computer,
    ];
    const winners = [0, 1, 2];

    renderBoard({ over, board, winners });

    const firstSquare = screen.queryByTestId("square-0");

    userEvent.click(firstSquare!);
    expect(mockPlayGame).not.toHaveBeenCalled();
  });

  it("should call the click handler", () => {
    const disabled = true;

    renderBoard({ disabled });

    const firstSquare = screen.queryByTestId("square-0");

    userEvent.click(firstSquare!);
    expect(mockPlayGame).toHaveBeenCalled();
  });
});
