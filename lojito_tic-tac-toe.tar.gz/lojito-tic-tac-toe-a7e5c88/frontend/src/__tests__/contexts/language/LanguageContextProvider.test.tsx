import React, { useContext } from "react";
import { render, screen } from "@testing-library/react";
import "@testing-library/jest-dom/extend-expect";
import userEvent from "@testing-library/user-event";
import { LanguageContext } from "../../../contexts/language/LanguageContext";
import LanguageContextProvider from "../../../contexts/language/LanguageContextProvider";
import { Language } from "../../../types";

const mockChangeLanguageHandler = jest.fn();

jest.mock("../../../hooks/useLanguage", () => ({
  __esModule: true,
  default: (language: Language) => ({
    language,
    handleChangeLanguage: mockChangeLanguageHandler,
  }),
}));

describe("LanguageContextProvider", () => {
  const renderTestComponent = () => {
    const TestComponent = () => {
      const { language, handleChangeLanguage } = useContext(LanguageContext);

      return (
        <>
          <div>{language}</div>
          <button
            onClick={() => {
              handleChangeLanguage!(Language.French);
            }}
          >
            Change language
          </button>
        </>
      );
    };

    return render(
      <LanguageContextProvider>
        <TestComponent />
      </LanguageContextProvider>
    );
  };

  it("should provide the dictionary", () => {
    renderTestComponent();

    expect(screen.getByText(Language.English)).toBeInTheDocument();
  });

  it("should call the change language handler", () => {
    renderTestComponent();

    userEvent.click(screen.getByText("Change language"));

    expect(mockChangeLanguageHandler).toHaveBeenCalled();
  });
});
