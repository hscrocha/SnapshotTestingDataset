import { Board } from "../../classes/GameBoard";
import { PlayingLevel, Player, Square } from "../../types";

let board: Board;

beforeEach(() => {
  board = new Board();
});

it("should create an empty board", () => {
  expect(board.isEmpty).toBeTruthy();
});

it("should create an board of 9 squares", () => {
  expect(board.getBoard()).toHaveLength(board.totalSquares);
});

it("should set level to PlayingLevel.Easy", () => {
  expect(board.level).toBe(PlayingLevel.Easy);
});

it("should set level to PlayingLevel.Smart", () => {
  board.level = PlayingLevel.Smart;

  expect(board.level).toBe(PlayingLevel.Smart);
});

it("should set the starting player to be the user", () => {
  board.first = Player.User;

  expect(board.first).toBe(Player.User);
});

it("should set the starting player to be the computer", () => {
  board.first = Player.Computer;

  expect(board.first).toBe(Player.Computer);
});

it("should set the number of moves to 0", () => {
  expect(board.moves).toBe(0);
});

it("should not have any empty square", () => {
  board.place(Player.User, Square.TopLeft);
  board.place(Player.Computer, Square.TopCenter);
  board.place(Player.User, Square.TopRight);
  board.place(Player.Computer, Square.MiddleLeft);
  board.place(Player.User, Square.MiddleCenter);
  board.place(Player.Computer, Square.MiddleRight);
  board.place(Player.User, Square.BottomLeft);
  board.place(Player.Computer, Square.BottomCenter);
  board.place(Player.User, Square.BottomRight);

  expect(board.isFull).toBeTruthy();
});

it("should have some empty squares", () => {
  board.place(Player.User, Square.TopLeft);
  board.place(Player.User, Square.MiddleCenter);
  board.place(Player.User, Square.BottomRight);

  const result = board.emptySquares;

  expect(result).toEqual([
    Square.TopCenter,
    Square.TopRight,
    Square.MiddleLeft,
    Square.MiddleRight,
    Square.BottomLeft,
    Square.BottomCenter,
  ]);
});

it("should reset the board", () => {
  board.place(Player.User, Square.TopLeft);
  board.place(Player.User, Square.MiddleCenter);
  board.place(Player.User, Square.BottomRight);

  board.reset();

  expect(board.isEmpty).toBeTruthy();
});

it("should place player on a square", () => {
  board.place(Player.User, Square.MiddleRight);

  expect(board.getBoard()[Square.MiddleRight]).toBe(Player.User);
});

it("should decrement the number of moves", () => {
  board.place(Player.Computer, Square.TopLeft);
  const moves = board.moves;

  board.place(Player.Nobody, Square.TopLeft);

  expect(board.moves).toBe(moves - 1);
});

it("should expect the user to be about to win the game", () => {
  board.place(Player.User, Square.TopLeft);
  board.place(Player.Computer, Square.TopCenter);
  board.place(Player.User, Square.MiddleCenter);
  board.place(Player.Computer, Square.MiddleLeft);

  expect(board.canWinInOneMove(Player.User)).not.toBe(board.SQUARE_NOT_FOUND);

  board.reset();

  board.place(Player.User, Square.TopLeft);
  board.place(Player.Computer, Square.MiddleRight);
  board.place(Player.User, Square.TopRight);
  board.place(Player.Computer, Square.MiddleLeft);

  expect(board.canWinInOneMove(Player.User)).not.toBe(board.SQUARE_NOT_FOUND);

  board.reset();

  board.place(Player.User, Square.TopCenter);
  board.place(Player.Computer, Square.MiddleRight);
  board.place(Player.User, Square.TopRight);
  board.place(Player.Computer, Square.MiddleLeft);

  expect(board.canWinInOneMove(Player.User)).not.toBe(board.SQUARE_NOT_FOUND);
});

it("should not expect the user to be about to win the game", () => {
  board.place(Player.User, Square.TopLeft);

  expect(board.canWinInOneMove(Player.User)).toBe(board.SQUARE_NOT_FOUND);
});

it("should expect to win in two moves single", () => {
  const arrSquares = [
    [Square.TopLeft, Square.TopCenter, Square.TopRight],
    [Square.TopCenter, Square.TopLeft, Square.TopRight],
    [Square.TopRight, Square.TopLeft, Square.TopCenter],
  ];

  for (let squares of arrSquares) {
    board.place(Player.User, squares[0]);

    const result = board.canWinInTwoMovesSingle(Player.User);

    expect(
      result.filter((value) => [squares[1], squares[2]].includes(value))
    ).toEqual([squares[1], squares[2]]);

    board.reset();
  }
});

it("should not expect to win in two moves single", () => {
  board.place(Player.Computer, Square.TopLeft);
  board.place(Player.User, Square.TopCenter);
  board.place(Player.Computer, Square.MiddleCenter);
  board.place(Player.User, Square.MiddleLeft);

  expect(board.canWinInTwoMovesSingle(Player.User)).toEqual([]);
});

it("should expect to win in two moves double", () => {
  const arrSquares = [
    Square.TopLeft,
    Square.TopCenter,
    Square.TopRight,
    Square.MiddleLeft,
    Square.BottomLeft,
  ];

  board.place(Player.User, arrSquares[1]);
  board.place(Player.Computer, Square.MiddleCenter);
  board.place(Player.User, arrSquares[3]);
  board.place(Player.Computer, Square.BottomCenter);

  const result = board.canWinInTwoMovesDouble(Player.User);

  expect(result.filter((value) => [arrSquares[0]].includes(value))).toEqual([
    arrSquares[0],
  ]);
});

it("should not expect to win in two moves double", () => {
  board.place(Player.Computer, Square.TopLeft);
  board.place(Player.User, Square.TopCenter);
  board.place(Player.Computer, Square.MiddleCenter);
  board.place(Player.User, Square.MiddleLeft);

  expect(board.canWinInTwoMovesDouble(Player.User)).toEqual([]);
});

it("should expect the user to be the winner of the game", () => {
  const arrSquares = [
    [
      Square.TopLeft,
      Square.TopCenter,
      Square.TopRight,
      Square.MiddleLeft,
      Square.MiddleCenter,
    ],
    [
      Square.MiddleLeft,
      Square.MiddleCenter,
      Square.MiddleRight,
      Square.TopLeft,
      Square.TopCenter,
    ],
    [
      Square.BottomLeft,
      Square.BottomCenter,
      Square.BottomRight,
      Square.TopLeft,
      Square.TopCenter,
    ],
    [
      Square.TopLeft,
      Square.MiddleLeft,
      Square.BottomLeft,
      Square.TopCenter,
      Square.TopRight,
    ],
    [
      Square.TopCenter,
      Square.MiddleCenter,
      Square.BottomCenter,
      Square.TopLeft,
      Square.TopRight,
    ],
    [
      Square.TopRight,
      Square.MiddleRight,
      Square.BottomRight,
      Square.TopLeft,
      Square.TopCenter,
    ],
    [
      Square.TopLeft,
      Square.MiddleCenter,
      Square.BottomRight,
      Square.TopCenter,
      Square.TopRight,
    ],
    [
      Square.TopRight,
      Square.MiddleCenter,
      Square.BottomLeft,
      Square.TopLeft,
      Square.TopCenter,
    ],
  ];

  for (let squares of arrSquares) {
    board.place(Player.User, squares[0]);
    board.place(Player.Computer, squares[3]);
    board.place(Player.User, squares[1]);
    board.place(Player.Computer, squares[4]);
    board.place(Player.User, squares[2]);

    expect(board.isAWinner(Player.User)).not.toEqual([]);

    board.reset();
  }
});

it("should expect the game to be a tie", () => {
  board.place(Player.Computer, Square.TopLeft);
  board.place(Player.User, Square.TopCenter);
  board.place(Player.Computer, Square.TopRight);
  board.place(Player.User, Square.MiddleLeft);
  board.place(Player.Computer, Square.MiddleCenter);
  board.place(Player.User, Square.MiddleRight);
  board.place(Player.User, Square.BottomLeft);
  board.place(Player.Computer, Square.BottomCenter);
  board.place(Player.User, Square.BottomRight);

  expect(board.isFull).toBeTruthy();
  expect(board.isAWinner(Player.User)).toEqual([]);
  expect(board.isAWinner(Player.Computer)).toEqual([]);
});

it("should expect winning squares on the board", () => {
  const arrSquares = [
    [
      Square.TopLeft,
      Square.TopCenter,
      Square.TopRight,
      Square.MiddleLeft,
      Square.MiddleCenter,
    ],
    [
      Square.MiddleLeft,
      Square.MiddleCenter,
      Square.MiddleRight,
      Square.TopLeft,
      Square.TopCenter,
    ],
    [
      Square.BottomLeft,
      Square.BottomCenter,
      Square.BottomRight,
      Square.TopLeft,
      Square.TopCenter,
    ],
    [
      Square.TopLeft,
      Square.MiddleLeft,
      Square.BottomLeft,
      Square.TopCenter,
      Square.TopRight,
    ],
    [
      Square.TopCenter,
      Square.MiddleCenter,
      Square.BottomCenter,
      Square.TopLeft,
      Square.TopRight,
    ],
    [
      Square.TopRight,
      Square.MiddleRight,
      Square.BottomRight,
      Square.TopLeft,
      Square.TopCenter,
    ],
    [
      Square.TopLeft,
      Square.MiddleCenter,
      Square.BottomRight,
      Square.TopCenter,
      Square.TopRight,
    ],
    [
      Square.TopRight,
      Square.MiddleCenter,
      Square.BottomLeft,
      Square.TopLeft,
      Square.TopCenter,
    ],
  ];

  for (let squares of arrSquares) {
    board.place(Player.User, squares[0]);
    board.place(Player.Computer, squares[3]);
    board.place(Player.User, squares[1]);
    board.place(Player.Computer, squares[4]);
    board.place(Player.User, squares[2]);

    expect(board.isAWinner(Player.User)).toEqual([
      squares[0],
      squares[1],
      squares[2],
    ]);

    board.reset();
  }
});

it("should not expect winning squares on the board", () => {
  board.place(Player.User, Square.TopLeft);
  board.place(Player.Computer, Square.MiddleLeft);
  board.place(Player.User, Square.TopCenter);
  board.place(Player.Computer, Square.MiddleCenter);

  expect(board.isAWinner(Player.User)).toEqual([]);
});

it("should not expect Player.Nobody to be the winner", () => {
  expect(board.isAWinner(Player.Nobody)).toEqual([]);
});
