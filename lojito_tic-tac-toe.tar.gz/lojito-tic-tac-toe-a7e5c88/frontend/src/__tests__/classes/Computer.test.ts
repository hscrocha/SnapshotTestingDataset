import { Board } from "../../classes/GameBoard";
import { Computer } from "../../classes/Computer";
import { PlayingLevel, Player, Square } from "../../types";

describe("Computer", () => {
  let board: Board;
  let computer: Computer;

  beforeEach(() => {
    board = new Board();
    computer = new Computer(board);
  });

  it("should expect the computer to play on the middle center square", () => {
    board.first = Player.User;
    board.level = PlayingLevel.Smart;
    board.place(Player.User, Square.TopLeft);

    computer.playForTheFirstTime();
    const squares = board.getBoard();

    expect(squares[Square.MiddleCenter]).toBe(Player.Computer);
  });

  it("should not expect the computer to play on the middle center square", () => {
    board.first = Player.User;
    board.level = PlayingLevel.Smart;
    board.place(Player.User, Square.MiddleCenter);

    computer.playForTheFirstTime();
    const squares = board.getBoard();

    expect([
      squares[Square.TopLeft],
      squares[Square.TopRight],
      squares[Square.BottomLeft],
      squares[Square.BottomRight],
    ]).toContain(Player.Computer);
  });

  it("should expect the computer to play on either the center square or one of the 4 corner squares", () => {
    board.first = Player.Computer;
    board.level = PlayingLevel.Smart;

    computer.playForTheFirstTime();
    const squares = board.getBoard();

    expect([
      squares[Square.MiddleCenter],
      squares[Square.TopLeft],
      squares[Square.TopRight],
      squares[Square.BottomLeft],
      squares[Square.BottomRight],
    ]).toContain(Player.Computer);
  });

  it("should expect the computer to play for the second time", () => {
    board.first = Player.Computer;
    board.level = PlayingLevel.Smart;
    board.place(Player.Computer, Square.MiddleCenter);
    board.place(Player.User, Square.TopLeft);
    jest.spyOn(global.Math, "random").mockReturnValueOnce(0.0528798980106473);
    computer.playForTheSecondTime();
    const squares = board.getBoard();

    expect([
      squares[Square.TopLeft],
      squares[Square.TopRight],
      squares[Square.BottomLeft],
      squares[Square.BottomRight],
    ]).toContain(Player.Computer);
  });

  it("should expect the computer to play for the second time when the user previously played on the middle center square", () => {
    board.first = Player.Computer;
    board.level = PlayingLevel.Smart;
    board.place(Player.Computer, Square.TopLeft);
    board.place(Player.User, Square.MiddleCenter);

    computer.playForTheSecondTime();
    const squares = board.getBoard();

    expect([
      squares[Square.TopCenter],
      squares[Square.TopRight],
      squares[Square.MiddleLeft],
      squares[Square.MiddleRight],
      squares[Square.BottomLeft],
      squares[Square.BottomCenter],
      squares[Square.BottomRight],
    ]).toContain(Player.Computer);
  });

  it("should expect the computer to play for the second time on the middle center square", () => {
    board.first = Player.Computer;
    board.level = PlayingLevel.Smart;
    board.place(Player.Computer, Square.TopLeft);
    board.place(Player.User, Square.TopCenter);

    computer.playForTheSecondTime();
    const squares = board.getBoard();

    expect(squares[Square.MiddleCenter]).toBe(Player.Computer);
  });

  it("should expect the computer to win on the next move", () => {
    board.first = Player.Computer;
    board.level = PlayingLevel.Smart;
    board.place(Player.Computer, Square.TopLeft);
    board.place(Player.User, Square.MiddleCenter);
    board.place(Player.Computer, Square.TopRight);

    computer.playAgain();
    const squares = board.getBoard();

    expect(squares[Square.TopCenter]).toBe(Player.Computer);
    expect(board.isAWinner(Player.Computer)).toBeTruthy();
  });

  it("should expect the user to win on the next move", () => {
    board.first = Player.User;
    board.level = PlayingLevel.Smart;
    board.place(Player.User, Square.TopLeft);
    board.place(Player.Computer, Square.MiddleCenter);
    board.place(Player.User, Square.TopRight);

    computer.playAgain();
    const squares = board.getBoard();

    expect(squares[Square.TopCenter]).toBe(Player.Computer);
  });

  it("should expect the computer to win in two moves in two different ways", () => {
    board.first = Player.Computer;
    board.level = PlayingLevel.Smart;
    board.place(Player.Computer, Square.MiddleCenter);
    board.place(Player.User, Square.TopRight);
    board.place(Player.Computer, Square.BottomLeft);
    board.place(Player.User, Square.BottomCenter);
    jest.spyOn(global.Math, "random").mockReturnValueOnce(0.29888451987787845);

    computer.playAgain();
    const squares = board.getBoard();

    expect(squares[Square.TopLeft]).toBe(Player.Computer);
  });

  it("should expect the computer to win in two moves in only one way", () => {
    board.first = Player.User;
    board.level = PlayingLevel.Smart;
    board.place(Player.User, Square.MiddleCenter);
    board.place(Player.Computer, Square.TopLeft);
    board.place(Player.User, Square.BottomRight);
    jest
      .spyOn(board, "canWinInTwoMovesSingle")
      .mockReturnValueOnce([Square.MiddleLeft, Square.TopRight]);

    computer.playAgain();
    const squares = board.getBoard();

    expect(squares[Square.MiddleLeft]).not.toBe(Player.Computer);
  });

  it("should expect the computer to play on any of the empty squares while playing again", () => {
    board.first = Player.User;
    board.level = PlayingLevel.Easy;
    board.place(Player.User, Square.MiddleCenter);
    board.place(Player.Computer, Square.TopLeft);
    board.place(Player.User, Square.BottomLeft);
    board.place(Player.Computer, Square.TopRight);
    board.place(Player.User, Square.TopCenter);
    board.place(Player.Computer, Square.BottomCenter);
    board.place(Player.User, Square.BottomRight);

    computer.playAgain();
    const squares = board.getBoard();

    expect([squares[Square.MiddleLeft], squares[Square.MiddleRight]]).toContain(
      Player.Computer
    );
  });

  it("should expect the computer to play on any of the empty squares", () => {
    board.first = Player.Computer;
    board.level = PlayingLevel.Easy;
    board.place(Player.Computer, Square.TopLeft);
    board.place(Player.User, Square.MiddleLeft);
    const emptySquares = board.emptySquares;

    computer.playOnAnyEmptySquare();

    expect(emptySquares).toContain(Player.Computer);
  });

  it("should expect the computer to play smart having the user played only one time", () => {
    board.first = Player.User;
    board.level = PlayingLevel.Smart;
    board.place(Player.User, Square.MiddleLeft);

    computer.playSmart();

    const squares = board.getBoard();
    expect(squares[Square.MiddleCenter]).toBe(Player.Computer);
  });

  it("should expect the computer to play smart having the user played at least two times", () => {
    board.first = Player.User;
    board.level = PlayingLevel.Smart;
    board.place(Player.User, Square.TopLeft);
    board.place(Player.Computer, Square.MiddleCenter);
    board.place(Player.User, Square.BottomCenter);

    computer.playSmart();
    const squares = board.getBoard();

    expect([
      squares[Square.TopCenter],
      squares[Square.TopRight],
      squares[Square.MiddleLeft],
      squares[Square.MiddleRight],
      squares[Square.BottomLeft],
      squares[Square.BottomRight],
    ]).toContain(Player.Computer);
  });

  it("should expect the computer to play smart and for the first time", () => {
    board.first = Player.Computer;
    board.level = PlayingLevel.Smart;

    computer.playSmart();
    const squares = board.getBoard();

    expect([
      squares[Square.TopLeft],
      squares[Square.TopRight],
      squares[Square.MiddleCenter],
      squares[Square.BottomLeft],
      squares[Square.BottomRight],
    ]).toContain(Player.Computer);
  });

  it("should expect the computer to play smart and for the second time", () => {
    board.first = Player.Computer;
    board.level = PlayingLevel.Smart;
    board.place(Player.Computer, Square.MiddleCenter);
    board.place(Player.User, Square.TopLeft);

    computer.playSmart();
    const squares = board.getBoard();

    expect([
      squares[Square.TopLeft],
      squares[Square.TopRight],
      squares[Square.BottomLeft],
      squares[Square.BottomRight],
    ]).toContain(Player.Computer);
  });

  it("should expect the computer to play smart after the its second move", () => {
    board.first = Player.Computer;
    board.level = PlayingLevel.Smart;
    board.place(Player.Computer, Square.MiddleCenter);
    board.place(Player.User, Square.TopLeft);
    board.place(Player.Computer, Square.TopRight);
    board.place(Player.User, Square.MiddleLeft);

    computer.playSmart();
    const squares = board.getBoard();

    expect(squares[Square.BottomLeft]).toBe(Player.Computer);
  });

  it("should expect the computer to play smart", () => {
    board.first = Player.User;
    board.level = PlayingLevel.Smart;

    board.place(Player.User, Square.TopLeft);
    computer.play();
    const squares = board.getBoard();

    expect(squares[Square.TopLeft]).not.toBe(Player.Computer);
  });

  it("should expect the computer to play on any empty square", () => {
    board.first = Player.User;
    board.level = PlayingLevel.Easy;
    board.place(Player.User, Square.TopLeft);
    const emptySquares = board.emptySquares;

    computer.play();

    expect(emptySquares).toContain(Player.Computer);
  });
});
