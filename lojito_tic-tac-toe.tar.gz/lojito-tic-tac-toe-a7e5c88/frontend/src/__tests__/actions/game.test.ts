import "@testing-library/jest-dom/extend-expect";
import {
  changeCategory,
  changeDisabled,
  changeFirst,
  changeImages,
  changeLevel,
  changeOver,
  changeResult,
  changeWinners,
} from "../../actions/game";
import {
  CHANGE_CATEGORY,
  CHANGE_DISABLED,
  CHANGE_FIRST,
  CHANGE_IMAGES,
  CHANGE_PLAYING_LEVEL,
  CHANGE_OVER,
  CHANGE_GAME_RESULT,
  CHANGE_WINNERS_SQUARES,
  ICategory,
  Player,
  PlayingLevel,
  GameResult,
  IImages,
} from "../../types";

describe("Game actions creator", () => {
  it("should create the category action object", () => {
    const category: ICategory = {
      id: 0,
      folder: "habana",
      name: "CATEGORY_HAVANA_LANDMARKS",
    };

    const actionCategory = changeCategory(category);

    expect(actionCategory).toEqual({
      type: CHANGE_CATEGORY,
      category: {
        ...category,
      },
    });
  });

  it("should create the disabled action object", () => {
    const disabled = false;

    const actionDisabled = changeDisabled(disabled);

    expect(actionDisabled).toEqual({
      type: CHANGE_DISABLED,
      disabled,
    });
  });

  it("should create the first move action object", () => {
    const first = Player.Computer;

    const actionFirstMove = changeFirst(first);

    expect(actionFirstMove).toEqual({
      type: CHANGE_FIRST,
      first,
    });
  });

  it("should create the images action object", () => {
    const images: IImages = {
      user: 10,
      computer: 11,
    };

    const actionImages = changeImages(images);

    expect(actionImages).toEqual({
      type: CHANGE_IMAGES,
      images: {
        ...images,
      },
    });
  });

  it("should create the computer playing level action object", () => {
    const level = PlayingLevel.Smart;

    const actionLevel = changeLevel(level);

    expect(actionLevel).toEqual({
      type: CHANGE_PLAYING_LEVEL,
      level,
    });
  });

  it("should create the game over action object", () => {
    const over = true;

    const actionOver = changeOver(over);

    expect(actionOver).toEqual({
      type: CHANGE_OVER,
      over,
    });
  });

  it("should create the game result action object", () => {
    const result = GameResult.Won;

    const actionGameResult = changeResult(result);

    expect(actionGameResult).toEqual({
      type: CHANGE_GAME_RESULT,
      result,
    });
  });

  it("should create the winning squares action object", () => {
    const winners = [4, 5, 6];

    const actionWinnerSquares = changeWinners(winners);

    expect(actionWinnerSquares).toEqual({
      type: CHANGE_WINNERS_SQUARES,
      winners,
    });
  });
});
