import React, { useContext, FC } from "react";
import { DictionaryContext } from "../../contexts/dictionary/DictionaryContext";
import "./Category.scss";
import { CategoryId, ICategory } from "../../types";
import categories from "../../assets/json/categories.json";

interface Props {
  categoryId: CategoryId;
}

const Historical: FC<Props> = ({ categoryId }) => {
  const { dictionary } = useContext(DictionaryContext);

  return (
    <div className="categories" data-testid="categories">
      {dictionary.CATEGORY}:{" "}
      {dictionary[(categories as ICategory[])[categoryId].name]}
    </div>
  );
};

export default Historical;
