import React, { useContext, memo, FC } from "react";
import { DictionaryContext } from "../../contexts/dictionary/DictionaryContext";
import { GameContext } from "../../contexts/game/GameContext";
import { changeCategory } from "../../actions/game";
import { ICategory, Action, IDictionaryEntry } from "../../types";
import "./Category.scss";
import categories from "../../assets/json/categories.json";

interface Props {
  disabled: boolean;
  categoryId: number;
  dispatch: React.Dispatch<Action>;
  categories: ICategory[];
  dictionary: IDictionaryEntry;
}

const MemoizedCategory: FC<Props> = memo(
  ({ disabled, categoryId, dispatch, categories, dictionary }) => {
    return (
      <div className="categories" data-testid="categories">
        <label htmlFor="categories">{dictionary.CATEGORY}: </label>
        <select
          id="categories"
          defaultValue={categoryId}
          onChange={(e) => {
            dispatch(changeCategory(categories[+e.target.value]));
          }}
          disabled={disabled}
        >
          {categories.map((category: ICategory) => {
            return (
              <option key={category.name} value={category.id}>
                {dictionary[category.name]}
              </option>
            );
          })}
        </select>
      </div>
    );
  }
);

const Category: FC = () => {
  const { dictionary } = useContext(DictionaryContext);
  const { game, dispatch } = useContext(GameContext);

  return (
    <MemoizedCategory
      disabled={game.disabled}
      categoryId={game.category.id}
      dispatch={dispatch}
      categories={categories as ICategory[]}
      dictionary={dictionary}
    />
  );
};

export default Category;
