import React, { useContext, FC } from "react";
import { DictionaryContext } from "../../contexts/dictionary/DictionaryContext";
import { CategoryFolder, IImage } from "../../types";
import "./Image.scss";

interface Props {
  folder: CategoryFolder;
  imageUser: IImage;
  imageComputer: IImage;
}

const Historical: FC<Props> = ({ folder, imageUser, imageComputer }) => {
  const { dictionary } = useContext(DictionaryContext);
  const url = "http://localhost:4000/images";

  return (
    <div className="images historical" data-testid="images-historical">
      <div className="user-image">
        <span>{dictionary.IMAGE_USER_LABEL + ": "}</span>
        <img
          className="image-token"
          src={`${url}/${folder}/${imageUser}.jpg`}
          alt="user"
        />
      </div>

      <div className="computer-image">
        <span>{dictionary.IMAGE_COMPUTER_LABEL + ": "}</span>
        <img
          className="image-token"
          src={`${url}/${folder}/${imageComputer}.jpg`}
          alt="computer"
        />
      </div>
    </div>
  );
};

export default Historical;
