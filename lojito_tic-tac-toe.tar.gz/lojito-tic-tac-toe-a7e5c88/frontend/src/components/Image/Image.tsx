import React, { useContext, useEffect, memo, FC } from "react";
import { DictionaryContext } from "../../contexts/dictionary/DictionaryContext";
import { GameContext } from "../../contexts/game/GameContext";
import { changeImages } from "../../actions/game";
import useImages from "../../hooks/useImages";
import "./Image.scss";
import { Action, IDictionaryEntry, CategoryFolder, IImage } from "../../types";

interface Props {
  disabled: boolean;
  folder: CategoryFolder;
  user: IImage;
  computer: IImage;
  dispatch: React.Dispatch<Action>;
  dictionary: IDictionaryEntry;
}

const MemoizedImage: FC<Props> = memo(
  ({ disabled, folder, user, computer, dispatch, dictionary }) => {
    const url = `${process.env.PUBLIC_URL}/images`;
    const backendUrl = "http://localhost:4000/images";
    const { images, handleRefreshImage } = useImages(user, computer);
    const { user: imageUser, computer: imageComputer } = images;

    useEffect(() => {
      if (imageUser === user && imageComputer === computer) {
        return;
      }
      dispatch(
        changeImages({
          user: imageUser,
          computer: imageComputer,
        })
      );
    }, [imageUser, imageComputer, user, computer, dispatch]);

    const imgClassName = `refresh ${disabled ? " disabled" : ""}`;

    return (
      <div className="images" data-testid="images">
        <div className="user-image">
          <span>{dictionary.IMAGE_USER_LABEL}: </span>
          <img
            className="image-token"
            src={`${backendUrl}/${folder}/${imageUser}.jpg`}
            alt="user"
            title={dictionary.IMAGE_USER_TOOLTIP}
          />
          <img
            className={imgClassName}
            id="user"
            src={`${url}/refresh.png`}
            alt="refresh-user-img"
            onClick={(e) => handleRefreshImage(e)}
            title={dictionary.IMAGE_REFRESH_TOOLTIP}
          />
        </div>

        <div className="computer-image">
          <span>{dictionary.IMAGE_COMPUTER_LABEL}: </span>
          <img
            className="image-token"
            src={`${backendUrl}/${folder}/${imageComputer}.jpg?`}
            alt="computer"
            title={dictionary.IMAGE_COMPUTER_TOOLTIP}
          />
          <img
            className={imgClassName}
            id="computer"
            src={`${url}/refresh.png`}
            alt="refresh-computer-img"
            onClick={(e) => handleRefreshImage(e)}
            title={dictionary.IMAGE_REFRESH_TOOLTIP}
          />
        </div>
      </div>
    );
  }
);

const Image: FC = () => {
  const { dictionary } = useContext(DictionaryContext);
  const { game, dispatch } = useContext(GameContext);
  const folder = game.category.folder;
  const { user, computer } = game.images;

  return (
    <MemoizedImage
      disabled={game.disabled}
      folder={folder}
      user={user}
      computer={computer}
      dispatch={dispatch}
      dictionary={dictionary}
    />
  );
};

export default Image;
