import React, { useContext, useEffect, FC } from "react";
import { DictionaryContext } from "../../contexts/dictionary/DictionaryContext";
import Historical from "../Game/Historical";
import useFetchGame from "../../hooks/game/useFetchGame";
import useDeleteGame from "../../hooks/game/useDeleteGame";
import { match, RouteComponentProps } from "react-router-dom";

interface AuditCompareRouteParams {
  id: string;
}

interface Props {
  match?: match<AuditCompareRouteParams>;
  token: string;
  history: RouteComponentProps["history"];
}

const GameHistorical: FC<Props> = ({ token, match, history }) => {
  const { dictionary } = useContext(DictionaryContext);
  const {
    game,
    error: errorFetchingGame,
    handleFetchGame,
  } = useFetchGame(token);
  const {
    gameId,
    error: errorDeletingGame,
    handleDeleteGame,
  } = useDeleteGame(token);

  useEffect(() => {
    handleFetchGame(match!.params.id);
  }, [handleFetchGame, match]);

  useEffect(() => {
    if (gameId && !errorDeletingGame) {
      history!.push("/historical");
    }
  }, [gameId, errorDeletingGame, history]);

  if (errorFetchingGame) {
    return <div className="error">{errorFetchingGame}</div>;
  }

  if (!game) {
    return <div className="error">{dictionary.HISTORICAL_NO_DATA_YET}</div>;
  }

  return (
    <div className="text-center">
      {errorDeletingGame ? (
        <div className="error">{errorDeletingGame}</div>
      ) : (
        ""
      )}
      <Historical
        key={game._id}
        game={game}
        displayBoard={true}
        onDeleteGame={async () => {
          await handleDeleteGame(game._id!);
        }}
      />
    </div>
  );
};

export default GameHistorical;
