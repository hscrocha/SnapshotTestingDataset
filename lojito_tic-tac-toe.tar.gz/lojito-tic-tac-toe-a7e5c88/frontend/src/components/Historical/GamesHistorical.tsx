import React, { useContext, useEffect, FC } from "react";
import { DictionaryContext } from "../../contexts/dictionary/DictionaryContext";
import Historical from "../Game/Historical";
import useFetchGames from "../../hooks/game/useFetchGames";
import useDeleteGame from "../../hooks/game/useDeleteGame";

import { IDBGame } from "../../types";

interface Props {
  token: string;
}

const GamesHistorical: FC<Props> = ({ token }) => {
  const { dictionary } = useContext(DictionaryContext);
  const {
    games,
    error: errorFetchingGames,
    handleFetchGames,
    handleRemoveGame,
  } = useFetchGames(token);
  const {
    gameId,
    error: errorDeletingGame,
    handleDeleteGame,
  } = useDeleteGame(token);

  useEffect(() => {
    handleFetchGames();
  }, [handleFetchGames]);

  useEffect(() => {
    if (gameId && !errorDeletingGame) {
      handleRemoveGame(gameId);
    }
  }, [handleRemoveGame, gameId, errorDeletingGame]);

  if (errorFetchingGames) {
    return <div className="error">{errorFetchingGames}</div>;
  }

  if (!games || games.length === 0) {
    return <div className="error">{dictionary.HISTORICAL_NO_DATA_YET}</div>;
  }

  return (
    <div className="text-center">
      {errorDeletingGame ? (
        <div className="error">{errorDeletingGame}</div>
      ) : (
        ""
      )}
      {games.map((game: IDBGame) => {
        return (
          <Historical
            key={game._id}
            game={game}
            displayBoard={false}
            onDeleteGame={async () => {
              await handleDeleteGame(game._id!);
            }}
          />
        );
      })}
    </div>
  );
};

export default GamesHistorical;
