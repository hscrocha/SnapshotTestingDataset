import React, { FC, memo } from "react";
import Square from "../Square/Historical";
import {
  Player,
  GameBoard,
  Square as BoardSquare,
  CategoryFolder,
  IImage,
} from "../../types";
import "./Board.scss";

interface Props {
  folder: CategoryFolder;
  imageComputer: IImage;
  imageUser: IImage;
  board: GameBoard;
  winners: BoardSquare[];
}

const Historical: FC<Props> = ({
  folder,
  imageUser,
  imageComputer,
  board,
  winners,
}) => {
  const boardJSX = board.map((player: Player, square: BoardSquare) => {
    const imagePath =
      player === Player.Computer
        ? `${folder}/${imageComputer}`
        : player === Player.User
        ? `${folder}/${imageUser}`
        : "default";
    const className = winners.indexOf(square) !== -1 ? "win" : "";

    return (
      <Square
        disabled={true}
        id={square + ""}
        imagePath={imagePath}
        key={`square-${square}`}
        className={className}
      />
    );
  });

  return <div className="board">{boardJSX}</div>;
};

export default memo(Historical);
