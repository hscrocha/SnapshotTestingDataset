import React, { useContext, FC, memo } from "react";
import { GameContext } from "../../contexts/game/GameContext";
import Square from "../Square/Square";
import useBoard from "../../hooks/useBoard";
import {
  IDBGame,
  Player,
  Square as BoardSquare,
  GameBoard,
  CategoryFolder,
  IImage,
} from "../../types";
import "./Board.scss";

interface MemoizedBoardProps {
  playGame: (id?: BoardSquare | undefined) => void;
  disabled: boolean;
  board: GameBoard;
  folder: CategoryFolder;
  imageUser: IImage;
  imageComputer: IImage;
  over: boolean;
  winners: BoardSquare[];
}

const MemoizedBoard: FC<MemoizedBoardProps> = memo(
  ({
    disabled,
    board,
    folder,
    imageUser,
    imageComputer,
    over,
    winners,
    playGame,
  }) => {
    const squares = board.map((player: Player, square: BoardSquare) => {
      const imagePath =
        player === Player.Computer
          ? `${folder}/${imageComputer}`
          : player === Player.User
          ? `${folder}/${imageUser}`
          : "default";
      const isDisabled =
        !disabled || over || player !== Player.Nobody ? true : false;
      const className = over
        ? winners.indexOf(square) !== -1
          ? "win"
          : ""
        : "";

      return (
        <Square
          disabled={isDisabled}
          id={square + ""}
          imagePath={imagePath}
          key={`square-${square}`}
          className={className}
        />
      );
    });

    return (
      <div
        className="board"
        onClick={(e: React.MouseEvent<HTMLDivElement, MouseEvent>) => {
          playGame(+(e.target as HTMLDivElement).id);
        }}
        data-testid="board"
      >
        {squares}
      </div>
    );
  }
);

interface Props {
  onGameOver: (game: IDBGame) => void;
}

const Board: FC<Props> = ({ onGameOver }) => {
  const { game } = useContext(GameContext);
  const { category, disabled, images, over, winners } = game;
  const { folder } = category;
  const { user: imageUser, computer: imageComputer } = images;

  const { playGame, gameBoard: board } = useBoard(game, onGameOver);

  return (
    <MemoizedBoard
      disabled={disabled}
      board={board}
      folder={folder}
      imageUser={imageUser}
      imageComputer={imageComputer}
      over={over}
      winners={winners}
      playGame={playGame}
    />
  );
};

export default Board;
