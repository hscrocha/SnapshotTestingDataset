import {
  Action,
  IState,
  CHANGE_CATEGORY,
  CHANGE_DISABLED,
  CHANGE_FIRST,
  CHANGE_IMAGES,
  CHANGE_PLAYING_LEVEL,
  CHANGE_OVER,
  CHANGE_GAME_RESULT,
  CHANGE_WINNERS_SQUARES,
} from "../types";

export const gameReducer = (state: IState, action: Action) => {
  const newState = {
    ...state,
    category: {
      ...state.category,
    },
    images: {
      ...state.images,
    },
  };

  switch (action.type) {
    case CHANGE_CATEGORY:
      return {
        ...newState,
        category: {
          ...action.category,
        },
      };

    case CHANGE_DISABLED:
      return {
        ...newState,
        disabled: action.disabled,
      };

    case CHANGE_FIRST:
      return {
        ...newState,
        first: action.first,
      };

    case CHANGE_IMAGES:
      return {
        ...newState,
        images: {
          ...action.images,
        },
      };

    case CHANGE_PLAYING_LEVEL:
      return {
        ...newState,
        level: action.level,
      };

    case CHANGE_OVER:
      return {
        ...newState,
        over: action.over,
      };

    case CHANGE_GAME_RESULT:
      return {
        ...newState,
        result: action.result,
      };

    case CHANGE_WINNERS_SQUARES:
      return {
        ...newState,
        winners: action.winners,
      };

    default:
      return state;
  }
};
