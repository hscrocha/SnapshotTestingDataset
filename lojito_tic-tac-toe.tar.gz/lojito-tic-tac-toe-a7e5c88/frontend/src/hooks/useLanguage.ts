import { useState, useCallback } from "react";
import { Language } from "../types";

function useLanguage(lang: Language) {
  const [language, setLanguage] = useState(lang);

  const handleChangeLanguage = useCallback((language: Language) => {
    setLanguage(language);
  }, []);

  return { language, handleChangeLanguage };
}

export default useLanguage;
