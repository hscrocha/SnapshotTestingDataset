import { useState, useCallback } from "react";
import axios from "axios";
import useMounted from "../useMounted";
import { IDBGame } from "../../types";

interface IFetchGame {
  game: IDBGame | null;
  error: string;
}

function useFetchGame(token: string) {
  const isMounted = useMounted();
  const [state, setState] = useState<IFetchGame>({
    game: null,
    error: "",
  });

  const updateState = useCallback(
    (newState: IFetchGame) => {
      if (isMounted()) {
        setState({ ...newState });
      }
    },
    [isMounted]
  );

  const handleFetchGame = useCallback(
    async (gameId: string) => {
      try {
        const res = await axios.get(
          `http://localhost:4000/api/games/${gameId}`,
          {
            headers: { Authorization: `Bearer ${token}` },
          }
        );
        updateState({ game: res.data, error: "" });
      } catch (e) {
        updateState({
          game: null,
          error: "Error while fetching the game historical from the database.",
        });
      }
    },
    [token, updateState]
  );

  return { ...state, handleFetchGame };
}

export default useFetchGame;
