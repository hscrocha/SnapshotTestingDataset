import { useState, useCallback } from "react";
import axios from "axios";
import useMounted from "../useMounted";
import { IDBGame } from "../../types";

interface IFetchGames {
  games: IDBGame[] | null;
  error: string;
}

function useFetchGames(token: string) {
  const isMounted = useMounted();
  const [state, setState] = useState<IFetchGames>({
    games: null,
    error: "",
  });

  const updateState = useCallback(
    (newState: IFetchGames) => {
      if (isMounted()) {
        setState({ ...newState });
      }
    },
    [isMounted]
  );

  const handleFetchGames = useCallback(async () => {
    try {
      const res = await axios.get("http://localhost:4000/api/games", {
        headers: { Authorization: `Bearer ${token}` },
      });
      updateState({ games: res.data, error: "" });
    } catch (e) {
      updateState({
        games: null,
        error: "Error while fetching the games historical from the database.",
      });
    }
  }, [token, updateState]);

  const handleRemoveGame = useCallback(
    (gameId: string) => {
      if (state.games) {
        const newGames = state.games.filter((game) => game._id !== gameId);
        if (newGames.length !== state.games.length) {
          if (newGames.length === 0) {
            updateState({ games: null, error: "" });
          } else {
            updateState({ games: newGames, error: "" });
          }
        }
      }
    },
    [state.games, updateState]
  );

  return { ...state, handleFetchGames, handleRemoveGame };
}

export default useFetchGames;
