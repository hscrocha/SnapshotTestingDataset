import { useCallback, useState } from "react";
import axios from "axios";
import useMounted from "../useMounted";

interface IDeleteGame {
  gameId: string;
  error: string;
}

function useDeleteGame(token: string) {
  const isMounted = useMounted();
  const [state, setState] = useState<IDeleteGame>({
    gameId: "",
    error: "",
  });

  const updateState = useCallback(
    (newState: IDeleteGame) => {
      if (isMounted()) {
        setState({ ...newState });
      }
    },
    [isMounted]
  );

  const handleDeleteGame = useCallback(
    async (gameId: string) => {
      try {
        await axios.delete(`http://localhost:4000/api/games/${gameId}`, {
          headers: { Authorization: `Bearer ${token}` },
        });
        updateState({
          gameId,
          error: "",
        });
      } catch (e) {
        updateState({
          gameId,
          error: "Error while deleting the game from the database.",
        });
      }
    },
    [token, updateState]
  );

  return { ...state, handleDeleteGame };
}

export default useDeleteGame;
