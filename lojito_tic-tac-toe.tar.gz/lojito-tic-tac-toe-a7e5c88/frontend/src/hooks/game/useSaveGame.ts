import { useCallback, useState } from "react";
import axios from "axios";
import useMounted from "../useMounted";
import { IDBGame } from "../../types";

function useSaveGame(token: string) {
  const isMounted = useMounted();
  const [error, setError] = useState("");

  const updateState = useCallback(
    (newError: string) => {
      if (isMounted()) {
        setError(newError);
      }
    },
    [isMounted]
  );

  const handleSaveGame = useCallback(
    async (game: IDBGame) => {
      try {
        await axios.post("http://localhost:4000/api/games/", game, {
          headers: { Authorization: `Bearer ${token}` },
        });

        updateState("");
      } catch (e) {
        updateState("Error while saving the game info to the database");
      }
    },
    [token, updateState]
  );

  return { error, handleSaveGame };
}

export default useSaveGame;
