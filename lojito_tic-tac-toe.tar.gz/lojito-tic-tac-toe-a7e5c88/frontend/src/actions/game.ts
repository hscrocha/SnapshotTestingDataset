import {
  GameResult,
  ICategory,
  IImages,
  FirstPlayer,
  PlayingLevel,
  Square,
  CHANGE_CATEGORY,
  CHANGE_DISABLED,
  CHANGE_FIRST,
  CHANGE_IMAGES,
  CHANGE_PLAYING_LEVEL,
  CHANGE_OVER,
  CHANGE_GAME_RESULT,
  CHANGE_WINNERS_SQUARES,
  ActionCategory,
  ActionDisabled,
  ActionFirst,
  ActionImages,
  ActionPlayingLevel,
  ActionOver,
  ActionResult,
  ActionWinners,
} from "../types";

export const changeCategory = (category: ICategory): ActionCategory => {
  return {
    type: CHANGE_CATEGORY,
    category,
  };
};

export const changeDisabled = (disabled: boolean): ActionDisabled => {
  return {
    type: CHANGE_DISABLED,
    disabled,
  };
};

export const changeFirst = (first: FirstPlayer): ActionFirst => {
  return {
    type: CHANGE_FIRST,
    first,
  };
};

export const changeImages = (images: IImages): ActionImages => {
  return {
    type: CHANGE_IMAGES,
    images,
  };
};

export const changeLevel = (level: PlayingLevel): ActionPlayingLevel => {
  return {
    type: CHANGE_PLAYING_LEVEL,
    level,
  };
};

export const changeOver = (over: boolean): ActionOver => {
  return {
    type: CHANGE_OVER,
    over,
  };
};

export const changeResult = (result: GameResult): ActionResult => {
  return {
    type: CHANGE_GAME_RESULT,
    result,
  };
};

export const changeWinners = (winners: Square[]): ActionWinners => {
  return {
    type: CHANGE_WINNERS_SQUARES,
    winners,
  };
};
