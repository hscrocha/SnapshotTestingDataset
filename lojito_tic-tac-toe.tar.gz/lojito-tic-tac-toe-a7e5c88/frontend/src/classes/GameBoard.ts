import { PlayingLevel, Player, GameBoard, Square } from "../types";

export class Board {
  readonly totalSquares = 9;
  readonly SQUARE_NOT_FOUND = -1;

  private board: GameBoard;
  private _moves = 0;

  constructor(
    private _first = Player.User,
    private _level = PlayingLevel.Easy
  ) {
    this.board = Array(this.totalSquares).fill(Player.Nobody) as GameBoard;
  }

  get level() {
    return this._level;
  }

  set level(level) {
    this._level = level;
  }

  get first() {
    return this._first;
  }

  set first(first) {
    this._first = first;
  }

  get moves() {
    return this._moves;
  }

  get isFull() {
    return !this.board.includes(Player.Nobody);
  }

  get isEmpty() {
    return !(
      this.board.includes(Player.Computer) || this.board.includes(Player.User)
    );
  }

  get emptySquares() {
    return this.board.reduce((squares: Square[], player, square: Square) => {
      if (player === Player.Nobody) {
        squares.push(square);
      }
      return squares;
    }, []);
  }

  reset() {
    this.board.fill(Player.Nobody);
    this._moves = 0;
  }

  getBoard() {
    return [...this.board] as GameBoard;
  }

  place(player: Player, square: Square) {
    this.board[square] = player;
    if (player !== Player.Nobody) {
      this._moves++;
    } else {
      this._moves--;
    }

    return true;
  }

  private getSquaresByDirection(): Square[][] {
    return [
      [Square.TopLeft, Square.TopCenter, Square.TopRight],
      [Square.MiddleLeft, Square.MiddleCenter, Square.MiddleRight],
      [Square.BottomLeft, Square.BottomCenter, Square.BottomRight],
      [Square.TopLeft, Square.MiddleLeft, Square.BottomLeft],
      [Square.TopCenter, Square.MiddleCenter, Square.BottomCenter],
      [Square.TopRight, Square.MiddleRight, Square.BottomRight],
      [Square.TopLeft, Square.MiddleCenter, Square.BottomRight],
      [Square.TopRight, Square.MiddleCenter, Square.BottomLeft],
    ];
  }

  isAWinner(player: Player) {
    if (player === Player.Nobody) {
      return [];
    }

    const arrSquares = this.getSquaresByDirection();
    let square0, square1, square2: Square;
    for (const squares of arrSquares) {
      [square0, square1, square2] = squares;

      if (
        this.board[square0] === player &&
        this.board[square1] === player &&
        this.board[square2] === player
      ) {
        return squares;
      }
    }

    return [];
  }

  canWinInOneMove(player: Player) {
    const arrSquares = this.getSquaresByDirection();

    let square0, square1, square2: Square;

    for (const squares of arrSquares) {
      [square0, square1, square2] = squares;

      if (
        this.board[square0] === player &&
        this.board[square1] === player &&
        this.board[square2] === Player.Nobody
      ) {
        return square2;
      }

      if (
        this.board[square0] === player &&
        this.board[square1] === Player.Nobody &&
        this.board[square2] === player
      ) {
        return square1;
      }

      if (
        this.board[square0] === Player.Nobody &&
        this.board[square1] === player &&
        this.board[square2] === player
      ) {
        return square0;
      }
    }

    return this.SQUARE_NOT_FOUND;
  }

  canWinInTwoMovesSingle = (player: Player) => {
    const arrSquares = this.getSquaresByDirection();

    const result = [];

    let square0, square1, square2: Square;

    for (const squares of arrSquares) {
      [square0, square1, square2] = squares;

      if (
        this.board[square0] === player &&
        this.board[square1] === Player.Nobody &&
        this.board[square2] === Player.Nobody
      ) {
        result.push(square1);
        result.push(square2);
      }

      if (
        this.board[square0] === Player.Nobody &&
        this.board[square1] === player &&
        this.board[square2] === Player.Nobody
      ) {
        result.push(square0);
        result.push(square2);
      }

      if (
        this.board[square0] === Player.Nobody &&
        this.board[square1] === Player.Nobody &&
        this.board[square2] === player
      ) {
        result.push(square0);
        result.push(square1);
      }
    }

    return result;
  };

  canWinInTwoMovesDouble = (player: Player) => {
    const arrSquares = [
      [
        Square.TopLeft,
        Square.TopCenter,
        Square.TopRight,
        Square.MiddleLeft,
        Square.BottomLeft,
      ],
      [
        Square.TopLeft,
        Square.TopCenter,
        Square.TopRight,
        Square.MiddleCenter,
        Square.BottomRight,
      ],
      [
        Square.TopLeft,
        Square.MiddleLeft,
        Square.BottomLeft,
        Square.MiddleCenter,
        Square.BottomRight,
      ],
      [
        Square.TopRight,
        Square.TopLeft,
        Square.TopCenter,
        Square.MiddleRight,
        Square.BottomRight,
      ],
      [
        Square.TopRight,
        Square.TopLeft,
        Square.TopCenter,
        Square.MiddleCenter,
        Square.BottomLeft,
      ],
      [
        Square.TopRight,
        Square.MiddleRight,
        Square.BottomRight,
        Square.MiddleCenter,
        Square.BottomLeft,
      ],
      [
        Square.BottomLeft,
        Square.TopLeft,
        Square.MiddleLeft,
        Square.BottomCenter,
        Square.BottomRight,
      ],
      [
        Square.BottomLeft,
        Square.TopLeft,
        Square.MiddleLeft,
        Square.TopRight,
        Square.MiddleCenter,
      ],
      [
        Square.BottomLeft,
        Square.TopRight,
        Square.MiddleCenter,
        Square.BottomCenter,
        Square.BottomRight,
      ],
      [
        Square.BottomRight,
        Square.BottomLeft,
        Square.BottomCenter,
        Square.TopRight,
        Square.MiddleRight,
      ],
      [
        Square.BottomRight,
        Square.BottomLeft,
        Square.BottomCenter,
        Square.TopLeft,
        Square.MiddleCenter,
      ],
      [
        Square.BottomRight,
        Square.TopRight,
        Square.MiddleRight,
        Square.TopLeft,
        Square.MiddleCenter,
      ],
      [
        Square.TopCenter,
        Square.TopLeft,
        Square.TopRight,
        Square.MiddleCenter,
        Square.BottomCenter,
      ],
      [
        Square.MiddleLeft,
        Square.TopLeft,
        Square.BottomLeft,
        Square.MiddleCenter,
        Square.MiddleRight,
      ],
      [
        Square.MiddleRight,
        Square.TopRight,
        Square.BottomRight,
        Square.MiddleLeft,
        Square.MiddleCenter,
      ],
      [
        Square.BottomCenter,
        Square.TopCenter,
        Square.MiddleCenter,
        Square.BottomLeft,
        Square.BottomRight,
      ],
    ];

    const result = [];

    let square0, square1, square2, square3, square4: Square;

    for (const squares of arrSquares) {
      [square0, square1, square2, square3, square4] = squares;

      if (
        this.board[square0] === Player.Nobody &&
        ((this.board[square1] === Player.Nobody &&
          this.board[square2] === player) ||
          (this.board[square1] === player &&
            this.board[square2] === Player.Nobody)) &&
        ((this.board[square3] === Player.Nobody &&
          this.board[square4] === player) ||
          (this.board[square3] === player &&
            this.board[square4] === Player.Nobody))
      ) {
        result.push(square0);
      }
    }

    return result;
  };
}

export default new Board();
