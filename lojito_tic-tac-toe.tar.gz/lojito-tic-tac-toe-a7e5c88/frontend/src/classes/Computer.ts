import GameBoard from "./GameBoard";
import { PlayingLevel, Player, Square } from "../types";

export class Computer {
  constructor(private board: typeof GameBoard) {}

  playForTheFirstTime = () => {
    const board = this.board.getBoard();
    if (this.board.isEmpty) {
      this.board.place(
        Player.Computer,
        [
          Square.TopLeft,
          Square.TopRight,
          Square.BottomLeft,
          Square.BottomRight,
          Square.MiddleCenter,
        ][Math.floor(Math.random() * 5)]
      );
    } else {
      this.board.place(
        Player.Computer,
        board[Square.MiddleCenter] === Player.User
          ? [
              Square.TopLeft,
              Square.TopRight,
              Square.BottomLeft,
              Square.BottomRight,
            ][Math.floor(Math.random() * 4)]
          : Square.MiddleCenter
      );
    }
  };

  playForTheSecondTime = () => {
    const board = this.board.getBoard();

    if (board[Square.MiddleCenter] === Player.Computer) {
      let square = [
        Square.TopLeft,
        Square.TopRight,
        Square.BottomLeft,
        Square.BottomRight,
      ][Math.floor(Math.random() * 4)];

      while (board[square] !== Player.Nobody) {
        square = [
          Square.TopLeft,
          Square.TopRight,
          Square.BottomLeft,
          Square.BottomRight,
        ][Math.floor(Math.random() * 4)];
      }

      this.board.place(Player.Computer, square);
    } else if (board[Square.MiddleCenter] === Player.User) {
      this.playOnAnyEmptySquare();
    } else {
      this.board.place(Player.Computer, Square.MiddleCenter);
    }
  };

  playAgain = () => {
    let square: Square | -1;
    let squares: Square[];

    square = this.board.canWinInOneMove(Player.Computer);
    if (square !== GameBoard.SQUARE_NOT_FOUND) {
      this.board.place(Player.Computer, square);
      return;
    }

    square = this.board.canWinInOneMove(Player.User);
    if (square !== GameBoard.SQUARE_NOT_FOUND) {
      this.board.place(Player.Computer, square);
      return;
    }

    squares = this.board.canWinInTwoMovesDouble(Player.Computer);
    if (squares.length > 0) {
      this.board.place(
        Player.Computer,
        squares[Math.floor(Math.random() * squares.length)]
      );
      return;
    }

    squares = this.board.canWinInTwoMovesSingle(Player.Computer);
    for (const square of squares) {
      this.board.place(Player.Computer, square);
      let squareComputer: Square | -1 = this.board.canWinInOneMove(
        Player.Computer
      );
      let squaresUser = this.board.canWinInTwoMovesDouble(Player.User);
      if (
        squaresUser.length > 0 &&
        squaresUser.indexOf(squareComputer) !== -1
      ) {
        this.board.place(Player.Nobody, square);
      } else {
        return;
      }
    }

    this.playOnAnyEmptySquare();
  };

  playSmart = () => {
    let moves = this.board.moves;

    if (this.board.first === Player.User) {
      if (moves === 1) {
        this.playForTheFirstTime();
      } else {
        this.playAgain();
      }
    } else if (this.board.isEmpty) {
      this.playForTheFirstTime();
    } else if (moves === 2) {
      this.playForTheSecondTime();
    } else {
      this.playAgain();
    }
  };

  playOnAnyEmptySquare = () => {
    const emptySquares = this.board.emptySquares;

    this.board.place(
      Player.Computer,
      emptySquares[Math.floor(Math.random() * emptySquares.length)]
    );
  };

  play = () => {
    const level = this.board.level;

    if (level === PlayingLevel.Smart) {
      this.playSmart();
    } else {
      this.playOnAnyEmptySquare();
    }
  };
}

export default new Computer(GameBoard);
