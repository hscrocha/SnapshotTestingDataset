import { IUser } from "./user";

export interface IGame {
  board: [
    number,
    number,
    number,
    number,
    number,
    number,
    number,
    number,
    number
  ];
  categoryId: number;
  first: number;
  imageComputer: number;
  imageUser: number;
  level: number;
  result: number;
  winners: [number, number, number];
  user: IUser;
}
