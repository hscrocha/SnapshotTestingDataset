export { default as XAxis } from './xaxis.js';
