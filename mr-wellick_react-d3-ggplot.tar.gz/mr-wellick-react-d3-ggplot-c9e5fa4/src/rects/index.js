export { default as Rects } from './rects.js';
