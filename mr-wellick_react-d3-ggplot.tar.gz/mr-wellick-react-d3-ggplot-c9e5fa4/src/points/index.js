export { default as Points } from './points.js';
