export const api = {
  save: jest.fn(),
  load: jest.fn(),
}
