module.exports = {
  accessCode: {
    validCode: {
      code: process.env.VALID_ACCESS_CODE
    },
    invalidCode: {
      code: process.env.INVALID_ACCESS_CODE
    }
  }
};
