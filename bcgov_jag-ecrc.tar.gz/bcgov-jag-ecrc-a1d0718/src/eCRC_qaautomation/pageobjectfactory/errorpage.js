class ErrorPage {
  constructor() {
    this.homeButton = element(by.buttonText("Home"));
  }
}

module.exports = new ErrorPage();
