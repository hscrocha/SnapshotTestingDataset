import initStoryshots from "@storybook/addon-storyshots";

window.scrollTo = jest.fn();

initStoryshots({
  /* configuration options */
});
