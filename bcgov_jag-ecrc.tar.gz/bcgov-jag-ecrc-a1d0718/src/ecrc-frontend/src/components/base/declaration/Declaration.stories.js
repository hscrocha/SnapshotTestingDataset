/* eslint-disable react/jsx-props-no-spreading */
import React from "react";
import { storiesOf } from "@storybook/react";

import Declaration from "./Declaration";

storiesOf("Declaration", module)
  .add("Default", () => <Declaration shareConsent={false} />)
  .add("ShareDeclaration", () => <Declaration shareConsent />);
