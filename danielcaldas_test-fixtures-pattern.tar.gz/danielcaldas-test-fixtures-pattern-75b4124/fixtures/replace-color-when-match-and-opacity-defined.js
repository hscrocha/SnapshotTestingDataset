const target = 'background-color: rgb(255, 0, 0)';
const fromColor = [255, 0, 0];
const toColor = [0, 255, 0];
const opacity = 0.5;
const options = { fromColor, toColor, opacity };

module.exports = { target, options };
