const target = 'background-color: rgb(253, 0, 0)';
const fromColor = [255, 0, 0];
const toColor = undefined;
const options = { fromColor, toColor };

module.exports = { target, options };
