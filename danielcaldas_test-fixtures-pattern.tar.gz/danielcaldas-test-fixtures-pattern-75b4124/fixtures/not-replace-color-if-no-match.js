const target = 'background-color: rgb(254, 0, 0)';
const fromColor = [255, 0, 0];
const toColor = [0, 255, 0];
const options = { fromColor, toColor };

module.exports = { target, options };
