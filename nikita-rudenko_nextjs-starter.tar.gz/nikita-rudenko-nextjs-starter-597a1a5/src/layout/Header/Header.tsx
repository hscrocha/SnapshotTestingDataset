function Header(): JSX.Element {
  return <header>Header</header>;
}

export default Header;
