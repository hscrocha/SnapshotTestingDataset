import { ReactNode } from 'react';

export type TRenderProps = {
  children: ReactNode;
};
