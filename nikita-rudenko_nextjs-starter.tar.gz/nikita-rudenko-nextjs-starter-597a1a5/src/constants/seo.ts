export const HEAD_TITLE = 'Next.js Starter';
