'use strict';
module.exports = require('@xunnamius/conventional-changelog-projector')({
  // * Your customizations here
});
