declare module 'unique-filename' {
  export default function (
    directory: string,
    filePrefix?: string,
    uniqStr?: string
  ): string;
}
