/**
 * An internal symbol representing the type of a normalized test configuration.
 *
 * @internal
 */
export const $type = Symbol('test-object-type');
