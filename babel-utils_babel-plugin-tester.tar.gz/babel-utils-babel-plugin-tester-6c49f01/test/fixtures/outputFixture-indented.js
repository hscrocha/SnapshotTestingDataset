const olleh = 'hey';
const owTolleh = 'hey';
const eerhTolleh = 'hey';
