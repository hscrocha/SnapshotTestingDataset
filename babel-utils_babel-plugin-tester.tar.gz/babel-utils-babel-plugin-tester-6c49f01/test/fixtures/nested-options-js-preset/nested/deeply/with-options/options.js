module.exports = {
  presetOptions: {
    bar: 'baz'
  }
};
