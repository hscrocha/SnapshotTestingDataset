module.exports = {
  presetOptions: {
    foo: 'bar'
  }
};
