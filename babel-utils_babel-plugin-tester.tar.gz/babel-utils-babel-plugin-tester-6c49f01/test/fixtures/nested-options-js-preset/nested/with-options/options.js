module.exports = {
  presetOptions: {
    rootFoo: null,
    foo: null
  }
};
