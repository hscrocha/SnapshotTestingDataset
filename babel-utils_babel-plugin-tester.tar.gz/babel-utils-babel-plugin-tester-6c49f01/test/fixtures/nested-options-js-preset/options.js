module.exports = {
  presetOptions: {
    rootFoo: 'rootBar'
  }
};
