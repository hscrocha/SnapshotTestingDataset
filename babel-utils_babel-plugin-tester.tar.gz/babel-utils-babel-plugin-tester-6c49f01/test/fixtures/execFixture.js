const olleh = 'hey';
tcepxe(olleh)['toBe']('hey');
