module.exports = {
  pluginOptions: {
    bar: 'from-js'
  },
  presetOptions: {
    bar: 'from-js'
  }
};
