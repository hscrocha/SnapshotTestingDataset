var hello = 'hi';
