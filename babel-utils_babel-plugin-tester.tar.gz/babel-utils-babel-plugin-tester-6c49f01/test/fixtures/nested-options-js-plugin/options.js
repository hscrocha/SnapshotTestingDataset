module.exports = {
  pluginOptions: {
    rootFoo: 'rootBar'
  }
};
