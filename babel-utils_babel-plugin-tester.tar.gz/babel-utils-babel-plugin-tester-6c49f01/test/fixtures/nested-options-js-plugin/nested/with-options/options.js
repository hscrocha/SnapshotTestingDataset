module.exports = {
  pluginOptions: {
    rootFoo: null,
    foo: null
  }
};
