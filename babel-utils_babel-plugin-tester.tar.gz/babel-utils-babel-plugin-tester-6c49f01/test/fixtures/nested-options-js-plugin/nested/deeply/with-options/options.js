module.exports = {
  pluginOptions: {
    bar: 'baz'
  }
};
