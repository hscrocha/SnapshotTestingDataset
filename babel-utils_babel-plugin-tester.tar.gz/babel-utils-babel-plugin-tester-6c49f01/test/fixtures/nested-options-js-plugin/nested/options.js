module.exports = {
  pluginOptions: {
    foo: 'bar'
  }
};
