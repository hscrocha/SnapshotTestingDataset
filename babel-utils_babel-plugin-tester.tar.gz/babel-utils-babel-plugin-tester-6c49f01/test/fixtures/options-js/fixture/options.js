module.exports = {
  pluginOptions: {
    bar: 'baz'
  },
  presetOptions: {
    bar: 'baz'
  }
};
