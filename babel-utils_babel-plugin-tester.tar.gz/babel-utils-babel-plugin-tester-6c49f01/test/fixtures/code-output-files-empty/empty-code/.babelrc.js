module.exports = {
  plugins: ['@babel/plugin-syntax-typescript', '../../../helpers/plugin-add-line.js']
};
