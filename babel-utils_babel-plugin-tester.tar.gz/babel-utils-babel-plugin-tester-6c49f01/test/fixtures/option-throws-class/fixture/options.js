module.exports = {
  "throws": SyntaxError
}
