module.exports = {
  throws: 'expected this error to be captured'
};
