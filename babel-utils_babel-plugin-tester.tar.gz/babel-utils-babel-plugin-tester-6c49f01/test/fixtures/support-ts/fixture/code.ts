export default (): { something: string } => {
  return { something: 'string' };
};
