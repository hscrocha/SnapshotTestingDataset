expect('failed!').toBe('passed!');
