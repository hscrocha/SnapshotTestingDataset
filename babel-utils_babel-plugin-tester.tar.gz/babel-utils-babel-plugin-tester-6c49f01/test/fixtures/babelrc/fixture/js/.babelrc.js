module.exports = {
  plugins: [require.resolve('@babel/plugin-syntax-jsx')]
};
