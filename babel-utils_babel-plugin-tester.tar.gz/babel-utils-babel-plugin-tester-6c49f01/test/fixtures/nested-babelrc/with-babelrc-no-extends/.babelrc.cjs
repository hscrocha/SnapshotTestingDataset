module.exports = {
  plugins: ['@babel/plugin-syntax-jsx']
};
