module.exports = {
  extends: '../.babelrc'
};
