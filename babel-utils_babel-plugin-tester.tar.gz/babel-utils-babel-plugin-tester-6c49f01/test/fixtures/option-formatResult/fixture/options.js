module.exports = {
  formatResult: (r) => `<< ${r} >>`
};
