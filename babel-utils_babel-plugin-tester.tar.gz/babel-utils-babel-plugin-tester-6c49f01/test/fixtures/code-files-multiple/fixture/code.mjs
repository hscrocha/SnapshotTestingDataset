export const hi = 'hey';
