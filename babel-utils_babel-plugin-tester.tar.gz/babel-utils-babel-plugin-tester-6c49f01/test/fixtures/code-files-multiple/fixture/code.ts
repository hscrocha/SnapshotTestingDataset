export const nope = 'bad';
