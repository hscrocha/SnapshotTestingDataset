module.exports = {
  pluginOptions: {
    bar:
  },
  presetOptions: {
    bar:
  }
};
