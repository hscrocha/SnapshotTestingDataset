var hi1 = 'hey';
var hi2 = 'hey';
var hi3 = 'there are two newlines at the bottom of this file on purpose';

