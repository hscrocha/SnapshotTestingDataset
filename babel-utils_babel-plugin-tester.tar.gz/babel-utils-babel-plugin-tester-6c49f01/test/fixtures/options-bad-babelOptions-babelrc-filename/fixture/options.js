module.exports = {
  babelOptions: {
    babelrc: true,
    filename: undefined
  }
};
