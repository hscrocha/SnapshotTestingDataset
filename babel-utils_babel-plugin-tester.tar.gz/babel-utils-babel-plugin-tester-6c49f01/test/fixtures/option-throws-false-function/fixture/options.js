module.exports = {
  throws: () => false
};
