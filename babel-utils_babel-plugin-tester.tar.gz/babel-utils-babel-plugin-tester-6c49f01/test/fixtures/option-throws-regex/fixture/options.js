module.exports = {
  throws: /captured/
};
