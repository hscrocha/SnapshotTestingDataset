var foo = '';
var bar = '';
var baz = '';
