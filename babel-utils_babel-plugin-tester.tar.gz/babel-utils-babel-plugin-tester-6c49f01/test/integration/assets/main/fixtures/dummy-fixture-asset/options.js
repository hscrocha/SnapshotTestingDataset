module.exports = {
  title: 'asset-test',
  setup: () => console.log('working')
};
