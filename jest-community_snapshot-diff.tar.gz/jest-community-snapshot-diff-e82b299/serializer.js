const snapshotDiff = require('./build');

module.exports = snapshotDiff.getSnapshotDiffSerializer();
