import { TodoService } from "./todo.service";

export const todoService = new TodoService("http://localhost:3000");
