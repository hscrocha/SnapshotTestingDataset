export * from "./modal.component";
