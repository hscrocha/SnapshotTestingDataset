import { defaultFixtureSerializer } from './serializer'

export = defaultFixtureSerializer
