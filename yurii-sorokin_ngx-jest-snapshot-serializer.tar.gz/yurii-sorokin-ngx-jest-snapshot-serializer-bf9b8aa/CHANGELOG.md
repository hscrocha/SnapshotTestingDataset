<a name="1.2.1"></a>
## [1.2.1](https://github.com/yurii-sorokin/ngx-jest-serializer/compare/v1.2.0...v1.2.1) (2018-03-13)


### Features

* make possible to ignore props by regexp ([e91a9fe](https://github.com/yurii-sorokin/ngx-jest-serializer/commit/e91a9fe))

<a name="1.2.0"></a>
## [1.2.0](https://github.com/yurii-sorokin/ngx-jest-serializer/compare/v1.1.0...v1.2.0) (2018-02-23)

* add codecov ([79e45eb](https://github.com/yurii-sorokin/ngx-jest-serializer/commit/79e45eb))
* add tests and Travis integration, fixed complex value printing, switch to Typescript ([25174e5](https://github.com/yurii-sorokin/ngx-jest-serializer/commit/25174e5))

<a name="1.1.0"></a>
## [1.1.0](https://github.com/yurii-sorokin/ngx-jest-serializer/compare/v1.0.0...v1.1.0) (2018-02-22)

* add example ([438aba8](https://github.com/yurii-sorokin/ngx-jest-serializer/commit/438aba8))
* add support for event listerens ([ca5318d](https://github.com/yurii-sorokin/ngx-jest-serializer/commit/ca5318d))
* fix comments stripping ([93578e0](https://github.com/yurii-sorokin/ngx-jest-serializer/commit/93578e0))

<a name="1.0.0"></a>
## 1.0.0 (2018-02-21)

* add fixture serializer ([afbb5ee](https://github.com/yurii-sorokin/ngx-jest-serializer/commit/afbb5ee))


