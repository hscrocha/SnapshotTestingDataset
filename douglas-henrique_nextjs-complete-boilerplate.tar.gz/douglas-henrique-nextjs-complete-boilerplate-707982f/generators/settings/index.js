const page = require('./page')
const component = require('./component')

module.exports = {
  page,
  component
}