import Layout from '../components/layout'

export default Layout(() => (<article>about</article>))