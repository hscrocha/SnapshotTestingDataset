module.exports = {
  images: {
    domains: ['activity-graph.herokuapp.com'],
  },
};
