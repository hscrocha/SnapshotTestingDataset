export interface ISocialMedia {
  name: string;
  link: string;
}
