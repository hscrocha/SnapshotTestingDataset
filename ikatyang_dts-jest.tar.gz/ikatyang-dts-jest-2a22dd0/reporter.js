module.exports = require('./lib/index').Reporter;
