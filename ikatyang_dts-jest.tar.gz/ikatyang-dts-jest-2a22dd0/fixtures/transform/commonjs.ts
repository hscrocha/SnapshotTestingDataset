import * as path from 'path';

// @dts-jest
path.basename('path/to/somewhere'); //=> 'somewhere'
