// @dts-jest:fail
// @dts-jest:fail:show
// @dts-jest:fail:snap
// @dts-jest:fail:snap:show
// @dts-jest:fail description
