// @dts-jest
// @dts-jest:show
// @dts-jest:snap
// @dts-jest:snap:show
// @dts-jest:pass
// @dts-jest:pass:show
// @dts-jest:pass:snap
// @dts-jest:pass:snap:show
// @dts-jest:fail
// @dts-jest:fail:show
// @dts-jest:fail:snap
// @dts-jest:fail:snap:show

// @dts-jest description
// @dts-jest:pass description + flag
