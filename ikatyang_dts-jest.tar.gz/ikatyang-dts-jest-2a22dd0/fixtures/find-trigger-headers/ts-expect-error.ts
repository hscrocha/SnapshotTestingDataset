// @ts-expect-error
// @ts-expect-error:show
// @ts-expect-error:snap
// @ts-expect-error:snap:show
// @ts-expect-error description
