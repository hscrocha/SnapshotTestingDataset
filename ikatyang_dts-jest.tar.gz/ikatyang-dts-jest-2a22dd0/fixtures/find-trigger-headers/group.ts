// @dts-jest 1
// @dts-jest 2
// @dts-jest:group
// @dts-jest ? 1
// @dts-jest ? 2
// @dts-jest:group A
// @dts-jest A 1
// @dts-jest A 2
// @dts-jest:group B
// @dts-jest B 1
// @dts-jest B 2
