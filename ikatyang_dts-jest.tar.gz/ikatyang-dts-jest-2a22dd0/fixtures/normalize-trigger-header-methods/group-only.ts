// @dts-jest 1
// @dts-jest 2
// @dts-jest:group:only A
// @dts-jest A1
// @dts-jest A2
// @dts-jest:group B
// @dts-jest B1
// @dts-jest B2
