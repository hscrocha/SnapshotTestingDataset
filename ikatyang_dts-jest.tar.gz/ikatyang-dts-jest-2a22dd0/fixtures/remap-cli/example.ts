// @dts-jest:snap
Math.max(3, 2, 1);

// @dts-jest:snap description-min
Math.min(3, 2, 1);

// @dts-jest:group A

// @dts-jest:snap
Math.abs(3);

// @dts-jest:snap description-sin
Math.sin(0);

// @dts-jest:group B

// @dts-jest:snap
Math.cos(0);

// @dts-jest:snap
Math.tan(0);

// @dts-jest:snap
Math.tan(0);
