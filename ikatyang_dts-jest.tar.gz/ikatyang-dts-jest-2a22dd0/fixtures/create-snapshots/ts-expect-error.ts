// @ts-expect-error
Math.abs('123');
