String.fromCharCode('str');
