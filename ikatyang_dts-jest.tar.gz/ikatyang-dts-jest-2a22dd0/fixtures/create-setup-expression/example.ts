// @dts-jest:pass:snap:show
Math.max(1, 2, 3); //=> 3

// @dts-jest:fail
Math.abs(-1); //=> ?
