// @dts-jest:snap
Math.max(1, 2, 3);

// @dts-jest:snap
Math.max(4, 5, 6);
