/**
 * @dts-jest disable:test-type
 */
