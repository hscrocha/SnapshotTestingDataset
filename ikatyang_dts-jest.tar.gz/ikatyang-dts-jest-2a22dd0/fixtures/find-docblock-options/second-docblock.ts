/**
 * first docblock
 */

/**
 * second docblock
 *
 * @dts-jest enable:test-type
 */
