/**
 * @dts-jest enable:test-value disable:test-type
 */
