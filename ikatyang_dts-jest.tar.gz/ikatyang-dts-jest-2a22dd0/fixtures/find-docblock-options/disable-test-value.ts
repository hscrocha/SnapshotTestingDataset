/**
 * @dts-jest disable:test-value
 */
