exports.process = require('./lib/index').transform;
