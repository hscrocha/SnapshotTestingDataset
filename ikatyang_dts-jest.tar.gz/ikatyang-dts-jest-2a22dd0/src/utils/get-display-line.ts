export const get_display_line = (line: number) => line + 1;
