export const replace_cwd = (str: string) => str.replace('<cwd>', process.cwd());
