export const get_trigger_header_line = (body_line: number) => body_line - 1;
export const get_trigger_body_line = (header_line: number) => header_line + 1;
export const get_trigger_body_end_line = (footer_line: number) => footer_line;
