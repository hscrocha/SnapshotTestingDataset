// this should be the entry point to your library
import RenderCounter, { withRenderCount, Counter } from './RenderCounter';

module.exports = {
  RenderCounter,
  withRenderCount,
  Counter,
};
