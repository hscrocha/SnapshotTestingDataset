module.exports = {
  mongoURI: 'mongodb://localhost:27017/db_heens_test',
  secretKey: 'test-app-secret-key',
};
