const { expect } = require('chai');

describe('add unit test for express', () => {
  it('should always pass', () => {
    const expected = 100;
    expect(100).to.equal(expected);
  });
});
