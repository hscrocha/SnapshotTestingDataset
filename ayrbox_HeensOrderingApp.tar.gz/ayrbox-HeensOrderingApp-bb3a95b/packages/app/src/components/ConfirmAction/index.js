import ConfirmAction from './ConfirmAction';

export default ConfirmAction;
