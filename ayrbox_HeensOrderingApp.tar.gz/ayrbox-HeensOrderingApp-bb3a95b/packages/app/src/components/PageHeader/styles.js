const styles = theme => ({
  header: {
    marginBottom: `${theme.spacing.unit * 4}px`,
  },
});

export default styles;
