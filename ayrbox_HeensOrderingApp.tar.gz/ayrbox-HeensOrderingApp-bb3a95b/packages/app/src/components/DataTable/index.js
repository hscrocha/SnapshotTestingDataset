import DataTable from './DataTable';

export default DataTable;
