const styles = {
  actionCell: {
    width: '200px',
  },
};

export default styles;
