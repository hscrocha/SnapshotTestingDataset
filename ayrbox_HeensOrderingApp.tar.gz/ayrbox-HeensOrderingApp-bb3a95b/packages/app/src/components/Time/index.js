import Time from './Time';

export default Time;
