import OrderDetails from './OrderDetails';

export default OrderDetails;
