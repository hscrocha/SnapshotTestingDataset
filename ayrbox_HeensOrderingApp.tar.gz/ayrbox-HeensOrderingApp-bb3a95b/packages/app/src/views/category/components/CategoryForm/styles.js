const styles = theme => ({
  formControl: {
    margin: `0 0 ${theme.spacing.unit * 2}px`,
  },
});

export default styles;
