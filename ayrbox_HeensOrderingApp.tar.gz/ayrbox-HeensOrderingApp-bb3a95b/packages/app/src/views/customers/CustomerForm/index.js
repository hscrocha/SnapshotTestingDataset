import CustomerForm from './CustomerForm';

export default CustomerForm;
