import OrderModal from './connect';

export default OrderModal;
