const styles = {
  itemDesc: {
    width: '90%',
  },
};

export default styles;
