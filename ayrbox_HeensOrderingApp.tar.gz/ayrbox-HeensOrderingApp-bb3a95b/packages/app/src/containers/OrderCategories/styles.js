const styles = {
  categorySelectionIcon: {
    marginRight: 0,
  },
};

export default styles;
