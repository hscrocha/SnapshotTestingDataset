import OrderTable from './OrderTable';

export default OrderTable;
