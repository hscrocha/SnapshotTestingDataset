import DeliveryAddress from './DeliveryAddress';

export default DeliveryAddress;
