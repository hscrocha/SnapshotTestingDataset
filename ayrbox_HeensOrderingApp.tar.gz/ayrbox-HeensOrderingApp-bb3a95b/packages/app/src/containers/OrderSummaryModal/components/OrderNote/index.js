import OrderNote from './OrderNote';

export default OrderNote;
