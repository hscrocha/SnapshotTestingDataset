import Discount from './Discount';

export default Discount;
