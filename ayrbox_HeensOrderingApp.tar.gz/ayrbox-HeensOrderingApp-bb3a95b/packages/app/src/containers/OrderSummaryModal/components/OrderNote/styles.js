const styles = theme => ({
  orderNote: {
    marginTop: `${theme.spacing.unit * 6}px`,
  },
});

export default styles;
