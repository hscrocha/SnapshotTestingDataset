import OrderSummary from './connect';

export default OrderSummary;
