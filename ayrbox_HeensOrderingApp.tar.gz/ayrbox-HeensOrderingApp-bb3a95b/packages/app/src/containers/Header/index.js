import Header from './connect';

export default Header;
