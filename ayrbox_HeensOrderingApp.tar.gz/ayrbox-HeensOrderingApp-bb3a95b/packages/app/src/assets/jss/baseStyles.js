const styles = {
  contentWrapper: {
    padding: '60px',
    minWidth: '640px',
    overflow: 'auto',
  },
};

export default styles;
