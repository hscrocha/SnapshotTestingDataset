import configureStore from './configureStore';

export default configureStore;
