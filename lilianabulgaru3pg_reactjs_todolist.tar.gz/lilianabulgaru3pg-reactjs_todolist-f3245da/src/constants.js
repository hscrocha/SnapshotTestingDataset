export const TASKS = '/tasks';
export const LOGIN = '/login';

// DB
export const TASKS_COLLECTION = 'tasks';
export const ITEMS_COLLECTION = 'items';
