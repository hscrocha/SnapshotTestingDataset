import Seo from './Seo'

export default Seo
