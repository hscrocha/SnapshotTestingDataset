import Plans from './Plans'

export default Plans
