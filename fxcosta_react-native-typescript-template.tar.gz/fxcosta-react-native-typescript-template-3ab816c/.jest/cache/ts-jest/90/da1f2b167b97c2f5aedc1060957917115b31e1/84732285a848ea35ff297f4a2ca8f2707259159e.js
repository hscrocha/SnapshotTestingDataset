"use strict";
/**
 * @format
 */
var __importDefault = (this && this.__importDefault) || function (mod) {
    return (mod && mod.__esModule) ? mod : { "default": mod };
};
Object.defineProperty(exports, "__esModule", { value: true });
require("react-native");
const react_1 = __importDefault(require("react"));
const App_1 = __importDefault(require("../App"));
// Note: test renderer must be required after react-native.
const react_test_renderer_1 = __importDefault(require("react-test-renderer"));
it('renders correctly', () => {
    react_test_renderer_1.default.create(<App_1.default />);
});
//# sourceMappingURL=data:application/json;charset=utf-8;base64,eyJ2ZXJzaW9uIjozLCJmaWxlIjoiL1VzZXJzL2h1bmdkYW8vUHJvamVjdHMvT3RoZXJzL1R5cGVzY3JpcHRSZWFjdE5hdGl2ZVN0YXJ0ZXIvX190ZXN0c19fL0FwcC10ZXN0LnRzeCIsInNvdXJjZXMiOlsiL1VzZXJzL2h1bmdkYW8vUHJvamVjdHMvT3RoZXJzL1R5cGVzY3JpcHRSZWFjdE5hdGl2ZVN0YXJ0ZXIvX190ZXN0c19fL0FwcC10ZXN0LnRzeCJdLCJuYW1lcyI6W10sIm1hcHBpbmdzIjoiO0FBQUE7O0dBRUc7Ozs7O0FBRUgsd0JBQXNCO0FBQ3RCLGtEQUEwQjtBQUMxQixpREFBeUI7QUFFekIsMkRBQTJEO0FBQzNELDhFQUEyQztBQUUzQyxFQUFFLENBQUMsbUJBQW1CLEVBQUUsR0FBRyxFQUFFO0lBQzNCLDZCQUFRLENBQUMsTUFBTSxDQUFDLENBQUMsYUFBRyxDQUFDLEFBQUQsRUFBRyxDQUFDLENBQUM7QUFDM0IsQ0FBQyxDQUFDLENBQUMiLCJzb3VyY2VzQ29udGVudCI6WyIvKipcbiAqIEBmb3JtYXRcbiAqL1xuXG5pbXBvcnQgJ3JlYWN0LW5hdGl2ZSc7XG5pbXBvcnQgUmVhY3QgZnJvbSAncmVhY3QnO1xuaW1wb3J0IEFwcCBmcm9tICcuLi9BcHAnO1xuXG4vLyBOb3RlOiB0ZXN0IHJlbmRlcmVyIG11c3QgYmUgcmVxdWlyZWQgYWZ0ZXIgcmVhY3QtbmF0aXZlLlxuaW1wb3J0IHJlbmRlcmVyIGZyb20gJ3JlYWN0LXRlc3QtcmVuZGVyZXInO1xuXG5pdCgncmVuZGVycyBjb3JyZWN0bHknLCAoKSA9PiB7XG4gIHJlbmRlcmVyLmNyZWF0ZSg8QXBwIC8+KTtcbn0pO1xuIl19