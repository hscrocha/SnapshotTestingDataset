import { Render } from "./Render";
Render.init();
