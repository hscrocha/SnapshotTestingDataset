#!/usr/bin/env node
import { CLI } from "./cli/CLI";

CLI.run(process.argv.slice(2));
