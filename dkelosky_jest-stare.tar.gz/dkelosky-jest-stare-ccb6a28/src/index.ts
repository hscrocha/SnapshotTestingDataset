import { entry } from "./entry";
module.exports = entry;
