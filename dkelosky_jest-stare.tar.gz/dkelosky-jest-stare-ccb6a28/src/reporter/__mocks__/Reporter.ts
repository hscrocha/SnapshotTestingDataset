export class Reporter {
    constructor(private mGlobalConfig: jest.GlobalConfig, private mOptions: any) {
    }
}
