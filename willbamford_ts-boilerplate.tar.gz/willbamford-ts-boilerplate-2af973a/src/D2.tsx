import * as React from 'react'

const D2 = () => <div>D2</div>

export default D2
