import * as React from 'react'

const D1 = () => <div>D1</div>

export default D1
