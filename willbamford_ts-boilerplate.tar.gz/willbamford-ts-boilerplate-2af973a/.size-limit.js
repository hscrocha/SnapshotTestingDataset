module.exports = [
  {
    limit: '100 KB',
    path: 'dist/main.js',
    webpack: false
  },
  {
    limit: '50 KB',
    path: 'dist/dynamic.js',
    webpack: false
  }
]
