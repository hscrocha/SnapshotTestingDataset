export { default } from './FAQ.jsx';
