import React from 'react';

function FAQ() {
  return <h1>FAQ</h1>;
}

export default FAQ;
