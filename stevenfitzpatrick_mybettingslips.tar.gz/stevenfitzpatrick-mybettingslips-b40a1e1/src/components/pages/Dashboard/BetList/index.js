import BetList from './BetList';

export default BetList;
