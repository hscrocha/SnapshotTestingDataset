import BetTotal from './BetTotal';

export default BetTotal;
