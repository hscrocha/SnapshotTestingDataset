export { default } from './Admin';
export { default as Teams } from './Teams/Teams';
export { default as Sports } from './Sports/Sports';
export { default as Competitions } from './Competitions/Competitions';
