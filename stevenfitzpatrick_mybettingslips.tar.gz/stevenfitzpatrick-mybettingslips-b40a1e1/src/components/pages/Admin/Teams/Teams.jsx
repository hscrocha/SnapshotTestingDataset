import React, { Component } from 'react';

class Teams extends Component {
  render() {
    return <div>here again</div>;
  }
}

export default Teams;
