export const HOME = '/';
export const BROWSE = '/browse';
export const Sign_UP = '/signup';
export const SIGN_IN = '/signin';