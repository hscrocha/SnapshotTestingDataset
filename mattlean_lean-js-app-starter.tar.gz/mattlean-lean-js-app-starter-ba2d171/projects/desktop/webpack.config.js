const rendererConfig = require('./config/renderer')
const mainConfig = require('./config/main')

module.exports = [rendererConfig, mainConfig]
