// @flow
import React from 'react'

const Loading = () => (
  <div className="center"><i>Loading...</i></div>
)

export default Loading
