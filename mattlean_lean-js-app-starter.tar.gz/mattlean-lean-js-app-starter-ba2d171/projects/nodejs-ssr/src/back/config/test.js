// @flow

export default {
  DB_URI: 'mongodb://localhost/nodejs-ssr-test'
}
