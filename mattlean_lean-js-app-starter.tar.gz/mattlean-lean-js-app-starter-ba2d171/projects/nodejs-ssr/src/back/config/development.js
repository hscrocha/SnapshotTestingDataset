// @flow

export default {
  PORT: 9001,
  CLIENT: 'http://localhost:8080'
}
