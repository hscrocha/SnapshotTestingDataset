// @flow

module.exports = {
  DB_URI: 'mongodb://localhost/nodejs-test'
}
