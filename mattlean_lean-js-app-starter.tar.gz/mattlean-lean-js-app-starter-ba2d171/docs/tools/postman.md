# Postman
## Overview
[Postman](https://getpostman.com) is an API development tool you can use to interface with Lean JS App Starter Node.js applications. You can download it here: https://getpostman.com/downloads

## Import Collection & Environment
Click on the button below to import a premade collection and environment for the `nodejs` release. For more info on the API, read the ["Node.js: Examples" documentation](../envs/nodejs/nodejs/examples.md).  
[![Run in Postman](https://run.pstmn.io/button.svg)](https://app.getpostman.com/run-collection/0a856b770363eab086b4#?env%5B*chan%20API%5D=W3sia2V5IjoiUk9PVCIsInZhbHVlIjoiaHR0cDovL2xvY2FsaG9zdDo5MDAxIiwiZGVzY3JpcHRpb24iOiIiLCJlbmFibGVkIjp0cnVlfV0=)