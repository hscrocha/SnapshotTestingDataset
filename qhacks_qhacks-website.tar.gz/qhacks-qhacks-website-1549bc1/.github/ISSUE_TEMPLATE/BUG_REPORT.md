---
name: Bug Report 🐞
about: Something isn't working as expected? Here is the right place to report.
---

## Description

### Expected Behavior

### Actual Behavior

### Steps to Reproduce

1.

2.

3.

### Environment

- Version:
- Platform:
