describe('Menu', () => {
  beforeEach(() => {
    cy.visit('/');
  });
});
