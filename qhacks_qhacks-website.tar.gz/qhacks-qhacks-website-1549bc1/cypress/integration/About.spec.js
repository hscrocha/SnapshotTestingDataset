describe("About", () => {
  beforeEach(() => {
    cy.visit("/#about");
  });
});
