describe("FAQs", () => {
  beforeEach(() => {
    cy.visit("/#faq");
  });
});
