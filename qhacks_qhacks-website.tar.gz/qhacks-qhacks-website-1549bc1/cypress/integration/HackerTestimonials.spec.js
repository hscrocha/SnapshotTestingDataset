describe("Hacker Testimonials", () => {
  beforeEach(() => {
    cy.visit("/#testimonials");
  });
});
