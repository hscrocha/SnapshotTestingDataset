describe("Event Schedule", () => {
  beforeEach(() => {
    cy.visit("/#schedule");
  });
});
