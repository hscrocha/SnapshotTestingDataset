describe("Speakers", () => {
  beforeEach(() => {
    cy.visit("/#speakers");
  });
});
