# Contributors

#### Name: [Luke Taylor](https://lmcjt.com/)
- Role: Owner
- Place: Derby, UK
- GitHub: [lmcjt37](https://github.com/lmcjt37)

#### Name: [Tyler McDonald](https://github.com/ManiacalBilby)
- Role: Contributor
- Place: Atlanta, GA
- GitHub: [ManiacalBilby](https://github.com/ManiacalBilby)

#### Name: [André Decher](https://github.com/Wolfy7)
- Role: Contributor
- Place: Buseck, Germany
- GitHub: [Wolfy7](https://github.com/Wolfy7)

#### Name: [Mehdi Druon](https://github.com/MehdiDr)
- Role: Contributor
- Place: Paris, France
- GitHub: [MehdiDr](https://github.com/MehdiDr)

#### Name: [Yamil Urbina](https://github.com/yamilurbina)
- Role: Contributor
- Place: La Paz, Bolivia
- GitHub: [yamilurbina](https://github.com/yamilurbina)

#### Name: [Isânio Moraes](https://github.com/isaniomoraes)
- Role: Contributor
- Place: Maringa, Brazil
- GitHub: [isaniomoraes](https://github.com/isaniomoraes)

#### Name: [Lee Connelly](https://github.com/LeeConnelly12)
- Role: Contributor
- Place: Coventry, UK
- GitHub: [LeeConnelly12](https://github.com/LeeConnelly12)

#### Name: [Junaid Anwar](https://github.com/Juni4567)
- Role: Contributor
- Place: Rawalpindi, Pakistan
- GitHub: [Juni4567](https://github.com/Juni4567)

#### Name: [Kndarp Patel](https://github.com/kndarp)
- Role: Contributor
- Place: London, UK
- GitHub: [kndarp](https://github.com/kndarp)

#### Name: [Kashan Hussain](https://github.com/kaashan)
- Role: Contributor
- Place: Bangalore, India
- GitHub: [kaashan](https://github.com/kaashan)

#### Name: [Kelvin Mai](https://github.com/kelvin-mai)
- Role: Contributor
- Place: Manchester, NH, USA
- GitHub: [kelvin-mai](https://github.com/kelvin-mai)

#### Name: [Shreena Athia](https://github.com/shreenaathia)
- Role: Contributor
- Place: Toronto, ON, Canada
- GitHub: [shreenaathia](https://github.com/shreenaathia)

#### Name: [Danny Ajilore](https://github.com/shreenaathia)
- Role: Contributor
- Place: London, UK
- GitHub: [danielandro](https://github.com/danielandro)

#### Name: [Rodrigo Nascimento](https://rodrigocnascimento.github.io/)
- Role: Contributor
- Place: Sao Paulo, BR, Brasil
- GitHub: [rodrigocnascimento](https://github.com/rodrigocnascimento/)

#### Name: [Matthew Carpenter](https://github.com/diddy225)
- Role: Contributor
- Place: Atlanta, GA
- GitHub: [diddy225](https://github.com/diddy225)

#### Name: [Nemanja Glumac](https://glumac.me)
- Role: Contributor
- Place: Ljubljana, Slovenia
- GitHub: [nemanjaglumac](https://github.com/nemanjaglumac)

#### Name: [Shawn Pang](https://github.com/CometS1)
- Role: Contributor
- Place: Markham, ON, Canada
- GitHub: [CometS1](https://github.com/CometS1)

#### Name: [Jason Garey](https://github.com/jason1985)
- Role: Contributor
- Place: Las Vegas, NV
- GitHub: [jason1985](https://github.com/jason1985)

#### Name: [Vinay Kanase](https://github.com/VinayKanase)
- Role: Contributor
- Place: Mumbai, India
- GitHub: [Vinay Kanase](https://github.com/VinayKanase)
