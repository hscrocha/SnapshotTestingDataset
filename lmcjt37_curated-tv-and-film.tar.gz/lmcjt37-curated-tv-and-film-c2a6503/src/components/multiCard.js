// React
import React from 'react';
import PropTypes from 'prop-types';

// Material Core
import Card from '@material-ui/core/Card';
import CardActions from '@material-ui/core/CardActions';
import CardHeader from '@material-ui/core/CardHeader';
import CardContent from '@material-ui/core/CardContent';
import CardMedia from '@material-ui/core/CardMedia';
import Typography from '@material-ui/core/Typography';
import Chip from '@material-ui/core/Chip';
import Fab from '@material-ui/core/Fab';
import PlayCircleOutlineIcon from '@material-ui/icons/PlayCircleOutline';
import LocalPlayIcon from '@material-ui/icons/LocalPlay';

// Material Core - Styles
import { withStyles } from '@material-ui/core/styles';

const styles = (theme) => ({
  card: {
    margin: theme.spacing(2)
  },
  innerContainer: {
    display: 'block',
    [theme.breakpoints.up('sm')]: {
      display: 'flex'
    }
  },
  media: {
    height: 175,
    display: 'block',
    [theme.breakpoints.up('sm')]: {
      display: 'none'
    }
  },
  description: {
    marginTop: theme.spacing(1)
  },
  thumbnail: {
    display: 'none',
    [theme.breakpoints.up('sm')]: {
      borderRadius: '0.5em',
      display: 'inherit',
      maxWidth: '100%',
      minHeight: '9.375em',
      width: '16.625em',
      objectFit: 'cover',
      margin: theme.spacing(2)
    }
  },
  chip: {
    marginRight: theme.spacing(1)
  },
  fab: {
    marginRight: theme.spacing(1)
  },
  playCircleOutlineIcon: {
    marginRight: theme.spacing(1)
  },
  localPlayIcon: {
    marginRight: theme.spacing(1)
  },
  actions: {
    marginTop: theme.spacing(2),
    padding: 0, // override default
    paddingBottom: theme.spacing(1),
    paddingTop: theme.spacing(1)
  }
});

const MultiCard = ({ classes, title, year, genre, content, type }) => {
  const typoProps = {
    variant: 'h6',
    component: 'h2'
  };
  return (
    <Card data-testid="multi-card" className={classes.card}>
      <CardHeader
        title={title + (year ? '(' + year + ')' : '')}
        titleTypographyProps={typoProps}
        data-testid="multi-card-title"
      />
      <CardContent data-testid="multi-card-chip-container">
        {genre.map((genre, idx) => {
          return (
            <Chip
              key={idx}
              label={genre}
              className={classes.chip}
              data-testid="multi-card-chip-container-item"
            />
          );
        })}
      </CardContent>
      {content.map((row, index) => {
        return (
          <div
            key={index}
            className={classes.innerContainer}
            data-testid="multi-card-item"
          >
            <CardMedia
              className={classes.media}
              image={process.env.PUBLIC_URL + row.thumbnail}
              title={row.title}
              data-testid="multi-card-media"
            />
            <img
              className={classes.thumbnail}
              src={process.env.PUBLIC_URL + row.thumbnail}
              alt={row.title}
              data-testid="multi-card-image"
            />
            <CardContent data-testid="multi-card-content">
              <div className={classes.details}>
                {type === 'tv_show' && (
                  <div>
                    <Typography
                      variant="subtitle1"
                      component="h2"
                      data-testid="multi-card-subtitle-1"
                      gutterBottom
                    >
                      {row.episode_title}
                    </Typography>
                    <Typography
                      gutterBottom
                      component="p"
                      color="textSecondary"
                      data-testid="multi-card-subtitle-2"
                    >
                      Season: {row.season} | Episode: {row.episode}
                    </Typography>
                  </div>
                )}
                <Typography
                  className={classes.description}
                  component="p"
                  data-testid="multi-card-description"
                >
                  {row.description}
                </Typography>
              </div>
              <CardActions
                classes={{ root: classes.actions }}
                data-testid="multi-card-actions"
              >
                <Fab
                  color="primary"
                  aria-label="IMDB"
                  className={classes.fab}
                  href={row.imdb}
                  target="_blank"
                  rel="noopener noreferrer"
                  variant="extended"
                  data-testid="multi-card-action-imdb"
                >
                  <LocalPlayIcon className={classes.localPlayIcon} />
                  IMDB
                </Fab>
                <Fab
                  color="primary"
                  aria-label="Watch"
                  className={classes.fab}
                  href={row.url}
                  target="_blank"
                  rel="noopener noreferrer"
                  variant="extended"
                  data-testid="multi-card-action-watch"
                >
                  <PlayCircleOutlineIcon
                    className={classes.playCircleOutlineIcon}
                  />
                  Watch
                </Fab>
              </CardActions>
            </CardContent>
          </div>
        );
      })}
    </Card>
  );
};

MultiCard.propTypes = {
  classes: PropTypes.object.isRequired
};

export default withStyles(styles)(MultiCard);
