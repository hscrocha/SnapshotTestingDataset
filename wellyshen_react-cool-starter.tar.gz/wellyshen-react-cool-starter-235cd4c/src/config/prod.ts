export default {
  PORT: 8080,
};
