export const minimumPasswordLength = 8;
export const requiredCharactersRegex = /^(?=.*[a-z])(?=.*[A-Z])(?=.*\d).+/;
