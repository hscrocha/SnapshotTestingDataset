const s3hostName = 'operation-code-assets.s3.us-east-2.amazonaws.com';
const s3 = `https://${s3hostName}/`;
const codeOfConduct = `https://github.com/OperationCode/operationcode_docs/blob/master/community/code_of_conduct.md`;

module.exports = { s3hostName, s3, codeOfConduct };
