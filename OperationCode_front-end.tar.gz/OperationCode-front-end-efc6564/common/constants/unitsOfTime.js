// In seconds
export const ONE_DAY = 86400;
export const ONE_WEEK = 604800;
export const TWO_WEEKS = 1209600;
