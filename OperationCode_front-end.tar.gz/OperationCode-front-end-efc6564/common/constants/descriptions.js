/* eslint-disable max-len */
/** Provides lorem ipsum descriptions of length
 * short: 1 sentence,
 * medium: 3 sentences,
 * long: 5 sentences
 */
export const descriptions = {
  short: 'Lorem ipsum dolor sit amet, consectetur adipiscing elit.',

  medium:
    'Lorem ipsum dolor sit amet, consectetur adipiscing elit. Ut in semper justo, quis efficitur urna. Aliquam et pretium est, nec viverra risus. Curabitur facilisis est in nibh luctus condimentum.',

  long: 'Lorem ipsum dolor sit amet, consectetur adipiscing elit. Ut in semper justo, quis efficitur urna. Aliquam et pretium est, nec viverra risus. Curabitur facilisis est in nibh luctus condimentum. Maecenas sed urna sed est dapibus venenatis. Quisque aliquet velit eu ligula pellentesque, non pretium massa blandit. Suspendisse vitae viverra ante, eget sodales arcu. Aliquam erat volutpat.',
};
