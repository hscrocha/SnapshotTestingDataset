Operasyon Kodu: Davranış Kuralları

Bizim Vaatlerimiz

Açık ve davetkar bir ortamı teşvik etmek adına, katkıda bulunanlar ve koruyucular olarak, projemize ve topluluğumuza, deneyim düzeyi, milliyet, kişisel görünüş, ırk, din veya cinsel kimlik ve yönelime bakılmaksızın herkes için tacizden arınmış bir deneyim sunmayı taahhüt ediyoruz.

Bizim Standartlarımız

Olumlu bir ortam yaratmaya katkıda bulunan davranış örnekleri şunları içerir:

Karşılama ve kapsayıcı dil kullanma

Farklı bakış açılarına ve deneyimlere saygılı olmak

Zarif bir şekilde yapıcı eleştiriyi kabul etmek
Toplum için en iyi olana odaklanmak

Diğer topluluk üyelerine karşı empati gösterme

Katılımcılar tarafından kabul edilemez davranış örnekleri şunları içerir:

Cinsel dil veya imgelerin kullanımı ve istenmeyen cinsel ilgi veya ilerlemeler

Trolling, aşağılayama/ aşağılayıcı yorumlar ve kişisel ya da politik saldırılar

Kamu ya da özel taciz

Fiziksel veya elektronik adres gibi başkalarının özel bilgilerini açık izinsiz yayınlama

Makul bir şekilde profesyonel bir ortamda uygunsuz olarak kabul edilebilecek diğer davranışlar

Sorumluluklarımız

Proje yürütücüleri kabul edilebilir davranış standartlarını açıklamaktan sorumludur ve kabul edilemez davranış durumlarına karşılık olarak uygun ve adil düzeltici önlemler almaları beklenmektedir.

Proje yürütücüler, bu Davranış Kurallarına uymayan yorumları, taahhütleri, kodları, wiki düzenlemelerini, sorunları ve diğer katkıları kaldırma, düzenleme ya da reddetme ya da diğer davranışlar için herhangi bir katkıyı geçici ya da kalıcı olarak yasaklama hakkına ve sorumluluğa sahiptir. Uygunsuz, tehdit edici, saldırgan veya zararlı sayılırlar.

Kapsam

Bu Davranış Kuralları, proje alanı veya kamusal alanlarda, bir kişi projeyi veya topluluğunu temsil ettiğinde geçerlidir. Bir projeyi veya topluluğu temsil etmenin örnekleri resmi bir proje e-posta adresi kullanmak, resmi bir sosyal medya hesabıyla göndermek veya çevrimiçi veya çevrimdışı bir etkinlikte atanmış bir temsilci olarak görev yapmaktır. Bir projenin temsili proje sahipleri tarafından daha fazla tanımlanabilir ve netleştirilebilir.

Yaptırım

Taciz edici, taciz edici veya başka türlü kabul edilemez davranışların örnekleri proje ekibiyle personel@operationcode.org adresinden iletişime geçerek bildirilebilir. Tüm şikayetler gözden geçirilecek ve soruşturulacak ve şartlara uygun ve uygun görülen bir cevaba yol açacaktır. Proje ekibi, bir olayın muhabiri hakkında gizliliği korumakla yükümlüdür. Özel yaptırım politikaları ile ilgili diğer ayrıntılar ayrı olarak yayınlanabilir.

Davranış Kurallarını iyi niyetle takip etmeyen veya uygulayan proje sahipleri, projenin liderliğinin diğer üyeleri tarafından belirlenen geçici veya kalıcı yankılarla karşı karşıya kalabilir.

Atfetme

Bu Davranış Kuralları, http://contributor-covenant.org/version/1/4 adresinde bulunan, Kullanıcı Sözleşmesi, 1.4 Sürümünden uyarlanmıştır.
