module.exports = 'test-file-mock';
