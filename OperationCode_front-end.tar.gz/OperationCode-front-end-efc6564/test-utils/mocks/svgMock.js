const { createElement } = require('react');

const Svg = props => createElement('svg', props, null);

module.exports = {
  __esModule: true,
  default: Svg,
};
