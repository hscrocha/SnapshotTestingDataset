import { addons } from '@storybook/addons';
import OCTheme from './OCTheme';

addons.setConfig({
  theme: OCTheme,
});
