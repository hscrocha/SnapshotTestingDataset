# Scripts

This should probably be called `bin`, but this folder is for local development scripts only. They
will not be available for deployments as they ignored in `.vercelignore`, so don't consume the files
within via source code.
