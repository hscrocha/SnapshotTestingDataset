module.exports = require('@cypress/code-coverage/middleware/nextjs');
