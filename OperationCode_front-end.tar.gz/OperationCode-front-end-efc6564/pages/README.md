# Pages

Every JavaScript file in this folder represents a route on the website. Note: The way the file is named is exactly as the route will appear. Please use underscores between words.

# Homepage

`index.js` represents the homepage.
