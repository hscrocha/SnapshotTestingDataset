import JoinSection from '../JoinSection';

export default {
  component: JoinSection,
  title: 'Reusable/JoinSection',
};
const Template = arguments_ => <JoinSection {...arguments_} />;

export const Default = Template.bind({});
