import UpgradeBrowserOverlay from '../UpgradeBrowserOverlay';

export default {
  component: UpgradeBrowserOverlay,
  title: 'UpgradeBrowserOverlay',
};

const Template = arguments_ => <UpgradeBrowserOverlay {...arguments_} />;

export const Default = Template.bind({});
