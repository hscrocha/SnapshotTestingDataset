Assets in this folder are thanks to Font Awesome and are licensed via attribution as required: https://fontawesome.com/license/free
