export type Elevation = { positive: number; negative: number };
