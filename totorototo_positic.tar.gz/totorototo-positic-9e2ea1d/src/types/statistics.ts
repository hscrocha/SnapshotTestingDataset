export type Distance = number;
export type Gain = number;
export type Loss = number;

export type Statistics = [Distance, Gain, Loss];
