Next.js as this thing that requires route pages are put in a pages folder. So this is why this is here
