These scripts (workers) are built into scripts and dumped into the static folder.

They are then loaded by url as webworkers
