import navData from '../components/organisms/NavBarTabs/uganda';
import { cacheData } from '.';

cacheData(navData.spotlightThemes);
