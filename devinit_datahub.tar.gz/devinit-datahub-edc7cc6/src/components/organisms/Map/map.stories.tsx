import * as React from 'react';
import { storiesOf } from '@storybook/react';
import withApolloAndReduxProvider from '../../../storybook-addon/apolloAndRedux';
import Map from '.';

storiesOf('Maps', module)
  .addDecorator(withApolloAndReduxProvider())
  .add('global picture default map', () => <Map country={'global'} />)
  .add('spotlight uganda default map', () => <Map country={'uganda'} />)
  .add('spotlight kenya default map', () => <Map country="kenya" />)
  .add('kenya_poverty_headcount', () => <Map id="spotlight_on_kenya_2017.kenya_poverty_headcount" />)
  .add('Depth of Poverty % Map', () => <Map id={'data_series.depth_of_extreme_poverty_190'} />)
  .add('Number of Poorest 20%', () => <Map id={'data_series.poorest_20_percent'} />)
  .add('Subnational', () => <Map id={'subnational_p20'} />)
  .add('fragile states', () => <Map id={'data_series.fragile_states'} />)
  .add('latest_census', () => <Map id={'data_series.latest_census'} />)
  .add('largest_intl_flow', () => <Map id={'data_series.largest_intl_flow'} />)
  .add('uganda_poverty_headcount', () =>
    <Map id={'spotlight_on_uganda_2017.uganda_poverty_headcount'} />,
  );
