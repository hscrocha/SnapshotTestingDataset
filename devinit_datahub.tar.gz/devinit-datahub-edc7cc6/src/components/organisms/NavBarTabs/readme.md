Navbar tabs are the navigation items for browsing through maps
