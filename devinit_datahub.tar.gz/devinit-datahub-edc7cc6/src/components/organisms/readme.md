## organisms


These are the same as containers in other app structures. They instantiate factories into living components.
They receive data / props from pages.
