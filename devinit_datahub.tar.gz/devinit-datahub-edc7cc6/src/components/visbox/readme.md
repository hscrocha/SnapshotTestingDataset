Visbox ( FYI visbox is a chart service) configs will be fetched and placed with in this folder at some point in the near future

