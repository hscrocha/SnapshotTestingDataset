import * as React from 'react';
import { storiesOf } from '@storybook/react';
import Map from '.';
const mapData = require('./testData.json');

storiesOf('Maps', module)
  .add('Net ODA Map', () => <Map {...mapData.data.mapData} />);
