component for both country and regional/district Map
