this is for the international resources area tree map chart
