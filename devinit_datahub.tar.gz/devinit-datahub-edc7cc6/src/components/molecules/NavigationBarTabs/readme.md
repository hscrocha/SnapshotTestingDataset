this is used for global picture and spotlight maps
