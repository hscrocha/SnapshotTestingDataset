## Molecule Components

Molecules are combination of atoms and any other Molecules.

They are factories for creating organisms / container components.
