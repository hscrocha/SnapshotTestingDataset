import * as React from 'react';
import { storiesOf } from '@storybook/react';
import SocialMediaBar from '.';

storiesOf('SocialMedia Bar', module)
    .add('bar', () => <SocialMediaBar />);
