this is the dual sidebar chart
