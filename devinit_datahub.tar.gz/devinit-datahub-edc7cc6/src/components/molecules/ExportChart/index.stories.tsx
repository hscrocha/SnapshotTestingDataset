import * as React from 'react';

import { storiesOf } from '@storybook/react';
import ExportChart from '.';

storiesOf('ExportChart', module).add('ExportChart', () => <ExportChart />);
