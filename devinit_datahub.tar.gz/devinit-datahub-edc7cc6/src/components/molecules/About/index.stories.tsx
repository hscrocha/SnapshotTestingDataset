import * as React from 'react';
import { storiesOf } from '@storybook/react';
import About from '.';

storiesOf('About', module)
  .add('Global picture && spotlight on uganda', () => <About />);
