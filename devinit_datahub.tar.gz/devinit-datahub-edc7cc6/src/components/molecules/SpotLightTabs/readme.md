The overview tab is shared across spotlight countries
