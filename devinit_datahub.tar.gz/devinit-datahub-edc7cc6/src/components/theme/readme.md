The exports in semantic.js are auto built from semantic variables
