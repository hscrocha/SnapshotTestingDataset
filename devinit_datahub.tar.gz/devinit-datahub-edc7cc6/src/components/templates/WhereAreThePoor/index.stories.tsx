import * as React from 'react';
import { storiesOf } from '@storybook/react';
import WhereAreThePoor from '.';

storiesOf('Templates', module).add(' Where are the poor', () => <WhereAreThePoor />);
