import * as React from 'react';
import { storiesOf } from '@storybook/react';
import Profiles from '.';

storiesOf('Templates', module)
  .add('Multilateral Profiles', () => <Profiles />);
