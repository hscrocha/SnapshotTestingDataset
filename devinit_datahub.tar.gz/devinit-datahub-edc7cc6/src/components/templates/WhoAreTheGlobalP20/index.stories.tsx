import * as React from 'react';
import { storiesOf } from '@storybook/react';
import WhoAreTheGlobalP20 from '.';

storiesOf('Templates', module)
  .add('who are the global P20', () => <WhoAreTheGlobalP20 />);
