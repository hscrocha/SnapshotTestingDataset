import * as React from 'react';
import withApolloAndReduxProvider from '../../../storybook-addon/apolloAndRedux';
import { storiesOf } from '@storybook/react';
import Aid from '.';

storiesOf('Templates', module)
  .addDecorator(withApolloAndReduxProvider())
  .add('Unbundling Aid ODA', () => <Aid aidType="oda" pathname="unbundling-aid" title="ODA" />)
  .add('Unbundling Aid OOF', () => <Aid aidType="oof" pathname="unbundling-oof"  title="OOF"  />);
