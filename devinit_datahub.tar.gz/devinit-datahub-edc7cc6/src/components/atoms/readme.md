## Atoms


Atoms are reactified styled native elements think turning a P tag into a styled P tag
