import * as React from 'react';

import { storiesOf } from '@storybook/react';
import Logo from '.';

storiesOf('Menu', module).add('Datahub Logo', () => <Logo />);
