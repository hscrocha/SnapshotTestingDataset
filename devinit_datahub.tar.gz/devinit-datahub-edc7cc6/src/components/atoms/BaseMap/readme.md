This is the base map atom. Its combined into a molecule with the legend atom and a few other atoms to create a map molecule
