Folders explained
--------

Atoms, molecules, organisms, if all that sounds strange please read [this](http://bradfrost.com/blog/post/atomic-web-design)

Files explained
------

- gql-types.ts contains  types derived from graphql queries

