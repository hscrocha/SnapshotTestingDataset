## auto deploy script ran by a service on host server

TODO
-------

- add ability to fetch latest deploy script by service from remote host (gitub)
