export const RECIPIENT = 'recipient';
export const DONOR = 'donor';
export const CROSSOVER = 'crossover';
export const NoData = 'No data';
export const GOVERNMENT_FINANCE_LOWER = 'government-finance-lower';
export const INFLOWS_VS_OUTFLOWS = 'inflows-vs-outflows';
export const INTERNATIONAL_RESOURCES = 'international-resources';
