# Service Entities

This module only holds TypeScript interface definitions to be shared by the server and ui.
See [todos.d.ts](todos.d.ts) as an example.
