declare module 'shared-models/timestamped-entity' {
	export interface TimestampedEntity {
		createdAt: Date;
		updatedAt: Date;
	}
}
