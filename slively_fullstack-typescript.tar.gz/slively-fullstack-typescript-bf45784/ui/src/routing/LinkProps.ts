export interface LinkProps {
	routeName: string;
	routeParams?: object;
	routeOptions?: object;
	className?: string;
}
