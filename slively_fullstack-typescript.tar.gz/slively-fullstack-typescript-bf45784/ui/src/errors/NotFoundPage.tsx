import * as React from 'react';

export class NotFoundPage extends React.Component<{}, {}> {
	render() {
		return <h1>Oh nooooooooooo</h1>;
	}
}
