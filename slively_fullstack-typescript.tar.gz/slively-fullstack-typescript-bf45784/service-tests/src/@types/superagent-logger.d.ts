declare module 'superagent-logger' {
	import {Plugin} from 'superagent';

	const superlogger: Plugin;

	export = superlogger;
}
