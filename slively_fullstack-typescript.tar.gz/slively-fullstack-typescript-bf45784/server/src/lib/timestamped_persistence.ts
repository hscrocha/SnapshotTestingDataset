export interface TimestampedPersistence {
	createdAt: Date;
	updatedAt: Date;
}
