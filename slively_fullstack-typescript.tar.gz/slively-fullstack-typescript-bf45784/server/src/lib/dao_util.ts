export const isSuccessfullyDeleted = (numRows: number) => numRows > 0;
