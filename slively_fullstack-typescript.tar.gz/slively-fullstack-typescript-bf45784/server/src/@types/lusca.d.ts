declare module 'lusca' {
	export const xframe: Function;
	export const xssProtection: Function;
}
