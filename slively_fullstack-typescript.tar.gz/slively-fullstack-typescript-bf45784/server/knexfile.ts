import { getConfig } from './src/config';

module.exports = getConfig().database;
