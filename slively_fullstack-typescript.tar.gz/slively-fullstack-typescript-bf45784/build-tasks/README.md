# Build Source

This folder is a collection of scripts used by the root [package.json](../package.json) to run more complicated build tasks.