module.exports = async () => {
  process.env.TZ = 'UTC';
};
