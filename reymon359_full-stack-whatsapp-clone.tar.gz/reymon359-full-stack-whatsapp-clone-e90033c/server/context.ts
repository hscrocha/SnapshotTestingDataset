import { ModuleContext } from '@graphql-modules/core';

export type MyContext = ModuleContext;
