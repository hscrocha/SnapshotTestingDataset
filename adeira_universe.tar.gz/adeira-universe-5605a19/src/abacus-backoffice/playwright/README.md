```
yarn workspace @adeira/abacus-backoffice playwright test
```
