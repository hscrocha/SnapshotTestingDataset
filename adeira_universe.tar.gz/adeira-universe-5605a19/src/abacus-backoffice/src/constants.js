// @flow strict

export default {
  graphqlServerURL: 'https://abacus.kochka.com.mx/graphql',
  googleClientID: '586578400209-5k61strd7i03b7pr2arn38o9qqghgfeq.apps.googleusercontent.com',
};
