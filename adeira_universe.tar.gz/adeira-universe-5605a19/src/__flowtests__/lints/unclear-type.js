// @flow strict

// $FlowExpectedError[unclear-type]
export const x: any = 42;
