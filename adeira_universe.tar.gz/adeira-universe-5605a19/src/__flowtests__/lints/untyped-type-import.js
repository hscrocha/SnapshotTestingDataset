// @flow strict

/* eslint-disable no-unused-vars */

// $FlowExpectedError[untyped-type-import]
import type { XYZ } from './__untypedFile';
