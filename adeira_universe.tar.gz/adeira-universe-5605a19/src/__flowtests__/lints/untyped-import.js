// @flow strict

/* eslint-disable no-unused-vars */

// $FlowExpectedError[untyped-import]
import { XYZ } from './__untypedFile';
