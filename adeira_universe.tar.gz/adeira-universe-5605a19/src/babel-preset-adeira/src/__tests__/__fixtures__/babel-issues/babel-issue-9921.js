#!/usr/bin/env node

// @flow strict-local

// See: https://github.com/babel/babel/issues/9921

/* eslint-disable */

new Set<() => void>([]);
