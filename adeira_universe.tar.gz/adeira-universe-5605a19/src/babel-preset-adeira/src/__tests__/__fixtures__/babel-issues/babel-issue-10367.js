// @flow strict

// https://github.com/babel/babel/issues/10367
// https://github.com/babel/babel/pull/10447

const re = /(?<x>.*)/u; // eslint-disable-line no-unused-vars
