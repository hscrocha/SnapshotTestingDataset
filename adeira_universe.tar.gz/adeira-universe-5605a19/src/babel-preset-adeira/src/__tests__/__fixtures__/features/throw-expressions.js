/* eslint-disable */

() => throw new Error('');
