// @flow strict

/* eslint-disable */

const x: number = (1 ** 2) ** (3 ** 4);

console.warn(x);
