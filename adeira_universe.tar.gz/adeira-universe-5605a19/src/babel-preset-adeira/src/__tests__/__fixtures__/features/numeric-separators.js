// @flow strict

/* eslint-disable */

const budget = 1_000_000_000_000;
const nibbles = 0b1010_0001_1000_0101;
const message = 0xa0_b0_c0;
