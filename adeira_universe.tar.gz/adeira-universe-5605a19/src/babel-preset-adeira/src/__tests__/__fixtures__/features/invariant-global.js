/* eslint-disable */

invariant(Math.random(), 'This should stay AS IS!');
