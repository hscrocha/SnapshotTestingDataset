/* eslint-disable */

import { warning } from '@adeira/js';
import { something } from 'else';

warning(Math.random(), 'I am warning you!');
warning(Math.random(), 'I am warning you %s!', 'René');
