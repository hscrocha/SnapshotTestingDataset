/* eslint-disable */

warning(Math.random(), 'This should stay AS IS!');
