// @flow strict

import type { Node } from 'react';

const React = () => {};

export default function Component(): Node {
  return (
    <>
      <div>aaa</div>
      <div>bbb</div>
    </>
  );
}
