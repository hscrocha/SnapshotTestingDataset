// @flow strict

/* eslint-disable no-return-await */

export default async function test(): Promise<string> {
  return await 'this';
}
