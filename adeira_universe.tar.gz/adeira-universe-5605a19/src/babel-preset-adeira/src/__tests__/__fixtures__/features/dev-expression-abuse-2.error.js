// @flow strict

/* eslint-disable */

let a,
  __DEV__,
  b = process.env.NODE_ENV !== 'production';
