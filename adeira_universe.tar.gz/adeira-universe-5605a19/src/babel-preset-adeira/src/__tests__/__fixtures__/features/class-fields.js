// @flow strict

export default class ClassFields {
  publicField: number = 1;
  #privateField: number = 2;
}
