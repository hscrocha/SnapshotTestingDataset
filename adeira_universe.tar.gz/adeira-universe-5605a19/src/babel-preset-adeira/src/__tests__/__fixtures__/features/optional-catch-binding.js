// @flow strict

try {
  // ...
} catch {
  // ...
}
