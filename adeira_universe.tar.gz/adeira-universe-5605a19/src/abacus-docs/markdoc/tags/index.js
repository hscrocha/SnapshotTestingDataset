// @flow

// $FlowFixMe[cannot-resolve-module]
export { comment } from '@markdoc/next.js/tags'; // eslint-disable-line import/no-unresolved
