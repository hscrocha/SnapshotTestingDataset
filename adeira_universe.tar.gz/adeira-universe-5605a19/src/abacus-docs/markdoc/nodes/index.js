// @flow

export { default as heading } from './heading.markdoc';
export { default as link } from './link.markdoc';
