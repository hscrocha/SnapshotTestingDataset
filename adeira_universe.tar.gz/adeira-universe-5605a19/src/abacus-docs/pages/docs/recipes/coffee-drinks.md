---
title: Coffee drinks
---

# {% $markdoc.frontmatter.title %}

Check out menu at: https://kochka.com.mx/en-us/menu

## Espresso

1. 16.5g of grounded coffee.
2. Time of extraction somewhere between 24 and 30 seconds.
3. We aim for 33g of liquid espresso (double grams of the grounded coffee).
4. Accompany by little spoon, mineral water and 2 chocolate paws.

![Espresso](/images/docs/recipes/coffee-drinks/espresso-crunch.png)

### Ristretto / espresso corto

tktk

## Espresso Americano

tktk

## Espresso Americano Nitro

tktk

## Espresso Tonic

tktk

## Flat White

tktk

## Cappuccino

tktk

## Caffe Latte

tktk

## Iced Caffe Latte

tktk
