---
title: Welcome to KOCHKA Café!
---

# {% $markdoc.frontmatter.title %}

_Tonalá 346, Roma Sur, Cuauhtémoc, 06760 Ciudad de México, CDMX_

This is where we store and share all our internal information. It's officially intended only for internal uses, however, anyone can publicly access and read it (we are trying to be open about what we do).

## Important links

- [kochka.com.mx](https://kochka.com.mx/)
- [Abacus: internal system](https://business.kochka.com.mx/) - this is where our POS is

Our active online presence (please follow 😉):

- [Instagram](https://www.instagram.com/kochkacafe/)
- [Facebook](https://www.facebook.com/kochkacafe/)
- [Google Maps](https://goo.gl/maps/NEB6oUbtBDSYideP8)
- [TikTok](https://www.tiktok.com/@kochkacafe)

## Onboarding

Are you a new member of our team? Awesome! There are some important steps that needs to be fulfilled as soon as possible:

1. make sure you were invited to our Telegram channels (there are 2)
1. make sure you got access to our internal system Abacus
