---
title: Cleaning in KOCHKA Café
---

# {% $markdoc.frontmatter.title %}

Cleaning is an essential part of what we do in KOCHKA Café. Generally speaking, people have quite low expectation about the quality of service and cleanliness when it comes to cat cafés. We are trying to change it. We are constantly maintaining the premises and keeping the workspaces clean.

## Toilet cleaning

tktk (make sure there is always extra toilet paper and soap)
