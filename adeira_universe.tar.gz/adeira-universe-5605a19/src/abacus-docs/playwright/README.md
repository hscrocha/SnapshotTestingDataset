```
yarn workspace @adeira/abacus-docs playwright test
```
