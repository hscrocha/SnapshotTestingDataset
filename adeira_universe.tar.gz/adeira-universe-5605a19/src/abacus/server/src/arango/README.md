This is a fork of unmaintained https://github.com/fMeow/arangors

In this first phase, the whole code (excluding integration tests) was basically copy-pasted. Later on the goal is to modify this project for our needs and remove unnecessary features.
