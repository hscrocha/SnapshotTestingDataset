// @flow

import * as React from 'react';

import ShopLayout from '../src/shop/ShopLayout';

export default function Shop(): React.Node {
  return <ShopLayout />;
}
