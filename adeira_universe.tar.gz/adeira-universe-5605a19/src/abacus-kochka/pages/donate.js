// @flow

import * as React from 'react';

import Donations from '../src/donations/Donations';

export default function DonatePage(): React.Node {
  return <Donations />;
}
