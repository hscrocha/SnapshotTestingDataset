// @flow

import * as React from 'react';

import Homepage from '../src/Homepage';

export default function IndexPage(): React.Node {
  return <Homepage />;
}
