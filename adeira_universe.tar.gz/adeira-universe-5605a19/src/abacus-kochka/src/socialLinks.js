// @flow strict

export default {
  facebookURL: 'https://www.facebook.com/kochkacafe',
  instagramURL: 'https://www.instagram.com/kochkacafe/',
  gitHubURL: 'https://github.com/adeira/universe/',
};
