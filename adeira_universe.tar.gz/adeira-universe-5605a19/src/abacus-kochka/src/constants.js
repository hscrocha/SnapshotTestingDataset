// @flow strict

export default {
  graphqlServerURL: 'https://abacus.kochka.com.mx/graphql',
};
