Design system used by **kochka.com.mx** which one main goal: accessibility

Powered by [@adeira/sx](https://www.npmjs.com/package/@adeira/sx) (atomic CSS-in-JS)

This directory is slowly being offloaded to [@adeira/sx-design](https://www.npmjs.com/package/@adeira/sx-design)
