# The Idea

Raw SVG -> SVGO (https://github.com/svg/svgo, online: https://jakearchibald.github.io/svgomg/) -> JSX (https://github.com/balajmarius/svg2jsx, online: https://svg2jsx.com/)
