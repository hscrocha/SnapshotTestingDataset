// @flow

import * as React from 'react';
import { graphql, useLazyLoadQuery } from '@adeira/relay';
import { ProductCard, Note, LayoutGrid, SupportedCurrencies } from '@adeira/sx-design';
import { fbt } from 'fbt';

import useViewerContext from '../hooks/useViewerContext';
import Link from '../primitives/Link';

export default function ShopLayoutContent(): React.Node {
  const viewerContext = useViewerContext();

  const {
    commerce: { products },
    // eslint-disable-next-line relay/generated-flow-types -- https://github.com/relayjs/eslint-plugin-relay/issues/131
  } = useLazyLoadQuery(
    graphql`
      query ShopLayoutContentQuery(
        $clientLocale: SupportedLocale!
        $priceSortDirection: PriceSortDirection!
      ) {
        commerce {
          products: searchAllPublishedProducts(
            clientLocale: $clientLocale
            priceSortDirection: $priceSortDirection
            visibility: ESHOP
          ) {
            key
            name
            price {
              unitAmount
              unitAmountCurrency
            }
            imageCover {
              blurhash
              url
            }
          }
        }
      }
    `,
    {
      clientLocale: viewerContext.languageTag.graphql,
      priceSortDirection: 'HIGH_TO_LOW',
    },
    { fetchPolicy: 'store-and-network' },
  );

  if (products.length === 0) {
    return (
      <Note tint="warning">
        <fbt desc="empty shop message">There are no products yet.</fbt>
      </Note>
    );
  }

  return (
    <LayoutGrid minColumnWidth="200px">
      {products.map((product) => {
        if (product == null) {
          return null;
        }

        const unitAmountCurrency = SupportedCurrencies.cast(product.price.unitAmountCurrency);
        if (unitAmountCurrency == null) {
          return null;
        }

        return (
          <Link key={product.key} href={`/shop/${product.key}`}>
            <ProductCard
              priceUnitAmount={
                product.price.unitAmount / 100 // adjusted for centavo
              }
              priceUnitAmountCurrency={unitAmountCurrency}
              title={product.name}
              imgBlurhash={product.imageCover?.blurhash}
              imgSrc={product.imageCover?.url}
              imgAlt={product.name}
            />
          </Link>
        );
      })}
    </LayoutGrid>
  );
}
