See: https://martinfowler.com/bliki/PageObject.html
