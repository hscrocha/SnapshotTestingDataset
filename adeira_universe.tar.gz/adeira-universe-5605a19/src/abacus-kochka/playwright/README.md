```
yarn workspace @adeira/abacus-kochka playwright test
```
