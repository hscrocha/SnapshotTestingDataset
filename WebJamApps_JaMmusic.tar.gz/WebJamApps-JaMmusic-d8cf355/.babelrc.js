module.exports = {
    presets: ["@babel/preset-react", "@babel/preset-env", "react-hot-loader/babel"]
  }
