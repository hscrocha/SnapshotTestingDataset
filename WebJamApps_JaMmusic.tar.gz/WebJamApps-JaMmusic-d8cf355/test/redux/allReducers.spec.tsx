import reducer from 'src/redux/allReducers';

describe('allReducers', () => {
  it('is defined', () => {
    expect(reducer).toBeDefined();
  });
});
