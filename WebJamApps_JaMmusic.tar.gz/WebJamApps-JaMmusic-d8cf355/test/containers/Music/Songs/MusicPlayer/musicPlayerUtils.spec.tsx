/* eslint-disable @typescript-eslint/no-explicit-any */
import musicPlayerUtils from 'src/containers/Songs/MusicPlayer/musicPlayerUtils';

describe('musicPlayerUtils', () => {
  // const params:any = {
  //   get: (item: string) => {
  //     if (item === 'oneplayer') return true;
  //     return '123' || '456';
  //   },
  // };
  // const view:any = {
  //   musicUtils: { setIndex: () => [{}] },
  //   setState: (obj: any) => { if (obj) return true; return false; },
  //   props: { songs: [{ _id: '123', category: 'pub' }] },
  //   state: {
  //     songsState: [{}],
  //     player: { onePlayerMode: true, isShuffleOn: true },
  //     pageTitle: '',
  //     missionState: 'on',
  //     pubState: 'off',
  //     originalState: 'on',
  //   },
  // };
  // it('checks for one player then sets the song when pub', async () => {
  //   const player: any = { onePlayerMode: false };
  //   const result = await musicPlayerUtils.checkOnePlayer(params, player, view);
  //   expect(result).toBe(true);
  // });
  // it('handles one player when mission', async () => {
  //   view.props.songs = [{ _id: '123', category: 'mission' }, { _id: '456', category: 'pub' }];
  //   const player: any = { onePlayerMode: false };
  //   const result = await musicPlayerUtils.checkOnePlayer(params, player, view);
  //   expect(result).toBe(true);
  // });
  // it('handles one player when original', async () => {
  //   view.props.songs = [{ _id: '123', category: 'original' }, { _id: '456', category: 'pub' }];
  //   const player: any = { onePlayerMode: false };
  //   const result = await musicPlayerUtils.checkOnePlayer(params, player, view);
  //   expect(result).toBe(true);
  // });
  // it('handles one player when song id does not match', async () => {
  //   view.props.songs = [{ _id: '999', category: 'original' }, { _id: '888', category: 'pub' }, { _id: '777', category: 'mission' }];
  //   const player: any = { onePlayerMode: false };
  //   const result = await musicPlayerUtils.checkOnePlayer(params, player, view);
  //   expect(result).toBe(true);
  // });
  it('makes one player', () => {
    const result = musicPlayerUtils.makeOnePlayerMode();
    expect(result).toBe(true);
  });
  it('makes one player and adjusts height for smaller devices', () => {
    Object.defineProperty(window, 'outerWidth', { writable: true, configurable: true, value: 500 });
    const result = musicPlayerUtils.makeOnePlayerMode();
    expect(result).toBe(true);
  });

  it('checks for null styles', () => {
    document.body.innerHTML = '';
    Object.defineProperty(window, 'outerWidth', { writable: true, configurable: true, value: 400 });
    const result = musicPlayerUtils.makeOnePlayerMode();
    expect(result).toBe(true);
  });

  // it('runs one player mode if it exists', () => {
  //   Object.defineProperty(window, 'outerWidth', { writable: true, configurable: true, value: 800 });
  //   const result = musicPlayerUtils.runIfOnePlayer(view);
  //   expect(result).toBe(true);
  // });
  it('does nothing to the mission and pub buttons when they do not exist', () => {
    document.body.innerHTML = '';
    const result = musicPlayerUtils.showHideButtons('none');
    expect(result).toBe(true);
  });
  // it('reshuffled the songs if shuffle is on and type is deselected', () => {
  //   view.setState = jest.fn(() => true);
  //   view.state.player.isShuffleOn = true;
  //   view.state.missionState = 'on';
  //   view.state.originalState = 'on';
  //   const r = musicPlayerUtils.toggleSongTypes('mission', view);
  //   expect(r).toBe(true);
  // });
  // it('does not toggle the original button', () => {
  //   view.state.missionState = 'off';
  //   view.state.originalState = 'on';
  //   const r = musicPlayerUtils.toggleSongTypes('original', view);
  //   expect(r).toBe(false);
  // });
  // it('runs toggle song types with no songs', () => {
  //   view.state.missionState = 'on';
  //   view.state.originalState = 'on';
  //   view.props.songs = null;
  //   const r = musicPlayerUtils.toggleSongTypes('original', view);
  //   expect(r).toBe(true);
  // });
  // it('runs toggleOn with no songs', () => {
  //   view.state.missionState = 'off';
  //   view.state.originalState = 'on';
  //   view.props.songs = null;
  //   const r = musicPlayerUtils.toggleOn('', view, '', '');
  //   expect(r).toBe(true);
  // });
  // it('handles click on prev button', () => {
  //   view.setState = jest.fn();
  //   view.state.index = 0;
  //   view.state.songsState = [{}, {}, {}, {}];
  //   musicPlayerUtils.prev(view);
  //   expect(view.setState).toHaveBeenCalled();
  // });
  // it('toggleOn when !player.isShuffleOn', () => {
  //   view.state.player.isShuffleOn = false;
  //   expect(musicPlayerUtils.toggleOn('mission', view, '', '')).toBe(true);
  // });
});
