export const useGoogleLogin = () => () => { };

export const googleLogout = () => {};

export function GoogleOAuthProvider() {
  return <div />;
}
