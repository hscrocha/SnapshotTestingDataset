interface JSOG {
  encode:(arg0: unknown) => unknown;
  decode:(arg0: unknown) => unknown;
}
export const jsog:JSOG;
export default jsog;
