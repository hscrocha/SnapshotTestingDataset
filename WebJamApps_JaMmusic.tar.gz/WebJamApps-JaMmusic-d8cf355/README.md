# JaMmusic

[![CircleCI](https://circleci.com/gh/WebJamApps/JaMmusic.svg?style=svg)](https://circleci.com/gh/WebJamApps/JaMmusic)
[![tested with jest](https://img.shields.io/badge/tested_with-jest-99424f.svg)](https://github.com/facebook/jest) 
[![Test Coverage](https://api.codeclimate.com/v1/badges/39beb7a5a056ba4cee15/test_coverage)](https://codeclimate.com/github/WebJamApps/JaMmusic/test_coverage)
[![Issue Count](https://codeclimate.com/github/WebJamApps/JaMmusic/badges/issue_count.svg)](https://codeclimate.com/github/WebJamApps/JaMmusic/issues)
[![Maintainability](https://api.codeclimate.com/v1/badges/39beb7a5a056ba4cee15/maintainability)](https://codeclimate.com/github/WebJamApps/JaMmusic/maintainability)
[![Known Vulnerabilities](https://snyk.io/test/github/WebJamApps/JaMmusic/badge.svg)](https://snyk.io/test/github/WebJamApps/JaMmusic)
<br>
<br>
<a href="http://joshandmariamusic.com" target="_blank">joshandmariamusic.com</a>
