export { default } from "./PostDetailPage";
