export { default } from "./IndexPage";
