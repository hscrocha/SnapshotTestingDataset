export { default } from "./PrivacyPolicyPage";
