export { default } from "./NewPostPage";
