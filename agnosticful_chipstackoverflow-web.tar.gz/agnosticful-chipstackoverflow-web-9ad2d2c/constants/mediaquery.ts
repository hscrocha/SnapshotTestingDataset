export const MOBILE_MEDIA = "@media screen and (max-width: 414px)";
