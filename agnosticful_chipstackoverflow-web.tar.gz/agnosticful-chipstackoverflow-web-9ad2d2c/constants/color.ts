export const CARD_BACKGROUND = "#f7fbff";
export const CARD_DARK_BACKGROUND = "#1e272e";
export const SPADE_COLOR = "#576574";
export const INVERSE_SPADE_COLOR = "#F1F5F8";
export const HEART_COLOR = "#ff6b6b";
export const DIAMOND_COLOR = "#54a0ff";
export const CLUB_COLOR = "#1dd1a1";
