export const NUMBER_OF_POSTS_IN_INDEX = 6;
