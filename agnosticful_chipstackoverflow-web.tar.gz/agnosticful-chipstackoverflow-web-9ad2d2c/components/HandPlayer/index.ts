export { default } from "./HandPlayer";
