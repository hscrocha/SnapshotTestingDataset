export { default } from "./Avatar";
