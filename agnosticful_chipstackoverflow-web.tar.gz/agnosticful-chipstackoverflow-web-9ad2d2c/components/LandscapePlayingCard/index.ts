export { default } from "./LandscapePlayingCard";
