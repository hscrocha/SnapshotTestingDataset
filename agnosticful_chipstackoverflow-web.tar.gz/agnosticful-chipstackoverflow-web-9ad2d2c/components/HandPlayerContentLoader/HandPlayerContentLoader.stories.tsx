import * as React from "react";
import HandPlayerContentLoader from "@@/components/HandPlayerContentLoader";

export default {
  title: "HandPlayerContentLoader",
  component: HandPlayerContentLoader,
};

export const example = () => <HandPlayerContentLoader />;
