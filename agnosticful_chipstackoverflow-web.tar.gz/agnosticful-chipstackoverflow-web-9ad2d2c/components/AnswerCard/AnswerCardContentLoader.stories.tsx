import * as React from "react";
import { AnswerCardContentLoader } from "@@/components/AnswerCard";

export default {
  title: "AnswerCard/AnswerCardContentLoader",
  component: AnswerCardContentLoader,
};

export const example = () => <AnswerCardContentLoader />;
