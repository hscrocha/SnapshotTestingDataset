export { default } from "./PortraitPlayingCard";
