/**
 * Represents playing card's suit.
 */
enum Suit {
  spade,
  heart,
  diamond,
  club,
}

export default Suit;
