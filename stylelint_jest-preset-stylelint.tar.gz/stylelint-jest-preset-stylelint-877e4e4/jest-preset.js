'use strict';

module.exports = {
	setupFiles: [require.resolve('./jest-setup.js')],
	testEnvironment: 'node',
};
