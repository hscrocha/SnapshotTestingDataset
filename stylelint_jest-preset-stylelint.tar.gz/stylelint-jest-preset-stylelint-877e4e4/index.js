'use strict';

const getTestRule = require('./getTestRule');

module.exports = { getTestRule };
