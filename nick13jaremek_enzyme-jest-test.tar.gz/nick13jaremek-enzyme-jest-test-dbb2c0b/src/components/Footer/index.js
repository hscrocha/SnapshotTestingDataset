import React from 'react';

const Footer = () => {
  return (
    <div className="footer">
      <ul>
        <li>Contact</li>
        <li>About</li>
      </ul>
    </div>
  );
};

export default Footer;
