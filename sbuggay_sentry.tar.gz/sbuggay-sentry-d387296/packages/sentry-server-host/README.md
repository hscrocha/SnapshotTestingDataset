## sentry-server-host

This server hosts the client and persists client/data-server data.
