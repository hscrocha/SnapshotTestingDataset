export enum EStatus {
    outage,
    available,
    unknown,
    issue,
    maintenence
}
