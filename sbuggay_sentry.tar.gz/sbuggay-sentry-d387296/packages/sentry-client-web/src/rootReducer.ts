import reducer from "./reducer";

// This file exists as a future entry point for mulitple stores, currently this
// is not needed.

export default reducer;
