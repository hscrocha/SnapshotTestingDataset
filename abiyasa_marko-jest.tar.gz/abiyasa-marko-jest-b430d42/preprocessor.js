module.exports = require('./src/preprocessor');
