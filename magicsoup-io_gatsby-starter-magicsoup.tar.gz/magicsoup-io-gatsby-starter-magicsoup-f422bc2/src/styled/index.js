export { default as Section } from './blocks/Section'
export { default as Footer } from './blocks/Footer'

export { default as Menu } from './elements/Menu'
export { default as P } from './elements/P'
