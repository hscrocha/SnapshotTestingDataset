import { loadPlugin } from 'earljs/internals'

import { plugin } from './plugin'
export { plugin }

loadPlugin(plugin)
