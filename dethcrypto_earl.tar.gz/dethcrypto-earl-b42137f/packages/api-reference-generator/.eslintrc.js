module.exports = require('../../.eslintrc.js')
