// load example earljs plugin
import 'example-plugin'
