import { Redirect } from '@docusaurus/router'
import React from 'react'

const GettingStartedPage = () => <Redirect to="/" />

export default GettingStartedPage
