module.exports = require('../../.eslintrc')
