export function toLine(value: string): [number, string][] {
  return [[0, value]]
}
