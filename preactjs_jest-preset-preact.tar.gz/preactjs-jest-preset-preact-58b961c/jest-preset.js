// This file must be at the root of the package to be able to be used in jest.
// See https://jestjs.io/docs/en/configuration#preset-string
module.exports = require('./src/preset');
