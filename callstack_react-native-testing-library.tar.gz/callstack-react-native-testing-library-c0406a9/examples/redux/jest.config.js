module.exports = {
  preset: '@testing-library/react-native',
  setupFiles: ['./jest-setup.js'],
};
