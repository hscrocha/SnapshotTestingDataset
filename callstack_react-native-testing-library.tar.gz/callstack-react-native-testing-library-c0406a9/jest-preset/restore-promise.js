global.Promise = global.RNTL_ORIGINAL_PROMISE;
