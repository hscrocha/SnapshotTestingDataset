global.RNTL_ORIGINAL_PROMISE = Promise;
