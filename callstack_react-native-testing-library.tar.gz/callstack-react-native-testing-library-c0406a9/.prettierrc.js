// added for Jest inline snapshots to not use default Prettier config
module.exports = {
  singleQuote: true,
  trailingComma: "es5"
}
