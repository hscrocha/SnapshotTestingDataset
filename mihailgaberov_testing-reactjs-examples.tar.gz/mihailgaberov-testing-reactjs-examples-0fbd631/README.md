# UI (React) Unit Testing
"What should we test in our React components" - working examples. 

You can view the [presentation here](http://mihailgaberov.github.io/testing-reactjs-presentation) and the demo app [here](http://mihailgaberov.github.io/testing-reactjs-presentation-examples).

![Screenshot](https://github.com/mihailgaberov/testing-reactjs-examples/blob/master/hp.jpg)
