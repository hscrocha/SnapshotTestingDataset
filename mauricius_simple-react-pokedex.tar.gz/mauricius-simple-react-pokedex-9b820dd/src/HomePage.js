import React from 'react'

const HomePage = (props) => (
  <div>
    <h1>Welcome to The Pokédex</h1>
    <div className="text-xl text-grey-dark mt-4">Explore Pokémons.</div>
  </div>
)

export default HomePage