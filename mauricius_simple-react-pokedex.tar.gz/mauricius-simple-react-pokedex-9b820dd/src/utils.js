/**
 * Capitalize a string
 * @param  string str
 * @return string
 */
module.exports.capitalize = (str) => str.charAt(0).toUpperCase() + str.slice(1)