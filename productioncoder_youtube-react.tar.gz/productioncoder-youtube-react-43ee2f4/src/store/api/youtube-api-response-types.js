export const VIDEO_LIST_RESPONSE = 'youtube#videoListResponse';
export const CHANNEL_LIST_RESPONSE = 'youtube#channelListResponse';
export const SEARCH_LIST_RESPONSE = 'youtube#searchListResponse';
export const COMMENT_THREAD_LIST_RESPONSE = 'youtube#commentThreadListResponse';