# Scripts

Contains scripts used by [`package.json`](../package.json).

## TypeScript support

TypeScript files can be read and executed by [`ts-node`](https://github.com/TypeStrong/ts-node):
```json
{
  "scripts": {
    "scriptName": "ts-node scripts/scriptName.ts",
  }
}
```
