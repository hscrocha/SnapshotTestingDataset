# Pages

This directory contains your application views and routes.

The framework reads all the `index.tsx` files inside a directory and creates the router of your application.

More information about the usage of this directory in [the documentation](https://nuxtjs.org/guide/routing).

# Index page

This directory contains the [index file](./index.tsx) and [tests](./index.spec.ts) for making sure it renders correctly.
