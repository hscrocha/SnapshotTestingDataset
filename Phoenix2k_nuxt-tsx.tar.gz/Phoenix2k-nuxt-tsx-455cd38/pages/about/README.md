# About page

Contains the [component file](./index.tsx) and [tests](./index.spec.ts) for making sure it renders correctly.
