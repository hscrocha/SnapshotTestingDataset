# Logo

Contains [component file](./Logo.tsx) and [tests](./Logo.spec.ts) for making sure it renders correctly.

Associated styles can be found in [`Logo.scss`](./Logo.scss).
