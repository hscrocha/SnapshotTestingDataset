---
home: true
heroImage: /logo.svg
actionText: Get Started →
actionLink: /en/home/
footer: MIT Licensed
