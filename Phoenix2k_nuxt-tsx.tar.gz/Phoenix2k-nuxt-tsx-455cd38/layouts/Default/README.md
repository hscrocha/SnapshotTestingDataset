# Default layout

Contains [component file](./Default.tsx) and [tests](./Default.spec.ts) for making sure it renders correctly.

Associated styles can be found in [`Default.scss`](./Default.scss).
