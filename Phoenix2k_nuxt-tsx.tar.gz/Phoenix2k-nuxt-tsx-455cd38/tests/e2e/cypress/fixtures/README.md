# Fixtures

For detailed explanation on how things work, check out [Fixtures](https://docs.cypress.io/guides/guides/network-requests.html#Fixtures) on [Cypress.io](https://docs.cypress.io/).
