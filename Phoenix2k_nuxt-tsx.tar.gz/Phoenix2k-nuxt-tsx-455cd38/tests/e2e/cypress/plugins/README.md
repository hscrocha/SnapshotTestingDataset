# Plugins

For detailed explanation on how things work, check out [Plugins](https://docs.cypress.io/guides/tooling/plugins-guide.html) on [Cypress.io](https://docs.cypress.io/).
