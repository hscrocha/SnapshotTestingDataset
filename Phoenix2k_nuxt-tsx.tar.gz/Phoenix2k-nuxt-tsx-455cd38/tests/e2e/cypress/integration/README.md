# Integration tests

For detailed explanation on how things work, check out the tutorial on [writing your first test](https://docs.cypress.io/guides/getting-started/writing-your-first-test.html) on [Cypress.io](https://docs.cypress.io/).
