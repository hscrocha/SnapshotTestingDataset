# Support file

For detailed explanation on how things work, check out [Support file](https://docs.cypress.io/guides/core-concepts/writing-and-organizing-tests.html#Support-file) on [Cypress.io](https://docs.cypress.io/).
