# Custom commands

For detailed explanation on how things work, check out [Custom Commands](https://docs.cypress.io/api/cypress-api/custom-commands.html) on [Cypress.io](https://docs.cypress.io/).
