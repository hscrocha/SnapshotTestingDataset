# Cypress

This directory contains [fixtures](./fixtures), [integration tests](./integration), [Cypress plugins](./plugins), [screenshots](./screenshots), [support tools](./suppport) and [videos](./videos) generated after a successful run in a local development environment.

For detailed explanation on how things work, check out [Cypress.io](https://www.cypress.io/).
