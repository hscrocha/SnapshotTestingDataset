# End to end tests

This directory contains tests and setup files for [Cypress](./cypress).
