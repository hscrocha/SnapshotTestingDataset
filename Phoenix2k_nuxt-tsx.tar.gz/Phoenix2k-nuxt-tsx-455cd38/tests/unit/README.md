# Unit tests

This folder contains setup files for [Jest](./jest).
