# Jest

For detailed explanation on how things work, check out [Jest.io](https://jestjs.io/).
