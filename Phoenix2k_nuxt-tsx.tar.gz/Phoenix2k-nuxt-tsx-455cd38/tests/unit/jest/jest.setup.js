/**
 * Jest setup
 * @link https://jestjs.io/docs/en/configuration.html#setupfiles-array
 */
require('jsdom-global')();
