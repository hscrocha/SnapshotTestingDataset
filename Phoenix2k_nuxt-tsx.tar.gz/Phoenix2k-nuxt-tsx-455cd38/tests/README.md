# Tests

This folder contains [end-to-end tests](./e2e) and setup files for [unit tests](./unit).

You can find the latest coverage report in the [coverage folder](./coverage) after successfully running all tests.
