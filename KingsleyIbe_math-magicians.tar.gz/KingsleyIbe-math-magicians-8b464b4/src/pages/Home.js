import React from 'react';

const Home = () => (
  <section className="home-section">
    <div>
      <h2 className="home">Welcome to our page!</h2>
      <p>
        Lorem ipsum dolor sit amet, consectetur adipiscing elit. Cras gravida,
        risus at dapibus aliquet, elit quam scelerisque tortor, nec accumsan eros
        nulla interdum justo. Pellentesque dignissim, sapien et congue rutrum,
        lorem tortor dapibus turpis, sit amet vestibulum eros mi et odio.
        Lorem ipsum dolor sit amet, consectetur adipiscing elit. Cras gravida,
        risus at dapibus aliquet, elit quam scelerisque tortor, nec accumsan eros
        nulla interdum justo. Pellentesque dignissim, sapien et congue rutrum,
        lorem tortor dapibus turpis, sit amet vestibulum eros mi et odio.
      </p>
      <p>
        Lorem ipsum dolor sit amet, consectetur adipiscing elit. Cras gravida,
        risus at dapibus aliquet, elit quam scelerisque tortor, nec accumsan eros
        nulla interdum justo. Pellentesque dignissim, sapien et congue rutrum,
        lorem tortor dapibus turpis, sit amet vestibulum eros mi et odio.
        Lorem ipsum dolor sit amet, consectetur adipiscing elit. Cras gravida,
        risus at dapibus aliquet, elit quam scelerisque tortor, nec accumsan eros
        nulla interdum justo. Pellentesque dignissim, sapien et congue rutrum,
        lorem tortor dapibus turpis, sit amet vestibulum eros mi et odio.
      </p>
    </div>
  </section>
);

export default Home;
