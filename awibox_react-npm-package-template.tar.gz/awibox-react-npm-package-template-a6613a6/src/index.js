import YourComponentName from './components/YourComponentName';

export default YourComponentName;
