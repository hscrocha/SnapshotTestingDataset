export default function getRandomOffset() {
  return Math.floor(Math.random() * 2000)
}
