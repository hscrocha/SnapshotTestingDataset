One preview of an artist:

```jsx
<ArtistPreview
  artist="Unprocessed"
  songTitle="Real"
  id="a"
  image="https://i.scdn.co/image/ab67616d0000b273251b8f4c6183988f5060b6eb"
  songUrl="https://testurl.com"
  updateTrack={() => {}}
  stopPlayingSong={() => {}}
  togglePlayingSong={() => {}}
  toggleCurrentSongId={() => {}}
  isSongPlaying={false}
  currentSongId="a"
  saveSong={() => {}}
  savedSongs={[]}
/>
```
