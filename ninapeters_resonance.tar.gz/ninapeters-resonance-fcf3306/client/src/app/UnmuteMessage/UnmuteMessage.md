Unmute message:

```jsx
<UnmuteMessage onClick={() => {}} isShown={true} />
```
