Header with headline

```jsx
<Header>Favorites</Header>
```
