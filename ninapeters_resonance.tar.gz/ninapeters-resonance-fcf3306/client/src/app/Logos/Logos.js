import { ReactComponent as Logo } from './assets/resonance.svg'
import { ReactComponent as Spotify } from './assets/spotify.svg'

export { Logo, Spotify }
