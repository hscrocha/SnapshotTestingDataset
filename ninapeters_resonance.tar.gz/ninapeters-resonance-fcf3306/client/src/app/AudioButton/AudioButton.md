Audio Button: Play

```jsx
<AudioButton onClick={() => {}} isSongPlaying={false} />
```

Audio Button: Pause

```jsx
<AudioButton onClick={() => {}} isSongPlaying={true} />
```
