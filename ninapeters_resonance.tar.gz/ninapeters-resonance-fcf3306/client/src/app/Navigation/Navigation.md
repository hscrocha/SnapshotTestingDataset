Navigation

```jsx
<Navigation onClick={() => {}}>all songs</Navigation>
```
