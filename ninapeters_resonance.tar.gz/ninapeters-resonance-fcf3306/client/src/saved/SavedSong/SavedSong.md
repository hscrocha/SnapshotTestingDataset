One saved song:

```jsx
<SavedSong
  stopPlayingSongById={() => {}}
  artist="Unprocessed"
  songTitle="Real"
  id="a"
  deleteSavedSong={() => {}}
  toggleCurrentSongId={() => {}}
  isSongPlaying={false}
  currentSongId="a"
/>
```
