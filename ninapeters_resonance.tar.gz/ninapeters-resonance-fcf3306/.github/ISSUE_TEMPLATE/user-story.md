---
name: User Story
about: A default user story
title: '(Short name)'
labels: ''
assignees: ''
---

## Value statement - a requirement, not a solution

As a **(role)**
I need **(an action)**
so that **(a benefit)**

## Description

## Acceptance criteria

- [ ]

## Tasks

- [ ]

## Size
