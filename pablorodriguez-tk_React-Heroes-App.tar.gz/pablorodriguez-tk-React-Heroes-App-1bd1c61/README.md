# React Heroes App

## Introduction
This is a React App that show a list of Heroes

When you click on a Hero, it shows a screen where there are more details.

You also can do a search of heroes

Use, Context and Bootstrap, 

## [Live Site](https://gallant-aryabhata-89d350.netlify.app)

![React Heroes](https://res.cloudinary.com/drcq2kx3u/image/upload/v1620172014/GitHub/React-Heroes-App/React-Heroes-App_ajxzlk.jpg)

